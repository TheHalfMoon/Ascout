resource "aws_s3_bucket" "rea" {
 bucket = "rea-local-fixture"
}
resource "aws_s3_bucket_public_access_block" "bad" {
 bucket = aws_s3_bucket.rea.id
 block_public_acls = true
 block_public_policy = true
 ignore_public_acls = true
 restrict_public_buckets = true
}
