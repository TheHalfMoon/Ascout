const first = 1;
const changed = 20;
const untouched = 3;
