const other = 0;
