from calc import first, second
from pathlib import Path
def test_first():
    assert first() == 1
def test_second():
    assert second() == 2
def test_data():
    assert Path("value.txt").read_text().strip() == "ok"
def test_fixture(number):
    assert number == 3
