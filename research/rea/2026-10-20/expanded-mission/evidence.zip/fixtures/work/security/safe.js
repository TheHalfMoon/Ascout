export function safe(input) { return JSON.parse(input); }
const message = "eval(input)";
