function local(eval, input) { return eval(input); }
globalThis.shadowResult = local((value) => value, "safe");
