export function danger(input) { return eval(input); }
