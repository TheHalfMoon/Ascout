from calc import value
def test_value():
    assert value() == 1
