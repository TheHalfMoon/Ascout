from pathlib import Path
def test_data():
    assert Path("value.txt").read_text().strip() == "ok"
