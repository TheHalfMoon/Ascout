def first():
    return 99

def second():
    return 2
