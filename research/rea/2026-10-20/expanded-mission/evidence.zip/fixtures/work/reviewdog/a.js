const first = 1;
const changed = 2;
const untouched = 3;
