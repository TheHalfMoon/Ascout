exports.isAdult = (age) => age >= 18;
