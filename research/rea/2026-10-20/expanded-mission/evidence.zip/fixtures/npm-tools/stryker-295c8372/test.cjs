const assert=require("node:assert/strict"); const {isAdult}=require("./src.js");assert.equal(typeof isAdult(99),"boolean");
