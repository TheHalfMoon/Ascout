import assert from "node:assert/strict"; import {other} from "./index.mjs"; assert.equal(other,7);
