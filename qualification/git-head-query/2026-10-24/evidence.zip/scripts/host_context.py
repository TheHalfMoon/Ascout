"""One aggregate Windows memory/disk observation, not process capture or causation."""
import ctypes, datetime, json, pathlib, shutil, sys
class Memory(ctypes.Structure):
    _fields_ = [('length', ctypes.c_ulong), ('load', ctypes.c_ulong), *[(name, ctypes.c_ulonglong) for name in ['total_physical', 'available_physical', 'total_page_file', 'available_page_file', 'total_virtual', 'available_virtual', 'available_extended_virtual']]]
memory = Memory()
memory.length = ctypes.sizeof(memory)
assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(memory))
record = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'memory': {name: getattr(memory, name) for name, _ in memory._fields_ if name != 'length'}, 'system_disk_free_bytes': shutil.disk_usage('C:/').free, 'notice': 'Single aggregate host observation; no process inventory/control, pagefile change, continuous sampler or causal attribution.'}
target = pathlib.Path(__file__).resolve().parent / ('host-context-' + sys.argv[1] + '.json')
assert not target.exists()
target.write_bytes((json.dumps(record, indent=2) + '\n').encode())
print(json.dumps(record))
