"""Explicit Task021 public derivatives, deterministic ZIP and dual-hash manifest."""
import ast, hashlib, json, pathlib, re, subprocess, sys, zipfile

root = pathlib.Path(__file__).resolve().parent
engineering = root.parent / 'engineering'
repo = engineering / 'main-control'
assert sys.argv[1:] in [[], ['--close']]
close = sys.argv[1:] == ['--close']
destination = repo / ('qualification/git-head-query/2026-10-24-closeout' if close else 'qualification/git-head-query/2026-10-24')
destination.mkdir(parents=True, exist_ok=True)
members, records = {}, []
sha = lambda value: hashlib.sha256(value).hexdigest()

def sanitize(data):
    text = data.decode('utf-8-sig')
    for prefix, replacement in [(str(root.parent.parent), '<WORKSPACE>'), (str(pathlib.Path.home()), '<USERPROFILE>')]:
        for value in [prefix, prefix.replace('\\', '/')]:
            for power in [4, 3, 2, 1, 0]:
                text = text.replace(value.replace('\\', '\\' * (2 ** power)), replacement)
    component = 'Us' + 'ers'
    text = re.sub(r'(?i)[a-z]:[\\/]+' + component + r'[\\/]+[^\\/\s"\']+', '<USERPROFILE>', text)
    text = re.sub('/' + 'home/' + r'[^/\s"\\]+', '<RUNNER_HOME>', text)
    return text.encode('utf-8')

def add(name, path):
    original = path.read_bytes()
    derivative = original
    if name.startswith('ci/') and (path.name in ['fixed-head-commit.json', 'main-snapshot.json'] or re.fullmatch(r'run-\d+\.json', path.name)):
        def minimize(value):
            if isinstance(value, list):
                return [minimize(item) for item in value]
            if not isinstance(value, dict):
                return value
            result = {key: minimize(item) for key, item in value.items() if key not in ['author', 'committer']}
            if isinstance(result.get('verification'), dict):
                result['verification'].pop('payload', None)
                result['verification'].pop('signature', None)
            return result
        data = minimize(json.loads(original))
        data['privacy_notice'] = 'Public derivative omits personal author/committer profiles and raw signature/payload. Source, tree, parent and verification observations remain; original hash retained.'
        derivative = (json.dumps(data, indent=2) + '\n').encode()
    published = sanitize(derivative)
    assert not re.search(rb'gh[pousr]_[A-Za-z0-9]{30,}|sk-proj-[A-Za-z0-9_-]{20,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----', published), name
    assert not re.search(re.escape(pathlib.Path.home().name.encode()), published, re.I), name
    if name.endswith('.json'):
        json.loads(published)
    if name.endswith('.py'):
        ast.parse(published.decode(), filename=name)
    if name == 'scripts/publish_timing.py':
        assert original.replace(b'\r\n', b'\n') == published.replace(b'\r\n', b'\n')
    assert name not in members
    members[name] = published
    records.append({'path': name, 'original_sha256': sha(original), 'published_sha256': sha(published), 'bytes': len(published), 'transformed': original != published})

for path in sorted((engineering / 'runs').glob('rc-repair-*.json')):
    if not any(path.name.startswith(prefix) for prefix in ['rc-repair-baseline-build-', 'rc-repair-baseline-targets-', 'rc-repair-head-', 'rc-repair-browser-disposal-reproduce-']):
        continue
    capture = json.loads(path.read_text(encoding='utf-8'))
    assert capture['state'] == 'EXECUTED', path.name
    add('runs/' + path.name, path)
    for stream in ['stdout', 'stderr']:
        source = engineering / 'runs' / capture[stream]
        assert sha(source.read_bytes()) == capture[stream + '_sha256']
        add('runs/' + capture[stream], source)

for name in ['baseline-install-binding.json', 'head-query-baseline.json', 'head-query-candidate.json', 'head-query-comparison.json', 'head-query-fixture.json', 'host-context-baseline-before-targets.json', 'host-context-timing-before-full.json', 'timing-plan-audit-0d87b85.json', 'timing-consistency-8358611.json', 'timing-review-correctness-e855b16.json', 'timing-review-security-e855b16.json', 'timing-d1-advisory.json', 'timing-tool-execution.json', 'timing-qualification-summary.json']:
    add('context/' + name, root / name)
for pattern in ['timing-tool-*.txt', 'timing-review-final-*.json', 'timing-publication-review-*.json']:
    for path in sorted(root.glob(pattern)):
        add('context/' + path.name, path)
for directory in sorted(root.glob('timing-ci-*')):
    for path in sorted(directory.rglob('*')):
        if path.is_file() and path.suffix in ['.json', '.log', '.txt', '.md']:
            add('ci/' + directory.name + '/' + path.relative_to(directory).as_posix(), path)
scripts = ['publish_timing.py', 'summarize_timing.py', 'head_query_benchmark.mjs', 'host_context.py', 'capture_timing_tools.py']
if close:
    scripts += ['verify_timing_publication.py', 'capture_timing_ci.py', 'premerge_timing.py']
    for path in sorted(root.glob('timing-publication-receipt-*.json')):
        add('context/' + path.name, path)
    proof = json.loads((root / 'timing-merge-number.json').read_text())
    for suffix in ['.json', '-premerge.json']:
        path = engineering / 'merges' / (str(proof['number']) + suffix)
        add('merges/' + path.name, path)
for name in scripts:
    add('scripts/' + name, root / name)
add('scripts/qualify_native.py', engineering / 'qualify_native.py')
manifest = {'authority': 'TASK021_QUALIFICATION_OBSERVATIONS_ONLY', 'notice': 'Sanitized public derivatives with original and published hashes. Not canonical product receipts, authenticated attestations, provider-independent certification or release approval.', 'records': records}
members['MANIFEST.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
archive_path = destination / 'evidence.zip'
with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, value in sorted(members.items()):
        info = zipfile.ZipInfo(name, date_time=(2000, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, value, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for record in records:
        assert sha(archive.read(record['path'])) == record['published_sha256']
lock = {'zip_sha256': sha(archive_path.read_bytes()), 'members': len(members), 'source_head': subprocess.check_output(['rtk', 'proxy', 'git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip(), 'notice': manifest['notice']}
(destination / 'evidence-lock.json').write_bytes((json.dumps(lock, indent=2) + '\n').encode())
print(json.dumps(lock))
