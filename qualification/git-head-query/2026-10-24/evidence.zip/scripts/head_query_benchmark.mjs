// Actual Git processes through the existing reader seam; diagnostic, not native-suite qualification.
import { spawnSync } from 'node:child_process';
import { createHash, randomUUID } from 'node:crypto';
import { existsSync, mkdtempSync, readFileSync, realpathSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { basename, dirname, join, resolve } from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';
const root = dirname(fileURLToPath(import.meta.url));
const repo = realpathSync(process.argv[2]);
const label = process.argv[3];
if (!/^(baseline|candidate)$/.test(label)) throw new Error('Invalid diagnostic label');
const hash = data => createHash('sha256').update(data).digest('hex');
const env = { ...process.env, GIT_CONFIG_GLOBAL: '/dev/null', GIT_CONFIG_SYSTEM: '/dev/null', GIT_TERMINAL_PROMPT: '0', GIT_AUTHOR_DATE: '2000-01-01T00:00:00Z', GIT_COMMITTER_DATE: '2000-01-01T00:00:00Z' };
const git = (cwd, args) => {
  const result = spawnSync('git', args, { cwd, env, encoding: 'utf8', shell: false, timeout: 10000, maxBuffer: 1024 * 1024, windowsHide: true });
  if (result.status !== 0 || result.error) throw new Error('Native fixture Git command failed: ' + args[0]);
  return result.stdout.trim();
};
const fixtureRecord = join(root, 'head-query-fixture.json');
let fixture;
if (!existsSync(fixtureRecord)) {
  const path = mkdtempSync(join(tmpdir(), 'ascout-e00-head-'));
  const owner = randomUUID();
  git(path, ['init', '-q']);
  writeFileSync(join(path, 'input.txt'), 'Ascout fixed native HEAD-query fixture\n');
  git(path, ['add', 'input.txt']);
  git(path, ['-c', 'user.name=Ascout Test', '-c', 'user.email=ascout@example.invalid', '-c', 'commit.gpgSign=false', 'commit', '-q', '-m', 'fixed fixture']);
  writeFileSync(join(path, '.ascout-owned-e00-fixture'), owner);
  fixture = { path, owner, head: git(path, ['rev-parse', 'HEAD']) };
  writeFileSync(fixtureRecord, JSON.stringify(fixture, null, 2) + '\n');
} else fixture = JSON.parse(readFileSync(fixtureRecord, 'utf8'));
if (realpathSync(fixture.path) !== resolve(fixture.path) || !basename(fixture.path).startsWith('ascout-e00-head-') || dirname(realpathSync(fixture.path)) !== realpathSync(tmpdir()) || readFileSync(join(fixture.path, '.ascout-owned-e00-fixture'), 'utf8') !== fixture.owner || git(fixture.path, ['rev-parse', 'HEAD']) !== fixture.head) throw new Error('Fixture identity changed');
const { readGitHeadState } = await import(pathToFileURL(join(repo, 'dist/git.js')).href);
const sourceHead = git(repo, ['rev-parse', 'HEAD']);
const sourceHash = hash(readFileSync(join(repo, 'src/git.ts')));
const observations = [];
for (let iteration = 0; iteration < 5; iteration++) {
  const commands = [];
  const runner = (cwd, argv) => {
    const start = performance.now();
    const result = spawnSync('git', [...argv], { cwd, env, encoding: 'utf8', shell: false, timeout: 10000, maxBuffer: 1024 * 1024, windowsHide: true });
    commands.push({ argv, elapsed_ms: performance.now() - start, status: result.status, error: result.error?.name ?? null });
    return { status: result.status, stdout: result.stdout ?? '', stderr: result.stderr ?? '', ...(result.error ? { error: result.error } : {}) };
  };
  const start = performance.now();
  const output = readGitHeadState(fixture.path, runner);
  if (output.head_sha !== fixture.head || output.detached !== false || output.shallow !== false) throw new Error('Native output differs from fixed fixture');
  observations.push({ iteration, elapsed_ms: performance.now() - start, git_processes: commands.length, commands, output });
}
if (sourceHead !== git(repo, ['rev-parse', 'HEAD']) || sourceHash !== hash(readFileSync(join(repo, 'src/git.ts')))) throw new Error('Source changed during diagnostic');
const summary = { label, observed_at_utc: new Date().toISOString(), source_head: sourceHead, source_git_ts_sha256: sourceHash, compiled_git_js_sha256: hash(readFileSync(join(repo, 'dist/git.js'))), helper_sha256: hash(readFileSync(fileURLToPath(import.meta.url))), git_version: git(repo, ['--version']), fixture_head: fixture.head, fixture_owner: fixture.owner, observations, total_git_processes: observations.reduce((sum, sample) => sum + sample.git_processes, 0), total_ms: observations.reduce((sum, sample) => sum + sample.elapsed_ms, 0), limits: 'Actual native Git launches through existing injected runner, controlled fixture/config and diagnostic counters. Not default-runner security qualification, an uninstrumented test result, historical timeout causation or release approval.' };
const target = join(root, 'head-query-' + label + '.json');
if (existsSync(target)) throw new Error('Refuse to overwrite frozen diagnostic');
writeFileSync(target, JSON.stringify(summary, null, 2) + '\n');
console.log(JSON.stringify(summary));
