"""Summarize completed native Task021 captures without changing their verdicts."""
import hashlib, json, pathlib, re, subprocess

root = pathlib.Path(__file__).resolve().parent
engineering = root.parent / 'engineering'
repo = engineering / 'main-control'
base = '92433f7039393d6a08b8f993bc50da8470de2b5c'
candidate = 'e855b16b668d490cf6e3b5bfbe11b0e36724ae0d'
sha = lambda value: hashlib.sha256(value).hexdigest()
captures = []
for path in sorted((engineering / 'runs').glob('rc-repair-*.json')):
    if not any(path.name.startswith(prefix) for prefix in ['rc-repair-baseline-build-', 'rc-repair-baseline-targets-', 'rc-repair-head-']):
        continue
    record = json.loads(path.read_text(encoding='utf-8'))
    assert record['state'] == 'EXECUTED', path.name
    assert record['source_unchanged'] and record['source_start'] == record['source_end'], path.name
    streams = {}
    for stream in ['stdout', 'stderr']:
        data = (engineering / 'runs' / record[stream]).read_bytes()
        assert sha(data) == record[stream + '_sha256']
        streams[stream] = re.sub(chr(27) + r'\[[0-?]*[ -/]*[@-~]', '', data.decode('utf-8'))
    lines = streams['stdout'].splitlines()
    captures.append({'capture': path.name, 'sha256': sha(path.read_bytes()),
                     'name': record['name'], 'head': record['source_start']['head'],
                     'tree': record['source_start']['head_tree'], 'native_exit': record['exit'],
                     'wall_seconds': record['wall_seconds'], 'source_unchanged': True,
                     'native_summaries': [line.strip() for line in lines if re.match(r'\s*(Test Files|Tests|Duration)\s', line)],
                     'failed_cases': [line.strip() for line in streams['stderr'].splitlines() if line.startswith(' FAIL ')]})
full = [item for item in captures if item['name'] == 'rc-repair-head-full-suite']
assert len(full) == 1 and full[0]['head'] == candidate
frozen = ['tests/git-tree-digest.test.ts', 'tests/drift.contract.test.ts', 'tests/cli.smoke.test.ts', 'tests/t107-self-verification-harness.contract.test.ts', 'package.json', 'package-lock.json', 'vitest.config.ts', 'src/assurance/kernel/authority.ts', 'src/assurance/kernel/effect-authority.ts']
bindings = {}
for name in frozen:
    versions = {}
    for head in [base, candidate]:
        data = subprocess.check_output(['rtk', 'proxy', 'git', 'show', head + ':' + name], cwd=repo)
        versions[head] = sha(data)
    assert len(set(versions.values())) == 1, name
    bindings[name] = versions
result = {'kind': 'TASK021_ACTUAL_NATIVE_QUALIFICATION', 'base': base, 'candidate': candidate,
          'captures': captures, 'frozen_path_sha256': bindings,
          'full_native_exit': full[0]['native_exit'], 'complete_local_control_passed': full[0]['native_exit'] == 0,
          'limitations': 'Actual source-bound local executions only. Historical 300/900-second captures and six failed deadlines remain failures. The unchanged current-main focused control reproduced two deadlines. Aggregate memory/disk and native Git timings do not establish a sole environmental cause. Existing platform skips remain explicit. Hosted and postmerge qualification are separate; no release approval.'}
(root / 'timing-qualification-summary.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
print(json.dumps(result))
