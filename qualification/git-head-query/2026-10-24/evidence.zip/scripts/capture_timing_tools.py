"""Actual local OCR rules and static navigation; no model/provider/cloud verdict."""
import datetime, hashlib, json, os, pathlib, subprocess
root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
head = subprocess.check_output(['rtk', 'proxy', 'git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip()
assert head == 'e855b16b668d490cf6e3b5bfbe11b0e36724ae0d'
assert not subprocess.check_output(['rtk', 'proxy', 'git', 'status', '--porcelain'], cwd=repo).strip()
packages = pathlib.Path.home() / 'AppData/Roaming/npm/node_modules'
ocr = str(packages / '@alibaba-group/open-code-review/bin/ocr.js')
graft = str(packages / '@nanonets/graft/dist/cli.js')
env = {**os.environ, 'DO_NOT_TRACK': '1', 'GRAFT_TELEMETRY': '0', 'GRAFT_API_KEY': '', 'GRAFT_NO_GITIGNORE': '1', 'GRAFT_NO_IGNORE': '1'}
commands = [
    ('alibaba-preview', ['node', ocr, 'delegate', 'preview', '--from', '92433f7039393d6a08b8f993bc50da8470de2b5c', '--to', head]),
    ('alibaba-rules', ['node', ocr, 'delegate', 'rule', 'src/git.ts', 'tests/git-identity.test.ts']),
    ('graft-build', ['node', graft, '--dir', str(root / 'timing-graft-graph'), 'build', str(repo), '--only-dir', 'src', '--no-gitignore', '--no-ignore']),
]
records = []
for label, argv in commands:
    result = subprocess.run(['rtk', 'proxy', *argv], cwd=repo, env=env, capture_output=True, timeout=180)
    for stream in ['stdout', 'stderr']:
        (root / ('timing-tool-' + label + '.' + stream + '.txt')).write_bytes(getattr(result, stream))
    records.append({'label': label, 'argv': argv, 'exit': result.returncode, 'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(), 'stderr_sha256': hashlib.sha256(result.stderr).hexdigest()})
assert not subprocess.check_output(['rtk', 'proxy', 'git', 'status', '--porcelain'], cwd=repo).strip()
record = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head': head, 'commands': records, 'notice': 'Actual local Alibaba preview/rules and Graft static source navigation. No deep/model mode, external provider verdict, independent-provider approval or release claim. Excluded files remain covered by fresh manual review. Graph cache is outside repository; telemetry-off controls retained.'}
(root / 'timing-tool-execution.json').write_bytes((json.dumps(record, indent=2) + '\n').encode())
print(json.dumps(record))
