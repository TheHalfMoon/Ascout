"""Keep native target entries, reject unrelated eager resolver churn with proof."""
import hashlib, json, pathlib

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
before_bytes = (root / 'dependency-before-lock.json').read_bytes()
native_bytes = (root / 'dependency-first-native-after-lock.json').read_bytes()
assert hashlib.sha256(before_bytes).hexdigest() == '36843f0ccb2a85fe71a27371055b539be825df59b653f1e0e02aadadb8ec6eb2'
assert hashlib.sha256(native_bytes).hexdigest() == '5ee90fe321c80669cec8eadb2eeddf828655e9c2abdb27c82bf473d72b2a3952'
assert (repo / 'package-lock.json').read_bytes() == native_bytes
assert json.loads((root / 'dependency-target-range-check.json').read_text())['all_target_edges_satisfied']
before, native = json.loads(before_bytes), json.loads(native_bytes)
graph = json.loads((root / 'dependency-first-native-native-graph.json').read_text())
names = graph['expected_changed_paths']
assert len(names) == 12 and '' in names
for name in names:
    before['packages'][name] = native['packages'][name]
result = (json.dumps(before, indent=2, ensure_ascii=False) + '\n').encode()
(repo / 'package-lock.json').write_bytes(result)
(root / 'dependency-minimal-selection.json').write_text(json.dumps({'method': 'Native npm generated target entries copied without field modification; canonical baseline retained for every other entry. Both native attempts produced identical eager unrelated churn. Independent range check confirms it is unnecessary, not a new dependency requirement. Exact-lock native install/ls and complete tests remain required.', 'before_sha256': hashlib.sha256(before_bytes).hexdigest(), 'native_intermediate_sha256': hashlib.sha256(native_bytes).hexdigest(), 'selected_sha256': hashlib.sha256(result).hexdigest(), 'selected_paths': names, 'rejected_unrelated_paths': graph['unexpected_changed_paths'], 'target_edge_checks': 85, 'all_target_edges_satisfied': True}, indent=2) + '\n', encoding='utf-8')
print(hashlib.sha256(result).hexdigest())
