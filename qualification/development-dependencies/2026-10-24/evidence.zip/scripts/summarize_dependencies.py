"""Derive qualification observations from finished native captures, including failures."""
import datetime, hashlib, json, pathlib, re

root = pathlib.Path(__file__).resolve().parent
runs = root.parent / 'engineering/runs'
head = '43848672b2c68380d8b01797004ee57a02cbf984'
records = []
for label in ['install', 'tree', 'audit', 'production-audit', 'signatures', 'typecheck', 'build', 'focused', 'full-suite', 'full-suite-isolated']:
    matches = [path for path in runs.glob('dep-repair-candidate-' + label + '-*.json') if json.loads(path.read_text())['name'] == 'dep-repair-candidate-' + label]
    assert len(matches) == 1, (label, matches)
    path = matches[0]
    capture = json.loads(path.read_text())
    assert capture['state'] == 'EXECUTED' and capture['source_unchanged'], path.name
    assert capture['source_start']['head'] == head and capture['source_start']['status'] == ''
    output = (runs / capture['stdout']).read_bytes()
    error = (runs / capture['stderr']).read_bytes()
    assert hashlib.sha256(output).hexdigest() == capture['stdout_sha256']
    assert hashlib.sha256(error).hexdigest() == capture['stderr_sha256']
    text = re.sub(chr(27) + r'\[[0-?]*[ -/]*[@-~]', '', output.decode('utf-8'))
    item = {'label': label, 'manifest': path.name, 'manifest_sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'native_exit': capture['exit'], 'wall_seconds': capture['wall_seconds'], 'source_unchanged': True}
    if label in ['audit', 'production-audit']:
        item['vulnerabilities'] = json.loads(output)['metadata']['vulnerabilities']
    if label == 'signatures':
        item['result'] = json.loads(output)
    if label in ['focused', 'full-suite', 'full-suite-isolated']:
        item['native_summaries'] = [line.strip() for line in text.splitlines() if re.search(r'Test Files|\bTests\s+|Duration', line)]
        item['stderr_tail'] = error.decode('utf-8')[-16000:]
    if label == 'install':
        item['existing_deprecation_warnings'] = error.decode('utf-8')
    records.append(item)
result = {'observed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'kind': 'TASK022_ACTUAL_NATIVE_CANDIDATE_QUALIFICATION', 'head': head, 'tree': capture['source_start']['head_tree'], 'controls': records, 'all_native_exit_zero': all(item['native_exit'] == 0 for item in records), 'audit_findings_removed': next(item for item in records if item['label'] == 'audit')['vulnerabilities']['total'] == 0, 'limitations': 'Actual candidate local native execution only. Every native failure and platform skip retained. Historical browser deadline failures, concurrent-disposal ownership gap and historical inner Self packaging failure remain separate debt. No E00/release readiness inferred; actual final-head CI/Self/live gates and postmerge evidence remain required.'}
(root / 'dependency-qualification-summary.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, indent=2))
