"""Read actual Task021 CI logs and shadow artifacts at one immutable source."""
import datetime, hashlib, io, json, pathlib, re, subprocess, sys, zipfile

root = pathlib.Path(__file__).resolve().parent
head, project_run, self_run, number = sys.argv[1:]
postmerge = self_run == '-'
out = root / ('timing-ci-' + ('postmerge-' if postmerge else '') + head[:7])
out.mkdir(exist_ok=True)
sha = lambda data: hashlib.sha256(data).hexdigest()
prefix = 'repos/TheHalfMoon/Ascout/'

def get(path, name):
    data = subprocess.check_output(['rtk', 'proxy', 'gh', 'api', prefix + path])
    (out / name).write_bytes(data)
    return json.loads(data)

commit = get('git/commits/' + head, 'fixed-head-commit.json')
assert commit['sha'] == head
tree = commit['tree']['sha']
main = get('branches/main', 'main-snapshot.json')
pr = get('pulls/' + number, 'pr-snapshot.json')
if postmerge:
    assert main['commit']['sha'] == head and pr['merged'] and pr['merge_commit_sha'] == head
    proof = json.loads((root.parent / 'engineering/merges' / (number + '.json')).read_text())
    assert proof['merge'] == head and proof['tree_equal'] and proof['github_signature_verification']['verified']
    assert tree == proof['merge_tree'] and [p['sha'] for p in commit['parents']] == proof['ordered_parents']
else:
    assert pr['head']['sha'] == head and pr['base']['sha'] == main['commit']['sha']
records = []
native_files = ['git-identity.test.ts', 'git-tree-digest.test.ts', 'drift.contract.test.ts', 't107-self-verification-harness.contract.test.ts', 'npm-package-content.test.ts', 'assurance-durable-harness.test.ts', 'assurance-durable-harness.native.test.ts', 'review-diagnostic-accounting.test.ts', 'pre-run-widening.integration.test.ts', 'assurance-test-stryker-output.test.ts', 'conservative-selection-data.contract.test.ts', 'conservative-selection-data.native.test.ts', 'browser-text-assertion.integration.test.ts', 'browser-text-assertion.contract.test.ts']
for run_id in [project_run] + ([] if postmerge else [self_run]):
    metadata = get('actions/runs/' + run_id, 'run-' + run_id + '.json')
    assert metadata['head_sha'] == head and metadata['status'] == 'completed'
    assert metadata['event'] == ('push' if postmerge else 'pull_request')
    jobs = get('actions/runs/' + run_id + '/jobs?per_page=100', 'jobs-' + run_id + '.json')
    assert jobs['total_count'] == len(jobs['jobs']) == (6 if run_id == project_run else 1)
    for job in jobs['jobs']:
        assert job['status'] == 'completed'
        filename = 'job-' + str(job['id']) + '.log'
        data = subprocess.check_output(['rtk', 'proxy', 'gh', 'api', prefix + 'actions/jobs/' + str(job['id']) + '/logs'])
        (out / filename).write_bytes(data)
        text = re.sub(chr(27) + r'\[[0-?]*[ -/]*[@-~]', '', data.decode('utf-8'))
        steps = {step['name']: step['conclusion'] for step in job['steps']}
        native = run_id == project_run
        test = 'Test (Windows bounded workers)' if 'windows' in job['name'] else 'Test'
        required = ['Guard exact source', 'Install exact lockfile', 'Provision exact Chromium runtime', 'Typecheck', test, 'Build'] if native else ['Guard exact PR head', 'Install exact lockfile', 'Build exact PR head', 'Capture exact-head self-verification', 'Capture selector-shadow observation', 'Upload bounded self-verification evidence']
        guard = ('EXPECTED_SHA: ' if native else 'PR_HEAD_SHA: ') + head in text
        summaries = [line for line in text.splitlines() if any(term in line for term in ['Test Files ', '      Tests ', 'Duration '])]
        execution = None
        if native:
            execution = all(command in text for command in ['> tsc -p tsconfig.json --noEmit', '> tsc -p tsconfig.json', 'vitest run']) and all(name in text for name in native_files) and bool(re.search(r'Tests\s+\d+ passed[^\r\n]*\(2425\)', text))
        records.append({'run': int(run_id), 'id': job['id'], 'name': job['name'], 'conclusion': job['conclusion'], 'steps': steps, 'required_steps': {name: steps.get(name) for name in required}, 'all_required_steps_success': all(steps.get(name) == 'success' for name in required), 'exact_source_guard_verified': guard, 'actual_native_full_execution_verified': execution, 'native_summaries': summaries, 'log': filename, 'sha256': sha(data), 'bytes': len(data)})
artifact_record = None
if not postmerge:
    listing = get('actions/runs/' + self_run + '/artifacts?per_page=100', 'self-artifacts.json')
    assert listing['total_count'] == len(listing['artifacts'])
    selected = [item for item in listing['artifacts'] if item['name'] == 'self-verification-' + head]
    assert len(selected) == 1 and not selected[0]['expired']
    artifact = selected[0]
    raw = subprocess.check_output(['rtk', 'proxy', 'gh', 'api', prefix + 'actions/artifacts/' + str(artifact['id']) + '/zip'])
    assert len(raw) <= 32 * 1024 * 1024
    (out / ('self-artifact-' + str(artifact['id']) + '.zip')).write_bytes(raw)
    log = (out / next(item['log'] for item in records if item['run'] == int(self_run))).read_text(encoding='utf-8')
    uploaded = re.search(r'SHA256 digest of uploaded artifact is ([a-f0-9]{64})', log)
    assert uploaded and uploaded[1] == sha(raw)
    if artifact.get('digest') is not None:
        assert artifact['digest'] == 'sha256:' + sha(raw)
    members = {}
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        assert len(archive.namelist()) == len(set(archive.namelist())) == 3
        assert set(archive.namelist()) == {'self-verification-receipt.json', 'self-verification-envelope.json', 'selector-shadow-observation.json'}
        assert sum(item.file_size for item in archive.infolist()) <= 40 * 1024 * 1024
        assert archive.testzip() is None
        for name in archive.namelist():
            data = archive.read(name)
            json.loads(data)
            (out / name).write_bytes(data)
            members[name] = {'sha256': sha(data), 'bytes': len(data)}
    envelope = json.loads((out / 'self-verification-envelope.json').read_text())
    receipt = json.loads((out / 'self-verification-receipt.json').read_text())
    selector = json.loads((out / 'selector-shadow-observation.json').read_text())
    assert envelope['classification'] == 'SHADOW_NON_GATING'
    assert envelope['verifier_head_sha'] == envelope['subject_target_head_sha'] == head
    assert envelope['subject_target_tree_sha'] == envelope['verifier_head_tree_sha'] == tree
    assert envelope['event_base_tip_sha'] == envelope['subject_merge_base_sha'] == pr['base']['sha']
    assert envelope['receipt_sha256'] == members['self-verification-receipt.json']['sha256']
    assert envelope['receipt_exit_code'] == receipt['summary']['exit_code']
    assert selector['source']['receipt_sha256'] == envelope['receipt_sha256']
    artifact_record = {'artifact_id': artifact['id'], 'original_zip_sha256': sha(raw), 'original_zip_excluded_from_publication': True, 'advertised_digest_and_crc_verified': True, 'source_tree_base_receipt_bindings_verified': True, 'members': members, 'classification': envelope['classification'], 'inner_exit': receipt['summary']['exit_code'], 'inner_summary': receipt['summary'], 'inner_findings': receipt['findings'], 'selector_comparison': selector['comparison'], 'notice': 'Actual inner failures/incompleteness/unavailable comparisons retained. Green Self workflow proves shadow capture integrity only.'}
summary = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'kind': 'TASK021_ACTUAL_POSTMERGE_CI' if postmerge else 'TASK021_ACTUAL_EXACT_HEAD_CI', 'head': head, 'tree': tree, 'base': pr['base']['sha'], 'pr': int(number), 'jobs': records, 'all_actual_jobs_success': all(item['conclusion'] == 'success' and item['all_required_steps_success'] and item['exact_source_guard_verified'] for item in records), 'six_actual_native_full_suites_verified': len([item for item in records if item['actual_native_full_execution_verified']]) == 6, 'self_artifact': artifact_record, 'limitations': 'Actual source-bound hosted execution only; historical failures are not erased. No provider-independent certification, governance waiver or release approval.'}
(out / 'summary.json').write_bytes((json.dumps(summary, indent=2) + '\n').encode())
print(json.dumps({'directory': out.name, 'head': head, 'all_actual_jobs_success': summary['all_actual_jobs_success'], 'six_actual_native_full_suites_verified': summary['six_actual_native_full_suites_verified'], 'shadow_inner_exit': artifact_record['inner_exit'] if artifact_record else None}))
