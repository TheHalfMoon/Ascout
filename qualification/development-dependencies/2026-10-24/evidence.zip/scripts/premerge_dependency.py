"""Use existing exact-head read-only gates with the current Task022 reference."""
import pathlib

path = pathlib.Path(__file__).with_name('premerge_timing.py')
source = path.read_text(encoding='utf-8').replace('Task021', 'Task022')
exec(compile(source, str(path), 'exec'))
