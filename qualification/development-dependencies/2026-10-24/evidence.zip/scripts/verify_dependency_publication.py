"""Actual remote byte/member verification with separate Task022 prefixes/receipts."""
import pathlib

path = pathlib.Path(__file__).with_name('verify_timing_publication.py')
source = path.read_text(encoding='utf-8').replace('qualification/git-head-query/', 'qualification/development-dependencies/').replace('timing-publication-receipt-', 'dependency-publication-receipt-').replace('Task021', 'Task022')
exec(compile(source, str(path), 'exec'))
