"""Retain first native output, then retry native resolution preferring existing pins."""
import hashlib, json, pathlib, subprocess

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == '570d59de3595ab9ce34cf366531a5d6d195662d4'
lock = repo / 'package-lock.json'
native = lock.read_bytes()
assert hashlib.sha256(native).hexdigest() == '5ee90fe321c80669cec8eadb2eeddf828655e9c2abdb27c82bf473d72b2a3952'
for name in ['dependency-after-lock.json', 'dependency-native-graph.json']:
    source = root / name
    target = root / name.replace('dependency-', 'dependency-first-native-', 1)
    assert not target.exists()
    target.write_bytes(source.read_bytes())
original = subprocess.check_output(['git', 'show', 'af5de7d1c56030d8842fc85c334cb8933d63fc08:package-lock.json'], cwd=repo)
assert hashlib.sha256(original).hexdigest() == '36843f0ccb2a85fe71a27371055b539be825df59b653f1e0e02aadadb8ec6eb2'
lock.write_bytes(original)
print(json.dumps({'first_native_preserved_sha256': hashlib.sha256(native).hexdigest(), 'restored_base_lock_sha256': hashlib.sha256(original).hexdigest(), 'notice': 'Only our uncommitted generated lock restored byte-for-byte to canonical base before a native prefer-dedupe retry. Updated direct manifest pins retained. No dependency installed, override or lock entry synthesized.'}))
