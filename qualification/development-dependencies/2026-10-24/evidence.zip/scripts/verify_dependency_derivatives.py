"""Verify meaningful source fields survive public minimization in the actual archive."""
import hashlib, json, pathlib, re, zipfile

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
packet = repo / 'qualification/development-dependencies/2026-10-24'
checks = []
with zipfile.ZipFile(packet / 'evidence.zip') as archive:
    assert archive.testzip() is None
    manifest = json.loads(archive.read('MANIFEST.json'))
    for record in manifest['records']:
        assert hashlib.sha256(archive.read(record['path'])).hexdigest() == record['published_sha256']
    for pattern, member_prefix in [('registry-*.json', 'context/'), ('dependency-closure-metadata/*.json', 'sources/')]:
        for source in sorted(root.glob(pattern)):
            original = json.loads(source.read_text())
            member = member_prefix + source.relative_to(root).as_posix()
            published = json.loads(archive.read(member))
            for key in ['name', 'version', '_id']:
                if key in original:
                    assert published[key] == original[key], (member, key)
            for key in ['tarball', 'integrity']:
                if key in original.get('dist', {}):
                    assert published['dist'][key] == original['dist'][key], (member, key)
            attestation = original.get('dist', {}).get('attestations', {}).get('url')
            if attestation:
                assert published['dist']['attestations']['url'] == attestation, member
            checks.append({'member': member, 'identity_dist_attestation_fields_preserved': True})
    for capture_path in sorted((root.parent / 'engineering/runs').glob('dep-repair-candidate-install-*.json')):
        capture = json.loads(capture_path.read_text())
        original = (capture_path.parent / capture['stderr']).read_text()
        published = archive.read('runs/' + capture['stderr']).decode()
        labels = re.findall(r'npm warn deprecated (\S+):', original)
        assert labels and all(label in published for label in labels), labels
        checks.append({'member': 'runs/' + capture['stderr'], 'deprecation_labels_preserved': labels})
result = {'archive_sha256': hashlib.sha256((packet / 'evidence.zip').read_bytes()).hexdigest(), 'checks': checks, 'notice': 'Actual published metadata identities, exact tarball/integrity and complete attestation URLs compared against originals; deprecation warning labels retained. Separate privacy review still required. No source test/security/release approval.'}
(root / 'dependency-derivative-verification.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'archive_sha256': result['archive_sha256'], 'source_field_checks': len(checks), 'all_passed': True}))
