"""Serial native controls; wrapper records actual exit even when a control fails."""
import pathlib, subprocess, sys

root = pathlib.Path(__file__).resolve().parent
engineering = root.parent / 'engineering'
repo = engineering / 'main-control'
npm = ['node', 'C:/Program Files/nodejs/node_modules/npm/bin/npm-cli.js']
stage = sys.argv[1]
commands = {
    'mechanical': [
        ('tree', 180, npm + ['ls', '--all', '--json']),
        ('audit', 300, npm + ['audit', '--json']),
        ('production-audit', 300, npm + ['audit', '--omit=dev', '--json']),
        ('signatures', 600, npm + ['audit', 'signatures', '--json']),
        ('typecheck', 300, npm + ['run', 'typecheck']),
        ('build', 300, npm + ['run', 'build']),
    ],
    'focused': [('focused', 900, npm + ['test', '--', '--maxWorkers=1', 'tests/vitest-check.integration.test.ts', 'tests/vitest-fixture.integration.test.ts', 'tests/vitest-task.contract.test.ts', 'tests/npm-package-content.test.ts'])],
    'full': [('full-suite', 1800, npm + ['test', '--', '--maxWorkers=1'])],
    'full-isolated': [('full-suite-isolated', 1800, npm + ['test', '--', '--maxWorkers=1'])],
}[stage]
for label, timeout, argv in commands:
    result = subprocess.run([sys.executable, '-X', 'utf8', str(engineering / 'qualify_native.py'), 'dep-repair-candidate-' + label, '--cwd', str(repo), '--timeout', str(timeout), '--', *argv])
    if result.returncode:
        raise SystemExit(result.returncode)
