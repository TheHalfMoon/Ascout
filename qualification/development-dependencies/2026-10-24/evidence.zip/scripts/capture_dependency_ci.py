"""Task022 uses unchanged 2425-case native CI and bounded Self artifact checks."""
import pathlib

# Reuse the previously qualified reader without modifying its frozen historical bytes.
# Only task label and output namespace differ. Native counts/contracts are unchanged.
path = pathlib.Path(__file__).with_name('capture_timing_ci.py')
source = path.read_text(encoding='utf-8')
assert "'timing-ci-'" in source and 'TASK021_ACTUAL_' in source
source = source.replace("'timing-ci-'", "'dependency-ci-'").replace('TASK021_ACTUAL_', 'TASK022_ACTUAL_')
exec(compile(source, str(path), 'exec'))
