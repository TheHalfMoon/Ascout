"""Preserve resumed frontier and compare governing facts before further publication."""
import hashlib, json, pathlib

root = pathlib.Path(__file__).resolve().parent
source = root / 'dependency-frontier-premerge.json'
target = root / 'dependency-frontier-resume-20261025.json'
assert not target.exists()
source.replace(target)
before = json.loads((root / 'dependency-frontier-refresh.json').read_text())
after = json.loads(target.read_text())
keys = ['main', 'main_tree', 'main_protected', 'protection_query_exit', 'protection_message', 'rulesets', 'issue618', 'governing_file_sha256']
assert all(before[key] == after[key] for key in keys)
assert before['open_prs'] == after['open_prs']
old_refs, new_refs = set(before['remote_head_refs']), set(after['remote_head_refs'])
added = sorted(new_refs - old_refs)
removed = sorted(old_refs - new_refs)
assert not removed and len(added) == 1 and added[0].split() == ['43848672b2c68380d8b01797004ee57a02cbf984', 'refs/heads/ps/rea-e05-dependency-patches']
record = {'resumed_utc': after['observed_at_utc'], 'governing_facts_unchanged': keys, 'open_prs_unchanged': True, 'remote_refs_added': added, 'remote_refs_removed': removed, 'before_sha256': hashlib.sha256((root / 'dependency-frontier-refresh.json').read_bytes()).hexdigest(), 'resume_sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'notice': 'Exact canonical main/governance/concurrent branch refresh after user pause. Only our backed-up Task022 branch was added. No policy change, implementation authority expansion, merge or release approval.'}
(root / 'dependency-resume-comparison-20261025.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps(record))
