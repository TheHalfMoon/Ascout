"""Read-only live frontier/governance refresh; absence of protection is no waiver."""
import datetime, hashlib, json, pathlib, subprocess, sys
from concurrent.futures import ThreadPoolExecutor

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
prefix = 'repos/TheHalfMoon/Ascout/'

def fetch(path):
    command = subprocess.run(['rtk', 'proxy', 'gh', 'api', prefix + path], capture_output=True)
    try: value = json.loads(command.stdout)
    except ValueError: value = None
    return {'native_exit': command.returncode, 'body_sha256': hashlib.sha256(command.stdout).hexdigest(), 'value': value}

paths = ['branches/main', 'branches/main/protection', 'rulesets', 'issues/618', 'issues/618/comments?per_page=100', 'pulls?state=open&per_page=100']
with ThreadPoolExecutor(max_workers=4) as pool:
    responses = dict(zip(paths, pool.map(fetch, paths)))
assert responses['branches/main']['native_exit'] == responses['rulesets']['native_exit'] == 0
issue = responses['issues/618']['value']; comments = responses['issues/618/comments?per_page=100']['value']
assert responses['issues/618']['native_exit'] == responses['issues/618/comments?per_page=100']['native_exit'] == 0
assert len(comments) < 100
prs = responses['pulls?state=open&per_page=100']['value']; assert len(prs) < 100
refs = subprocess.check_output(['rtk', 'proxy', 'git', 'ls-remote', '--heads', 'origin'], cwd=repo).decode().splitlines()
governing = {}
for name in ['CONTRIBUTING.md', '.specify/PROVENANCE.md', '.specify/memory/constitution.md']:
    data = subprocess.check_output(['rtk', 'proxy', 'git', 'show', 'HEAD:' + name], cwd=repo)
    governing[name] = hashlib.sha256(data).hexdigest()
result = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'main': responses['branches/main']['value']['commit']['sha'], 'main_tree': responses['branches/main']['value']['commit']['commit']['tree']['sha'], 'main_protected': responses['branches/main']['value']['protected'], 'protection_query_exit': responses['branches/main/protection']['native_exit'], 'protection_message': (responses['branches/main/protection']['value'] or {}).get('message'), 'rulesets': responses['rulesets']['value'], 'issue618': {'state': issue['state'], 'updated_at': issue['updated_at'], 'body_sha256': hashlib.sha256(issue['body'].encode()).hexdigest(), 'comments': [{'id': item['id'], 'updated_at': item['updated_at'], 'body_sha256': hashlib.sha256(item['body'].encode()).hexdigest()} for item in comments]}, 'open_prs': [{'number': item['number'], 'title': item['title'], 'head': item['head']['sha'], 'head_ref': item['head']['ref'], 'base_ref': item['base']['ref'], 'draft': item['draft'], 'updated_at': item['updated_at']} for item in prs], 'remote_head_refs': refs, 'governing_file_sha256': governing, 'notice': 'Point-in-time read-only observations. No settings changed; absent protection never waives repository governance. Issue618 remains scoped by the fresh Task021 applicability audit. No authority grant or merge approval.'}
filename = sys.argv[1] if len(sys.argv) > 1 else 'timing-frontier-refresh.json'
assert filename in ['timing-frontier-refresh.json', 'timing-frontier-premerge.json']
(root / filename).write_bytes((json.dumps(result, indent=2) + '\n').encode())
print(json.dumps({'main': result['main'], 'open_prs': len(prs), 'remote_head_refs': len(refs), 'protected': result['main_protected'], 'issue618_updated': issue['updated_at']}))
