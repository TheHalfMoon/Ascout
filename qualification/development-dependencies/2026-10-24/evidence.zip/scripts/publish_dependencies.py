"""Explicit Task022 plaintext derivatives and deterministic, hash-bound evidence ZIP."""
import ast, hashlib, json, pathlib, re, subprocess, sys, zipfile

root = pathlib.Path(__file__).resolve().parent
engineering = root.parent / 'engineering'
repo = engineering / 'main-control'
close = sys.argv[1:] == ['--close']
assert sys.argv[1:] in [[], ['--close']]
destination = repo / ('qualification/development-dependencies/2026-10-24-closeout' if close else 'qualification/development-dependencies/2026-10-24')
destination.mkdir(parents=True, exist_ok=True)
members, records = {}, []
sha = lambda data: hashlib.sha256(data).hexdigest()

def minimize(value):
    if isinstance(value, list):
        return [minimize(item) for item in value]
    if isinstance(value, str) and value.lstrip().startswith(('{', '[')):
        try:
            embedded = json.loads(value)
        except ValueError:
            return value
        return json.dumps(minimize(embedded), ensure_ascii=False)
    if not isinstance(value, dict):
        return value
    result = {key: minimize(item) for key, item in value.items() if key not in ['author', 'committer', '_npmUser', 'email']}
    if isinstance(result.get('verification'), dict):
        result['verification'].pop('payload', None)
        result['verification'].pop('signature', None)
    return result

def sanitize(data):
    text = data.decode('utf-8-sig')
    for prefix, replacement in [(str(root.parent.parent), '<WORKSPACE>'), (str(pathlib.Path.home()), '<USERPROFILE>')]:
        for spelling in [prefix, prefix.replace('\\', '/')]:
            for power in [4, 3, 2, 1, 0]:
                text = text.replace(spelling.replace('\\', '\\' * (2 ** power)), replacement)
    text = re.sub(r'(?i)[a-z]:[\\/]+Us' + r'ers[\\/]+[^\\/\s"\']+', '<USERPROFILE>', text)
    text = re.sub(r'/ho' + r'me/[^/\s"\\]+', '<RUNNER_HOME>', text)
    text = re.sub(r'(?i)[A-Z0-9.!#$%&\x27*+/=?^_`{|}~-]+@[A-Z0-9-]+(?:\.[A-Z0-9-]+)*\.[A-Z]{2,63}(?![A-Z0-9-])', '<PUBLIC_EMAIL_OMITTED>', text)
    return text.encode('utf-8')

def add(name, source):
    original = source.read_bytes()
    derivative = original
    if source.suffix == '.json':
        derivative = (json.dumps(minimize(json.loads(original)), indent=2, ensure_ascii=False) + '\n').encode()
    published = sanitize(derivative)
    assert name not in members
    assert not re.search(rb'gh[pousr]_[A-Za-z0-9]{30,}|sk-proj-[A-Za-z0-9_-]{20,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----', published), name
    # Public source usernames can contain the home component as a substring.
    # Reject the private component as a standalone token; preserve verifiable public refs.
    assert not re.search(rb'(?i)\b' + re.escape(pathlib.Path.home().name.encode()) + rb'\b', published), name
    if name.endswith('.json'):
        json.loads(published)
    if name.endswith('.py'):
        ast.parse(published.decode(), filename=name)
    members[name] = published
    records.append({'path': name, 'original_sha256': sha(original), 'published_sha256': sha(published), 'bytes': len(published), 'transformed': original != published})

for source in sorted((engineering / 'runs').glob('dep-repair-*.json')):
    capture = json.loads(source.read_text())
    assert capture['state'] == 'EXECUTED', source.name
    add('runs/' + source.name, source)
    for stream in ['stdout', 'stderr']:
        path = engineering / 'runs' / capture[stream]
        assert sha(path.read_bytes()) == capture[stream + '_sha256']
        add('runs/' + path.name, path)

for pattern in ['dependency-*.json', 'npm-*.json', 'registry-*.json']:
    for source in sorted(root.glob(pattern)):
        # Public derivatives/receipts go outside the frozen archive to avoid recursive publication.
        if any(token in source.name for token in ['publication-receipt', 'publication-review', 'closing-review', 'derivative-verification']):
            continue
        add('context/' + source.name, source)
for directory in ['advisory-sources', 'dependency-closure-metadata']:
    for source in sorted((root / directory).glob('*.json')):
        add('sources/' + directory + '/' + source.name, source)
add('sources/advisory-source-manifest.json', root / 'advisory-source-manifest.json')
add('sources/vite-6.4.5-changelog.md', root / 'vite-6.4.5-changelog.md')
for source in sorted(root.glob('dependency-tool-*.txt')):
    add('tools/' + source.name, source)
for directory in sorted(root.glob('dependency-ci-*')):
    for source in sorted(directory.iterdir()):
        if source.suffix in ['.json', '.log', '.txt']:
            add('ci/' + directory.name + '/' + source.name, source)
for name in ['dependency_graph.py', 'dependency_retry_minimal.py', 'dependency_range_check.mjs', 'dependency_select_minimal.py', 'dependency_candidate_binding.py', 'qualify_dependencies.py', 'publish_dependencies.py', 'capture_dependency_ci.py', 'capture_timing_ci.py', 'premerge_dependency.py', 'premerge_timing.py', 'capture_dependency_tools.py', 'summarize_dependencies.py', 'dependency_timing_context.py', 'capture_dependency_frontier.py', 'capture_timing_frontier.py', 'verify_dependency_publication.py', 'verify_timing_publication.py', 'dependency_resume_frontier.py', 'verify_dependency_derivatives.py']:
    add('scripts/' + name, root / name)
add('scripts/qualify_native.py', engineering / 'qualify_native.py')
if close:
    number = json.loads((root / 'dependency-pr-number.json').read_text())['number']
    for suffix in ['.json', '-premerge.json']:
        source = engineering / 'merges' / (str(number) + suffix)
        add('merges/' + source.name, source)
    add('scripts/record_merge.py', engineering / 'record_merge.py')

manifest = {'authority': 'TASK022_QUALIFICATION_OBSERVATIONS_ONLY', 'notice': 'Explicit plaintext public derivatives: local homes/emails and personal author/committer/raw signature profiles minimized. Original and published hashes retained. Registry usernames, target versions, license identifiers and package/attestation integrity evidence preserved. No original opaque archives, registry cache, private REA expansion or installed dependencies included. No security certification, release approval or historical failure erasure.', 'records': records}
members['MANIFEST.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
archive_path = destination / 'evidence.zip'
with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, value in sorted(members.items()):
        info = zipfile.ZipInfo(name, date_time=(2000, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, value, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
with zipfile.ZipFile(archive_path) as archive:
    assert len(archive.namelist()) == len(set(archive.namelist()))
    assert archive.testzip() is None
    for record in records:
        assert sha(archive.read(record['path'])) == record['published_sha256']
lock = {'zip_sha256': sha(archive_path.read_bytes()), 'members': len(members), 'source_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip(), 'notice': manifest['notice']}
(destination / 'evidence-lock.json').write_text(json.dumps(lock, indent=2) + '\n', encoding='utf-8')
print(json.dumps(lock))
