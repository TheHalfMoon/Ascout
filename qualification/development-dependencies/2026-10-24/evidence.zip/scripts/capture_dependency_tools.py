"""Actual local OCR path selection/rules, with explicit provider/applicability limits."""
import datetime, hashlib, json, os, pathlib, subprocess

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip()
assert head == '43848672b2c68380d8b01797004ee57a02cbf984'
ocr = pathlib.Path.home() / 'AppData/Roaming/npm/node_modules/@alibaba-group/open-code-review/bin/ocr.js'
commands = [('preview', ['node', str(ocr), 'delegate', 'preview', '--from', 'af5de7d1c56030d8842fc85c334cb8933d63fc08', '--to', head]), ('rules', ['node', str(ocr), 'delegate', 'rule', 'tests/vitest-check.integration.test.ts'])]
records = []
for label, argv in commands:
    result = subprocess.run(argv, cwd=repo, env={**os.environ, 'DO_NOT_TRACK': '1'}, capture_output=True, timeout=180)
    for stream in ['stdout', 'stderr']:
        (root / ('dependency-tool-ocr-' + label + '.' + stream + '.txt')).write_bytes(getattr(result, stream))
    records.append({'label': label, 'argv': argv, 'exit': result.returncode, 'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(), 'stderr_sha256': hashlib.sha256(result.stderr).hexdigest()})
result = {'observed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head': head, 'commands': records, 'scope': 'Actual local Alibaba OCR preview/rules only; no Claude login, external provider/model judgment or provider-independent approval. Selected and excluded paths remain fresh-manual-review obligations.', 'd1': 'Actually executed local CPU advisory; retained separately, not a gate.', 'pstack': 'Actual prospective final plan and separate consistency contexts; candidate review still required. Shared OpenAI lineage.', 'graft': 'Not rerun for a dependency-only source delta: all src/** blobs identical canonical base; prior static source navigation remains historical, no new graph/model finding claimed.', 'testerarmy_e2e': 'No changed browser/product source in this task. Existing native integration/full tests remain required. No new TesterArmy execution claimed.', 'telemetry': 'DO_NOT_TRACK=1; no paid/cloud runtime introduced.'}
(root / 'dependency-tool-execution.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result))
