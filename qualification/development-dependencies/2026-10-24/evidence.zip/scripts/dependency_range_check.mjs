// Read-only feasibility check using the installed native npm semver implementation.
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
const require = createRequire('C:/Program Files/nodejs/node_modules/npm/package.json');
const semver = require('semver');
const root = path.dirname(fileURLToPath(import.meta.url));
const before = JSON.parse(fs.readFileSync(path.join(root, 'dependency-before-lock.json'), 'utf8'));
const graph = JSON.parse(fs.readFileSync(path.join(root, 'dependency-first-native-native-graph.json'), 'utf8'));
const selected = graph.changes.filter(x => graph.expected_changed_paths.includes(x.path));
const proposed = structuredClone(before);
for (const entry of selected) proposed.packages[entry.path] = entry.after;
const checks = [];
for (const entry of selected) {
  for (const kind of ['dependencies', 'optionalDependencies', 'peerDependencies']) {
    for (const [name, range] of Object.entries(entry.after[kind] ?? {})) {
      const installed = proposed.packages[`node_modules/${name}`];
      const optional = kind === 'optionalDependencies' || (kind === 'peerDependencies' && entry.after.peerDependenciesMeta?.[name]?.optional === true);
      const satisfies = installed ? semver.satisfies(installed.version, range) : optional;
      checks.push({ package: entry.path || '<root>', kind, name, range, version: installed?.version ?? null, optional, satisfies });
    }
  }
}
const result = { method: 'Read-only target closure edge check against unchanged canonical existing entries using native npm semver. No candidate lock written; no dependency installed.', all_target_edges_satisfied: checks.every(x => x.satisfies), checks };
fs.writeFileSync(path.join(root, 'dependency-target-range-check.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ all_target_edges_satisfied: result.all_target_edges_satisfied, checks: checks.length, failures: checks.filter(x => !x.satisfies) }));
