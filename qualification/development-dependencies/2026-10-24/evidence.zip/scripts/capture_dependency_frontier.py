"""Reuse actual frontier reader with separate Task022 snapshots; no old evidence overwritten."""
import pathlib

path = pathlib.Path(__file__).with_name('capture_timing_frontier.py')
source = path.read_text(encoding='utf-8').replace('timing-frontier-', 'dependency-frontier-').replace('Task021', 'Task022')
exec(compile(source, str(path), 'exec'))
