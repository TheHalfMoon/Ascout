"""Bind observed matching historical timing failures without inventing causality."""
import hashlib, json, pathlib, re, subprocess

root = pathlib.Path(__file__).resolve().parent
runs = root.parent / 'engineering/runs'
repo = root.parent / 'engineering/main-control'
needles = ['preserves added, deleted, renamed, and modified tracked content as exact H tree', 'changes tree_digest_v1 when tracked worktree content mutates after the start snapshot']
observations = []
for prefix in ['durable-harness-full-suite-', 'e02-full-suite-', 'rc-repair-head-full-suite-', 'dep-repair-candidate-full-suite-', 'dep-repair-candidate-full-suite-isolated-']:
    matches = [path for path in runs.glob(prefix + '*.json') if '-isolated-' not in path.name or '-isolated-' in prefix]
    assert len(matches) == 1, (prefix, matches)
    capture_path = matches[0]
    capture = json.loads(capture_path.read_text())
    stdout = (runs / capture['stdout']).read_bytes()
    stderr = (runs / capture['stderr']).read_bytes()
    if capture['state'] == 'EXECUTED':
        assert hashlib.sha256(stdout).hexdigest() == capture['stdout_sha256']
        assert hashlib.sha256(stderr).hexdigest() == capture['stderr_sha256']
    head = capture['source_start']['head']
    manifest = json.loads(subprocess.check_output(['git', 'show', head + ':package.json'], cwd=repo))
    lines = [line for line in stdout.decode('utf-8').splitlines() if any(needle in line for needle in needles)]
    lines += [line for line in stderr.decode('utf-8').splitlines() if 'FAIL ' in line and any(needle in line for needle in needles)]
    observations.append({'capture': capture_path.name, 'capture_sha256': hashlib.sha256(capture_path.read_bytes()).hexdigest(), 'state': capture['state'], 'head': head, 'manifest_vitest_pin': manifest['devDependencies']['vitest'], 'native_exit': capture.get('exit'), 'stdout_sha256': hashlib.sha256(stdout).hexdigest(), 'stderr_sha256': hashlib.sha256(stderr).hexdigest(), 'exact_case_observations': lines})
result = {'observations': observations, 'interpretation': 'The exact T107 and drift cases failed their original5000ms budgets before Task022 at Vitest4.1.11, passed during Task021, and failed again during Task022 complete controls at Vitest4.1.12. The first Task022 control had review process overlap; the strictly serial second control still failed drift at5485ms. Both remain FAIL. This establishes matching historical timing debt, not a controlled before/after dependency comparison or proof of cause. Task022 dependency contribution remains unknown. No test/deadline/source change or further repeat-until-green is proposed here.', 'historical_remote_evidence': ['https://github.com/TheHalfMoon/Ascout/tree/e4a12b32264ad3d2cc3757095af56258da0cd099/qualification/durable-harness', 'https://github.com/TheHalfMoon/Ascout/tree/1f24cc68d837145224510d184dbbe10e0c326232/qualification/git-head-query/2026-10-24-closeout']}
(root / 'dependency-timing-context.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, indent=2))
