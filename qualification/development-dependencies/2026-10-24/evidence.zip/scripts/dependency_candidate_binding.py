"""Read-only exact installed/registry/license/notices binding for Task022."""
import hashlib, json, pathlib, stat, subprocess

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
directory = repo / 'node_modules'
assert directory.is_dir() and not directory.is_symlink() and not directory.is_junction()
assert not directory.lstat().st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT
assert directory.resolve().parent == repo.resolve()
graph = json.loads((root / 'dependency-native-graph.json').read_text())
assert graph['scope_clear']
lock = json.loads((repo / 'package-lock.json').read_text())
manifest = json.loads((repo / 'package.json').read_text())
registry = json.loads((root / 'dependency-closure-manifest.json').read_text())['records']
notices = (repo / 'THIRD_PARTY_NOTICES.md').read_text(encoding='utf-8')
records = []
for name in graph['expected_changed_paths']:
    if not name:
        continue
    package_name = name.removeprefix('node_modules/')
    installed = json.loads((repo / name / 'package.json').read_text())
    entry = lock['packages'][name]
    exact = next(record for record in registry if record['name'] == package_name and record['version'] == entry['version'])
    assert installed['name'] == package_name and installed['version'] == entry['version']
    assert entry['resolved'] == exact['dist']['tarball'] and entry['integrity'] == exact['dist']['integrity']
    assert entry['license'] == installed['license'] == exact['license']
    assert not set(installed.get('scripts', {})) & {'preinstall', 'install', 'postinstall', 'prepare'}
    if package_name in manifest['devDependencies']:
        assert manifest['devDependencies'][package_name] == entry['version']
        assert exact['dist']['tarball'] in notices and exact['dist']['integrity'] in notices
    records.append({'name': package_name, 'installed': installed['version'], 'registry_and_lock_tarball_integrity_equal': True, 'license': installed['license'], 'no_lifecycle_scripts': True})
result = {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip(), 'owned_physical_node_modules': True, 'entries': records, 'lock_sha256': hashlib.sha256((repo / 'package-lock.json').read_bytes()).hexdigest(), 'notice': 'Installed exact package metadata, registry and lock binding. Native npm ci verified tarball integrity; npm audit signatures is separately captured. No provenance or security approval inferred from metadata alone.'}
(root / 'dependency-candidate-binding.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result))
