"""Download explicit public Task021 files and verify bytes, members and hashes."""
import ast, base64, datetime, hashlib, io, json, pathlib, subprocess, sys, zipfile

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
head, branch, prefix = sys.argv[1:]
assert prefix in ['qualification/git-head-query/2026-10-24', 'qualification/git-head-query/2026-10-24-closeout']
sha = lambda data: hashlib.sha256(data).hexdigest()

def gh(*args):
    return json.loads(subprocess.check_output(['rtk', 'proxy', 'gh', *args]))

assert gh('api', 'repos/TheHalfMoon/Ascout/commits/' + branch)['sha'] == head
files = {}
for name in ['evidence-lock.json', 'evidence.zip', 'REPORT.md']:
    metadata = gh('api', 'repos/TheHalfMoon/Ascout/contents/' + prefix + '/' + name + '?ref=' + head)
    data = base64.b64decode(metadata['content']) if metadata.get('encoding') == 'base64' else base64.b64decode(gh('api', 'repos/TheHalfMoon/Ascout/git/blobs/' + metadata['sha'])['content'])
    assert data == (repo / prefix / name).read_bytes(), name
    files[name] = {'sha256': sha(data), 'bytes': len(data), 'git_blob': metadata['sha']}
    if name.endswith('.zip'):
        archive_data = data
    elif name.endswith('.json'):
        lock = json.loads(data)
assert lock['zip_sha256'] == sha(archive_data)
with zipfile.ZipFile(io.BytesIO(archive_data)) as archive:
    names = archive.namelist()
    assert len(names) == len(set(names)) == lock['members']
    assert archive.testzip() is None
    assert all(not pathlib.PurePosixPath(name).is_absolute() and '..' not in pathlib.PurePosixPath(name).parts and '\\' not in name for name in names)
    manifest = json.loads(archive.read('MANIFEST.json'))
    assert set(names) == {'MANIFEST.json'} | {item['path'] for item in manifest['records']}
    for item in manifest['records']:
        data = archive.read(item['path'])
        assert len(data) == item['bytes'] and sha(data) == item['published_sha256']
        if item['path'].endswith('.json'):
            json.loads(data)
        if item['path'].endswith('.py'):
            ast.parse(data.decode())
result = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head': head, 'branch': branch, 'path': prefix, 'remote_ref_verified': True, 'remote_bytes_equal_local': True, 'all_member_hashes_crc_json_python_verified': True, 'members': len(names), 'files': files, 'notice': 'Remote evidence durability only; no authentication of sanitized originals or release approval.'}
(root / ('timing-publication-receipt-' + head[:7] + '.json')).write_bytes((json.dumps(result, indent=2) + '\n').encode())
print(json.dumps(result))
