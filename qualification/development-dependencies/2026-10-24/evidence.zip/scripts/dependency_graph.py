"""Inspect the real native lock delta; never repairs or rewrites lock metadata."""
import hashlib, json, pathlib, subprocess

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
before_bytes = subprocess.check_output(['git', 'show', 'af5de7d1c56030d8842fc85c334cb8933d63fc08:package-lock.json'], cwd=repo)
after_bytes = (repo / 'package-lock.json').read_bytes()
before, after = json.loads(before_bytes), json.loads(after_bytes)
expected = {'node_modules/' + name for name in ['@vitest/coverage-v8', '@vitest/expect', '@vitest/mocker', '@vitest/pretty-format', '@vitest/runner', '@vitest/snapshot', '@vitest/spy', '@vitest/utils', 'vitest', 'vite', 'source-map-js']}
added = sorted(after['packages'].keys() - before['packages'].keys())
removed = sorted(before['packages'].keys() - after['packages'].keys())
changes = []
for name in sorted(before['packages'].keys() & after['packages'].keys()):
    old, new = before['packages'][name], after['packages'][name]
    if old != new:
        changes.append({'path': name, 'before': old, 'after': new, 'changed_fields': sorted(key for key in old.keys() | new.keys() if old.get(key) != new.get(key))})
changed_paths = {change['path'] for change in changes}
top_old = {key: value for key, value in before.items() if key != 'packages'}
top_new = {key: value for key, value in after.items() if key != 'packages'}
result = {'before_sha256': hashlib.sha256(before_bytes).hexdigest(), 'after_sha256': hashlib.sha256(after_bytes).hexdigest(), 'before_count': len(before['packages']), 'after_count': len(after['packages']), 'added': added, 'removed': removed, 'changes': changes, 'top_level_metadata_unchanged': top_old == top_new, 'expected_changed_paths': sorted(expected | {''}), 'unexpected_changed_paths': sorted(changed_paths - expected - {''}), 'missing_expected_changed_paths': sorted(expected - changed_paths), 'scope_clear': not added and not removed and top_old == top_new and changed_paths == expected | {''}}
(root / 'dependency-native-graph.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
(root / 'dependency-before-lock.json').write_bytes(before_bytes)
(root / 'dependency-after-lock.json').write_bytes(after_bytes)
print(json.dumps({key: value for key, value in result.items() if key != 'changes'}))
for change in changes:
    print(change['path'], change['before'].get('version'), '->', change['after'].get('version'), ','.join(change['changed_fields']))
