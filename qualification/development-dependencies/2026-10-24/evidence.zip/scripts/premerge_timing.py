"""Refresh actual Task021 gates at the last moment; never approves or merges."""
import datetime, json, pathlib, subprocess, sys

root = pathlib.Path(__file__).resolve().parent
number = int(sys.argv[1]); head = sys.argv[2]; base = sys.argv[3]

def gh(*args):
    return json.loads(subprocess.check_output(['rtk', 'proxy', 'gh', *args]))

pr = gh('pr', 'view', str(number), '--repo', 'TheHalfMoon/Ascout', '--json', 'headRefOid,baseRefOid,state,isDraft,statusCheckRollup,reviews,mergeable,mergeStateStatus')
assert pr['state'] == 'OPEN' and pr['headRefOid'] == head and pr['baseRefOid'] == base
assert gh('api', 'repos/TheHalfMoon/Ascout/commits/main')['sha'] == base
checks = pr['statusCheckRollup']; assert len(checks) == 7
assert all(check['status'] == 'COMPLETED' and check['conclusion'] == 'SUCCESS' for check in checks)
for run_id in {check['detailsUrl'].split('/runs/')[1].split('/')[0] for check in checks}:
    metadata = gh('api', 'repos/TheHalfMoon/Ascout/actions/runs/' + run_id)
    assert metadata['head_sha'] == head and metadata['status'] == 'completed' and metadata['conclusion'] == 'success'
    jobs = gh('api', 'repos/TheHalfMoon/Ascout/actions/runs/' + run_id + '/jobs?per_page=100')
    assert jobs['total_count'] == len(jobs['jobs'])
    assert all(job['status'] == 'completed' and job['conclusion'] == 'success' for job in jobs['jobs'])
assert not any(review['state'] == 'CHANGES_REQUESTED' for review in pr['reviews'])
query = 'query($number:Int!){repository(owner:"TheHalfMoon",name:"Ascout"){pullRequest(number:$number){reviewThreads(first:100){nodes{isResolved}pageInfo{hasNextPage}}}}}'
threads = gh('api', 'graphql', '-f', 'query=' + query, '-F', 'number=' + str(number))['data']['repository']['pullRequest']['reviewThreads']
assert not threads['pageInfo']['hasNextPage'] and all(thread['isResolved'] for thread in threads['nodes'])
assert pr['mergeable'] == 'MERGEABLE' and pr['mergeStateStatus'] in ['CLEAN', 'DRAFT']
out = root.parent / 'engineering/merges'; out.mkdir(exist_ok=True)
record = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'purpose': 'Last-moment read-only gate refresh, no approval/merge performed', 'number': number, 'head': head, 'base': base, 'pr': pr, 'review_threads': threads, 'authority_reference': 'Direct user repair/continuing autonomous engineering direction after fresh Task021 plan/gate and exact-head consistency audits. PLAN_CLEAR does not grant authority or waive qualification. Scope excludes UA-P07 and unrelated draft branches.'}
(out / (str(number) + '-premerge.json')).write_bytes((json.dumps(record, indent=2) + '\n').encode())
print(json.dumps({'number': number, 'head': head, 'base': base, 'checks': len(checks), 'threads': len(threads['nodes']), 'mergeable': pr['mergeable']}))
