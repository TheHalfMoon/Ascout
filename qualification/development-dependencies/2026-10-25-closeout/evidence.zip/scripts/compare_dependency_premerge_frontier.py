"""Compare current governing/foreign-branch facts with the preserved resumed frontier."""
import hashlib, json, pathlib

root = pathlib.Path(__file__).resolve().parent
before_path = root / 'dependency-frontier-resume-20261025.json'
after_path = root / 'dependency-frontier-premerge.json'
before, after = json.loads(before_path.read_text()), json.loads(after_path.read_text())
governing = ['main', 'main_tree', 'main_protected', 'protection_query_exit', 'protection_message', 'rulesets', 'issue618', 'governing_file_sha256']
assert all(before[key] == after[key] for key in governing)
old_prs = {item['number']: item for item in before['open_prs']}
new_prs = {item['number']: item for item in after['open_prs']}
assert set(new_prs) - set(old_prs) == {644} and not set(old_prs) - set(new_prs)
assert all(old_prs[number] == new_prs[number] for number in old_prs)
def refs(value):
    return {line.split()[1]: line.split()[0] for line in value['remote_head_refs']}
old_refs, new_refs = refs(before), refs(after)
assert old_refs.keys() == new_refs.keys()
changed = [name for name in old_refs if old_refs[name] != new_refs[name]]
assert changed == ['refs/heads/ps/rea-e05-dependency-patches']
assert old_refs[changed[0]] == '43848672b2c68380d8b01797004ee57a02cbf984'
assert new_refs[changed[0]] == 'c429ab07170db92192e574e0add9d1af330f3ef2'
record = {'main': after['main'], 'governing_facts_unchanged': governing, 'all_foreign_prs_and_remote_heads_unchanged': True, 'own_pr_added': 644, 'own_ref_forward_only': {'before': old_refs[changed[0]], 'after': new_refs[changed[0]]}, 'before_sha256': hashlib.sha256(before_path.read_bytes()).hexdigest(), 'premerge_sha256': hashlib.sha256(after_path.read_bytes()).hexdigest(), 'notice': 'Read-only comparison, not an approval. Last-moment actual head/base/check/review/thread/mergeability gates remain separately required. No governance settings changed.'}
(root / 'dependency-frontier-merge-comparison.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps(record))
