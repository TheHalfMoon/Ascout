// Independent diagnostic using public Node APIs, not process capture or suite qualification.
import childProcess from 'node:child_process';
import { syncBuiltinESMExports } from 'node:module';
import { createHash, randomUUID } from 'node:crypto';
import { mkdtempSync, readFileSync, realpathSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { basename, dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = dirname(fileURLToPath(import.meta.url));
const repo = realpathSync(process.argv[2]);
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const original = childProcess.spawnSync;
const env = { ...process.env, GIT_CONFIG_GLOBAL: '/dev/null', GIT_CONFIG_SYSTEM: '/dev/null', GIT_TERMINAL_PROMPT: '0' };
function git(cwd, argv) {
  const start = performance.now();
  const result = original('git', argv, { cwd, env, encoding: 'utf8', shell: false, timeout: 10000, windowsHide: true });
  if (result.error || result.status !== 0) throw new Error('Diagnostic native Git command failed: ' + argv[0]);
  return { text: result.stdout.trim(), elapsed_ms: performance.now() - start };
}
const head = git(repo, ['rev-parse', 'HEAD']).text;
const sourceHash = hash(readFileSync(join(repo, 'src/git.ts')));
const compiledHash = hash(readFileSync(join(repo, 'dist/git.js')));
let observation = null;
childProcess.spawnSync = function(file, argv, options) {
  const start = performance.now();
  const result = original(file, argv, options);
  if (observation && file === 'git') observation.commands.push({ argv: [...argv], elapsed_ms: performance.now() - start, status: result.status, error: result.error?.name ?? null });
  return result;
};
syncBuiltinESMExports();
const { readTreeDigestV1 } = await import(pathToFileURL(join(repo, 'dist/git.js')).href);
const samples = [];
for (let iteration = 0; iteration < 3; iteration++) {
  const fixture = mkdtempSync(join(tmpdir(), 'ascout-drift-diagnostic-'));
  const owner = randomUUID();
  if (dirname(realpathSync(fixture)) !== realpathSync(tmpdir()) || !basename(fixture).startsWith('ascout-drift-diagnostic-') || resolve(fixture) !== realpathSync(fixture)) throw new Error('Unexpected fixture containment');
  const setup = [];
  const setupStart = performance.now();
  for (const args of [['init', '-q'], ['config', 'user.name', 'Ascout Test'], ['config', 'user.email', 'fixture.invalid'], ['config', 'commit.gpgSign', 'false'], ['config', 'core.autocrlf', 'false']]) setup.push({ argv: args, ...git(fixture, args) });
  writeFileSync(join(fixture, 'tracked.txt'), 'start\n');
  for (const args of [['add', '--all'], ['commit', '-q', '-m', 'base']]) setup.push({ argv: args, ...git(fixture, args) });
  const setupMs = performance.now() - setupStart;
  observation = { commands: [] };
  const start = performance.now();
  const first = readTreeDigestV1(fixture);
  writeFileSync(join(fixture, 'tracked.txt'), 'mutated\n');
  const second = readTreeDigestV1(fixture);
  const readMs = performance.now() - start;
  if (first.unstaged_changed_count !== 0 || second.unstaged_changed_count !== 1 || first.tree_digest === second.tree_digest) throw new Error('Native drift semantic check failed');
  // Ownership marker is written only after measured observations to avoid extra untracked input.
  writeFileSync(join(fixture, '.ascout-owned-drift-diagnostic'), owner);
  samples.push({ iteration, fixture, owner, setup_git_processes: setup.length, setup_ms: setupMs, setup_commands: setup, reader_git_processes: observation.commands.length, reader_ms: readMs, measured_setup_plus_reader_ms: setupMs + readMs, commands: observation.commands, first, second });
  observation = null;
}
childProcess.spawnSync = original;
syncBuiltinESMExports();
if (git(repo, ['rev-parse', 'HEAD']).text !== head || hash(readFileSync(join(repo, 'src/git.ts'))) !== sourceHash || hash(readFileSync(join(repo, 'dist/git.js'))) !== compiledHash) throw new Error('Diagnostic source drifted');
const result = { observed_at_utc: new Date().toISOString(), head, source_sha256: sourceHash, compiled_sha256: compiledHash, helper_sha256: hash(readFileSync(fileURLToPath(import.meta.url))), samples, limitations: 'Actual native Git execution observed through public Node spawnSync/syncBuiltinESMExports in this independent diagnostic only. No product or test source mutation, OS process capture, REA safety bypass, default-runner security qualification or native-suite PASS claim. No cleanup is measured; fixture identity uses a harmless non-email diagnostic identity. Timings include instrumentation. These observations do not recover historical timeout causation, isolate dependency contribution or prove production readiness. Owned fixtures retained for later verified cleanup.' };
const target = join(root, 'dependency-drift-native-diagnostic.json');
writeFileSync(target, JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ head, samples: samples.map(({ setup_git_processes, reader_git_processes, measured_setup_plus_reader_ms }) => ({ setup_git_processes, reader_git_processes, measured_setup_plus_reader_ms })) }));
