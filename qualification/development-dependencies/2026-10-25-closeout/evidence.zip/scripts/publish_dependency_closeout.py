"""Task022 closing-only extension; keep the previously published producer immutable."""
import hashlib, json, pathlib, sys, zipfile

root = pathlib.Path(__file__).resolve().parent
path = root / 'publish_dependencies.py'
merge = json.loads((root.parent / 'engineering/merges/644.json').read_text())
assert merge['merge'] == '62e588adda04dda1a517742fe10af352e5dfa83f'
assert merge['tree_equal'] and merge['github_signature_verification']['verified']
postmerge = json.loads((root / 'dependency-ci-postmerge-62e588a/summary.json').read_text())
assert postmerge['head'] == merge['merge']
assert postmerge['all_actual_jobs_success'] and postmerge['six_actual_native_full_suites_verified']
initial = root.parent / 'engineering/main-control/qualification/development-dependencies/2026-10-24/evidence.zip'
assert hashlib.sha256(initial.read_bytes()).hexdigest() == '29ead476a64393f75f5d069072ef9f16a2e49d4fb7818cecdc3ca35fe3d02ae8'
with zipfile.ZipFile(initial) as archive:
    manifest = json.loads(archive.read('MANIFEST.json'))
    original = next(item for item in manifest['records'] if item['path'] == 'scripts/publish_dependencies.py')
    assert hashlib.sha256(path.read_bytes()).hexdigest() == original['original_sha256']
source = path.read_text(encoding='utf-8')
source = source.replace('2026-10-24-closeout', '2026-10-25-closeout')
source = source.replace("for directory in sorted(root.glob('dependency-ci-*')):", "for directory in sorted(path for path in root.glob('dependency-ci-*') if path.is_dir()):")
needle = "manifest = {'authority': 'TASK022_QUALIFICATION_OBSERVATIONS_ONLY'"
assert source.count(needle) == 1
extra = '''for name in ['publish_dependency_closeout.py', 'verify_dependency_closeout.py', 'compare_dependency_premerge_frontier.py', 'drift_native_probe.mjs']:
    add('scripts/' + name, root / name)
for name in ['dependency-publication-review-c429ab0.json', 'dependency-publication-receipt-c429ab0.json']:
    add('context/' + name, root / name)

'''
source = source.replace(needle, extra + needle)
sys.argv = [str(path), '--close']
exec(compile(source, str(path), 'exec'))
