"""Download Task022 October25 closing bytes; previous verification helper remains frozen."""
import pathlib

path = pathlib.Path(__file__).with_name('verify_timing_publication.py')
source = path.read_text(encoding='utf-8').replace('qualification/git-head-query/', 'qualification/development-dependencies/').replace('2026-10-24-closeout', '2026-10-25-closeout').replace('timing-publication-receipt-', 'dependency-publication-receipt-').replace('Task021', 'Task022')
exec(compile(source, str(path), 'exec'))
