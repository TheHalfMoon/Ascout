"""Actual immutable Task028 public core/member byte readback."""
import pathlib

path=pathlib.Path(__file__).with_name('verify_timing_publication.py')
source=path.read_text(encoding='utf-8').replace('qualification/git-head-query/2026-10-24','qualification/self-browser-readiness/2026-10-27').replace('timing-publication-receipt-','browser-readiness-publication-receipt-')
exec(compile(source,str(path),'exec'))
