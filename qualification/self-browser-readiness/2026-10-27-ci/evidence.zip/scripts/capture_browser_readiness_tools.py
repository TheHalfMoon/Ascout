"""Actual free local Alibaba scope preview and rule lookup, not model review."""
import datetime,hashlib,json,os,pathlib,subprocess

root=pathlib.Path(__file__).resolve().parent
repo=root.parent/'engineering/main-control'
head=subprocess.check_output(['rtk','proxy','git','rev-parse','HEAD'],cwd=repo).decode().strip()
assert head=='53efe84dbc1550742b09cb3bae58a6a9a1c295a2'
ocr=pathlib.Path.home()/'AppData/Roaming/npm/node_modules/@alibaba-group/open-code-review/bin/ocr.js'
commands=[('alibaba-preview',['C:/Program Files/nodejs/node.exe',str(ocr),'delegate','preview','--from','7a089771aaad8f599b2ee342cf2c17eac19f547b','--to',head]),
 ('alibaba-rules',['C:/Program Files/nodejs/node.exe',str(ocr),'delegate','rule','.github/workflows/self-verify.yml'])]
records=[]
for label,argv in commands:
    result=subprocess.run(['rtk','proxy',*argv],cwd=repo,env={**os.environ,'DO_NOT_TRACK':'1'},capture_output=True,timeout=180)
    for stream in ['stdout','stderr']:
        (root/('browser-readiness-tool-'+label+'.'+stream+'.txt')).write_bytes(getattr(result,stream))
    records.append({'label':label,'argv':argv,'exit':result.returncode,'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(result.stderr).hexdigest()})
record={'observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'commands':records,
 'notice':'Actual local preview/rules only, not Claude/model/provider code approval. PStack fresh separate source/workflow-security reviews remain independent role bars, shared OpenAI lineage disclosed. D1 actual triage advisory only. All435 product/test/benchmark entries are unchanged: prior leaf-bound local controls and actual hosted browser/E2E evidence are reused with original outcomes; no fresh unrelated Graft/TesterArmy execution claimed. The changed workflow requires actual final-head/canonical setup/matrix/Self capture. No paid service/dependency/cloud runtime/UA-P07/admission or release waiver.'}
(root/'browser-readiness-tool-execution.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
print(json.dumps({'head':head,'commands':[{'label':x['label'],'exit':x['exit']} for x in records],'kind':'LOCAL_SCOPE_RULES_ONLY'}))
