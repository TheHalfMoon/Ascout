"""Actual Task028 hosted full suites plus the new Self setup prerequisite."""
import hashlib,pathlib

path=pathlib.Path(__file__).with_name('capture_timing_ci.py')
assert hashlib.sha256(path.read_bytes()).hexdigest()=='cc8a199c6e3f5d35c3a02047bdd0229d9ff22466c8e871daacdfb706eccc4fe4'
source=path.read_text(encoding='utf-8')
assert source.count('2425')==1
source=source.replace("'timing-ci-'","'browser-readiness-ci-'").replace('TASK021_ACTUAL_','TASK028_ACTUAL_').replace('2425','2469')
source=source.replace('native_files = [',"native_files = ['self-verify-clean-state.native.test.ts', 'git-index-observation.test.ts', 'browser-cleanup-ownership.test.ts', ")
old="['Guard exact PR head', 'Install exact lockfile', 'Build exact PR head'"
new="['Guard exact PR head', 'Install exact lockfile', 'Provision exact Chromium runtime', 'Build exact PR head'"
assert source.count(old)==1
source=source.replace(old,new)
exec(compile(source,str(path),'exec'))
