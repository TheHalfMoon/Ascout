"""Inspect actual Task027 inner Self truth without promoting badge success."""
import datetime,hashlib,json,pathlib,sys

root=pathlib.Path(__file__).resolve().parent
head=sys.argv[1]
directory=root/('clean-state-ci-'+head[:7])
summary=json.loads((directory/'summary.json').read_text())
receipt=json.loads((directory/'self-verification-receipt.json').read_text())
envelope=json.loads((directory/'self-verification-envelope.json').read_text())
selector=json.loads((directory/'selector-shadow-observation.json').read_text())
assert summary['head']==envelope['subject_target_head_sha']==envelope['verifier_head_sha']==head
assert envelope['receipt_sha256']==hashlib.sha256((directory/'self-verification-receipt.json').read_bytes()).hexdigest()
assert receipt['source']['start']==receipt['source']['end']
assert receipt['source']['start']['head_sha']==envelope['subject_merge_base_sha']=='36768f4ffe1e2c18492cb3a8fdccd9274c2c615a'
test=next(task for task in receipt['tasks'] if task['task_type']=='test')
result={'observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,
 'actual_artifact':summary['self_artifact'],'receipt_summary':receipt['summary'],'selection':receipt['selection'],
 'test_task':{'status':test['status'],'exit':test.get('exit_code'),'duration_ms':test.get('duration_ms'),'observations':test.get('observations'),'output_truncated':test.get('output_truncated')},
 'exercise':receipt['exercise'],'reconstructed_subject_head':receipt['source']['start']['head_sha'],'exact_target_head':head,
 'source_start_end_equal':True,'selector_comparison':selector['comparison'],
 'notice':'Actual current inner Self evidence; retain nonzero/incomplete outcomes. Reconstructed base HEAD is the staged-subject contract, with exact target tree bound by envelope/receipt. Bounded artifact excludes referenced raw testJSON/LCOV payloads, so their hashes cannot be independently recomputed from this artifact. Current outcome cannot resolve historical Task02463unresolved lines, original local FAIL6plus hook or unknown fixture initialization cause. Selector unavailable/full fallback stays explicit. No changed-command-surface admission, historical cause/exoneration, provider-independent certification, gate waiver or release approval.'}
(root/'clean-state-self-inspection.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
print(json.dumps({'head':head,'inner_summary':receipt['summary'],'test_status':test['status'],'selection':receipt['selection'],'selector':selector['comparison']}))
