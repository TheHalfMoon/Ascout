"""Copy the reviewed existing setup step after recorded bounded authority."""
import datetime,hashlib,json,pathlib,subprocess

root=pathlib.Path(__file__).resolve().parent
repo=root.parent/'engineering/main-control'
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['rtk','proxy','git',*args],cwd=repo)
head=git('rev-parse','HEAD').decode().strip()
assert head=='1a5b4448097a0926567f6b4f1223f1326b899a12'
assert not git('status','--porcelain').strip()
baseline=json.loads((root/'browser-readiness-baseline.json').read_text())
entries={row.split(b'\t',1)[1].decode():row.split(b'\t',1)[0].decode() for row in git('ls-tree','-r','-z','HEAD','--','src','tests','benchmarks').split(b'\0') if row}
assert entries==baseline['source_git_entries'] and len(entries)==435
assert all(sha((repo/name).read_bytes())==digest for name,digest in baseline['bindings'].items())
source=(repo/'.github/workflows/ci.yml').read_bytes()
lines=source.splitlines(keepends=True)
index=next(i for i,line in enumerate(lines) if line.strip()==b'- name: Provision exact Chromium runtime')
block=b''.join(lines[index:index+3])
assert block==baseline['existing_project_ci_step']['text'].encode()
assert sha(block)==baseline['existing_project_ci_step']['sha256']
target=repo/'.github/workflows/self-verify.yml'
before=target.read_bytes()
marker=b'      - name: Build exact PR head\n'
assert before.count(marker)==1 and b'Provision exact Chromium runtime' not in before
after=before.replace(marker,block+b'\n'+marker,1)
assert after.replace(block+b'\n',b'',1)==before
target.write_bytes(after)
assert all(sha((repo/name).read_bytes())==digest for name,digest in baseline['bindings'].items() if name!='.github/workflows/self-verify.yml')
record={'observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'authority_head':head,
 'authority_tree':git('rev-parse','HEAD^{tree}').decode().strip(),'target':'.github/workflows/self-verify.yml',
 'before_sha256':sha(before),'after_sha256':sha(after),'source_step_sha256':sha(block),'source_step_bytes':len(block),
 'frozen_source_entries':435,'unchanged_nontarget_control_hashes':14,
 'mechanical_checks':['Exact recorded source block copied byte-for-byte','Removing the one inserted block plus separator recovers original target bytes','All435 source/test/benchmark entries unchanged','All14 nontarget control hashes unchanged'],
 'execution':'Workflow file written only; no browser installer, test, build, new local full suite or hosted job executed.',
 'notice':'Bounded prerequisite setup change, not proof of the prior browser failure cause. Original localFAIL6plus hook, Self inner1/FLAKY/materially incomplete, UNKNOWN causes and E00/release blockers retained. Fresh actual-diff reviews and actual final-head/canonical hosted gates remain; no admission or UA-P07 waiver.'}
payload=(json.dumps(record,indent=2)+'\n').encode()
path=root/'browser-readiness-implementation.json';assert not path.exists();path.write_bytes(payload)
(repo/'qualification/self-browser-readiness/2026-10-27/implementation.json').write_bytes(payload)
for name in ['specs/028-self-browser-readiness/spec.md','specs/028-self-browser-readiness/tasks.md']:
    path=repo/name
    text='\n'.join(('Status: IMPLEMENTED_PENDING_ACTUAL_DIFF_REVIEW. Existing pinned Chromium setup step copied after recorded audit/consistency/user-derived authority;435source entries/14nontarget controls unchanged. No hosted execution yet; original adverse outcomes retained and E00/release BLOCKED.' if line.startswith('Status:') else line) for line in path.read_text().splitlines())+'\n'
    path.write_bytes(text.encode())
path=repo/'STATE.md'
path.write_bytes(('''Last updated: 2026-10-27 Asia/Riyadh · Branch: ps/rea-self-browser-readiness

Task028 workflow-only implementation is pending actual-diff reviews. Final plan audit1757f56 PLAN_CLEAR, different consistency51fb2f4 CONSISTENCY_CLEAR, bounded user authority1a5b444 all precede the first edit. The exact existing pinned Chromium1.63.0 setup step is now copied into Self after lock install/before build/capture. Mechanical removal recovers original target bytes; all435source/test/benchmark entries and14nontarget controls unchanged. No hosted execution or local test/build/browser setup occurred for this change.

Task027/PR649 is focused CLOSED_CANONICAL onmain7a08977 with actual final9812e4a3core6sidecar180-member proof verified before this branch. Prior Self inner1/FLAKY/materially incomplete (2runs1failure), localfullFAIL6plus hook and UNKNOWN browser/fixture causes remain. Upfront prerequisite gap is observed; its relation to the prior failure remains unproved. E00/release BLOCKED.

Next: fresh actual-diff correctness/product/parsimony and separate workflow-boundary/security, actual advisory/rule scope, minimized evidence/publication, focused PR and actual hosted setup/matrix/Self truth, live eligibility and canonical/closing remote gates. No duplicate local full run for an unchanged local source tree, no paid service/new dependency/cloud requirement/global config/deadline/admission/UA-P07 or release waiver. Raw evidence retained.
''').encode())
print(json.dumps(record))
