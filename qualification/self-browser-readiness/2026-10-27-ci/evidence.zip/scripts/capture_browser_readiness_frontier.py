"""Task028 separate read-only live frontier namespace."""
import pathlib

path=pathlib.Path(__file__).with_name('capture_timing_frontier.py')
source=path.read_text(encoding='utf-8').replace('timing-frontier-','browser-readiness-frontier-').replace('Task021','Task028')
exec(compile(source,str(path),'exec'))
