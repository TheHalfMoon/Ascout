"""Read-only Task028 baseline after actual final Task027 remote proof."""
import datetime,hashlib,json,pathlib,subprocess

root=pathlib.Path(__file__).resolve().parent
repo=root.parent/'engineering/main-control'
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['rtk','proxy','git',*args],cwd=repo)
assert git('rev-parse','HEAD').decode().strip()=='7a089771aaad8f599b2ee342cf2c17eac19f547b'
assert not git('status','--porcelain').strip()
previous='9812e4abb57d40ac563aa26e37e6fda00b06225c'
core=json.loads((root/('clean-state-closing-publication-receipt-'+previous[:7]+'.json')).read_text())
sidecars=json.loads((root/('clean-state-closing-sidecars-readback-'+previous[:7]+'.json')).read_text())
assert core['head']==sidecars['head']==previous and core['members']==180
assert core['remote_ref_verified'] and core['remote_bytes_equal_local'] and core['all_member_hashes_crc_json_python_verified']
assert sidecars['remote_ref_and_all_sidecar_bytes_verified'] and len(sidecars['records'])==6
entries={row.split(b'\t',1)[1].decode():row.split(b'\t',1)[0].decode() for row in git('ls-tree','-r','-z','HEAD','--','src','tests','benchmarks').split(b'\0') if row}
assert len(entries)==435
paths=['.github/workflows/self-verify.yml','.github/workflows/ci.yml','src/browser/playwright-adapter.ts','tests/browser-playwright-adapter.contract.test.ts','benchmarks/self-verify.mjs','benchmarks/selector-shadow.mjs','package.json','package-lock.json','tsconfig.json','vitest.config.ts','CONTRIBUTING.md','.specify/PROVENANCE.md','.specify/memory/constitution.md','src/discovery.ts','src/check.ts']
bindings={name:sha((repo/name).read_bytes()) for name in paths}
ci=(repo/'.github/workflows/ci.yml').read_text()
self_workflow=(repo/'.github/workflows/self-verify.yml').read_text()
lines=ci.splitlines()
index=next(i for i,line in enumerate(lines) if line.strip()=='- name: Provision exact Chromium runtime')
block='\n'.join(lines[index:index+3])+'\n'
assert "pkg.version!=='1.63.0'" in block and "['install','--with-deps','chromium']" in block
assert 'Provision exact Chromium runtime' not in self_workflow
inspection=json.loads((root/'clean-state-self-inspection.json').read_text())
assert inspection['receipt_summary']['exit_code']==1 and inspection['test_task']['status']=='FLAKY'
record={'observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':git('rev-parse','HEAD').decode().strip(),
 'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'source_git_entries':entries,'bindings':bindings,
 'predecessor_core':core,'predecessor_sidecars':sidecars,'predecessor_remote_head':previous,
 'prior_self_inspection_sha256':sha((root/'clean-state-self-inspection.json').read_bytes()),
 'prior_self_summary':inspection['receipt_summary'],'prior_self_test':inspection['test_task'],
 'existing_project_ci_step':{'path':'.github/workflows/ci.yml','text':block,'sha256':sha(block.encode())},
 'hypothesis':'Self lacks an explicit pre-test Chromium setup step while Project CI has one. Reuse that exact pinned-version/fixed-argv step before Self capture to establish the same prerequisite. The runtime helper can lazily provision already; no claim that absent upfront setup caused the earlier browser finding, since the original failure payload was not uploaded.',
 'planned_existing_executable_change_only':'.github/workflows/self-verify.yml',
 'notice':'Read-only preparation only after actual final9812e4a three-core-file/six-sidecar/180-member remote readback and Task027 focused closure. No source/test/fixture/control/workflow change or new native execution yet. All435 source/test/benchmark entries, existing deadlines/skips, lock/dependencies and authority remain frozen. Any future authority refusal stays explicit; no --allow-changed-command-surface or UA-P07. Historical local failures, current Self FLAKY/materially incomplete, UNKNOWN causes and E00/release blockers remain. No paid services or required new cloud/dependencies.'}
path=root/'browser-readiness-baseline.json';assert not path.exists()
path.write_bytes((json.dumps(record,indent=2)+'\n').encode())
print(json.dumps({'head':record['head'],'frozen_entries':435,'bindings':len(bindings),'prior_self_exit':1,'implementation':'NOT_STARTED'}))
