"""Explicit Task028 minimized qualification evidence; no new runtime/test execution."""
import ast,hashlib,json,pathlib,re,subprocess,zipfile

root=pathlib.Path(__file__).resolve().parent
repo=root.parent/'engineering/main-control'
destination=repo/'qualification/self-browser-readiness/2026-10-27'
producer=root/'publish_dependencies.py'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(producer.read_bytes())=='87d1e9597dc89e9727821808a7790089d50b4574c012aa1f30f6a9f8770b32d1'
members,records={},[]
functions=[n for n in ast.parse(producer.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in ['minimize','sanitize','add']]
exec(compile(ast.Module(body=functions,type_ignores=[]),str(producer),'exec'))
context=['baseline','frontier-refresh','plan-audit-1757f56','consistency-51fb2f4','implementation','correctness-53efe84','security-53efe84','d1-status','d1-review','tool-execution']
for name in context:add('context/browser-readiness-'+name+'.json',root/('browser-readiness-'+name+'.json'))
for path in sorted(root.glob('browser-readiness-tool-*.txt')):add('tools/'+path.name,path)
scripts=['publish_browser_readiness.py','publish_dependencies.py','freeze_browser_readiness_baseline.py','capture_browser_readiness_frontier.py','capture_timing_frontier.py','implement_browser_readiness.py','capture_browser_readiness_tools.py','capture_browser_readiness_ci.py','capture_timing_ci.py','inspect_browser_readiness_self.py','inspect_clean_state_self.py','verify_browser_readiness_publication.py','verify_timing_publication.py']
for name in scripts:add('scripts/'+name,root/name)
manifest={'authority':'TASK028_WORKFLOW_QUALIFICATION_OBSERVATIONS_ONLY',
 'notice':'Explicit minimized JSON/text/source derivatives with original/published hashes. Baseline records actual predecessor9812e4a core/six-sidecar/180-member remote proof.435source/test/benchmark entries and14nontarget controls frozen; only existing Project CI pinned Chromium step copied to Self. Actual local D1 advisory and Alibaba preview/rules only, no model/provider gate approval. No browser installer/local test/build/new complete local suite or hosted job has executed for Task028 at packet preparation; all later actual hosted gates remain separate. Earlier fullFAIL6plus hook, Self inner1/FLAKY/materially incomplete, UNKNOWN causes, Task024 provenance and unavailable selector remain. Security review discloses its read-only bootstrap command deviations; no evidence is erased. Personal homes/emails/author/raw-signature fields minimized; no credentials/account quota data/cache/private REA/raw full manuals/installed dependencies/opaque artifacts. Same-provider role separation, no authentication of minimized originals, universal security certification, causal claim, admission/UA-P07/policy waiver or release approval.',
 'records':records}
members['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
archive=destination/'evidence.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as output:
    for name,data in sorted(members.items()):
        info=zipfile.ZipInfo(name,date_time=(2000,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
        output.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
with zipfile.ZipFile(archive) as output:
    assert len(output.namelist())==len(set(output.namelist())) and output.testzip() is None
    for record in records:assert sha(output.read(record['path']))==record['published_sha256']
lock={'zip_sha256':sha(archive.read_bytes()),'members':len(members),'source_head':subprocess.check_output(['rtk','proxy','git','rev-parse','HEAD'],cwd=repo).decode().strip(),'notice':manifest['notice']}
(destination/'evidence-lock.json').write_bytes((json.dumps(lock,indent=2)+'\n').encode())
print(json.dumps(lock))
