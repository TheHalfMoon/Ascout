"""Persist actual premerge results without changing PR650's qualified source head."""
import ast,json,pathlib

root=pathlib.Path(__file__).resolve().parent
producer=root/'publish_browser_readiness.py'
summary=json.loads((root/'browser-readiness-ci-9286f8e/summary.json').read_text())
assert summary['head']=='9286f8e83af5bae786a69427c629eb31d7626ff2'
assert summary['all_actual_jobs_success'] and summary['six_actual_native_full_suites_verified']
assert summary['self_artifact']['inner_exit']==0
source=producer.read_text(encoding='utf-8').replace("destination=repo/'qualification/self-browser-readiness/2026-10-27'","destination=repo/'qualification/self-browser-readiness/2026-10-27-ci'")
assert source!=producer.read_text(encoding='utf-8')
tree=ast.parse(source)
extra=ast.parse('''
directory=root/'browser-readiness-ci-9286f8e'
for path in sorted(directory.iterdir()):
    if path.suffix in ['.json','.log','.txt']:
        add('ci/'+directory.name+'/'+path.name,path)
for name in ['browser-readiness-self-inspection.json','browser-readiness-publication-review-eba4030.json','browser-readiness-publication-receipt-9286f8e.json','browser-readiness-sidecars-readback-9286f8e.json','browser-readiness-pr-number.json','browser-readiness-ci-review-unavailable.json']:
    add('actual/'+name,root/name)
add('scripts/publish_browser_readiness_ci_checkpoint.py',root/'publish_browser_readiness_ci_checkpoint.py')
''').body
for index,node in enumerate(tree.body):
    if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='manifest' for t in node.targets):
        tree.body[index:index]=extra
        break
else:raise AssertionError('Manifest declaration missing')
notice=ast.parse("manifest['notice'] += ' This forward CI checkpoint additionally preserves actual final-head seven-job logs/metadata and decoded Self artifact JSON: setup succeeded, six native full suites passed, Self inner0/complete. Required fresh CI review could not finish and produced no report; no review/merge/closure or release approval is inferred. Original opaque ZIP is excluded; its actual advertised digest/CRC/member bindings are retained. PR650 source head remains9286f8e; no workflow rerun or source change was requested.'").body
for index,node in enumerate(tree.body):
    if isinstance(node,ast.Assign) and any(isinstance(t,ast.Subscript) and isinstance(t.value,ast.Name) and t.value.id=='members' for t in node.targets):
        tree.body[index:index]=notice
        break
else:raise AssertionError('Manifest serialization missing')
ast.fix_missing_locations(tree)
exec(compile(tree,str(producer),'exec'))
