"""Actual local rule/navigation execution; no model or paid service invocation."""
import datetime, hashlib, json, os, pathlib, subprocess
root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/durability'
head = subprocess.check_output(['rtk','proxy','git','rev-parse','HEAD'], cwd=repo).decode().strip()
assert head == 'f689c476b717422dbd0619f60c32819457e699ff'
assert not subprocess.check_output(['rtk','proxy','git','status','--porcelain'], cwd=repo).strip()
ocr = '<USERPROFILE>/AppData/Roaming/npm/node_modules/@alibaba-group/open-code-review/bin/ocr.js'
graft = '<USERPROFILE>/AppData/Roaming/npm/node_modules/@nanonets/graft/dist/cli.js'
env = {**os.environ, 'DO_NOT_TRACK':'1', 'GRAFT_TELEMETRY':'0', 'GRAFT_API_KEY':'', 'GRAFT_NO_GITIGNORE':'1', 'GRAFT_NO_IGNORE':'1'}
commands = [
 ('alibaba-preview', ['node',ocr,'delegate','preview','--from','89e5f01d7b77a92099961dff21e28052e5fa8dcc','--to',head]),
 ('alibaba-rules', ['node',ocr,'delegate','rule','src/assurance/workflow/durable-harness.ts','src/assurance/workflow/durable-harness-store.ts','tests/assurance-durable-harness.test.ts','tests/assurance-durable-harness.native.test.ts','docs/ascout-durable-harness.md']),
 ('graft-build', ['node',graft,'--dir',str(root/'graft-graph'),'build',str(repo),'--only-dir','src/assurance/workflow','--no-gitignore','--no-ignore']),
]
records = []
for label, command in commands:
    p = subprocess.run(['rtk','proxy',*command],cwd=repo,env=env,capture_output=True,timeout=180)
    (root/('tool-'+label+'.txt')).write_bytes(p.stdout)
    (root/('tool-'+label+'.stderr.txt')).write_bytes(p.stderr)
    records.append({'label':label,'argv':command,'exit':p.returncode,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()})
record = {'captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'commands':records,'scope':'Actual local OCR preview/rules and Graft static navigation only; no external provider review, model verdict, independent-provider approval or release claim. OCR-excluded tests/docs/vendor require manual review.'}
(root/'tool-execution.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
print(json.dumps(record))
