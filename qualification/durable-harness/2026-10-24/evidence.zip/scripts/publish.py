"""Publish only explicit task020 evidence as sanitized derivatives; never Git writes."""
import ast, hashlib, json, pathlib, re, subprocess, zipfile
root = pathlib.Path(__file__).resolve().parent
engineering = root.parent / 'engineering'
repo = engineering / 'durability'
destination = repo / 'qualification/durable-harness/2026-10-24'
destination.mkdir(parents=True, exist_ok=True)
members = {}
records = []
sha = lambda data: hashlib.sha256(data).hexdigest()

def sanitize(data):
    text = data.decode('utf-8-sig')
    for prefix, replacement in [(str(root.parent.parent), '<WORKSPACE>'), (str(pathlib.Path.home()), '<USERPROFILE>')]:
        for value in [prefix, prefix.replace('\\', '/')]:
            for power in [4, 3, 2, 1, 0]:
                text = text.replace(value.replace('\\', '\\' * (2 ** power)), replacement)
    user_component = 'Us' + 'ers'
    linux_prefix = '/' + 'home/'
    text = re.sub(r'(?i)[a-z]:[\\/]+' + user_component + r'[\\/]+[^\\/\s"\']+', '<USERPROFILE>', text)
    text = re.sub(re.escape(linux_prefix) + r'[^/\s"\\]+', '<RUNNER_HOME>', text)
    return text.encode('utf-8')

def add(name, path):
    original = path.read_bytes()
    derivative = original
    if name.startswith('ci/') and (path.name in ['fixed-head-commit.json', 'main-snapshot.json'] or re.fullmatch(r'run-\d+\.json', path.name)):
        def minimize(value):
            if isinstance(value, list):
                return [minimize(item) for item in value]
            if not isinstance(value, dict):
                return value
            result = {key: minimize(item) for key, item in value.items() if key not in ['author', 'committer']}
            if isinstance(result.get('verification'), dict):
                result['verification'].pop('payload', None)
                result['verification'].pop('signature', None)
            return result
        observation = minimize(json.loads(original))
        observation['privacy_notice'] = 'Public derivative omits personal author/committer profiles and raw signature/payload text. SHA, parents, tree and verification status remain observations; original hash is in the manifest.'
        derivative = (json.dumps(observation, indent=2) + '\n').encode()
    published = sanitize(derivative)
    if re.search(rb'gh[pousr]_[A-Za-z0-9]{30,}|sk-proj-[A-Za-z0-9_-]{20,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----', published):
        raise ValueError('Credential-format match: ' + name)
    if re.search(re.escape(pathlib.Path.home().name.encode()), published, re.I):
        raise ValueError('Private home identity remains: ' + name)
    if name.endswith('.json'):
        json.loads(published)
    if name.endswith('.py'):
        ast.parse(published.decode('utf-8'), filename=name)
    if name == 'scripts/publish.py' and original.replace(b'\r\n', b'\n') != published.replace(b'\r\n', b'\n'):
        raise ValueError('Publisher source changed through its own privacy transform')
    assert name not in members
    members[name] = published
    records.append({'path': name, 'original_sha256': sha(original), 'published_sha256': sha(published), 'bytes': len(published), 'transformed': original != published})

for path in sorted((engineering / 'runs').glob('durable-harness-*.json')):
    capture = json.loads(path.read_text(encoding='utf-8'))
    if capture.get('state') == 'RUNNING':
        raise RuntimeError('Live task capture still pending: ' + path.name)
    add('runs/' + path.name, path)
    for stream in ['stdout', 'stderr']:
        add('runs/' + capture[stream], engineering / 'runs' / capture[stream])
for pattern in ['plan-*.json', 'review-*.json', 'd1-*.json', 'donor-provenance.json', 'tool-execution.json', 'tool-*.txt', 'qualification-*.json', 'gate-applicability.json']:
    for path in sorted(root.glob(pattern)):
        add('context/' + path.name, path)
for directory in sorted(root.glob('ci-*')):
    if directory.is_dir():
        for path in sorted(directory.rglob('*')):
            if path.is_file() and path.suffix in ['.json', '.log', '.txt', '.md']:
                add('ci/' + directory.name + '/' + path.relative_to(directory).as_posix(), path)
add('sources/article.md', root / 'article-markdown-response.txt')
for filename in ['publish.py', 'capture_tools.py', 'summarize_control.py']:
    add('scripts/' + filename, root / filename)
add('scripts/qualify_native.py', engineering / 'qualify_native.py')
manifest = {'authority': 'TASK020_QUALIFICATION_OBSERVATIONS_ONLY', 'notice': 'Public sanitized derivatives; original/published hashes differ. Not canonical product receipts, authenticated attestations, release approval or provider-independent review.', 'records': records}
members['MANIFEST.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
archive_path = destination / 'evidence.zip'
with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, value in sorted(members.items()):
        archive.writestr(name, value)
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    assert len(set(archive.namelist())) == len(archive.namelist())
    for record in records:
        assert sha(archive.read(record['path'])) == record['published_sha256']
lock = {'zip_sha256': sha(archive_path.read_bytes()), 'members': len(members), 'source_head': subprocess.check_output(['rtk', 'proxy', 'git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip(), 'notice': manifest['notice']}
(destination / 'evidence-lock.json').write_bytes((json.dumps(lock, indent=2) + '\n').encode())
print(json.dumps(lock))
