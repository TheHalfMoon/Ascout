"""Bind actual complete control and unchanged legacy paths; no causal promotion."""
import hashlib, json, pathlib, re, subprocess
root = pathlib.Path(__file__).resolve().parent
engineering = root.parent / 'engineering'
repo = engineering / 'durability'
manifest_path = next((engineering/'runs').glob('durable-harness-full-suite-*.json'))
capture = json.loads(manifest_path.read_text())
stdout = (engineering/'runs'/capture['stdout']).read_bytes()
stderr = (engineering/'runs'/capture['stderr']).read_bytes()
assert capture['state'] == 'EXECUTED' and capture['exit'] == 1 and capture['source_unchanged']
assert hashlib.sha256(stdout).hexdigest() == capture['stdout_sha256']
assert hashlib.sha256(stderr).hexdigest() == capture['stderr_sha256']
text, errors = stdout.decode('utf-8'), stderr.decode('utf-8')
assert '4 failed | 239 passed (243)' in text and '6 failed | 2371 passed | 34 skipped (2411)' in text
new_cases = [line for line in text.splitlines() if 'tests/assurance-durable-harness' in line]
assert len(new_cases) == 27 and all('\u2713' in line for line in new_cases)
legacy = ['tests/cli.smoke.test.ts','tests/drift.contract.test.ts','tests/git-tree-digest.test.ts','tests/t107-self-verification-harness.contract.test.ts']
bindings = {}
for filename in legacy:
    values = {}
    for head in ['89e5f01d7b77a92099961dff21e28052e5fa8dcc','f8c0825f936bcac836c77098296888e8c2b1ac10']:
        data = subprocess.check_output(['rtk','proxy','git','show',head+':'+filename],cwd=repo)
        values[head] = hashlib.sha256(data).hexdigest()
    assert len(set(values.values())) == 1
    bindings[filename] = values
record = {'kind':'ACTUAL_COMPLETE_LOCAL_FAIL_WITH_EXPLICIT_LEGACY_DEBT','capture':manifest_path.name,
 'capture_sha256':hashlib.sha256(manifest_path.read_bytes()).hexdigest(),'head':capture['source_start']['head'],
 'tree':capture['source_start']['head_tree'],'native_exit':1,'source_unchanged':True,'wall_seconds':capture['wall_seconds'],
 'files':{'passed':239,'failed':4,'total':243},'tests':{'passed':2371,'failed':6,'existing_platform_skips':34,'total':2411},
 'new_durability_cases':{'passed':27,'failed':0,'native_cross_process':3},
 'failed_cases':[line.strip() for line in errors.splitlines() if line.startswith(' FAIL ')],
 'unchanged_legacy_test_hashes':bindings,'stdout_sha256':capture['stdout_sha256'],'stderr_sha256':capture['stderr_sha256'],
 'limits':'All six local failures remain failures. Earlier four Git/drift deadlines recur; CLI/T107 deadlines are additionally observed here. Identical source, six passing hosted controls and aggregate host context do not establish a single environmental cause. No deadline/skip/configuration was changed. Full control exceeded900seconds at this exact source; historical300/900 captures retain their original attribution limits. Whole-product readiness remains BLOCKED.'}
(root/'qualification-full-control.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
print(json.dumps(record))
