"""Read back two explicit public evidence files without extracting members."""
import ast, base64, datetime, hashlib, io, json, pathlib, subprocess, sys, zipfile
root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/durability'
head = sys.argv[1]
branch = sys.argv[2] if len(sys.argv) > 2 else 'ps/ascout-durable-harness'
prefix = sys.argv[3] if len(sys.argv) > 3 else 'qualification/durable-harness/2026-10-24'
def gh(*args):
    return json.loads(subprocess.check_output(['rtk', 'proxy', 'gh', *args]))
def sha(data):
    return hashlib.sha256(data).hexdigest()
assert gh('api', 'repos/TheHalfMoon/Ascout/commits/' + branch)['sha'] == head
files = {}
for filename in ['evidence-lock.json', 'evidence.zip']:
    metadata = gh('api', 'repos/TheHalfMoon/Ascout/contents/' + prefix + '/' + filename + '?ref=' + head)
    if metadata.get('encoding') == 'base64':
        data = base64.b64decode(metadata['content'])
    else:
        blob = gh('api', 'repos/TheHalfMoon/Ascout/git/blobs/' + metadata['sha'])
        assert blob['encoding'] == 'base64'
        data = base64.b64decode(blob['content'])
    assert data == (repo / prefix / filename).read_bytes()
    files[filename] = {'sha256': sha(data), 'bytes': len(data), 'git_blob': metadata['sha']}
    if filename.endswith('.zip'):
        archive_data = data
    else:
        lock = json.loads(data)
assert lock['zip_sha256'] == sha(archive_data)
with zipfile.ZipFile(io.BytesIO(archive_data)) as archive:
    names = archive.namelist()
    assert len(names) == len(set(names)) == lock['members']
    assert archive.testzip() is None
    assert all(not pathlib.PurePosixPath(name).is_absolute() and '..' not in pathlib.PurePosixPath(name).parts and '\\' not in name for name in names)
    manifest = json.loads(archive.read('MANIFEST.json'))
    assert set(names) == {'MANIFEST.json'} | {record['path'] for record in manifest['records']}
    for record in manifest['records']:
        data = archive.read(record['path'])
        assert len(data) == record['bytes'] and sha(data) == record['published_sha256']
        if record['path'].endswith('.json'):
            json.loads(data)
        if record['path'].endswith('.py'):
            ast.parse(data.decode('utf-8'))
result = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head': head, 'branch': branch, 'path': prefix, 'remote_ref_verified': True, 'remote_bytes_equal_local': True, 'all_member_hashes_crc_json_python_verified': True, 'members': len(names), 'files': files, 'notice': 'Remote evidence durability only; not release approval or authentication of sanitized originals.'}
(root / ('publication-receipt-' + head[:7] + '.json')).write_bytes((json.dumps(result, indent=2) + '\n').encode())
print(json.dumps(result))
