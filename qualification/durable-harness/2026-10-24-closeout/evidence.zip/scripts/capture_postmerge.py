"""Collect actual native postmerge CI; never infer success from check names."""
import datetime, hashlib, json, pathlib, re, subprocess, sys
root = pathlib.Path(__file__).resolve().parent
head, run_id = sys.argv[1:]
out = root / ('ci-postmerge-' + head[:7])
out.mkdir(exist_ok=True)
proof = json.loads((root.parent / 'engineering/merges/642.json').read_text())
assert proof['merge'] == head and proof['tree_equal'] and proof['github_signature_verification']['verified']
def gh(path, name):
    data = subprocess.check_output(['rtk', 'proxy', 'gh', 'api', 'repos/TheHalfMoon/Ascout/' + path])
    (out / name).write_bytes(data)
    return json.loads(data)
metadata = gh('actions/runs/' + run_id, 'run-' + run_id + '.json')
assert metadata['head_sha'] == head and metadata['event'] == 'push'
assert metadata['status'] == 'completed' and metadata['conclusion'] == 'success'
main = gh('branches/main', 'main-snapshot.json')
assert main['commit']['sha'] == head
commit = gh('git/commits/' + head, 'fixed-head-commit.json')
assert commit['tree']['sha'] == proof['merge_tree'] and [p['sha'] for p in commit['parents']] == proof['ordered_parents']
jobs = gh('actions/runs/' + run_id + '/jobs?per_page=100', 'jobs.json')
assert jobs['total_count'] == len(jobs['jobs']) == 6
records = []
for job in jobs['jobs']:
    assert job['status'] == 'completed' and job['conclusion'] == 'success'
    filename = 'job-' + str(job['id']) + '.log'
    data = subprocess.check_output(['rtk', 'proxy', 'gh', 'api', 'repos/TheHalfMoon/Ascout/actions/jobs/' + str(job['id']) + '/logs'])
    (out / filename).write_bytes(data)
    text = re.sub(chr(27) + r'\[[0-?]*[ -/]*[@-~]', '', data.decode('utf-8'))
    steps = {step['name']: step['conclusion'] for step in job['steps']}
    test = 'Test (Windows bounded workers)' if 'windows' in job['name'] else 'Test'
    required = ['Guard exact source', 'Install exact lockfile', 'Provision exact Chromium runtime', 'Typecheck', test, 'Build']
    assert all(steps.get(name) == 'success' for name in required)
    assert 'EXPECTED_SHA: ' + head in text
    assert all(command in text for command in ['> tsc -p tsconfig.json --noEmit', '> tsc -p tsconfig.json', 'vitest run'])
    tests = ['assurance-durable-harness.test.ts', 'assurance-durable-harness.native.test.ts', 'review-diagnostic-accounting.test.ts', 'pre-run-widening.integration.test.ts', 'assurance-test-stryker-output.test.ts', 'conservative-selection-data.contract.test.ts', 'conservative-selection-data.native.test.ts', 'browser-text-assertion.integration.test.ts', 'browser-text-assertion.contract.test.ts', 'git-tree-digest.test.ts', 'drift.contract.test.ts', 't107-self-verification-harness.contract.test.ts']
    assert all(name in text for name in tests)
    assert re.search(r'Tests\s+\d+ passed.*\(2411\)', text)
    assert re.search(r'assurance-durable-harness\.test\.ts \(24 tests\)', text)
    assert re.search(r'assurance-durable-harness\.native\.test\.ts \(3 tests\)', text)
    records.append({'id': job['id'], 'name': job['name'], 'conclusion': job['conclusion'], 'steps': steps, 'required_steps': {name: steps[name] for name in required}, 'exact_source_guard_verified': True, 'all_required_execution_verified': True, 'log': filename, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data), 'native_summary': [line for line in text.splitlines() if any(term in line for term in ['Test Files ', '      Tests ', 'Duration ', 'assurance-durable-harness.'])]})
summary = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head': head, 'tree': proof['merge_tree'], 'reviewed_head': proof['head'], 'ordered_parents': proof['ordered_parents'], 'run': int(run_id), 'event': 'push', 'all_six_actual_native_lanes_pass': True, 'jobs': records, 'limitations': 'Actual postmerge hosted CI only; local full native1, inner PR Self packaging FAIL and development advisory debt remain failures/debt. Same-provider evidence collector; no release readiness or independent-provider certification.'}
(out / 'summary.json').write_bytes((json.dumps(summary, indent=2) + '\n').encode())
print(json.dumps({'head': head, 'run': run_id, 'all_six_actual_native_lanes_pass': True, 'directory': out.name}))
