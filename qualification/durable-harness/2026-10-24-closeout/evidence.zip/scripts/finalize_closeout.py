"""Write task closeout only after actual merge and six native main controls."""
import datetime, hashlib, json, pathlib
root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/durability'
load = lambda path: json.loads(path.read_text(encoding='utf-8'))
proof = load(root.parent / 'engineering/merges/642.json')
head, merge = proof['head'], proof['merge']
assert head == '7f1c8dd88c2df4c815a7d8983d91eedc59df4576'
assert proof['merged'] and proof['tree_equal'] and proof['github_signature_verification']['verified']
premerge = load(root.parent / 'engineering/merges/642-premerge.json')
assert premerge['head'] == head and premerge['base'] == proof['base']
assert all(c['status'] == 'COMPLETED' and c['conclusion'] == 'SUCCESS' for c in premerge['pr']['statusCheckRollup'])
assert all(t['isResolved'] for t in premerge['review_threads']['nodes'])
final = load(root / 'ci-7f1c8dd/verification.json')
assert final['head'] == head and final['verdict'] == 'HOSTED_EVIDENCE_VERIFIED'
post_path = root / ('ci-postmerge-' + merge[:7]) / 'summary.json'
post = load(post_path)
assert post['head'] == merge and post['tree'] == proof['merge_tree'] and post['all_six_actual_native_lanes_pass']
reviews = {}
for filename in ['review-final-close-7f1c8dd.json', 'review-publication-security.json', 'review-final-helper-security.json']:
    path = root / filename
    data = load(path)
    assert data['must_fix'] == []
    reviews[filename] = hashlib.sha256(path.read_bytes()).hexdigest()
local = load(root / 'qualification-full-control.json')
assert local['native_exit'] == 1 and local['tests']['failed'] == 6
result = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'task': '020-T01', 'task_state': 'CLOSED_CANONICAL_BOUNDED_IMPLEMENTATION', 'release_readiness': 'BLOCKED', 'pr': proof['pr'], 'base': proof['base'], 'reviewed_head': head, 'merge': merge, 'tree': proof['merge_tree'], 'ordered_parents': proof['ordered_parents'], 'github_signature_verification': proof['github_signature_verification'], 'final_head_raw_log_and_artifact_verification': 'ci-7f1c8dd/verification.json', 'actual_postmerge_ci': {'run': post['run'], 'all_six_native_lanes_pass': True, 'summary': post_path.relative_to(root).as_posix()}, 'review_sha256': reviews, 'local_control': local, 'remaining_blockers': ['E00: six local deadline failures remain; no single environmental cause established. Git/runtime repair is separately coordinated with existing PR589/614; no deadline or failure suppression.', 'Development dependency debt: five package entries, two high/three moderate and eight underlying advisories; E05 separately deferred, not implemented or waived.', 'PR Self Verification remains valid SHADOW_NON_GATING capture with actual inner packaging FAIL/material incompleteness and unavailable selector comparison.'], 'provider_independence_claimed': False, 'ua_p07_authorized': False, 'notice': 'Bounded task closure only, not Spec018 completion, product PASS, release/deployment authority or an authenticated canonical receipt. Public archive derivatives retain original/published hashes. Closing archive publication/readback is recorded separately after execution.'}
(root / 'qualification-closeout.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
destination = repo / 'qualification/durable-harness/2026-10-24-closeout'
destination.mkdir(exist_ok=True)
readme = f'''# Ascout Durable Harness closing evidence

Task020-T01 is canonically merged and qualified at **{merge}**, [PR642]({proof['pr']}). **Whole-product release readiness and Spec018 remain BLOCKED.** This evidence-only branch adds no production code or gates.

Reviewed final head `{head}` and resulting main share tree `{proof['merge_tree']}`. Readback verified ordered parents `{proof['base']}`, `{head}`, merged/closed PR state and GitHub valid signature status. All seven actual final-head checks passed; seven raw logs and Self artifact digest/CRC/head/tree/base/receipt bindings verified. Fresh integrated and separate security reviews found no outstanding required fix. All six actual postmerge full native/typecheck/build lanes passed in [Project CI{post['run']}](https://github.com/TheHalfMoon/Ascout/actions/runs/{post['run']}); all27new durability cases executed in each lane. No source/test/package/lock/workflow mutation followed code headf8c0825.

The complete local control remains **native1**: 2,371 passed, six unchanged CLI/Git/drift/T107 deadline failures and 34 existing platform skips in 1,083.29 seconds. All 27 new cases passed. Actual hosted passes do not erase local failures or prove their cause. Production dependency audit has zero advisories; development audit retains five package entries/two high/three moderate/eight underlying advisories. Self green establishes valid non-gating capture only: inner packaging FAIL 3/3, material incompleteness and selector UNAVAILABLE remain explicit. No test was newly skipped or weakened, and no timeout change or release-readiness claim is made.

The local journal preserves intents, terminal outcomes and uncertainty; every recovery decision is execute:false. Caller-owned fresh bindings and normal effect admission remain necessary. No provider runtime, new dependency, cloud requirement, automatic retry or process resurrection. Upstream Apache-2.0 license and pinned Vercel authorship/provenance are preserved. Completed Spec018 research/implementation and its closing evidence6b3055c remain intact.

`evidence.zip` includes the original qualification packet inputs, final-head raw hosted logs, actual postmerge raw logs, merge/premerge readbacks, review findings, reproduction helpers, tool limitations and actual collector usage-limit/root-verification recovery. `MANIFEST.json` records original and published hashes; sanitized derivatives are not canonical authenticated receipts. Opaque original hosted ZIPs remain retained locally and excluded. The original 97-member packet remains unchanged and remotely verified. This closing ZIP has its own lock and requires final integrity/privacy review before publication; that review is recorded separately beside the archive. Publication readback is performed after upload and retained separately.

PStack reviews use fresh separate contexts with shared provider lineage. D1 is advisory only; Alibaba OCR executed local preview/rules without an external model verdict, Graft indexed statically, and three native child-process controls supply applicable E2E. No new browser surface required another TesterArmy run. Final evidence reviews do not replace an independent gate or approve a release.

Remaining work is E00 controlled timing qualification or a separately coordinated Git/runtime repair, plus prospectively scoped development dependency repair. Existing concurrent PR589/614 and unauthorized UA-P07 remain untouched. No paid upgrade/service, governance bypass, billing/protection change or new production feature is implied.
'''
(destination / 'README.md').write_bytes(readme.encode())
roadmap = repo / 'ROADMAP.md'
lines = roadmap.read_text(encoding='utf-8').splitlines()
matches = [i for i, line in enumerate(lines) if line.startswith('| Task020-T01 Ascout Durable Harness |')]
assert len(matches) == 1
lines[matches[0]] = f'| Task020-T01 Ascout Durable Harness | CLOSED_CANONICAL: PR642 merge{merge[:7]}; seven final-head checks and six actual postmerge native lanes pass; local six deadline failures and release BLOCKED retained | [spec](specs/020-ascout-durable-harness/spec.md) |'
roadmap.write_bytes(('\n'.join(lines) + '\n').encode())
spec = repo / 'specs/020-ascout-durable-harness/spec.md'
lines = spec.read_text(encoding='utf-8').splitlines()
matches = [i for i, line in enumerate(lines) if line.startswith('Status:')]
assert len(matches) == 1
lines[matches[0]] = f'Status: CLOSED_CANONICAL Task020-T01 at main{merge}; reviewed head{head}, seven exact-head checks and six actual postmerge native controls pass. Whole-product release and Spec018 remain BLOCKED. Closing evidence: qualification/durable-harness/2026-10-24-closeout. User request and authority boundaries below remain unchanged.'
spec.write_bytes(('\n'.join(lines) + '\n').encode())
tasks = repo / 'specs/020-ascout-durable-harness/tasks.md'
text = tasks.read_text(encoding='utf-8')
assert '\nStatus: IMPLEMENTED_REVIEWED' in text
text = text.replace('\nStatus: IMPLEMENTED_REVIEWED', '\nHistorical premerge status: IMPLEMENTED_REVIEWED', 1)
text += f'\nCurrent status: CLOSED_CANONICAL Task020-T01, PR642 merge{merge}. Final head{head} passed seven actual checks and fresh integrated/security reviews. Ordered parents/tree/signature were verified; six complete native main suites pass in run{post["run"]}. Local full native1 and development debt remain explicit release blockers. Closing evidence is on this separate evidence-only branch; implementation main bytes remain unchanged.\n'
tasks.write_bytes(text.encode())
checklist = repo / 'specs/020-ascout-durable-harness/checklists/requirements.md'
text = checklist.read_text(encoding='utf-8')
old = '- [ ] Final documentation/evidence-head gates and canonical post-merge closeout, recorded separately after actual execution.'
assert old in text
text = text.replace(old, f'- [x] Final7f1c8dd exact-head gates, guarded PR642 merge{merge[:7]}, ordered parents/tree/signature and six actual postmerge native lanes verified. Task-only closure; local failures and whole-product BLOCKED retained. Closing records are on a separate evidence-only branch.')
checklist.write_bytes(text.encode())
state = f'''Last updated: 2026-10-24 · Branch: evidence/durable-harness-postmerge-20261024

## Current state

Ascout Durable Harness Task020-T01 is CLOSED_CANONICAL at main{merge}, PR642. Reviewed head{head} has identical tree{proof['merge_tree']}; ordered parents, merged/closed PR and GitHub valid signature verified. Seven actual final-head checks passed, raw logs and artifact bindings verified, and all six actual postmerge full native/typecheck/build lanes passed in run{post['run']}. Fresh integrated and separate security reviews have no required fixes. The source remains exactly f8c0825; 27 new durability cases and 60 focused cases pass. No runtime dependency/cloud/CLI/effect replay was added. Apache license/provenance retained.

Spec018 features/research/coordination are merged, with closing evidence at6b3055c; no REA restart. Spec018 and whole-product release readiness remain BLOCKED. The latest complete local control remains native1:2,371passed/six unchanged CLI/Git/drift/T107 deadline failures/34existing platform skips in1,083.29seconds. All27new cases pass. No single environmental cause is proved. Production audit has zero advisories; development audit retains five entries/two high/three moderate/eight underlying advisories. Self green remains a valid shadow capture with actual inner packaging FAIL/material incompleteness and selectorUNAVAILABLE.

## Next steps

Finish closing evidence publication/readback; preserve this evidence-only branch separately from implementation main. Remaining authorized qualification is E00 controlled timing qualification or separately coordinated Git/runtime repair, respecting PR589/614 ownership. Development dependency repair E05 needs prospective bounded audit/qualification and remains deferred. Do not repeat suites blindly, weaken deadlines, restart REA or infer UA-P07/security-phase/release authority.

## Limits

Local journal metadata never authorizes effects; callers provide fresh source bindings and normal admission/evidence resolution. Unknown never-effects still require reconciliation under drift. Abandoned locks need operator verification/repair; checksums do not authenticate hostile storage. Same-provider fresh-context review lineage is explicit. D1 is advisory; Alibaba OCR ran local preview/rules without provider verdict, Graft statically indexed, and three native child-process controls are the applicable new E2E. No additional browser run is claimed. Interrupted delegated CI collection and root's actual successful evidence verification are separately recorded. No paid upgrade or policy/protection/billing change.
'''
(repo / 'STATE.md').write_bytes(state.encode())
print(json.dumps({'task': result['task'], 'task_state': result['task_state'], 'release_readiness': result['release_readiness'], 'merge': merge, 'postmerge_run': post['run']}))
