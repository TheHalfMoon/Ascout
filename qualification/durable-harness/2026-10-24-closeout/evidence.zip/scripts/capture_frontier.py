"""Read-only minimal public frontier; no author profiles or Git payloads."""
import datetime, json, pathlib, subprocess
root = pathlib.Path(__file__).resolve().parent
def gh(path, paginated=False):
    args = ['rtk', 'proxy', 'gh', 'api', 'repos/TheHalfMoon/Ascout/' + path]
    if paginated:
        args += ['--paginate', '--slurp']
    return json.loads(subprocess.check_output(args))
main = gh('branches/main')
pulls = [p for page in gh('pulls?state=open&per_page=100', True) for p in page]
branches = [b for page in gh('branches?per_page=100', True) for b in page]
rulesets = [r for page in gh('rulesets?per_page=100', True) for r in page]
result = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'main': main['commit']['sha'], 'main_protected': main['protected'], 'ruleset_ids': [r['id'] for r in rulesets], 'active_pull_requests': [{'number': p['number'], 'title': p['title'], 'head_ref': p['head']['ref'], 'head': p['head']['sha'], 'base_ref': p['base']['ref'], 'base': p['base']['sha'], 'draft': p['draft']} for p in pulls], 'branches': [{'name': b['name'], 'head': b['commit']['sha'], 'protected': b['protected']} for b in branches], 'notice': 'Read-only paginated public metadata inventory. No settings, concurrent work or authority changed; effective textual governance remains separately audited.'}
(root / 'qualification-frontier.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
print(json.dumps({'main': result['main'], 'open_prs': len(pulls), 'branches': len(branches), 'rulesets': len(rulesets)}))
