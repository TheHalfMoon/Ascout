"""Preserve a lost wrapper record and its partial failure streams; never infer exit."""
import datetime,hashlib,json,pathlib,subprocess,time,psutil
root=pathlib.Path(__file__).resolve().parent.parent
path=root/'runs/e04-final-full-suite-db98dd05-ed7b-4dda-af02-975223ca81f6.json'
original=path.read_bytes();record=json.loads(original)
assert record['state']=='RUNNING'
started=datetime.datetime.fromisoformat(record['started_at_utc'].replace('Z','+00:00')).timestamp()
try:
    process=psutil.Process(record['pid'])
    observation={'pid':process.pid,'create_time':process.create_time(),'name':process.name()}
    assert abs(observation['create_time']-started)>30,'Original process may still be active; reconciliation refused'
    disposition='PID now belongs to a different creation time; original process exit is unavailable'
except psutil.NoSuchProcess:
    observation={'pid':record['pid'],'present':False}
    disposition='Original process absent; exit is unavailable'
directory=root/'phase-e04/interrupted-final-capture';directory.mkdir(exist_ok=True)
(directory/'original-running-record.json').write_bytes(original)
record.update(state='CAPTURE_INTERRUPTED',exit=None,reconciled_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),original_record_sha256=hashlib.sha256(original).hexdigest(),process_observation=observation,interruption_disposition=disposition,native_exit_method='UNKNOWN: original wrapper session and original process exit status unavailable',qualification='INCOMPLETE_FAILED_OBSERVATIONS_RETAINED; not a completed full-suite control')
for stream in ['stdout','stderr']:
    artifact=root/'runs'/record[stream]
    assert time.time()-artifact.stat().st_mtime>3600
    data=artifact.read_bytes();assert data==artifact.read_bytes()
    record[stream+'_sha256']=hashlib.sha256(data).hexdigest()
    record[stream+'_bytes']=len(data)
    record[stream+'_last_modified_utc']=datetime.datetime.fromtimestamp(artifact.stat().st_mtime,datetime.timezone.utc).isoformat()
repo=root/'browser'
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
record['source_at_reconciliation']={'head':git('rev-parse','HEAD').decode().strip(),'head_tree':git('rev-parse','HEAD^{tree}').decode().strip(),'status':git('status','--porcelain=v1').decode(),'diff_sha256':hashlib.sha256(git('diff','HEAD','--binary')).hexdigest()}
record['source_matches_original_at_reconciliation']=record['source_at_reconciliation']==record['source_start']
path.write_bytes((json.dumps(record,indent=2)+'\n').encode())
print(json.dumps({k:record[k] for k in ['state','exit','interruption_disposition','qualification','source_matches_original_at_reconciliation']}))
