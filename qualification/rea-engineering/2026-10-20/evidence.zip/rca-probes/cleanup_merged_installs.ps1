param([switch]$Execute)
$ErrorActionPreference = 'Stop'
$taskRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$archivePath = Join-Path $taskRoot 'Ascout/qualification/rea-engineering/2026-10-20/evidence.zip'
$receiptPath = Join-Path $taskRoot 'publication-receipts/9f5aa62bf3ff75ccf8fd5694f1c05fd261cf5fac.json'
function Hash-File([string]$Path) {
    $hash = [Security.Cryptography.SHA256]::Create()
    $stream = [IO.File]::OpenRead($Path)
    try { return ([BitConverter]::ToString($hash.ComputeHash($stream))).Replace('-', '').ToLowerInvariant() }
    finally { $stream.Dispose(); $hash.Dispose() }
}
$receipt = Get-Content -LiteralPath $receiptPath -Raw | ConvertFrom-Json
if ($receipt.result -ne 'REMOTE_REF_AND_DOWNLOADED_BLOB_MATCH' -or $receipt.sha256 -ne 'f5ba05ae30bc3a6b9554d118ccea0b7136f818d6b07fcb2774803006ac770c32') { throw 'Remote evidence receipt mismatch' }
if ((Hash-File $archivePath) -ne $receipt.sha256) { throw 'Archive changed since verified publication' }
Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive = [IO.Compression.ZipFile]::OpenRead($archivePath)
try {
    $reader = [IO.StreamReader]::new($archive.GetEntry('MANIFEST.json').Open())
    try { $manifest = $reader.ReadToEnd() | ConvertFrom-Json } finally { $reader.Dispose() }
} finally { $archive.Dispose() }
$specifications = @(
    @{ phase = 'diagnostic'; pr = 638; prefix = 'e01-isolated-npm-ci-' },
    @{ phase = 'selection'; pr = 639; prefix = 'e02-isolated-npm-ci-' },
    @{ phase = 'mutation'; pr = 640; prefix = 'e03-isolated-npm-ci-' }
)
$plan = @()
foreach ($item in $specifications) {
    $checkout = (Resolve-Path -LiteralPath (Join-Path $taskRoot $item.phase)).Path
    foreach ($captureFile in Get-ChildItem -LiteralPath (Join-Path $taskRoot 'runs') -Filter '*.json') {
        $capture = Get-Content -LiteralPath $captureFile.FullName -Raw | ConvertFrom-Json
        if ($capture.state -eq 'RUNNING' -and $capture.cwd -eq $checkout) { throw 'A captured check still uses this checkout' }
    }
    $target = (Resolve-Path -LiteralPath (Join-Path $checkout 'node_modules')).Path
    $expected = [IO.Path]::GetFullPath((Join-Path (Join-Path $taskRoot $item.phase) 'node_modules'))
    if (-not $target.Equals($expected, [StringComparison]::OrdinalIgnoreCase) -or -not $target.StartsWith($taskRoot + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Target outside exact owned checkout' }
    if ((Get-Item -LiteralPath $target -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Dependency root is a reparse point' }
    $children = @(Get-ChildItem -LiteralPath $target -Recurse -Force)
    if (@($children | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }).Count) { throw 'Nested reparse point: refuse recursive removal' }
    $mergePath = Join-Path $taskRoot ('merges/' + $item.pr + '.json')
    $merge = Get-Content -LiteralPath $mergePath -Raw | ConvertFrom-Json
    $mergeMember = @($manifest.records | Where-Object { $_.path -eq ('merges/' + $item.pr + '.json') })
    if ($mergeMember.Count -ne 1 -or (Hash-File $mergePath) -ne $mergeMember[0].original_sha256 -or -not $merge.merged -or -not $merge.tree_equal) { throw 'Published merge evidence mismatch' }
    $sourceHead = (& git -C $checkout rev-parse HEAD).Trim()
    if ($LASTEXITCODE -ne 0 -or $sourceHead -ne $merge.head) { throw 'Checkout differs from qualified merged head' }
    $status = & git -C $checkout status --porcelain=v1
    if ($LASTEXITCODE -ne 0 -or $status) { throw 'Tracked/untracked source changes present' }
    if ((Hash-File (Join-Path $checkout 'package-lock.json')) -ne '36843f0ccb2a85fe71a27371055b539be825df59b653f1e0e02aadadb8ec6eb2') { throw 'Exact lockfile mismatch' }
    $installFiles = @(Get-ChildItem -LiteralPath (Join-Path $taskRoot 'runs') -Filter ($item.prefix + '*.json'))
    if ($installFiles.Count -ne 1) { throw 'Ambiguous install provenance' }
    $install = Get-Content -LiteralPath $installFiles[0].FullName -Raw | ConvertFrom-Json
    $installMember = @($manifest.records | Where-Object { $_.path -eq ('runs/' + $installFiles[0].Name) })
    if ($installMember.Count -ne 1 -or (Hash-File $installFiles[0].FullName) -ne $installMember[0].original_sha256 -or $install.state -ne 'EXECUTED' -or $install.exit -ne 0 -or $install.cwd -ne $checkout) { throw 'Published owned-install evidence mismatch' }
    $plan += [pscustomobject]@{ phase = $item.phase; pr = $item.pr; head = $sourceHead; target = $target; files = @($children | Where-Object { -not $_.PSIsContainer }).Count; logical_bytes = ($children | Where-Object { -not $_.PSIsContainer } | Measure-Object Length -Sum).Sum; reparse_points = 0; evidence_verified = $true }
}
$result = [ordered]@{ observed_utc = [DateTime]::UtcNow.ToString('o'); execute = [bool]$Execute; verified_publication = $receipt.commit; verified_archive_sha256 = $receipt.sha256; targets = $plan; source_checkouts_removed = $false; canonical_evidence_removed = $false; browser_and_main_control_touched = $false }
if ($Execute) {
    $result.free_c_before = (Get-PSDrive -Name C).Free
    foreach ($entry in $plan) { Remove-Item -LiteralPath $entry.target -Recurse -Force; if (Test-Path -LiteralPath $entry.target) { throw 'Removal incomplete' } }
    $result.free_c_after = (Get-PSDrive -Name C).Free
    $result.disk_delta_limit = 'Free-space observations include concurrent activity; logical file bytes are reported separately.'
}
$name = if ($Execute) { 'merged-install-cleanup.json' } else { 'merged-install-cleanup-plan.json' }
$json = $result | ConvertTo-Json -Depth 8
[IO.File]::WriteAllText((Join-Path $PSScriptRoot $name), $json + [Environment]::NewLine, [Text.UTF8Encoding]::new($false))
$json
