"""One read-only memory observation; no arguments, paths or process control."""
import datetime,json,pathlib,psutil
root=pathlib.Path(__file__).resolve().parent.parent
rows=[]
for process in psutil.process_iter(['pid','ppid','name','create_time']):
    try:
        memory=process.memory_info()
        rows.append({**process.info,'rss':memory.rss,'private':getattr(memory,'private',None)})
    except psutil.Error:
        continue
result={'captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kind':'Single host memory observation, not continuous sampling or causal attribution','virtual_memory':psutil.virtual_memory()._asdict(),'swap_memory':psutil.swap_memory()._asdict(),'largest_private_processes':sorted(rows,key=lambda r:r['private'] or 0,reverse=True)[:15],'ownership':'Process names and memory do not establish task ownership. No process was stopped, reprioritized or modified.','limit':'psutil reports Windows commit-related swap fields; no pagefile or operating-system setting was inspected or changed.'}
destination=root/('rca-probes/host-memory-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'.json')
destination.write_bytes((json.dumps(result,indent=2)+'\n').encode())
print(json.dumps({k:result[k] for k in ['captured_utc','virtual_memory','swap_memory','largest_private_processes']}))
