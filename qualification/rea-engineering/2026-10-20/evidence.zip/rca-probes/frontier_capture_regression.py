"""Replay retained API responses through only the trusted summary statements."""
import ast,json,pathlib,subprocess
root=pathlib.Path(__file__).resolve().parent.parent
capture=root/'github-frontier/20261022T013622Z'
records={p.stem:json.loads(p.read_bytes()) for p in capture.glob('*.json') if p.stem!='capture-disposition'}

def summarize(source):
    tree=ast.parse(source)
    start=next(i for i,node in enumerate(tree.body) if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='summary' for t in node.targets))
    # Compile just the summary assignment and its following loop. No network,
    # subprocess, file writes or surrounding helper statements are executed.
    subset=ast.Module(body=tree.body[start:start+2],type_ignores=[])
    scope={'records':records,'stamp':'retained-response-replay','out':capture}
    exec(compile(subset,'trusted-frontier-summary','exec'),scope)
    return scope['summary']

original=subprocess.check_output(['git','show','a5639500ba85f417e507495d42c2ae7de4367995:qualification/rea-engineering/2026-10-20/scripts/github_frontier.py'],cwd=root/'Ascout').decode()
try:
    summarize(original)
except TypeError as error:
    before={'result':'EXPECTED_RED','exception':type(error).__name__,'message':str(error)}
else:
    raise AssertionError('Original summary must reproduce the retained capture failure')
after=summarize((root/'github_frontier.py').read_text())
unavailable=[r for r in after['runs'] if 'capture_state' in r]
assert unavailable and all(r['native_exit']!=0 for r in unavailable)
assert after['errors']
result={'kind':'Retained-response regression; no new API requests or CI execution','source_capture':capture.name,'before':before,'after':'PASS_SUMMARY_RETAINS_UNAVAILABLE_METADATA','unavailable':unavailable,'retained_native_errors':after['errors'],'all_run_requests_accounted':len(after['runs'])==len([k for k in records if k.startswith('run-')])}
assert result['all_run_requests_accounted']
(root/'packet-review/frontier-summary-regression.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
print(json.dumps({k:result[k] for k in ['kind','source_capture','before','after','unavailable','all_run_requests_accounted']}))
