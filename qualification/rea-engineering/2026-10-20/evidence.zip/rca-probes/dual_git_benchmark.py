"""Interleaved read-only launch-cost observation for two installed Git builds."""
import datetime,hashlib,json,pathlib,shutil,statistics,subprocess,time
root=pathlib.Path(__file__).resolve().parent.parent
cwd=root/'main-control'
executables={'default':pathlib.Path(shutil.which('git')),'bundled':pathlib.Path.home()/'.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe'}
head=subprocess.check_output([str(executables['default']),'rev-parse','HEAD'],cwd=cwd).decode().strip()
rows=[];bindings={}
for label,executable in executables.items():
    assert executable.is_file()
    bindings[label]={'path':str(executable),'sha256':hashlib.sha256(executable.read_bytes()).hexdigest(),'version':subprocess.check_output([str(executable),'--version']).decode().strip()}
for index in range(12):
    for label in (['default','bundled'] if index%2==0 else ['bundled','default']):
        start=time.perf_counter()
        result=subprocess.run([str(executables[label]),'rev-parse','--verify','HEAD'],cwd=cwd,capture_output=True)
        elapsed=(time.perf_counter()-start)*1000
        assert result.returncode==0 and result.stdout.decode().strip()==head and not result.stderr
        rows.append({'iteration':index,'tool':label,'milliseconds':elapsed,'exit':result.returncode,'head':head})
assert subprocess.check_output([str(executables['default']),'rev-parse','HEAD'],cwd=cwd).decode().strip()==head
summary={label:{'count':len(values),'median_ms':statistics.median(values),'sum_ms':sum(values),'max_ms':max(values)} for label in executables for values in [[r['milliseconds'] for r in rows if r['tool']==label]]}
record={'captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kind':'Read-only installed-tool launch benchmark; not native-suite qualification','head':head,'bindings':bindings,'observations':rows,'summary':summary,'limits':'Two installed build/path/DLL configurations, one trusted checkout and inherited environment; not isolated Git-version causation, full digest latency, process tracing or a product fix. No source or global PATH/configuration mutation.'}
(root/'rca-probes/dual-git-benchmark.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
print(json.dumps({'head':head,'bindings':bindings,'summary':summary}))
