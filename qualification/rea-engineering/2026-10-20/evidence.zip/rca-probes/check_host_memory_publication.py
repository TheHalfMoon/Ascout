"""Check aggregate host observations retain raw binding without process inventory."""
import hashlib,json,pathlib,zipfile
root=pathlib.Path(__file__).resolve().parent.parent
archive=root/'Ascout/qualification/rea-engineering/2026-10-20/evidence.zip'
records=[]
with zipfile.ZipFile(archive) as zipped:
    manifest={r['path']:r for r in json.loads(zipped.read('MANIFEST.json'))['records']}
    for path in sorted((root/'rca-probes').glob('host-memory-*.json')):
        name='rca-probes/'+path.name
        original=json.loads(path.read_bytes());published=json.loads(zipped.read(name))
        assert 'largest_private_processes' in original and 'largest_private_processes' not in published
        assert published['virtual_memory']==original['virtual_memory']
        assert published['swap_memory']==original['swap_memory']
        assert published['captured_utc']==original['captured_utc']
        assert published['privacy_notice']
        assert manifest[name]['original_sha256']==hashlib.sha256(path.read_bytes()).hexdigest()
        assert manifest[name]['sha256']==hashlib.sha256(zipped.read(name)).hexdigest()
        assert manifest[name]['transformed']
        records.append({'member':name,'original_sha256':manifest[name]['original_sha256'],'published_sha256':manifest[name]['sha256'],'aggregate_values_equal':True,'process_inventory_absent':True})
assert len(records)==2
result={'result':'PASS','scope':'Only the two actual owned host-memory observations; no process inventory published','archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'records':records}
(root/'packet-review/host-memory-publication-check.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
print(json.dumps(result))
