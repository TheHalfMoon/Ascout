$ErrorActionPreference = 'Stop'
function Read-Sha256([string]$literalPath) {
  $hashStream = [IO.File]::OpenRead($literalPath)
  $algorithm = [Security.Cryptography.SHA256]::Create()
  try { return ([BitConverter]::ToString($algorithm.ComputeHash($hashStream))).Replace('-','').ToLowerInvariant() }
  finally { $algorithm.Dispose(); $hashStream.Dispose() }
}
$engineeringRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).ProviderPath
$workRoot = Split-Path -Parent $engineeringRoot
$fixtureParent = (Resolve-Path -LiteralPath (Join-Path $workRoot 'npm-tools/fixtures')).ProviderPath
$fixtureName = 'engineering-e04-ed77be51-d959-405c-99d2-2e8334833214'
$target = (Resolve-Path -LiteralPath (Join-Path $fixtureParent $fixtureName)).ProviderPath
if (!$target.StartsWith($fixtureParent + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw 'Outside fixture parent' }
if ((Split-Path -Leaf $target) -cne $fixtureName) { throw 'Wrong owned fixture' }
if ((Get-Item -LiteralPath $target).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Reparse root' }
$items = @(Get-ChildItem -LiteralPath $target -Recurse -Force)
if (@($items | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }).Count) { throw 'Reparse descendant' }
if (@(Get-ChildItem -LiteralPath $target -Force | Where-Object { $_.Name -notin @('working','broken','owned-profile') }).Count) { throw 'Unexpected contents' }
foreach ($capture in Get-ChildItem -LiteralPath (Join-Path $engineeringRoot 'runs') -Filter '*.json') {
  $run = Get-Content -LiteralPath $capture.FullName -Raw | ConvertFrom-Json
  if ($run.state -eq 'RUNNING') { throw 'Live capture; leave fixture for later' }
}
$receipt = Get-Content -LiteralPath (Join-Path $engineeringRoot 'publication-receipts/4308e9ea89ad1b44081bac530e04bb9b8008c740.json') -Raw | ConvertFrom-Json
$zipPath = Join-Path $engineeringRoot 'Ascout/qualification/rea-engineering/2026-10-20/evidence.zip'
if ($receipt.result -ne 'REMOTE_REF_AND_DOWNLOADED_BLOB_MATCH' -or $receipt.sha256 -ne 'cd229435c07f93b87f59cba3c59b22dc2b425593743a6949da9670dff662db2e' -or (Read-Sha256 $zipPath) -ne $receipt.sha256) { throw 'Remote archive binding absent' }
Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive = [IO.Compression.ZipFile]::OpenRead($zipPath)
try {
  $reader = [IO.StreamReader]::new($archive.GetEntry('MANIFEST.json').Open())
  try { $manifest = $reader.ReadToEnd() | ConvertFrom-Json } finally { $reader.Dispose() }
} finally { $archive.Dispose() }
$summary = Get-Content -LiteralPath (Join-Path $engineeringRoot 'phase-e04/final-main-testerarmy/testerarmy-summary.json') -Raw | ConvertFrom-Json
if (!$summary.controls_match -or @($summary.runs).Count -ne 2) { throw 'Missing finished controls' }
$verified = @()
foreach ($mode in @('working','broken')) {
  $run = @($summary.runs | Where-Object mode -eq $mode)[0]
  foreach ($relative in @('package.json','e2e.config.ts','tests/literal.e2e.ts','fixture.html')) {
    $source = Join-Path (Join-Path $target $mode) $relative
    $retained = Join-Path (Join-Path $engineeringRoot ('phase-e04/final-main-testerarmy/testerarmy/' + $mode)) $relative
    $digest = Read-Sha256 $source
    if ((Read-Sha256 $retained) -ne $digest -or $run.fixture_hashes.$relative -ne $digest) { throw 'Fixture identity mismatch' }
    $member = 'phases/phase-e04/final-main-testerarmy/testerarmy/' + $mode + '/' + $relative
    $entry = @($manifest.records | Where-Object { $_.path -ceq $member })
    if ($entry.Count -ne 1 -or $entry[0].original_sha256 -ne $digest) { throw 'Fixture absent from verified remote evidence' }
    $verified += $member
  }
}
if (@($manifest.records | Where-Object { $_.path -like 'phases/phase-e04/final-main-testerarmy/testerarmy/*/runner-artifacts/*' }).Count -lt 1) { throw 'Runner evidence absent' }
$fileCount = @($items | Where-Object { !$_.PSIsContainer }).Count
Remove-Item -LiteralPath $target -Recurse -Force -ErrorAction Stop
if (Test-Path -LiteralPath $target) { throw 'Removal incomplete' }
$record = @{ action='REMOVED_ONLY_FINAL_OWNED_E04_FIXTURE_AND_PROFILE'; at_utc=[DateTime]::UtcNow.ToString('o'); target=$target; removed_files=$fileCount; remote_commit=$receipt.commit; archive_sha256=$receipt.sha256; verified_fixture_members=$verified; canonical_copies_retained=$true; processes_terminated=$false; active_worktrees_removed=$false }
$record | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $engineeringRoot 'phase-e04/final-main-disposable-cleanup.json') -Encoding UTF8
$record | ConvertTo-Json -Depth 6
