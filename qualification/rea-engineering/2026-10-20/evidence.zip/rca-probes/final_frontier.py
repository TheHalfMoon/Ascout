"""Read-only final governance/frontier snapshot; no approvals or source changes."""
import datetime
import hashlib
import json
import pathlib
import subprocess

root = pathlib.Path(__file__).resolve().parent.parent
repo = root / 'Ascout'
out = root / 'packet-review'
records = []
for label, endpoint in [
    ('repository', 'repos/TheHalfMoon/Ascout'),
    ('main', 'repos/TheHalfMoon/Ascout/branches/main'),
    ('rulesets', 'repos/TheHalfMoon/Ascout/rulesets'),
    ('protection', 'repos/TheHalfMoon/Ascout/branches/main/protection'),
    ('open-prs', 'repos/TheHalfMoon/Ascout/pulls?state=open&per_page=100'),
    ('review-amendment', 'repos/TheHalfMoon/Ascout/issues/618'),
]:
    command = ['rtk', 'proxy', 'gh', 'api', endpoint]
    result = subprocess.run(command, cwd=repo, capture_output=True)
    # Retain failed responses explicitly, including expected unprotected-main404.
    parsed = json.loads(result.stdout) if result.stdout else None
    record = {'observed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'argv': command, 'exit': result.returncode,
              'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
              'response': parsed, 'stderr': result.stderr.decode('utf-8', 'replace')}
    (out / ('final-frontier-' + label + '.json')).write_text(
        json.dumps(record, indent=2) + '\n', encoding='utf-8')
    records.append({'label': label, 'exit': result.returncode})

policies = ['CONTRIBUTING.md', '.specify/memory/constitution.md',
            'specs/017-unified-assurance/UA_P06_REVIEW_MODEL_AMENDMENT.md']
diff = subprocess.run(['rtk', 'proxy', 'git', 'diff', '--exit-code',
    'ea93553a5423fd47f12a6bf282820dd199b994d4', 'origin/main', '--', *policies],
    cwd=repo, capture_output=True)
summary = {'kind': 'READ_ONLY_FRONTIER_OBSERVATION_NOT_APPROVAL', 'responses': records,
    'policy_comparison': {'from': 'ea93553a5423fd47f12a6bf282820dd199b994d4',
                         'to': 'origin/main', 'paths': policies, 'exit': diff.returncode,
                         'stdout': diff.stdout.decode('utf-8', 'replace'),
                         'stderr': diff.stderr.decode('utf-8', 'replace')},
    'notice': '404 is retained as an unavailable protection response. Existing documentary gates still apply; no settings changed.'}
(out / 'final-frontier-summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary))
