# REA-E00 read-only diagnosis — preliminary

Canonical source: `ea93553a5423fd47f12a6bf282820dd199b994d4`.
No production or test edits, no heavy probe launched by the diagnostician.

## Evidence boundaries

- Old `ascout-native-full.json`: outer timeout after 300.177s, no final Vitest failure details; peak live-tree RSS 2,002,706,432 bytes.
- Old `ascout-native-windows-single-worker.json`: outer timeout after 900.433s, no final failure details; peak live-tree RSS 959,406,080 bytes.
- Both use recursive Windows process-tree sampling every 20ms. `bench.py` drains pipes in a thread; pipe deadlock is not supported by its implementation. The CPU statistic is a maximum of live-tree totals, not final accounting.
- Neither old native artifact records source HEAD/worktree status; `bench.py` does not capture those fields. The old full artifact additionally lacks run ID and harness hashes. They establish historical symptoms, not an exact-main gate unless separate acquisition evidence binds source.
- Current serial run `55214ef9-f37f-4dc3-be24-33c85a3dc592`: diagnostic only. Planning documents were committed during execution (`ea93553a` → `442b999`), so this is not a qualified exact-main control. Individual deadlines remain unchanged, outer budget7200s, sampling100ms.
- Isolated exact-main `process-control-baseline-62d9d55b-cc33-4f67-80fb-8ded82c07872`: exit0,11 passed/1 existing POSIX skip,12.105s overall. Thus old process-control failures are not a deterministic universal failure on this host.

## Findings supported now

1. Current first four `git-tree-digest.test.ts` failures are deadline failures, not failed digest assertions:
   - clean/staged/unstaged/deleted/untracked:26.512s against15s;
   - stale-stat:9.404s against5s;
   - large-file:7.606s against5s;
   - executable/symlink test on Windows:5.167s against5s (only setup plus clean digest executes on Windows).
2. Fixed subprocess amplification is source-proven. Each `collectTreeDigestV1` calls4 HEAD identity commands plus index, visibility, diff, untracked commands:8 Git launches. `readTreeDigestV1` makes2 complete observations:16 launches minimum. Each modified same-mode tracked file adds a `hash-object` process per observation. The first live test calls7 digests:112 baseline launches, plus changed-file hashes and fixture setup. A fast `git --version` launch alone cannot establish this test fits15s.
3. `composeSourceState` separately reads HEAD then a two-observation digest (20 Git launches minimum). `runCheck` takes start/end snapshots, so40 minimum just for source snapshots, plus working-tree comparison/discovery. Controlled integration fixtures still incur these real Git costs.
4. Current serial diagnostic run passes all7 Vitest integration cases (first55.456s; branch cases8.994–12.845s), where old300s run failed6/7. Current Jest first test times out at91.976s against90s; three branch cases initially crossed15s while other controlled cases pass in11–13s. Timing sensitivity and cumulative native fixture cost are established; exact contribution of host load versus sampler/environment is not established.
5. Old Windows timeout/cleanup cases cluster at5.05–5.57s. `process.ts` has5s taskkill budget and Vitest defaults to5s. The old artifacts lack the assertion/error details needed to distinguish test deadline from taskkill failure. Current isolated success prevents attributing them to product cleanup without a controlled reproduction.
6. Several integration fixtures synchronously copy the entire `node_modules` tree (`jest-check`, `vitest-check`, `changed-line-exercise`, `t090`) then recursively delete it. Vitest deadlines cover fixture construction/cleanup too; synchronous work can overrun the deadline before the timer runs. This explains how elapsed duration can exceed the configured deadline, but operation timings must still be captured before assigning a root cause.

## Existing overlapping work (read-only references)

- PR589 `fix/v0-t08-git-invocation-hardening`: shared Git environment/options and filter refusal; overlaps `src/git.ts`, worktree Git calls, digest tests.
- PR614 `perf/608-batch-hash-object`, stacked on589: batched HEAD query and hash-object calls; reported98→20 digest processes on40-file fixture. This is unlanded directional evidence, not a canonical repair. Do not duplicate it in REA-E00.
- PR633 `maint/626-security-dedup`: security comparator/accessor consolidation, unrelated to observed native timeouts. Preserve its scope.

## Next probes after baseline completes

1. Preserve completed raw stdout/stderr/metadata and exact source identity, including the mid-run plan commit limitation. Run the separate untouched-main full-suite control alone before changing source.
2. On untouched main, run only the first live digest case once with unchanged native15s timeout and verbose output; then one inexpensive stale-stat or executable case with default5s. Capture command timings/counts with an external Node preload that wraps `spawnSync`/`execFileSync`, persisting only Git argv categories and durations, no environment or stdout. Keep this explicitly instrumented/diagnostic; do not claim qualification from it.
3. Compare clean fixture8-Git-observation timings with trivial launch timings; separately measure fixture setup and digest counts. A successful native operation over budget supports a performance/environment issue; error/status/ETIMEDOUT identifies a command defect needing its own reproduction.
4. Reproduce one controlled Jest branch case with unchanged15s, instrumenting real Git and fixture setup/cleanup. Run the real Jest case only if needed afterward; count/timing from a controlled fixture resolves the common snapshot overhead first.
5. If old cleanup remains relevant, run the existing Windows cleanup case under old allowlist/20ms harness and new allowlist/100ms harness sequentially, preserving the same test deadline. Include one outer runner with no sampling to measure sampler impact. Do not run simultaneous full suites. The sampler repeatedly calls recursive `psutil.Process.children`, memory and CPU queries; its causal impact is unmeasured until this control. This isolates harness/environment effects before touching process control.
6. Any proposed source repair must have a reproduced cause and coordinate589/614 overlap. Do not widen native deadlines, weaken assertions, add skips, or merge unlanded fixes into baseline evidence.
