import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve, join } from 'node:path';
import { pathToFileURL } from 'node:url';

const { translateStrykerOutputV1 } = await import(pathToFileURL(resolve('dist/assurance/test/stryker-output.js')).href);
const directory = resolve('../../Ascout/research/rea/2026-10-20/expansion');
const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex');
const records = [];
for (const strength of ['strong', 'weak']) {
  for (const repeat of [0, 1]) {
    const name = `stryker-${strength}-${repeat}`;
    const bytes = readFileSync(join(directory, name + '-mutants.json'));
    const run = JSON.parse(readFileSync(join(directory, name + '.json'), 'utf8'));
    // The historical JSON has no authenticated Git or attempt binding. This is
    // an explicit qualification envelope, not a claim that Stryker attested it.
    const binding = { source_identity: 'fixture:' + run.fixture_manifest.sha256,
      head_sha: 'ea93553a5423fd47f12a6bf282820dd199b994d4', attempt_id: run.run_id };
    const output = translateStrykerOutputV1({ bytes, expected: { ...binding, report_sha256: sha256(bytes) }, observed: binding,
      complete: run.status === 'EXECUTED', process_exit_code: run.exit });
    assert.equal(output.generated_count, 5);
    assert.equal(output.observation.killed_count, strength === 'strong' ? 5 : 1);
    assert.equal(output.observation.survived_count, strength === 'weak' ? 4 : 0);
    assert.equal(output.observation.canonical_status, 'UNTRUSTED_OBSERVATION');
    assert.ok(output.observation.blocking_reasons.includes('external-runner:limitation:stryker:untrusted-report'));
    records.push({ name, report_sha256: sha256(bytes), bytes: bytes.length, run_id: run.run_id,
      fixture_manifest_sha256: run.fixture_manifest.sha256, status_counts: output.status_counts,
      source_status: output.observation.source_status, blocking_reasons: output.observation.blocking_reasons,
      mutants: output.mutants.map(({ status_reason, ...mutant }) => ({ ...mutant,
        reason_characters: status_reason?.length ?? 0, reason_sha256: status_reason === null ? null : sha256(status_reason) })) });
  }
}
writeFileSync(resolve('../phase-e03/frozen-reports.json'), JSON.stringify({
  binding_limit: 'caller-supplied qualification envelope; not authenticated historical report provenance or source-drift proof', records
}, null, 2) + '\n');
console.log(JSON.stringify(records.map(({ name, report_sha256, status_counts }) => ({ name, report_sha256, status_counts })), null, 2));
