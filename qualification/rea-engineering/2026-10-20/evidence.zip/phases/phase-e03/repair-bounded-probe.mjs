import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { execFileSync, spawnSync } from 'node:child_process';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex');
const module = pathToFileURL(resolve('dist/assurance/test/stryker-output.js')).href;
const cases = [
  { kind: 'unterminated-escaped-string', bytes: 64001 },
  { kind: 'unterminated-escaped-string', bytes: 256001 },
  { kind: 'unterminated-escaped-string', bytes: 2097152 },
  { kind: 'valid-json-with-long-escaped-value', bytes: 2097152 },
];
const records = cases.map((probe) => {
  const child = spawnSync(process.execPath, ['--input-type=module', '--eval', `
    import { createHash } from 'node:crypto';
    import { performance } from 'node:perf_hooks';
    import { translateStrykerOutputV1 } from ${JSON.stringify(module)};
    const probe = ${JSON.stringify(probe)};
    let text;
    if (probe.kind === 'unterminated-escaped-string') {
      text = String.fromCharCode(34) + String.fromCharCode(92, 34).repeat(Math.floor((probe.bytes - 1) / 2));
      if (text.length < probe.bytes) text += String.fromCharCode(92);
    } else {
      const base = JSON.stringify({ schemaVersion: '1.0', framework: { name: 'StrykerJS', version: '10.0.0' }, files: {}, padding: '' });
      const padding = String.fromCharCode(92, 34).repeat(Math.floor((probe.bytes - base.length) / 2));
      text = base.slice(0, -2) + padding + base.slice(-2);
      text += ' '.repeat(probe.bytes - text.length);
    }
    const bytes = Buffer.from(text);
    const digest = createHash('sha256').update(bytes).digest('hex');
    const identity = { source_identity: 'tree:e03', head_sha: 'a'.repeat(40), attempt_id: 'attempt:1' };
    const started = performance.now();
    let errorName = null;
    let sourceStatus = null;
    try {
      sourceStatus = translateStrykerOutputV1({ bytes, expected: { ...identity, report_sha256: digest }, observed: identity,
        complete: true, process_exit_code: 0 }).observation.source_status;
    } catch (error) { errorName = error.name; }
    console.log(JSON.stringify({ ...probe, actual_bytes: bytes.length, input_sha256: digest, errorName, sourceStatus,
      elapsed_ms: Number((performance.now() - started).toFixed(3)) }));
  `], { encoding: 'utf8', timeout: 2000, maxBuffer: 4096, windowsHide: true });
  assert.equal(child.error, undefined, 'child must finish within fixed 2000ms');
  assert.equal(child.status, 0, child.stderr);
  const record = JSON.parse(child.stdout);
  assert.equal(record.actual_bytes, probe.bytes);
  if (probe.kind === 'unterminated-escaped-string') assert.equal(record.errorName, 'SyntaxError');
  else {
    assert.equal(record.errorName, null);
    assert.equal(record.sourceStatus, 'NOT_RUN');
  }
  return record;
});
const result = { head: execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(),
  recorded_at: new Date().toISOString(), node: process.version, child_timeout_ms: 2000,
  source_sha256: sha256(readFileSync('src/assurance/test/stryker-output.ts')),
  compiled_sha256: sha256(readFileSync('dist/assurance/test/stryker-output.js')),
  probe_sha256: sha256(readFileSync(new URL(import.meta.url))),
  records, scope: 'Observed on this host; malformed and valid exact-limit input exercised. No provider-independent review or general timing guarantee.' };
writeFileSync(resolve('../phase-e03', process.argv[2] ?? 'repair-bounded-probe.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result, null, 2));
