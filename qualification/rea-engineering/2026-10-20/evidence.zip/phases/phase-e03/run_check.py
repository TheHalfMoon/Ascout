from pathlib import Path
import datetime, hashlib, json, subprocess, sys

name, *command = sys.argv[1:]
root = Path(__file__).resolve().parent
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
log = root / (name + '.log')
log.write_bytes(result.stdout)
(root / (name + '.json')).write_text(json.dumps({
    'command': command, 'started_at': started, 'exit': result.returncode,
    'output_sha256': hashlib.sha256(result.stdout).hexdigest(),
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
}, indent=2), encoding='utf-8')
print(json.dumps({'check': name, 'exit': result.returncode, 'log': str(log)}))
print(result.stdout.decode('utf-8', errors='replace')[-1800:])
sys.exit(result.returncode)
