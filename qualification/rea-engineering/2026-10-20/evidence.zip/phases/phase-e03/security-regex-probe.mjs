import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

// Invoke from engineering/mutation. This probe never exceeds 64,001 input bytes.
const head = '4e32286fbfec4a04f37a13eef2358e839e3ada6d';
const source = 'src/assurance/test/stryker-output.ts';
const compiled = 'dist/assurance/test/stryker-output.js';
const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex');
const { translateStrykerOutputV1 } = await import(pathToFileURL(resolve(compiled)).href);
const identity = { source_identity: 'tree:e03', head_sha: 'a'.repeat(40), attempt_id: 'attempt:1' };
const records = [];
for (const n of [2000, 4000, 8000, 16000, 32000]) {
  const bytes = Buffer.from(String.fromCharCode(34) + String.fromCharCode(92, 34).repeat(n));
  const start = performance.now();
  let error;
  try {
    translateStrykerOutputV1({ bytes, expected: { ...identity, report_sha256: sha256(bytes) },
      observed: identity, complete: true, process_exit_code: 0 });
  } catch (caught) {
    error = caught.name;
  }
  records.push({ escaped_quote_pairs: n, bytes: bytes.length, input_sha256: sha256(bytes),
    elapsed_ms: Number((performance.now() - start).toFixed(3)), error });
}
const result = { head, node: process.version, recorded_at: new Date().toISOString(),
  command: ['rtk', 'proxy', 'node', '../phase-e03/security-regex-probe.mjs'],
  source, source_sha256: sha256(readFileSync(source)), compiled,
  compiled_sha256: sha256(readFileSync(compiled)),
  probe_sha256: sha256(readFileSync(new URL(import.meta.url))),
  records, limit: 'No maximum-size payload run. Timings are observations, not a maximum-size runtime claim.' };
writeFileSync(resolve('../phase-e03/security-regex-probe.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result, null, 2));
