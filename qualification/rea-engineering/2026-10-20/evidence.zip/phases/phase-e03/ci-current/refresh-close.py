from pathlib import Path
import json, hashlib, shutil, subprocess, re
from datetime import datetime, timezone
p=Path(__file__).resolve().parent
repo=p.parent.parent/'mutation'
head='d390056c9e6f3b486e34be4a31fa30498e2eff47'
base='48902389ec37019845fd67c8b8c53c5f499ffc85'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head
assert subprocess.check_output(['git','status','--short'],cwd=repo,text=True)==''
report_path=p.parent/'close-review.json'
prior=p.parent/'close-review-before-final-ci.json'
if not prior.exists(): shutil.copy2(report_path,prior)
d=json.loads(report_path.read_text(encoding='utf-8'))
jobs=json.loads((p/'project-jobs-final-native.json').read_text(encoding='utf-8'))['jobs']
selfjobs=json.loads((p/'self-jobs-final-native.json').read_text(encoding='utf-8'))['jobs']
assert len(jobs)==6 and len(selfjobs)==1
assert all(j['head_sha']==head and j['status']=='completed' and j['conclusion']=='success' for j in jobs+selfjobs)
for name in ['project-run-final-native.json','self-run-final-native.json']:
 r=json.loads((p/name).read_text(encoding='utf-8'))
 assert r['head_sha']==head and r['run_attempt']==1 and r['conclusion']=='success'
a=p/'self-verification-artifact'
validation=json.loads((a/'source-binding-validation.json').read_text(encoding='utf-8'))
assert validation['valid'] and all(x['match'] for x in validation['source_six_fields'])
assert validation['canonical_capture_valid'] and validation['canonical_envelope_equal']
files=[{'path':str(f.relative_to(p)).replace(chr(92),'/'),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in sorted(a.glob('*.json'))]
danger=re.compile(r'(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|sk-proj-[A-Za-z0-9_-]{20,}|Bearer [A-Za-z0-9_.-]{16,}|[?&](?:sig|token|access_token)=)',re.I)
assert all(not danger.search(f.read_text(encoding='utf-8')) for f in a.glob('*.json'))
zip_path=p/'self-verification-e03-d390.original.zip'
zip_hash=hashlib.sha256(zip_path.read_bytes()).hexdigest()
assert zip_hash=='aa5b6e151e2ebf2802bd0c4f136f542550f0866c3f82afcf04373c403c733ae0'
manifest={'artifact_id':12310424715,'artifact_name':'self-verification-'+head,'workflow_run':39521420208,'run_attempt':1,'head':head,'base':base,'original_zip_local_only':{'file':zip_path.name,'bytes':zip_path.stat().st_size,'sha256':zip_hash,'matches_github_artifact_digest':True,'publication':'EXCLUDE_RAW_ZIP; publish extracted allowlisted JSONs and this digest manifest'},'extracted_files':files,'publication_audit':{'signed_urls_persisted':False,'credential_pattern_matches':0,'original_json_bytes_retained':True,'contents':'Receipt contains repository-relative paths, task statuses, evidence hashes and source identities. No raw task output is embedded. Selector comparison unavailable remains explicit.'},'inner_receipt_summary':validation['inner_summary'],'inner_findings':validation['findings'],'classification':'VALID_SHADOW_CAPTURE_WITH_INNER_TEST_FAIL','clean_receipt':False}
(p/'self-verification-artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
d['previous_close_review']='close-review-before-final-ci.json'
d['observed_at_utc']=datetime.now(timezone.utc).isoformat().replace('+00:00','Z')
d['verdict']='PASS_LOCAL_CLOSE_REVIEW'
d['merge_gate_status']='Current exact-head source/static review and all seven applicable GitHub job conclusions are clear at d390/base4890. This is a close-review report, not a merge or approval; parent retains final source/main/review-inventory/draft-state checks and post-merge verification. Spec006 self-verification is valid SHADOW_NON_GATING capture with a retained inner FAIL, not a clean receipt or release-readiness claim.'
d['ci']['project_run']['job_conclusions_success']=6
d['ci']['project_run']['job_conclusions_pending']=0
d['ci']['snapshot_discrepancy_history']={'earlier_record':'close-review-before-final-ci.json and existing ci-current/windows24-job-native.json, project-jobs-native.json','prior_state':'Win24 in_progress/null while workflow already success and all steps complete','resolution':'Fresh final job metadata now completed/success, matching all six Project CI jobs and self-verify. Earlier inconsistency remains preserved; no pending state was counted as pass.'}
d['ci'].pop('snapshot_discrepancy',None)
finalbyid={j['id']:j for j in jobs+selfjobs}
for item in d['ci']['jobs']:
 final=finalbyid[item['id']]
 item['status']=final['status'];item['conclusion']=final['conclusion']
 item['final_metadata']='ci-current/self-jobs-final-native.json' if item['id']==118965894978 else 'ci-current/project-jobs-final-native.json'
d['ci']['final_native_metadata']=['ci-current/project-run-final-native.json','ci-current/self-run-final-native.json','ci-current/project-jobs-final-native.json','ci-current/self-jobs-final-native.json','ci-current/windows24-job-final-native.json']
d['ci']['self_verification_artifact']={'manifest':'ci-current/self-verification-artifact-manifest.json','canonical_validation':'ci-current/self-verification-artifact/canonical-validation.json','source_binding_validation':'ci-current/self-verification-artifact/source-binding-validation.json','receipt_sha256':validation['receipt_digest'],'classification':'SHADOW_NON_GATING','capture_integrity':'PASS schema, semantics, canonical envelope, receipt hash, six reconstructed source fields and start/end identity; exact H/HT/base/mergebase verified','inner_summary':validation['inner_summary'],'inner_tasks':validation['inner_tasks'],'inner_findings':validation['findings'],'selector_comparison':'UNAVAILABLE_FULL_SUITE_CONTRACT; no selector-miss or complete-comparison claim','spec006_rule':'specs/006-self-verification-shadow-receipt/spec.md:130: successful job means valid shadow capture, not clean receipt','interpretation':'Existing npm-package-content task FAIL reproduced 3/3 under shadow direct Vitest invocation is retained. It is not suppressed or relabeled; six canonical npm-test matrix suites passed. No new E03 source finding was established, and root retains qualification reconciliation responsibility.'}
for c in d['criteria']:
 if c['id']=='E03-canonical-full-suite':
  c['status']='PASS_ACTUAL_HOSTED_EXACT_HEAD'
  c['evidence']='All six actual canonical Project CI test/build jobs completed success at d390 attempt1. Original native log summaries/counts and platform skips preserved; all six include 29 translator and 6 existing adapter tests. No local six-lane execution claimed. Shadow capture retains a separate deterministic packaging FAIL.'
 if c['id']=='E03-final-record-reconciliation':
  c['evidence']='Parent should update PR narrative/draft status and final gate records before guarded merge. Current job conclusions are all success; self-verification is valid non-gating capture with inner test FAIL, not clean receipt. Original builder document is historical, not a release claim.'
d['actions']='Read/review only; refreshed final CI metadata and downloaded actual shadow artifact, independently validated hashes/envelope/schema/semantics/six reconstructed source fields using current built canonical validators, and saved external artifacts. No source edit, install, heavy test, PR write/approval, push or merge.'
d['panel_manifest']='panel: light fresh combined correctness/parsimony/product PASS; separate prior security + delta identity verified; actual hosted six-lane canonical CI and Self Verification capture job SUCCESS; inner SHADOW_NON_GATING packaging FAIL preserved; same-provider lineage explicit'
report_path.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
capture=[]
for f in sorted(p.rglob('*')):
 if f.is_file() and f.suffix.lower()!='.zip' and f.name!='capture-manifest.json':
  capture.append({'file':str(f.relative_to(p)).replace(chr(92),'/'),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
(p/'capture-manifest.json').write_text(json.dumps({'raw_zip_excluded':True,'files':capture},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'verdict':d['verdict'],'head':head,'base':base,'actual_successful_jobs':len(jobs+selfjobs),'self_capture_integrity':'PASS','self_inner_exit':validation['inner_summary']['exit_code'],'self_test':'FAIL (3/3 packaging)','prior_review_preserved':prior.name,'artifact_files':len(files),'signed_urls_saved':False}))

