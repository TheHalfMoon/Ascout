import datetime
import hashlib
import json
import pathlib
import subprocess

ROOT = pathlib.Path(__file__).resolve().parent.parent
REPO = ROOT / 'diagnostic'
OUT = ROOT / 'phase-e01'
BASE = 'ea93553a5423fd47f12a6bf282820dd199b994d4'
HEAD = '2a57e42ad1a027481f7a169fe5d670eb751aec82'

def run(args):
    result = subprocess.run(['rtk', 'proxy', *args], cwd=REPO, text=True, capture_output=True, check=True)
    return result.stdout

def capture(name, args):
    value = json.loads(run(args))
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
    return value

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

pr = capture('close-pr-metadata.json', ['gh', 'pr', 'view', '638', '--json', 'url,title,state,headRefOid,baseRefOid,mergeable,mergeStateStatus,reviewDecision,statusCheckRollup,comments,files'])
reviews = capture('close-submitted-reviews.json', ['gh', 'api', 'repos/TheHalfMoon/Ascout/pulls/638/reviews'])
threads = capture('close-inline-threads.json', ['gh', 'api', 'graphql', '-f', 'query={repository(owner:"TheHalfMoon",name:"Ascout"){pullRequest(number:638){headRefOid baseRefOid reviewThreads(first:100){totalCount pageInfo{hasNextPage} nodes{isResolved isOutdated path line comments(first:10){nodes{author{login}body url}}}}}}}'])
ci = capture('close-project-ci.json', ['gh', 'api', 'repos/TheHalfMoon/Ascout/actions/runs/39482504721', '--jq', '{id,head_sha,run_attempt,status,conclusion,path,html_url}'])
jobs = capture('close-project-jobs.json', ['gh', 'api', 'repos/TheHalfMoon/Ascout/actions/runs/39482504721/attempts/2/jobs', '--jq', '[.jobs[] | {name,head_sha,conclusion,steps:[.steps[]|{name,conclusion}]}]'])
selfverify = capture('close-self-verify.json', ['gh', 'api', 'repos/TheHalfMoon/Ascout/actions/runs/39482504882', '--jq', '{id,head_sha,run_attempt,status,conclusion,path,html_url}'])
main = capture('close-live-main.json', ['gh', 'api', 'repos/TheHalfMoon/Ascout/branches/main', '--jq', '{name,sha:.commit.sha,protected}'])
files = run(['git', 'diff', '--name-only', BASE + '..' + HEAD]).splitlines()
status = run(['git', 'status', '--porcelain']).strip()
local_head = run(['git', 'rev-parse', 'HEAD']).strip()
assert pr['headRefOid'] == HEAD == local_head
assert pr['baseRefOid'] == BASE == main['sha']
assert status == ''
assert len(files) == 4
assert len(pr['statusCheckRollup']) == 7
assert all(c['conclusion'] == 'SUCCESS' for c in pr['statusCheckRollup'])
assert ci['head_sha'] == selfverify['head_sha'] == HEAD
assert ci['conclusion'] == selfverify['conclusion'] == 'success'
assert len(jobs) == 6 and all(j['head_sha'] == HEAD and j['conclusion'] == 'success' for j in jobs)
thread_data = threads['data']['repository']['pullRequest']['reviewThreads']
assert thread_data['totalCount'] == 0 and not thread_data['pageInfo']['hasNextPage']
manifest = json.loads((OUT / 'manifest-panel.json').read_text(encoding='utf-8-sig'))
source_hashes = {name: sha(REPO / name) for name in files}
assert source_hashes == manifest['sources']
full_path = ROOT / 'runs/e01-isolated-full-suite-20742d55-e55c-4131-a18a-a38dab6ad064.json'
full = json.loads(full_path.read_text(encoding='utf-8-sig'))
assert full['exit'] == 0 and full['source_unchanged'] and full['source_start']['head'] == HEAD == full['source_end']['head']
assert sha(full_path.parent / full['stdout']) == full['stdout_sha256']
assert sha(full_path.parent / full['stderr']) == full['stderr_sha256']
evidence_paths = [OUT / name for name in ['reviews.json', 'manifest-panel.json', 'qualification-full.json', 'original-eight.json', 'panel-exact-head-unit-green.json', 'panel-exact-head-unit-green.log', 'panel-exact-head-typecheck.log', 'panel-exact-head-build.log', 'close-pr-metadata.json', 'close-submitted-reviews.json', 'close-inline-threads.json', 'close-project-ci.json', 'close-project-jobs.json', 'close-self-verify.json', 'close-live-main.json']]
evidence_paths += [ROOT / 'governance-current.json', ROOT / 'plan-audit.json', full_path, full_path.parent / full['stdout'], full_path.parent / full['stderr']]
report = {
  'task': 'REA-E01',
  'captured_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
  'reviewed_range': {'base': BASE, 'head': HEAD, 'tree': full['source_end']['head_tree']},
  'audited_plan': '442b999e28bfd94080ba752795cb4eb2af2a6b3c',
  'method': 'Fresh-context READONLY integrated PStack close combined judge, reviewing all four changed files and native seam contracts against audited Spec018 intent; prior separate correctness/security findings and exact-head reconciliation inspected. Same inherited model/provider lineage, not independent-provider verification. No product edits, dependency installation, test reruns, PR approval, or merge performed.',
  'panel': 'light combined correctness/parsimony/product; boundary-security trigger covered by prior separate exact-head security review plus final boundary inspection',
  'criteria': [
    {'criterion': 'Every original input accounted exactly once, in original order', 'result': 'CLEAR', 'evidence': 'Frozen eight-observation fixture independently pins original bytes; explicit retained/suppressed/locationless/diff-excluded/rejected/missing/unknown-location assertions and duplicate disposition failures.'},
    {'criterion': 'Source/execution identity and original path/payload integrity', 'result': 'CLEAR', 'evidence': 'Strict deep equality for original/output/exclusions, coverage/location head agreement, changed-field/cross-wired-validation/foreign-ID/unsafe-path regressions; no repaired raw paths.'},
    {'criterion': 'Incomplete and uncertain outcomes never become clean scan or coverage claims', 'result': 'CLEAR', 'evidence': 'Missing outputs remain MISSING_OUTPUT; rejected originals remain REJECTED_INPUT; complete accounting is explicitly independent of coverage, promotability, and authority; no new PASS/status carrier.'},
    {'criterion': 'Existing API compatibility and branch purity', 'result': 'CLEAR', 'evidence': 'Original normalization implementation/signature unchanged; additive API composes existing validators/coverage/normalization; exactly four authorized paths, unchanged lockfile, CLI, kernel and security contracts; clean exact HEAD; live main still equals base.'},
    {'criterion': 'Product intent and parsimony', 'result': 'CLEAR', 'evidence': 'Implements only the planned accounting seam with native Map/Set, strict equality and existing contracts. No dependency, graph, daemon, new canonical Finding, CLI expansion, or speculative integration. Callers must supply independent pre-filter inventory as documented.'},
    {'criterion': 'Qualification and review reconciliation', 'result': 'CLEAR', 'evidence': '39 focused / 114 selected tests, noEmit and build recorded PASS; initial malformed-location/category findings repaired with 9 RED-to-GREEN cases; isolated native suite exit 0, 236 files, 2270 pass, 34 existing skips; exact source unchanged; original EPERM control preserved. Six platform/Node lanes and self-verification actually executed successfully at exact head, attempt 2.'},
    {'criterion': 'Current submitted reviews and unresolved threads', 'result': 'CLEAR', 'evidence': 'Live GitHub returned no submitted reviews, no issue comments and zero inline review threads with complete pagination; no material unresolved finding detected.'}
  ],
  'source_files': source_hashes,
  'all_changed_files_covered': True,
  'all_changed_files_count': 4,
  'findings': [],
  'verdict': 'CLEAR_FOR_REA_E01_CLOSE_REVIEW_AT_EXACT_RANGE',
  'local_native': {'exit': 0, 'files_passed': 236, 'tests_passed': 2270, 'existing_skips': 34, 'source_unchanged': True, 'stdout_sha256': full['stdout_sha256']},
  'hosted': {'project_ci': ci, 'self_verification': selfverify, 'successful_checks': 7, 'submitted_reviews': len(reviews), 'inline_threads': 0, 'mergeable': pr['mergeable'], 'merge_state': pr['mergeStateStatus']},
  'governance_reconciliation': 'Current direct user attachment authorizes finishing bounded Spec018 and merges conditioned on effective gates. Earlier plan/task documentation records historical no-merge/pending status; current authority is reconciled in governance-current.json and final registry/status publication remains orchestrator work. P06-specific provider/attempt-1/founder approval conditions are not imported into E01. This review does not itself ratify policy or authorize another task/security phase.',
  'limits': ['Review is same-model/provider lineage fresh context.', 'Existing suite platform skips and original failed EPERM control remain recorded.', 'Evidence publication and post-merge canonical verification are orchestrator responsibilities; no release-ready or merged claim is made.'],
  'evidence_sha256': {str(path.relative_to(ROOT)).replace('\\', '/'): sha(path) for path in evidence_paths}
}
(OUT / 'close-review.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'verdict': report['verdict'], 'path': str(OUT / 'close-review.json'), 'sha256': sha(OUT / 'close-review.json'), 'files': len(files), 'checks': 7}))
