from pathlib import Path

root = Path(__file__).resolve().parent
capture = (root/'capture-close-review.py').read_text()
capture = capture.replace("OUT = EVIDENCE / 'ci-current'", "OUT = EVIDENCE / 'ci-integrated'")
replacements = {
    '48902389ec37019845fd67c8b8c53c5f499ffc85':'36d1e504b300780d68b7bb692f90179e79b8c8bb',
    '4b64b8ec3105670dee4fe39c920a5991b2f88b1d':'4a8ad4c6a49b4355e45b73abc32327c0f093c74a',
    '39521429023':'39627705872',
    '39521429191':'39627705866',
}
for old,new in replacements.items():
    capture = capture.replace(old,new)
capture = capture.replace("for job in jobs['jobs']:", "for job in jobs['jobs']:\n        if job['status'] != 'completed':\n            continue")
(root/'capture-integrated.py').write_text(capture, encoding='utf-8')
report = (root/'write-close-review.py').read_text()
report = report.replace("CI = ROOT / 'ci-current'", "CI = ROOT / 'ci-integrated'")
for old,new in replacements.items():
    report = report.replace(old,new)
report = report.replace("['6a502300d11b725f7947d9b16226b2b7f5c4497c', BASE]", "['4b64b8ec3105670dee4fe39c920a5991b2f88b1d', BASE]")
report = report.replace("No E01/browser coupling or imported E02/E03 source. Current integrated native suites test E01+E04 together.", "E01 diagnostics and E03 optional Stryker translator have no browser imports, shared runtime mutation or changed browser contracts. E03 contributes only translator/test/docs and unchanged mutation-adapter composition. Current integrated native suites test E01+E03+E04 together; no E02 source imported.")
report = report.replace("E01 main adds diagnostic-accounting.ts, finding-normalization.ts changes, review-diagnostic-accounting.test.ts and REA-E01 docs; no browser overlap.", "Prior main merge integrated E01. Current forward merge integrates E03 stryker-output.ts, its focused tests and qualification docs; no browser overlap and no mutation-adapter edit.")
report = report.replace("'artifact_zip':{'file':str(CI/'self-artifact-12310774825.zip'),'sha256':digest(CI/'self-artifact-12310774825.zip'),'bytes':(CI/'self-artifact-12310774825.zip').stat().st_size,'matches_github_uploaded_digest':digest(CI/'self-artifact-12310774825.zip')=='f9646580b6283b2cfb49a794182298d0684211ff063b7e5b6da9052cdf177483'},", "'artifact_zip':read('artifact-download.json'),")
report = report.replace("(ROOT/'close-review.json').write_text(json.dumps(report,indent=2)+'\\n',encoding='utf-8')", "report['previous_close_review'] = {'file':str(ROOT/'close-review-4b64b8ec.json'),'sha256':digest(ROOT/'close-review-4b64b8ec.json'),'source_head':'4b64b8ec3105670dee4fe39c920a5991b2f88b1d','new_merge_parent':BASE}\n(ROOT/'close-review-integrated.tmp').write_text(json.dumps(report,indent=2)+'\\n',encoding='utf-8')\n(ROOT/'close-review-integrated.tmp').replace(ROOT/'close-review-integrated.json')\n(ROOT/'close-review.tmp').write_text(json.dumps(report,indent=2)+'\\n',encoding='utf-8')\n(ROOT/'close-review.tmp').replace(ROOT/'close-review.json')")
(root/'write-integrated-review.py').write_text(report,encoding='utf-8')
print('Prepared integrated capture and atomic close-review scripts')
