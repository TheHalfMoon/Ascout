import hashlib
import json
import subprocess
from pathlib import Path
from datetime import datetime, timezone

EVIDENCE = Path(__file__).resolve().parent
REPO = EVIDENCE.parent / 'browser'
OUT = EVIDENCE / 'ci-integrated'
OUT.mkdir(exist_ok=True)
BASE = '36d1e504b300780d68b7bb692f90179e79b8c8bb'
HEAD = '4a8ad4c6a49b4355e45b73abc32327c0f093c74a'
OCR = '<USERPROFILE>/AppData/Roaming/npm/node_modules/@alibaba-group/open-code-review/bin/ocr.js'

def run(args, destination=None):
    p = subprocess.run(['rtk', 'proxy', *args], cwd=REPO, capture_output=True)
    if destination:
        (OUT / destination).write_bytes(p.stdout)
        (OUT / (destination + '.stderr')).write_bytes(p.stderr)
    if p.returncode:
        raise RuntimeError(str(args) + ': ' + p.stderr.decode('utf-8', errors='replace'))
    return p.stdout.decode('utf-8')

def api(path, name):
    return json.loads(run(['gh', 'api', path], name))

assert run(['git','rev-parse','HEAD']).strip() == HEAD
assert not run(['git','status','--porcelain']).strip()
run(['git', 'diff', BASE, HEAD], 'exact-range.diff')
run(['git', 'diff', '--check', BASE, HEAD], 'diff-check.log')
run(['git', 'log', '--format=%H %P %s', BASE+'..'+HEAD], 'commits.log')
run(['git', 'show', '--format=fuller', '--stat', HEAD], 'merge-commit.log')
run(['git', 'diff', '--name-status', BASE, HEAD], 'changed-paths.log')
pr = api('repos/TheHalfMoon/Ascout/pulls/641', 'pr.json')
api('repos/TheHalfMoon/Ascout/pulls/641/reviews?per_page=100', 'reviews.json')
api('repos/TheHalfMoon/Ascout/pulls/641/comments?per_page=100', 'inline-comments.json')
query = 'query { repository(owner:"TheHalfMoon",name:"Ascout") { pullRequest(number:641) { reviewThreads(first:100) { totalCount pageInfo { hasNextPage endCursor } nodes { isResolved isOutdated path line comments(first:100) { nodes { body url } } } } } } }'
run(['gh','api','graphql','-f','query='+query], 'review-threads.json')
checks = api('repos/TheHalfMoon/Ascout/commits/'+HEAD+'/check-runs?per_page=100', 'check-runs.json')
runs = []
for rid in [39627705872,39627705866]:
    metadata = api('repos/TheHalfMoon/Ascout/actions/runs/'+str(rid), str(rid)+'-run.json')
    jobs = api('repos/TheHalfMoon/Ascout/actions/runs/'+str(rid)+'/jobs?per_page=100', str(rid)+'-jobs.json')
    assert metadata['head_sha'] == HEAD
    for job in jobs['jobs']:
        if job['status'] != 'completed':
            continue
        run(['gh','api','repos/TheHalfMoon/Ascout/actions/jobs/'+str(job['id'])+'/logs'], str(job['id'])+'.log')
    runs.append({'id':rid,'run':metadata,'jobs':jobs})
manifest = json.loads((EVIDENCE/'evidence-exact.json').read_text())
hashes = {}
for path, digest in manifest['source_sha256'].items():
    actual = hashlib.sha256((REPO/path).read_bytes()).hexdigest()
    assert actual == digest
    hashes[path] = actual
    assert not run(['git','diff',manifest['source_head'],HEAD,'--',path]).strip()
run(['node',OCR,'delegate','preview','--from',BASE,'--to',HEAD], 'ocr-preview.log')
run(['node',OCR,'delegate','rule',*hashes], 'ocr-rules.log')
capture = {'captured_utc':datetime.now(timezone.utc).isoformat(),'base':BASE,'head':HEAD,'tree':run(['git','rev-parse','HEAD^{tree}']).strip(),'source_sha256':hashes,'all_six_feature_files_unchanged_since_review':True,'files':{p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in OUT.iterdir() if p.is_file() and p.name != 'capture.json'}}
(OUT/'capture.json').write_text(json.dumps(capture,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'capture':str(OUT/'capture.json'),'jobs':[{ 'run':r['id'], 'jobs':[{k:j[k] for k in ['id','name','status','conclusion']} for j in r['jobs']['jobs']]} for r in runs], 'hashes_verified':len(hashes)}))
