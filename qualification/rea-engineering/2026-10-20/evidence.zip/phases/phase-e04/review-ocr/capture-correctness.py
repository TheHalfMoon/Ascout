import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / "browser"
EVIDENCE = ROOT.parent / "phase-e04"
HEAD = "6a502300d11b725f7947d9b16226b2b7f5c4497c"
BASE = "ea93553a5423fd47f12a6bf282820dd199b994d4"
OCR = "<USERPROFILE>/AppData/Roaming/npm/node_modules/@alibaba-group/open-code-review/bin/ocr.js"
manifest = json.loads((EVIDENCE / "evidence-exact.json").read_text())

def run(args):
    result = subprocess.run(["rtk", "proxy", *args], cwd=REPO, capture_output=True, text=True, encoding="utf-8")
    if result.returncode:
        raise RuntimeError(f"{args}: {result.stderr}")
    return result.stdout

actual_head = run(["git", "rev-parse", "HEAD"]).strip()
actual_tree = run(["git", "rev-parse", "HEAD^{tree}"]).strip()
status = run(["git", "status", "--porcelain"])
assert actual_head == HEAD and not status
assert actual_tree == manifest["source_tree"]

hash_checks = {}
for path, expected in manifest["source_sha256"].items():
    actual = hashlib.sha256((REPO / path).read_bytes()).hexdigest()
    assert actual == expected, path
    hash_checks[path] = actual
log_checks = {}
for path, expected in manifest["logs_sha256"].items():
    actual = hashlib.sha256((EVIDENCE / path).read_bytes()).hexdigest()
    assert actual == expected, path
    log_checks[path] = actual
fixture_lines = (REPO / "tests/browser-text-assertion.integration.test.ts").read_bytes().splitlines()
fixture = b"\n".join(line for line in fixture_lines if line.startswith(b"const PAGE =") or line.startswith(b"  response.end("))
fixture_hash = hashlib.sha256(fixture).hexdigest()
assert fixture_hash == manifest["fixture_definition_sha256"]

files = list(manifest["source_sha256"])
preview = run(["node", OCR, "delegate", "preview", "--from", BASE, "--to", HEAD])
rules = run(["node", OCR, "delegate", "rule", *files])
(ROOT / "alibaba-preview-correctness.txt").write_text(preview, encoding="utf-8")
(ROOT / "alibaba-rules-correctness.txt").write_text(rules, encoding="utf-8")

report = {
    "schema_version": 1,
    "kind": "fresh_context_pstack_combined_review",
    "captured_utc": datetime.now(timezone.utc).isoformat(),
    "repository": str(REPO),
    "base": BASE,
    "head": HEAD,
    "tree": actual_tree,
    "clean_worktree_verified": True,
    "lineage": {
        "reviewer": "separate fresh-context Codex subagent browser_correctness",
        "model": "session model inherited from orchestrator",
        "implementation_authorship": "reviewer did not implement this patch",
        "provider_independent": False,
        "alibaba_mode": "actual installed CLI delegate preview/rule; rules applied manually by this reviewer; no external model call",
        "paid_services_used": False,
    },
    "context": [
        "<USERPROFILE>/.agents/skills/ps-review/SKILL.md",
        "<USERPROFILE>/.codex/attachments/7023bf41-01d7-4366-a41f-2ddb5fb0d62e/Pasted text.txt",
        "../Ascout/specs/018-rea-engineering-qualification/spec.md",
        "../Ascout/specs/018-rea-engineering-qualification/plan.md",
        "../Ascout/specs/018-rea-engineering-qualification/tasks.md",
        "../Ascout/specs/018-rea-engineering-qualification/IMPLEMENTATION_SCOPE.md",
        "../governance-current.json",
        "src/browser/locators.ts and src/browser/recovery.ts",
        "existing browser executor/playwright contracts and existing readTargetText callers",
    ],
    "coverage": [
        {"file": "src/browser/executor.ts", "lines": "99-108,433-462", "bars": ["correctness", "parsimony", "product", "Alibaba TypeScript rules"], "result": "closed exact_text kind; canonical string identities; bounded target/expected data and integer timeout; fresh primitive-field snapshot"},
        {"file": "src/browser/playwright-adapter.ts", "lines": "67-70,424-478,504-530", "bars": ["correctness", "parsimony", "product", "Alibaba TypeScript rules"], "result": "session/source admission before resolution; literal DOM comparison; one outer monotonic deadline includes resolution/read/compare; active check after await; mapped failures; fresh response per request; unchanged free-text path"},
        {"file": "tests/browser-text-assertion.contract.test.ts", "lines": "1-36", "bars": ["correctness", "product", "Alibaba TypeScript rules (manual excluded-file coverage)"], "result": "literal and malformed/boundary request data covered; no implementation mirror replacing actual browser tests"},
        {"file": "tests/browser-text-assertion.integration.test.ts", "lines": "1-145", "bars": ["correctness", "product", "Alibaba TypeScript rules (manual excluded-file coverage)"], "result": "owned loopback actual Chromium; exact/empty/code text, role/name, broken/working, expired/missing/ambiguous/invalid target, shared resolver budget, foreign/malformed, deferred text and disposal covered; retained failed response survives later success"},
        {"file": "docs/browser-playwright-adapter.md", "lines": "85-117", "bars": ["correctness", "product", "Alibaba default rules (manual excluded-file coverage)"], "result": "accurate exact raw text semantics, bounds, deadline and explicit unsupported/release limits"},
        {"file": "docs/qualification/REA-E04.md", "lines": "1-52", "bars": ["correctness", "product", "Alibaba default rules (manual excluded-file coverage)"], "result": "retains RED/GREEN lineage, scope and pending qualification; honestly states no retry ledger, visibility, oracle or provider-independent review"},
    ],
    "compatibility": {
        "old_readTargetText": "Signature and raw textContent result unchanged. Existing callers inspected use positive bounded timeout values; subtracting synchronous resolver elapsed time enforces that existing supported budget. Zero/unbounded timeout is outside the validated 1..120000 request contract.",
        "response_history": "New operation reuses existing readonly response envelope, returns a fresh response/error value, and never mutates earlier responses. No runtime Object.freeze or durable retry ledger exists or is claimed; existing recovery module remains unchanged.",
        "locator": "New path calls the same injected resolver and readTargetText; no selection fallback or policy bypass added. Role/name delegation is exercised through Playwright selector syntax; ambiguity remains fail-closed.",
        "minimal_subset": "Spec018 plan explicitly allows one minimal subset; visibility/input-value additions are optional, so exact_text alone meets this bounded task's feature intent.",
    },
    "findings": {"must_fix": [], "worth_considering": [], "skip_it": []},
    "verdicts": {
        "correctness": "PASS: no demonstrated regression or boundary defect in the reviewed six-file diff",
        "parsimony": "PASS: additive request/factory and one runtime method reuse existing read and response contracts; no dependency/framework or speculative kinds",
        "product": "PASS for bounded REA-E04 implementation intent; qualification and publication are separate incomplete work",
        "overall": "PASS_WITH_QUALIFICATION_LIMITS",
    },
    "alibaba": {"preview": "alibaba-preview-correctness.txt", "rules": "alibaba-rules-correctness.txt", "reviewable": 2, "total_changed": 6, "manual_exclusions": ["both tests: default_path", "both docs: unsupported_ext"], "actual_rules_applied": "typos/dead code/duplication/comments/hardcoding/types/nulls/equality/async/injection/secrets/prototypes; React-only rules inapplicable; docs default correctness/security/performance/maintainability/test coverage assessed"},
    "evidence_validation": {"source_sha256_all_match": hash_checks, "logs_sha256_all_match": log_checks, "fixture_sha256_match": fixture_hash, "manifest": "../phase-e04/evidence-exact.json", "reported_exact_results": manifest["results"], "own_execution": "static review, actual Alibaba CLI preview/rules and immutable hash checks only; no heavy browser/full suite rerun"},
    "limits": [
        "Not a merge, release, hosted CI, complete-suite or integrated-main approval.",
        "No fresh browser execution; retained exact-head typecheck/build/17 files 160 tests logs were read and all manifest hashes verified.",
        "Full suite controlled by orchestrator; no concurrent heavy tests run during known localhost resource contention.",
        "Security trust-boundary review belongs to separately assigned security reviewer; combined report is not substituted for that gate.",
        "Same-model fresh-context local review is not independent-provider verification; no Claude gate claimed. P06-only gates are not automatically applied to Spec018.",
    ],
    "panel": "combined fresh-context correctness/parsimony/product plus actual Alibaba local delegation rules; security separate",
}
(ROOT / "review-correctness.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"report": str(ROOT / "review-correctness.json"), "head": actual_head, "source_hashes_verified": len(hash_checks), "log_hashes_verified": len(log_checks), "fixture_hash_verified": fixture_hash, "verdict": report["verdicts"]["overall"]}))
