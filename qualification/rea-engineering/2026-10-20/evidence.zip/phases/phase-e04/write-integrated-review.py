import hashlib
import json
import re
import subprocess
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
CI = ROOT / 'ci-integrated'
REPO = ROOT.parent / 'browser'
HEAD = '4a8ad4c6a49b4355e45b73abc32327c0f093c74a'
BASE = '36d1e504b300780d68b7bb692f90179e79b8c8bb'

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def git(*args):
    p = subprocess.run(['rtk','proxy','git',*args], cwd=REPO, capture_output=True, text=True, encoding='utf-8')
    assert p.returncode == 0, p.stderr
    return p.stdout.strip()

def read(name):
    return json.loads((CI/name).read_text(encoding='utf-8'))

assert git('rev-parse','HEAD') == HEAD
assert not git('status','--porcelain')
assert git('merge-base',BASE,HEAD) == BASE
assert git('show','-s','--format=%P',HEAD).split() == ['4b64b8ec3105670dee4fe39c920a5991b2f88b1d', BASE]
capture = read('capture.json')
old = json.loads((ROOT/'evidence-exact.json').read_text())
for p,h in old['source_sha256'].items():
    assert digest(REPO/p) == h
for p,h in old['logs_sha256'].items():
    assert digest(ROOT/p) == h
assert set(git('diff','--name-only',BASE,HEAD).splitlines()) == set(old['source_sha256'])
native = []
assert len(read('39627705872-jobs.json')['jobs']) == 6
assert read('39627705872-run.json')['status'] == 'completed'
assert read('39627705872-run.json')['conclusion'] == 'success'
for job in read('39627705872-jobs.json')['jobs']:
    log_path = CI/(str(job['id'])+'.log')
    text = re.sub(r'(?:\x1b|\^\[)\[[0-9;]*m','',log_path.read_text(encoding='utf-8'))
    lines = text.splitlines()
    assert job['conclusion'] == 'success'
    assert 'EXPECTED_SHA: '+HEAD in text
    assert '> tsc -p tsconfig.json --noEmit' in text
    assert '> tsc -p tsconfig.json' in text
    assert 'tests/browser-text-assertion.integration.test.ts' in text
    assert 'tests/browser-text-assertion.contract.test.ts' in text
    assert 'tests/npm-package-content.test.ts' in text
    steps = {s['name']:s['conclusion'] for s in job['steps']}
    test_step = 'Test (Windows bounded workers)' if 'windows' in job['name'] else 'Test'
    required = ['Guard exact source','Install exact lockfile','Provision exact Chromium runtime','Typecheck',test_step,'Build']
    assert all(steps[k] == 'success' for k in required)
    summaries = [line.split('\t')[-1] for line in lines if any(k in line for k in ['Test Files','      Tests ','   Duration'])]
    native.append({'id':job['id'],'name':job['name'],'status':job['status'],'conclusion':job['conclusion'],'required_steps':{k:steps[k] for k in required},'full_suite_summary':summaries,'exact_source_guard':HEAD,'new_tests':'8 integration + 2 contract tests passed','same_shadow_failing_package_test':'passed in native suite','log':str(log_path),'log_sha256':digest(log_path),'log_bytes':log_path.stat().st_size})
artifacts = {p.name:p for p in (CI/'self-artifact').rglob('*.json')}
envelope = json.loads(artifacts['self-verification-envelope.json'].read_text())
receipt = json.loads(artifacts['self-verification-receipt.json'].read_text())
assert envelope['classification'] == 'SHADOW_NON_GATING'
assert receipt['summary']['exit_code'] == 1, 'Current shadow outcome changed; review and update template before publishing'
assert [finding['path'] for finding in receipt['findings']] == ['tests/npm-package-content.test.ts'], 'Current shadow findings changed; review before publishing'
assert envelope['subject_target_head_sha'] == HEAD
assert envelope['subject_merge_base_sha'] == BASE
assert digest(artifacts['self-verification-receipt.json']) == envelope['receipt_sha256']
self_job = read('39627705866-jobs.json')['jobs'][0]
assert len(read('39627705866-jobs.json')['jobs']) == 1
assert read('39627705866-run.json')['status'] == 'completed'
assert self_job['conclusion'] == 'success'
threads = read('review-threads.json')['data']['repository']['pullRequest']['reviewThreads']
assert threads['totalCount'] == 0 and not threads['pageInfo']['hasNextPage']
assert read('reviews.json') == [] and read('inline-comments.json') == []
pr = read('pr.json')
assert pr['head']['sha'] == HEAD and pr['base']['sha'] == BASE
tester = json.loads((ROOT/'testerarmy-summary.json').read_text())
assert tester['controls_match'] and [r['exit'] for r in tester['runs']] == [0,1]
assert all(r['usage']['modelTokens'] == 0 for r in tester['runs'])
for run in tester['runs']:
    for p,h in run['fixture_hashes'].items():
        assert digest(ROOT/'testerarmy'/run['mode']/p) == h
coverage = [
 {'file':'src/browser/executor.ts','bars':['correctness','parsimony','product','Alibaba TypeScript rules'],'assessment':'Additive closed exact_text request/factory; primitive string identities; target 1..4096 code units, expected literal <=65536 code units and integer 1..120000ms timeout; returned scalar snapshot. No executable predicates or dependencies.'},
 {'file':'src/browser/playwright-adapter.ts','bars':['integrated correctness','parsimony','product','Alibaba TypeScript rules','security continuity'],'assessment':'Validated session/source admission before resolver, existing resolver authority and strict raw text equality. Shared monotonic budget deducts trusted synchronous resolver time, checks after read and comparison, and maps missing/invalid/ambiguous/disposed results without success. Existing read callers use positive bounded timeouts; no public signature changed. New responses copy error/scalars and do not mutate prior observations.'},
 {'file':'tests/browser-text-assertion.contract.test.ts','bars':['correctness','product','manual Alibaba excluded-file coverage'],'assessment':'All 36 lines manually reviewed; literal/empty/whitespace/code strings and malformed/type/size/kind/time limits. Default OCR path excludes tests; actual TypeScript rules explicitly loaded for them. 2 tests pass on all six lanes.'},
 {'file':'tests/browser-text-assertion.integration.test.ts','bars':['correctness','product','manual Alibaba excluded-file coverage'],'assessment':'All 145 lines manually reviewed; owned inline loopback real Chromium controls cover exact/empty/literal/role target; wrong/broken and retained prior failure; expired/missing/ambiguous/invalid selector; exhausted/shared resolver budget; source/session/malformed rejection before resolution; unsupported free-text and disposal. 8 tests pass on all six lanes.'},
 {'file':'docs/browser-playwright-adapter.md','bars':['product','correctness','manual Alibaba unsupported-extension coverage'],'assessment':'All changed documentation reviewed with actual default rules: exact raw text only, no visibility/retry predicate, bounded inputs, callback non-preemption and local observation/evidence limits accurately stated.'},
 {'file':'docs/qualification/REA-E04.md','bars':['product','correctness','manual Alibaba unsupported-extension coverage'],'assessment':'All 52 lines manually reviewed: retained RED/GREEN lineage, source-bound real-browser scope, unsupported/release/provider limits and no durable retry ledger. Builder-time statements are historical; current CI and external fixture control are additive evidence, not rewrites of failures.'},
]
baseline_prefix = ROOT.parent/'runs/exact-main-full-suite-f9b1bd65-96a9-47ec-b1ba-0c9e4c1e1524'
baseline_meta = json.loads(Path(str(baseline_prefix)+'.json').read_text())
baseline_stderr = Path(str(baseline_prefix)+'.stderr.txt')
assert digest(baseline_stderr) == baseline_meta['stderr_sha256']
assert 'T082 requires npm_execpath from the canonical npm test invocation' in baseline_stderr.read_text(encoding='utf-8')
source_context = {
 'captured_utc':datetime.now(timezone.utc).isoformat(),
 'exact_head':HEAD,
 'current_shadow_exact_error_available':False,
 'current_shadow_error_evidence':'Receipt has only normalized test identity/message. Its test stderr is recorded empty (sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855); the raw Vitest JSON/stdout referenced by hash/path is not among the three uploaded artifact members. It is not possible to extract the exact historical exception from the uploaded artifact.',
 'baseline_exact_exception':'Error: T082 requires npm_execpath from the canonical npm test invocation',
 'baseline_stack':'runNpm tests/npm-package-content.test.ts:30:11; test invocation line 137:36',
 'baseline_source':baseline_meta['source_start'],
 'baseline_command':baseline_meta['argv'],
 'baseline_execution':{'metadata':str(Path(str(baseline_prefix)+'.json')),'metadata_sha256':digest(Path(str(baseline_prefix)+'.json')),'stderr':str(baseline_stderr),'stderr_sha256':digest(baseline_stderr),'stdout':str(Path(str(baseline_prefix)+'.stdout.txt')),'stdout_sha256':digest(Path(str(baseline_prefix)+'.stdout.txt')),'exit':baseline_meta['exit'],'source_unchanged':baseline_meta['source_unchanged']},
 'source_context':{},
 'classification':'Reconciled existing canonical-npm invocation compatibility limitation, not an E04 regression demonstrated. Exact exception confirmed in unchanged-main direct-Vitest baseline; current shadow exhibits same test identity via direct Vitest, while six canonical npm test executions pass it. Current exact exception remains unavailable and is not falsely equated with the baseline stack.',
 'mandatory_gate_basis':{'file':'specs/006-self-verification-shadow-receipt/spec.md','line':130,'quote':'A valid, source-bound receipt exit 0/1/3/4 is successful capture. Job green means capture integrity, not a clean receipt verdict. Exit 2 is never successful shadow capture evidence.','interpretation':'Applicable Self Verification requires valid non-gating capture, not producer exit 0. Spec018 separately requires complete passing native controls, supplied by the six actual Project CI suites. No policy waiver or failure relabeling.'},
 'artifact_zip':read('artifact-download.json'),
}
for name,ranges in {'tests/npm-package-content.test.ts':[(27,45),(122,144)],'benchmarks/self-verify.mjs':[(178,185),(457,474),(483,529)],'.github/workflows/self-verify.yml':[(1,75)],'specs/006-self-verification-shadow-receipt/spec.md':[(120,132)]}.items():
    lines = (REPO/name).read_text(encoding='utf-8').splitlines()
    source_context['source_context'][name] = {'sha256':digest(REPO/name),'unchanged_in_e04':not git('diff',BASE,HEAD,'--',name),'snippets':[{'start':start,'end':end,'text':'\n'.join(f'{i+1}: {line}' for i,line in enumerate(lines) if start<=i+1<=end)} for start,end in ranges]}
(CI/'shadow-investigation.json').write_text(json.dumps(source_context,indent=2)+'\n',encoding='utf-8')
report = {
 'schema_version':1,
 'kind':'fresh_context_pstack_integrated_close_review_and_native_ci_audit',
 'captured_utc':datetime.now(timezone.utc).isoformat(),
 'repository':str(REPO),'base':BASE,'head':HEAD,'tree':git('rev-parse','HEAD^{tree}'),
 'verdict':'PASS_SOURCE_REVIEW_AND_NATIVE_CI_WITH_PRESERVED_NON_GATING_SHADOW_FAILURE',
 'findings':{'must_fix':[],'worth_considering':[],'skip_it':[], 'reconciled_observations':[{'kind':'existing_shadow_invocation_compatibility_limitation','file':'tests/npm-package-content.test.ts','observation':'Self Verification workflow succeeds but its explicitly SHADOW_NON_GATING receipt records test FAIL, 3 runs/3 failures, receipt exit 1 and materially_incomplete. Same unchanged test passes all six canonical npm test lanes. Receipt is not clean.','investigation':str(CI/'shadow-investigation.json'),'classification':source_context['classification'],'gate_basis':source_context['mandatory_gate_basis'],'resolution':'Retained complete raw artifact ZIP with matching GitHub-uploaded SHA256, decompressed bytes, current normalized failure and baseline exact exception/source lineage. No source finding against E04 and no requirement for producer PASS in the canonical shadow gate. No assertion that the producer failure is fixed; any separate runner/test compatibility repair belongs in bounded E00 work.'}]},
 'coverage':coverage,
 'integration':{'parents':git('show','-s','--format=%P',HEAD).split(),'clean_worktree':True,'main_is_ancestor':True,'source_sha256':capture['source_sha256'],'all_six_files_unchanged_since_original_review':True,'forward_merge_only':'Prior main merge integrated E01. Current forward merge integrates E03 stryker-output.ts, its focused tests and qualification docs; no browser overlap and no mutation-adapter edit. Exact current-main..HEAD diff is only six allowed E04 files, 386 insertions/4 deletions. No workflow/package/lock/kernel/security/CLI edits.','cross_surface_assessment':'E01 diagnostics and E03 optional Stryker translator have no browser imports, shared runtime mutation or changed browser contracts. E03 contributes only translator/test/docs and unchanged mutation-adapter composition. Current integrated native suites test E01+E03+E04 together; no E02 source imported.','dependency_scope':'Spec018 tasks/plan explicitly independent; E04 depends on already merged P016 browser runtime + exact plan audit, not E02/E03. E03 is now on main. Separate E02 blockers are not relabeled as passes.'},
 'criteria':{'bounded_typed_literal_intent':'PASS','identity_and_locator_binding':'PASS','missing_ambiguous_invalid_broken_timeout_disposal_fail_closed':'PASS','unsupported_free_text_remains_unavailable':'PASS','retained_prior_failure_not_overwritten':'PASS','real_owned_fixture_and_pinned_chromium':'PASS: native CI provisions playwright 1.63.0 Chromium revision 1243; both browser assertion files pass all lanes','compatibility':'PASS for existing bounded contracts; additive API, unchanged existing signatures','tests_first_lineage':'Preserved RED 2 files/6 failed/2 passed, expanded GREEN 2 files/10 passed; earlier exact browser 17 files/160 passed. All original manifest log hashes verified.','complete_native_current_head':'PASS: six actual full-suite jobs, source guard/typecheck/build all success','qualification_limits':'No visibility API, retries, durable ledger, oracle/global coverage or release readiness claim. TesterArmy control is independent fixture validation with different normalized text semantics; not Ascout runtime verification.'},
 'native_ci':{'run_id':39627705872,'run_head':read('39627705872-run.json')['head_sha'],'run_conclusion':read('39627705872-run.json')['conclusion'],'actual_jobs':native,'platform_skips':'Existing platform skips preserved; see exact per-job native summaries for current integrated test totals. E04 new tests run and pass everywhere. Native invocation matches existing workflow: npm test on Unix and npm test -- --maxWorkers=1 on Windows. No timeout/skip/filter changes in this patch.','all_job_conclusions_checked_not_only_aggregate':True},
 'self_verification':{'run_id':39627705866,'job_id':self_job['id'],'job_status':self_job['status'],'job_conclusion':self_job['conclusion'],'steps':[{k:s[k] for k in ['name','status','conclusion']} for s in self_job['steps']],'envelope':envelope,'receipt_summary':receipt['summary'],'receipt_selection':receipt['selection'],'receipt_findings':receipt['findings'],'receipt_is_clean':False,'gate_interpretation':'Workflow confirms integrity/retention of allowed shadow receipt exits, not a clean product result. benchmark/self-verify.mjs ALLOWED_RECEIPT_EXITS includes 1 and envelope explicitly SHADOW_NON_GATING. Preserve actual failure; six canonical native suites are the passing full-suite evidence.','receipt_hash_verified':True},
 'testerarmy_control':{'report':str(ROOT/'testerarmy-summary.json'),'report_sha256':digest(ROOT/'testerarmy-summary.json'),'all_fixture_hashes_verified':True,'controls_match':True,'working_exit':0,'broken_exit':1,'broken_error':'ASSERTION_FAILED','model_tokens':0,'scope':'Same underlying owned HTML fixture, role/name locator, normalized text and visibility; does not attest Ascout exact raw equality or add visibility API.'},
 'ocr':{'method':'Actual installed @alibaba-group/open-code-review delegate preview --from current main --to current head; delegate rule explicitly over all six files. This reviewer manually applied emitted rules to entire range including excluded files; no external Alibaba model call or provider independence claimed.','preview':str(CI/'ocr-preview.log'),'rules':str(CI/'ocr-rules.log'),'reviewable':2,'total':6,'separate_excluded_coverage':['both test files: default_path, TypeScript rules manually applied','both documentation files: unsupported_ext, default rules manually applied'],'rules_applied':'typos/dead code/duplication/comments/hardcoding/const-types/null checks/strict equality/async ordering/error handling/injection/secrets/prototype safety; React-specific rules inapplicable; docs correctness/security/performance/maintainability/test coverage.'},
 'reviews':{'pr':641,'state_at_capture':pr['state'],'draft_at_capture':pr['draft'],'submitted_reviews':[],'inline_comments':[],'review_thread_total':0,'review_threads_has_next_page':False,'original_combined_review':str(ROOT/'review-ocr/review-correctness.json'),'original_separate_security_review':str(ROOT/'review-security.json'),'security_continuity':'Prior separate fresh-context security review covers all six byte-identical feature files. Current integrated review found no new trust-boundary interactions from E01 or E03. E03 translator is an isolated additive module with no browser imports or shared side effects. Security review remains same-provider, not independent-provider.'},
 'source_artifact_hashes':{name:digest(ROOT/name) for name in ['evidence-exact.json','review-security.json','review-ocr/review-correctness.json','testerarmy-summary.json']},
 'ci_evidence_hashes':{str(p.relative_to(CI)):{'sha256':digest(p),'bytes':p.stat().st_size} for p in CI.rglob('*') if p.is_file()},
 'governance':'Current direct founder direction plus governance-current.json/governance-sequencing.json support conditioned Spec018 admission. No P06-only Claude/Jev/attempt-1 rule inferred. This reviewer does not issue authorization, approve PR, merge or claim external provider review.',
 'remaining_close_actions':['Orchestrator must reconcile/publish current qualification evidence, including shadow receipt failure and original failures; update stale pending PR/task status accurately.','Refresh main/head/checks immediately before any guarded merge; any source/base change invalidates this exact-range close review.','Ordinary draft-to-ready/merge and post-merge canonical main qualification remain orchestrator actions within applicable authorization.'],
 'lineage':{'reviewer':'fresh-context Codex subagent browser_close_review','authored_implementation':False,'model':'inherited session model','provider':'OpenAI','provider_independent':False,'d1_used_as_gate':False,'execution':'Static full six-file range/relevant existing seams review, exact source/log/fixture hashes, actual CLI preview/rules and live native job/step/log/artifact audit; no test rerun, install, source edits, approval or merge.'},
 'panel':'integrated fresh-context correctness/parsimony/product PASS; prior separate security retained by exact hashes; actual local Alibaba delegation/rules applied with manual excluded-file coverage; all six native CI jobs PASS; self shadow receipt FAIL preserved',
}
report['previous_close_review'] = {'file':str(ROOT/'close-review-4b64b8ec.json'),'sha256':digest(ROOT/'close-review-4b64b8ec.json'),'source_head':'4b64b8ec3105670dee4fe39c920a5991b2f88b1d','new_merge_parent':BASE}
(ROOT/'close-review-integrated.tmp').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
(ROOT/'close-review-integrated.tmp').replace(ROOT/'close-review-integrated.json')
(ROOT/'close-review.tmp').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
(ROOT/'close-review.tmp').replace(ROOT/'close-review.json')
print(json.dumps({'report':str(ROOT/'close-review.json'),'verdict':report['verdict'],'native_jobs':len(native),'source_findings':0,'shadow_receipt_exit':envelope['receipt_exit_code'],'head':HEAD}))
