import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'ci-integrated'
REPO = ROOT.parent/'browser'
RUNS = ROOT.parent/'runs'
HEAD = '4a8ad4c6a49b4355e45b73abc32327c0f093c74a'
BASE = '36d1e504b300780d68b7bb692f90179e79b8c8bb'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*args):
    p = subprocess.run(['rtk','proxy','git',*args],cwd=REPO,capture_output=True,text=True,encoding='utf-8')
    assert p.returncode == 0,p.stderr
    return p.stdout.strip()

assert git('rev-parse','HEAD') == HEAD
assert git('merge-base',BASE,HEAD) == BASE
assert not git('status','--porcelain')
initial = json.loads((ROOT/'evidence-exact.json').read_text())
sources = {name:digest(REPO/name) for name in initial['source_sha256']}
assert sources == initial['source_sha256']
assert set(git('diff','--name-only',BASE,HEAD).splitlines()) == set(sources)
delta = json.loads((OUT/'delta-static.json').read_text())
assert all(x['matches_prior_review'] for x in delta['E03_hashes_verified'])
local = []
for name in ['e04-integrated-typecheck-e2384c6c-648c-4679-a9cf-f8bd38012978.json','e04-integrated-build-678c5a3b-2ba7-4e49-8963-d0d9547a23cb.json']:
    path = RUNS/name
    meta = json.loads(path.read_text())
    assert meta['source_start']['head'] == HEAD and meta['source_end']['head'] == HEAD
    assert meta['source_unchanged'] and meta['exit'] == 0
    logs = {}
    for stream in ['stdout','stderr']:
        log = RUNS/meta[stream]
        assert digest(log) == meta[stream+'_sha256']
        logs[stream] = {'path':str(log),'sha256':digest(log),'bytes':log.stat().st_size}
    local.append({'name':meta['name'],'status':'PASS','metadata':str(path),'metadata_sha256':digest(path),'head':HEAD,'source_unchanged':True,'exit':0,'argv':meta['argv'],'logs':logs})
full_path = RUNS/'e04-integrated-full-suite-49eb825f-ebe0-482e-b56c-a08ad537930e.json'
full = json.loads(full_path.read_text())
assert full['source_start']['head'] == HEAD
full_log = RUNS/full['stdout']
failure_lines = [line for line in full_log.read_text(encoding='utf-8',errors='replace').splitlines() if '\u00d7 ' in line or 'Test timed out' in line]
snapshot = {'observed_at_checkpoint_utc':'2026-10-21T15:57:20Z','timestamp_precision':'Approximate tool-call checkpoint, not individual job API update time','head':HEAD,'project_run':39627705872,'self_run':39627705866,'project_status':'queued','self_status':'queued','jobs':[{'id':job,'status':'queued','step_count':0,'conclusion':None} for job in [119317247450,119317248046,119317248047,119317248079,119317248121,119317248321,119317246749]],'method':'Two live gh run view snapshots during review, after at least five minutes since previous read; no rerun/cancel or GitHub writes.'}
(OUT/'queued-snapshot.json').write_text(json.dumps(snapshot,indent=2)+'\n',encoding='utf-8')
report = {
 'schema_version':1,
 'kind':'conditional_fresh_integrated_close_review',
 'captured_utc':datetime.now(timezone.utc).isoformat(),
 'repository':str(REPO),'base':BASE,'head':HEAD,'tree':git('rev-parse','HEAD^{tree}'),
 'verdict':'SOURCE_AND_OCR_REVIEW_CLEAR_QUALIFICATION_PENDING_NOT_MERGE_ELIGIBLE',
 'merge_eligible':False,
 'findings':{'must_fix':[],'worth_considering':[],'source_review':'No new source/integration finding in this bounded delta. This does not clear pending test/platform/CI gates.'},
 'qualification':{'current_head_native_full_suite':'PENDING; local run active with observed failures, hosted six lanes queued zero steps','current_head_local_typecheck_build':'PASS_VERIFIED_SOURCE_AND_LOG_HASHES','current_head_hosted_project_ci':'PENDING_NOT_STARTED','current_head_self_verification':'PENDING_NOT_STARTED','previous_head_native_full_ci':'HISTORICAL_PASS_ONLY_AT_4b64b8ec; not promoted to current head','all_required_gates_cleared':False},
 'integration':{'parents':git('show','-s','--format=%P',HEAD).split(),'clean_worktree':True,'base_is_ancestor':True,'feature_files':6,'insertions':386,'deletions':4,'E04_source_sha256':sources,'all_E04_files_unchanged_since_initial_review':True,'E03_source_hashes':delta['E03_hashes_verified'],'delta_assessment':'Only E03 translator/test/docs enter through main. No mutation-adapter change, browser imports, shared runtime state or browser contract alteration. E01+E03+E04 now coexist; no E02 source imported. Original six E04 files remain the complete current-main..HEAD diff.','purity':'No workflow/package/lock/core/CLI/security policy edit in E04 range.'},
 'bars':{'correctness':'PASS_STATIC_DELTA: unchanged E04 request validation, identity admission, resolver authority, monotonic deadline and strict literal equality; no E03 call path reaches these modules. Runtime qualification at new integrated head is pending.','parsimony':'PASS: no additional E04 implementation, speculative kinds, dependency or integration abstraction.','product':'PASS_IMPLEMENTATION_INTENT: Spec018 permits one minimal exact-text subset. No visibility API/LLM/predicate execution/ledger/oracle/release claim. Real working/broken/timeout/session/disposal tests remain byte-identical; current execution gate not yet established.','security':'Prior separate E04 fresh-context security review remains bound by all six unchanged SHA256s. E03 source matches its separate prior reviewed hashes and has no browser interaction. This is continuity review, not independent-provider certification.'},
 'coverage':[{'file':name,'method':'Exact source hash verified against initial security/combined review plus current-range delta inspection','current_ci_coverage':'PENDING'} for name in sources],
 'ocr':{'method':'Actual installed Alibaba CLI delegate preview --from 36d1.. --to 4a8.. plus delegate rule over all six paths; emitted rules manually applied in this integrated delta review. No external model call.','reviewable':2,'total':6,'preview':str(OUT/'ocr-preview.log'),'preview_sha256':digest(OUT/'ocr-preview.log'),'rules':str(OUT/'ocr-rules.log'),'rules_sha256':digest(OUT/'ocr-rules.log'),'separate_excluded_coverage':[{'files':['tests/browser-text-assertion.contract.test.ts','tests/browser-text-assertion.integration.test.ts'],'reason':'default_path','assessment':'Both complete files manually covered under actual TypeScript rules, inherited review verified by exact bytes; assertions still bind raw literal text, failures and disposal.'},{'files':['docs/browser-playwright-adapter.md','docs/qualification/REA-E04.md'],'reason':'unsupported_ext','assessment':'All changed prose manually covered with actual default rules; bounds/limitations and historical evidence accurately scoped.'}]},
 'local_checks':local,
 'local_full_suite_snapshot':{'metadata':str(full_path),'metadata_sha256_at_snapshot':digest(full_path),'state':full['state'],'exit':full.get('exit'),'argv':full['argv'],'source_start':full['source_start'],'outer_capture_deadline_seconds':full['outer_capture_deadline_seconds'],'individual_deadlines_changed':full['individual_deadlines_changed'],'stdout':str(full_log),'stdout_bytes_at_snapshot':full_log.stat().st_size,'observed_failure_lines':failure_lines,'orchestrator_observation':'At least three existing deadline failures observed while run remains active: T107 private exact-runtime case and two Git digest cases. Final outcome/counts/causes remain unestablished; preserve eventual FAIL and source snapshots. No timeout/skip/suppression changes.','gate':'NOT_PASS; root retains ownership of this already running full control.'},
 'hosted_snapshot':snapshot,
 'external_status_context':{'file':str(OUT/'github-status-context.json'),'sha256':digest(OUT/'github-status-context.json'),'interpretation':'Official Actions degraded_performance/PR-webhook incident is supporting context; exact queue cause not proved. It does not satisfy or waive any CI gate.'},
 'review_inventory':{'capture':str(OUT/'review-threads.json'),'submitted_reviews':[],'inline_threads':0,'limitations':'Empty inventory captured earlier in this delta session; must refresh before any later admission.'},
 'historical_evidence':{'previous_close':str(ROOT/'close-review-4b64b8ec.json'),'previous_close_sha256':digest(ROOT/'close-review-4b64b8ec.json'),'previous_head':'4b64b8ec3105670dee4fe39c920a5991b2f88b1d','previous_base':'48902389ec37019845fd67c8b8c53c5f499ffc85','previous_actual_jobs':'6 native success + valid shadow capture at prior head only','original_security':str(ROOT/'review-security.json'),'original_combined':str(ROOT/'review-ocr/review-correctness.json'),'previous_shadow_failure':'Historical SHADOW_NON_GATING receipt exit 1 and T082 failure remain retained in ci-current ZIP/investigation; no clean producer PASS inferred for old or current heads.'},
 'next_actions':['Collect final existing local full-suite outcome and preserve actual failures/log hashes/source state. Diagnose causes within E00 scope; do not call an active/failed control passing.','After hosted execution actually completes, run capture-integrated.py, inspect all six native job conclusions/step outcomes/log counts and current-head guards, then download-integrated-artifact.py to retain exact shadow artifact and its real inner verdict.','Review any changed/new failure rather than copying historical shadow classification mechanically. Refresh reviews/head/base/source cleanliness, then publish only a truthful updated close report.','Do not merge until all actual applicable gates are clear.'],
 'helper_scripts':{'capture':str(ROOT/'capture-integrated.py'),'artifact_download':str(ROOT/'download-integrated-artifact.py'),'final_report_template':str(ROOT/'write-integrated-review.py'),'template_limit':'Final report helper is guarded against incomplete/non-success native CI. Inspect current self artifact before applying its historical failure text and update any changed inner outcome.'},
 'lineage':{'reviewer':'Codex browser_close_review fresh-context reviewer continuing bounded integration delta','implementation_authorship':False,'model':'inherited session model','provider_independent':False,'d1_used_as_gate':False,'actions':'Read-only source/static/OCR/CI inventory and retained evidence review; wrote only external evidence. No local tests/install, source edits, reruns/cancel, approval, merge or GitHub writes.'},
 'evidence_hashes':{str(path.relative_to(OUT)):{'sha256':digest(path),'bytes':path.stat().st_size} for path in OUT.rglob('*') if path.is_file()},
}
for name in ['close-review-integrated.json','close-review.json']:
    temporary = ROOT/(name+'.tmp')
    temporary.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    temporary.replace(ROOT/name)
print(json.dumps({'report':str(ROOT/'close-review-integrated.json'),'current_alias':str(ROOT/'close-review.json'),'verdict':report['verdict'],'merge_eligible':False,'local_typecheck_build':len(local),'full_state':full['state'],'observed_failure_lines':failure_lines,'head':HEAD}))
