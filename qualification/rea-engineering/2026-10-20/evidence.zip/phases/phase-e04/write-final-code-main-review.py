import hashlib
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent/'main-control'
RUNS = ROOT.parent/'runs'
HEAD = '4688ecc5188cc5c4ccf811ce10be04b9156c5e8b'
BASELINE = 'ea93553a5423fd47f12a6bf282820dd199b994d4'
RESEARCH_MAIN = '576cfaa748d9f88ac752c20b385c69a2e7dd1f58'
FIXTURE = ROOT/'final-main-testerarmy'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*args):
    p = subprocess.run(['rtk','proxy','git',*args],cwd=REPO,capture_output=True)
    assert p.returncode == 0, (args,p.returncode,p.stderr)
    return p.stdout

assert git('rev-parse','HEAD').decode().strip() == HEAD
assert not git('status','--porcelain').strip()
controls = {}
for name in ['typecheck','build','full-suite','production-audit','full-audit','testerarmy-controls']:
    paths = list(RUNS.glob('final-main-'+name+'-*.json'))
    assert len(paths) == 1, paths
    path = paths[0]
    metadata = json.loads(path.read_text())
    assert metadata['state'] == 'EXECUTED' and metadata['source_unchanged']
    assert metadata['source_start'] == metadata['source_end']
    assert metadata['source_start']['head'] == HEAD and not metadata['source_start']['status']
    assert not metadata['individual_deadlines_changed']
    for stream in ['stdout','stderr']:
        assert sha(RUNS/metadata[stream]) == metadata[stream+'_sha256'], path
    controls[name] = {'metadata':str(path),'metadata_sha256':sha(path),'record':metadata,'stdout':str(RUNS/metadata['stdout']),'stderr':str(RUNS/metadata['stderr'])}
assert [controls[name]['record']['exit'] for name in ['typecheck','build','full-suite','production-audit','full-audit','testerarmy-controls']] == [0,0,1,0,1,0]
stdout = Path(controls['full-suite']['stdout']).read_text(encoding='utf-8')
stderr = Path(controls['full-suite']['stderr']).read_text(encoding='utf-8')
failures = re.findall(r' FAIL  ([^\r\n]+)\r?\nError: Test timed out in (\d+)ms\.',stderr)
assert len(failures) == 4 and sorted(int(budget) for test,budget in failures) == [5000,5000,5000,15000]
assert sum('tests/git-tree-digest.test.ts' in test for test,budget in failures) == 3
assert sum('tests/drift.contract.test.ts' in test for test,budget in failures) == 1
assert not any('T107' in test for test,budget in failures)
failure_observations = [line for line in stdout.splitlines() if line.startswith(' ×')]
assert len(failure_observations) == 4
feature_passes = [line for line in stdout.splitlines() if line.startswith(' ✓ tests/browser-text-assertion.')]
assert len(feature_passes) == 10
t107_passes = [line for line in stdout.splitlines() if line.startswith(' ✓ tests/t107-self-verification-harness.contract.test.ts')]
assert t107_passes and not any('tests/t107-self-verification-harness.contract.test.ts' in line for line in failure_observations)
summary = [line for line in stdout.splitlines() if any(term in line for term in ['Test Files  ','Tests  ','Duration  '])]
assert any('2 failed | 239 passed (241)' in line for line in summary)
assert any('4 failed | 2346 passed | 34 skipped (2384)' in line for line in summary)
assert 'EPERM' not in stderr and 'Worker exited unexpectedly' not in stderr
failure_blobs = {}
for path in ['tests/git-tree-digest.test.ts','tests/drift.contract.test.ts','tests/t107-self-verification-harness.contract.test.ts','src/git.ts','src/check.ts','src/receipt/build.ts','src/receipt/model.ts','benchmarks/self-verify.mjs','vitest.config.ts','package.json','package-lock.json']:
    states = {}
    for ref in [BASELINE,HEAD,RESEARCH_MAIN]:
        states[ref] = {'blob':git('rev-parse',ref+':'+path).decode().strip(),'sha256':hashlib.sha256(git('show',ref+':'+path)).hexdigest()}
    assert len({entry['blob'] for entry in states.values()}) == 1, path
    assert sha(REPO/path) == states[HEAD]['sha256'], path
    failure_blobs[path] = states
assert not (REPO/'src/drift.ts').exists()
research_delta = git('diff','--name-status',HEAD,RESEARCH_MAIN).decode().splitlines()
assert len(research_delta) == 25 and all(line.startswith('A\tresearch/') for line in research_delta)
production_roots = ['src','tests','schemas','benchmarks','python','.github','package.json','package-lock.json','tsconfig.json','vitest.config.ts']
assert not git('diff',HEAD,RESEARCH_MAIN,'--',*production_roots).strip()
subtrees = {path:{ref:git('rev-parse',ref+':'+path).decode().strip() for ref in [HEAD,RESEARCH_MAIN]} for path in production_roots}
assert all(len(set(refs.values())) == 1 for refs in subtrees.values())

fullaudit = json.loads(Path(controls['full-audit']['stdout']).read_text())
prodaudit = json.loads(Path(controls['production-audit']['stdout']).read_text())
assert prodaudit['metadata']['vulnerabilities']['total'] == 0 and not prodaudit['vulnerabilities']
assert fullaudit['metadata']['vulnerabilities'] == {'info':0,'low':0,'moderate':3,'high':2,'critical':0,'total':5}
assert set(fullaudit['vulnerabilities']) == {'@vitest/coverage-v8','@vitest/mocker','vitest','vite','source-map-js'}
advisories = {item['source']:item for entry in fullaudit['vulnerabilities'].values() for item in entry['via'] if isinstance(item,dict)}
assert len(advisories) == 8

tester = json.loads((FIXTURE/'testerarmy-summary.json').read_text())
assert tester['controls_match'] and tester['source_fixture_sha256'] == sha(REPO/'tests/browser-text-assertion.integration.test.ts')
assert tester['source_fixture_sha256'] == '38bb686b91a2fd40962f497632048b7b0c052e238d8451196c168a05f2f0548f'
assert tester['html_sha256'] == 'ac2984d00b64869afb3801bb6cfa10886d1e728f4a2fc19f27c79bbd3bfe8d24'
assert [run['exit'] for run in tester['runs']] == [0,1]
for run in tester['runs']:
    mode = run['mode']
    assert not run['timed_out'] and run['usage']['modelTokens'] == 0
    assert run['summary']['executed'] == 1 and run['summary']['selected'] == 1
    assert run['summary']['passed'] == int(mode == 'working') and run['summary']['failed'] == int(mode == 'broken')
    for path,digest in run['fixture_hashes'].items():
        assert sha(FIXTURE/'testerarmy'/mode/path) == digest
    raw = json.loads((FIXTURE/'testerarmy'/mode/'stdout.json').read_text())['run']
    assert raw['summary'] == run['summary'] and raw['usage'] == run['usage']
original = next((FIXTURE/'testerarmy/broken/runner-artifacts').rglob('001-failure.png'))
copy = ROOT/'testerarmy/final-main-001-failure.png'
assert sha(original) == sha(copy)
assert original.read_bytes().startswith(b'\x89PNG\r\n\x1a\n')

CI = ROOT/'postmerge-main-4688/20261024T024734Z'
ci = json.loads((CI/'postmerge-ci-review.json').read_text())
assert ci['head'] == HEAD and ci['actual_six_native_lanes_verified']
for path,entry in ci['files'].items():
    assert sha(CI/path) == entry['sha256']
feature = json.loads((ROOT/'final-close-review-743787b4-20261024.json').read_text())
for path,digest in feature['integration']['feature_hash_continuity'].items():
    assert sha(REPO/path) == digest, path

record = {
 'schema_version':1,'kind':'final_code_main_bound_results_and_qualification_limits','captured_utc':datetime.now(timezone.utc).isoformat(),
 'tested_code_main':HEAD,'tested_tree':controls['full-suite']['record']['source_start']['head_tree'],'repository':str(REPO),'tested_worktree_clean':True,
 'verdict':'E01_E04_CODE_MERGED_HOSTED_NATIVE_PASS_LOCAL_MAIN_FULL_FAIL_SPEC018_BLOCKED_E00_AND_DEVELOPMENT_ADVISORIES',
 'Spec018_complete':False,'release_or_project_readiness':False,'source_review_findings':{'must_fix':[],'worth_considering':[]},
 'controls':controls,
 'local_full_suite':{'result':'FAIL','native_exit':1,'state':'EXECUTED','source_start_equals_end':True,'source_unchanged':True,'wall_seconds':controls['full-suite']['record']['wall_seconds'],'summary':summary,'failures':[{'test':test,'deadline_ms':int(budget),'kind':'native test deadline failure'} for test,budget in failures],'observed_failure_lines':failure_observations,'E04_passes':feature_passes,'all_10_E04_cases_passed':True,'all_T107_cases_passed':True,'T107_pass_lines':t107_passes,'EPERM_or_worker_crash_in_stderr':False,'interpretation':'Complete native exit 1 remains FAIL. Three unchanged Git-tree cases and one T058 drift case exceeded unchanged deadlines. T107 passed in this run; do not carry its earlier failure into this run. No sole host-cause conclusion follows.'},
 'failure_source_continuity':{'files':failure_blobs,'all_eleven_files_equal_baseline_code_main_research_main':True,'drift_implementation_note':'No src/drift.ts exists. The drift test imports readTreeDigestV1 from src/git.ts and receipt build/model; their actual blobs are bound here.','meaning':'Definitions, underlying native Git/receipt/self-runtime code, test config and package/lock bytes are unchanged from original ea935 baseline. This establishes continuity and separate ownership, not a causal proof for timing failures.'},
 'postmerge_hosted_CI':{'review':str(CI/'postmerge-ci-review.json'),'review_sha256':sha(CI/'postmerge-ci-review.json'),'run':ci['run'],'exact_head':HEAD,'actual_native_lanes_passed':6,'meaning':'All six exact-head native job logs verify source guard, lockfile/Chromium, complete applicable suites, typecheck and build. Hosted success does not rewrite the local FAIL.'},
 'audit':{'production':{'native_exit':0,'metadata':prodaudit['metadata'],'package_entries':[],'meaning':'No production advisory entries returned by this exact npm audit --omit=dev observation; not a general safety or reachability certification.'},'full':{'native_exit':1,'metadata':fullaudit['metadata'],'package_entry_count':len(fullaudit['vulnerabilities']),'direct_advisory_object_count':len(advisories),'package_entries':fullaudit['vulnerabilities'],'unique_advisories':list(advisories.values()),'meaning':'Current live audit reports five affected package entries (three moderate, two high), with eight distinct advisory objects. This replaces no historical record and must not be reported using earlier count 20. Lockfile/source were not upgraded. Reachability/exploitability was not established by this audit alone.'},'status':'DEVELOPMENT_ADVISORIES_OPEN; E05 dependency work deferred and not implemented; no npm audit fix/install/upgrade performed by reviewer.'},
 'independent_TesterArmy_fixture_control':{'outer_native_exit':0,'summary':tester,'control_script':str(FIXTURE/'control.mjs'),'control_script_sha256':sha(FIXTURE/'control.mjs'),'summary_file':str(FIXTURE/'testerarmy-summary.json'),'summary_sha256':sha(FIXTURE/'testerarmy-summary.json'),'fixture_bytes_verified':True,'raw_report_summary_and_usage_verified':True,'meaning':'Independent fixture tool control only: working inner0/pass1, intentionally broken inner1/fail1, no model tokens. TesterArmy normalizes text/checks visibility; Ascout literal equality remains separately tested. No new Ascout visibility API or provider independence implied.'},
 'synthetic_screenshot':{'original':str(original),'published_copy':str(copy),'sha256':sha(copy),'bytes':copy.stat().st_size,'copy_byte_identity_verified':True,'visual_inspection':'Reviewer viewed published copy: only the owned synthetic Broken UI state, Ready controls, literal code-looking data and Expire target button. No customer/live-site image.','meaning':'Expected broken-fixture failure evidence; screenshot is not a passing Ascout assertion.'},
 'subsequent_research_main':{'head':RESEARCH_MAIN,'merge_proof':str(ROOT.parent/'merges/636.json'),'changes':research_delta,'all_25_paths_research_additions':True,'production_roots':subtrees,'production_paths_identical_to_tested_4688':True,'exact_head_limit':'Native local outcomes above belong to 4688. Research-only 576 has identical production/test/config/package roots but a different complete tree. Do not relabel 4688 runs as executions at 576 or a later qualification packet head; those exact-head CI/frontier gates remain root-owned.'},
 'remaining_blockers':['E00/local complete-suite timing debt remains BLOCKED: final code-main suite exited1. Preserve earlier candidate failures and interrupted execution separately.','Development dependency advisories remain open; E05 is deferred outside implemented scope. No release/readiness claim.','Final qualification-packet/main CI and publication/closure are still pending root verification.'],
 'lineage':'Fresh-context same-provider evidence reviewer; no provider independence or D1 approval claimed. Read-only metadata/source/log/audit/artifact review and external evidence write only. No tests, installs, source changes, Git/GitHub writes or network requests executed by this final reconciliation.',
 'minimum_next_action':'Root publishes these exact-bound results and blockers, retains E00 and development-dependency ownership, completes the final packet/main CI and registry close without claiming full local PASS or whole-Spec completion.'
}
OUT = ROOT/'final-code-main-review-4688.json'
OUT.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'review':str(OUT),'local_exit':1,'local_failures':len(failures),'T107_passed':True,'E04_passed':len(feature_passes),'hosted_lanes_passed':6,'production_advisories':0,'full_audit_package_entries':5,'full_audit_distinct_advisories':8,'screenshot_sha256':sha(copy),'research_only_additions':len(research_delta),'Spec018_complete':False}))
