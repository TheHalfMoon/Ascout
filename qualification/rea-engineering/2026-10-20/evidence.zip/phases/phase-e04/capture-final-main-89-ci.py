import hashlib
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent/'main-control'
HEAD = '89e5f01d7b77a92099961dff21e28052e5fa8dcc'
PARENTS = ['576cfaa748d9f88ac752c20b385c69a2e7dd1f58','4308e9ea89ad1b44081bac530e04bb9b8008c740']
CODE = '4688ecc5188cc5c4ccf811ce10be04b9156c5e8b'
RESEARCH = '34c81e184541165fa2170e0cd30a4c67f39caf9b'
RUN = 40057848215
OUT = ROOT/'postmerge-main-89e5f01'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
OUT.mkdir(parents=True)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def run(args,name):
    p = subprocess.run(['rtk','proxy',*args],cwd=REPO,capture_output=True)
    (OUT/name).write_bytes(p.stdout)
    (OUT/(name+'.stderr')).write_bytes(p.stderr)
    assert p.returncode == 0, (args,p.returncode,p.stderr)
    return p.stdout

def api(path,name):
    return json.loads(run(['gh','api','repos/TheHalfMoon/Ascout/'+path],name))

def git(*args,name):
    return run(['git',*args],name).decode().strip()

metadata = api('actions/runs/'+str(RUN),'run.json')
assert metadata['head_sha'] == HEAD
jobs = api('actions/runs/'+str(RUN)+'/jobs?per_page=100','jobs.json')['jobs']
assert len(jobs) == 6
api('commits/'+HEAD+'/check-runs?per_page=100','check-runs.json')
proof = json.loads((ROOT.parent/'merges/637.json').read_text())
assert proof['merge'] == HEAD and proof['tree_equal'] and proof['ordered_parents'] == PARENTS
assert proof['github_signature_verification']['verified']
assert git('show','-s','--format=%P',HEAD,name='parents.log').split() == PARENTS
tree = git('rev-parse',HEAD+'^{tree}',name='tree.log')
assert tree == proof['merge_tree'] == '6645f3f10a0cfab761ca232d9f97c1a684283f49'
assert git('rev-parse',PARENTS[1]+'^{tree}',name='reviewed-head-tree.log') == tree
delta = git('diff','--name-status',CODE,HEAD,name='code-main-to-final-main-paths.log').splitlines()
assert all(line.startswith('A\t') and (line[2:] in ['ROADMAP.md','STATE.md'] or line[2:].startswith(('qualification/','research/','specs/018-rea-engineering-qualification/','specs/019-source-map-js-repair/'))) for line in delta)
roots = ['src','tests','schemas','benchmarks','python','.github','package.json','package-lock.json','tsconfig.json','vitest.config.ts','SECURITY.md','CONTRIBUTING.md']
assert not git('diff',CODE,HEAD,'--',*roots,name='production-continuity.diff')
subtrees = {}
for path in roots:
    before = git('rev-parse',CODE+':'+path,name='code-tree-'+path.replace('/','_')+'.log')
    after = git('rev-parse',HEAD+':'+path,name='final-tree-'+path.replace('/','_')+'.log')
    assert before == after, path
    subtrees[path] = before
original_research = git('rev-parse',RESEARCH+':research',name='original-research-tree.log')
final_research = git('rev-parse',HEAD+':research',name='final-research-tree.log')
assert original_research == final_research
package = json.loads(git('show',HEAD+':package.json',name='package.json'))
lock = json.loads(git('show',HEAD+':package-lock.json',name='package-lock.json'))
assert package['dependencies']['playwright'] == '1.63.0'
assert lock['packages']['node_modules/playwright']['version'] == '1.63.0'
assert lock['packages']['node_modules/playwright-core']['version'] == '1.63.0'
lane_records = []
all_complete = all(job['status'] == 'completed' for job in jobs)
for job in jobs:
    record = {key:job[key] for key in ['id','name','status','conclusion']}
    steps = {step['name']:step['conclusion'] for step in job['steps']}
    record['steps'] = steps
    if all_complete:
        logname = str(job['id'])+'.log'
        log = run(['gh','api','repos/TheHalfMoon/Ascout/actions/jobs/'+str(job['id'])+'/logs'],logname).decode('utf-8')
        clean = re.sub(r'\x1b\[[0-9;]*m','',log)
        record['log'] = str(OUT/logname)
        record['log_sha256'] = sha(OUT/logname)
        record['log_bytes'] = (OUT/logname).stat().st_size
        record['summary'] = [line for line in clean.splitlines() if any(term in line for term in ['Test Files ', '      Tests ', 'Duration ', 'browser-text-assertion.', 'conservative-selection-data.', 'assurance-test-stryker-output.', 'git-tree-digest.test.ts','drift.contract.test.ts','t107-self-verification-harness.contract.test.ts','EXPECTED_SHA:'])]
        test = 'Test (Windows bounded workers)' if 'windows' in job['name'] else 'Test'
        required = ['Guard exact source','Install exact lockfile','Provision exact Chromium runtime','Typecheck',test,'Build']
        record['required_steps'] = {name:steps.get(name) for name in required}
        record['exact_source_guard'] = 'EXPECTED_SHA: '+HEAD in clean
        record['commands_verified'] = all(term in clean for term in ['> tsc -p tsconfig.json --noEmit','> tsc -p tsconfig.json'])
        files = ['tests/browser-text-assertion.contract.test.ts','tests/browser-text-assertion.integration.test.ts','tests/conservative-selection-data.contract.test.ts','tests/conservative-selection-data.native.test.ts','tests/assurance-test-stryker-output.test.ts','tests/git-tree-digest.test.ts','tests/drift.contract.test.ts','tests/t107-self-verification-harness.contract.test.ts']
        record['integrated_test_files_present'] = all(name in clean for name in files)
        record['complete_suite_summary_present'] = 'Test Files ' in clean and '      Tests ' in clean
        record['runtime_evidence_lines'] = [line for line in clean.splitlines() if any(term in line for term in ['1.63.0','1243','chromium','Chromium'])][:30]
        record['required_execution_verified'] = job['conclusion'] == 'success' and all(value == 'success' for value in record['required_steps'].values()) and all(record[key] for key in ['exact_source_guard','commands_verified','integrated_test_files_present','complete_suite_summary_present'])
    lane_records.append(record)
qualified = all_complete and metadata['status'] == 'completed' and metadata['conclusion'] == 'success' and all(job.get('required_execution_verified') for job in lane_records)
failure = any(job['status'] == 'completed' and job['conclusion'] not in ['success','skipped'] for job in jobs)
record = {
 'kind':'final_spec018_main_exact_head_native_CI_capture','captured_utc':datetime.now(timezone.utc).isoformat(),'head':HEAD,'tree':tree,'ordered_parents':PARENTS,'run':RUN,'attempt':metadata['run_attempt'],'workflow_status':metadata['status'],'workflow_conclusion':metadata['conclusion'],'actual_six_native_lanes_verified':qualified,'verdict':'PASS_ACTUAL_SIX_NATIVE_LANES' if qualified else ('ACTUAL_FAILURE' if failure else 'PENDING_ACTUAL_JOBS'),
 'merge_proof':str(ROOT.parent/'merges/637.json'),'merge_proof_sha256':sha(ROOT.parent/'merges/637.json'),'github_signature':'verified/valid per retained GitHub merge proof; not an independent cryptographic validation',
 'continuity':{'tested_code_main':CODE,'added_documentation_research_evidence_paths':delta,'production_test_config_package_tree_ids_unchanged':subtrees,'original_research_commit':RESEARCH,'research_tree':final_research,'research_tree_identical_to_original':True,'pin':'playwright and playwright-core exact1.63.0 in unchanged package/lock; passed integration test additionally asserts Chromium revision1243'},
 'jobs':lane_records,
 'prior_local_results':{'head':CODE,'review':str(ROOT/'final-code-main-review-4688.json'),'review_sha256':sha(ROOT/'final-code-main-review-4688.json'),'full_suite_native_exit':1,'summary':'239/241files passed;2346passed/4Git-drift native-deadline failures/34existing skips;wall755.8856s','typecheck_build_native_exit':0,'production_audit_native_exit':0,'full_audit_native_exit':1,'full_audit_package_entries':5,'full_audit_advisory_objects':8,'TesterArmy':'expected working0/pass1 and broken1/fail1, zero model tokens','binding_limit':'All local records remain bound to code-main4688, never relabeled as executions at final main89e5. Identical production/test/config/package blobs and separately executed final-head hosted suites establish continuity without erasing prior failures.'},
 'status_limits':'No release/readiness or local full PASS claim. E00 local timing debt and development advisories remain open; E05 deferred, no provider independence or D1 approval. No feature edit/install/test/rerun/GitHub write/merge performed by this read-only capture.',
 'files':{p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in OUT.iterdir() if p.is_file()}}
(OUT/'postmerge-ci-review.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'review':str(OUT/'postmerge-ci-review.json'),'qualified':qualified,'verdict':record['verdict'],'workflow':metadata['status'],'jobs':[(job['name'],job['status'],job['conclusion']) for job in lane_records],'documentation_research_evidence_additions':len(delta),'research_tree':final_research}))
