import hashlib
import json
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'browser'
HEAD = sys.argv[1]
PROJECT = int(sys.argv[2])
SELF = int(sys.argv[3])
OUT = ROOT / ('ci-final-' + HEAD[:8] + '-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
OUT.mkdir()

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def run(args, name):
    proc = subprocess.run(['rtk', 'proxy', *args], cwd=REPO, capture_output=True)
    (OUT / name).write_bytes(proc.stdout)
    (OUT / (name + '.stderr')).write_bytes(proc.stderr)
    if proc.returncode:
        raise RuntimeError(f'{args}: exit {proc.returncode}: {proc.stderr.decode(errors="replace")}')
    return proc.stdout.decode('utf-8')

def api(path, name):
    return json.loads(run(['gh', 'api', path], name))

prefix = 'repos/TheHalfMoon/Ascout/'
pr = api(prefix + 'pulls/641', 'pr.json')
checks = api(prefix + 'commits/' + HEAD + '/check-runs?per_page=100', 'check-runs.json')
api(prefix + 'pulls/641/reviews?per_page=100', 'reviews.json')
api(prefix + 'pulls/641/comments?per_page=100', 'inline-comments.json')
query = 'query { repository(owner:"TheHalfMoon",name:"Ascout") { pullRequest(number:641) { reviewThreads(first:100) { totalCount pageInfo { hasNextPage endCursor } nodes { isResolved isOutdated path line comments(first:100) { nodes { body url } } } } } } }'
run(['gh', 'api', 'graphql', '-f', 'query=' + query], 'review-threads.json')
records = []
for rid in [PROJECT, SELF]:
    metadata = api(prefix + 'actions/runs/' + str(rid), str(rid) + '-run.json')
    assert metadata['head_sha'] == HEAD
    jobs = api(prefix + 'actions/runs/' + str(rid) + '/jobs?per_page=100', str(rid) + '-jobs.json')
    lane_records = []
    for job in jobs['jobs']:
        record = {k:job[k] for k in ['id', 'name', 'status', 'conclusion']}
        record['steps'] = {step['name']:step['conclusion'] for step in job['steps']}
        if job['status'] == 'completed':
            name = str(job['id']) + '.log'
            content = run(['gh', 'api', prefix + 'actions/jobs/' + str(job['id']) + '/logs'], name)
            content = re.sub(r'\x1b\[[0-9;]*m', '', content)
            record['log'] = str(OUT / name)
            record['log_sha256'] = digest(OUT / name)
            record['summary'] = [line for line in content.splitlines() if any(term in line for term in ['Test Files ', '      Tests ', 'Duration ', 'browser-text-assertion.', 'EXPECTED_SHA:'])]
            if rid == PROJECT:
                test = 'Test (Windows bounded workers)' if 'windows' in job['name'] else 'Test'
                required = ['Guard exact source', 'Install exact lockfile', 'Provision exact Chromium runtime', 'Typecheck', test, 'Build']
                record['required_steps'] = {key:record['steps'].get(key) for key in required}
                record['exact_head_guard_present'] = 'EXPECTED_SHA: ' + HEAD in content
                record['typecheck_command_present'] = '> tsc -p tsconfig.json --noEmit' in content
                record['build_command_present'] = '> tsc -p tsconfig.json' in content
                record['feature_contract_test_present'] = 'tests/browser-text-assertion.contract.test.ts' in content
                record['feature_integration_test_present'] = 'tests/browser-text-assertion.integration.test.ts' in content
                record['required_execution_verified'] = all(record['required_steps'].values()) and all(value == 'success' for value in record['required_steps'].values()) and all(record[key] for key in ['exact_head_guard_present', 'typecheck_command_present', 'build_command_present', 'feature_contract_test_present', 'feature_integration_test_present'])
        lane_records.append(record)
    records.append({'id':rid, 'head':metadata['head_sha'], 'status':metadata['status'], 'conclusion':metadata['conclusion'], 'jobs':lane_records})
prior = json.loads((ROOT / 'close-review-integrated.json').read_text(encoding='utf-8'))
record = {'kind':'historical_exact_head_final_ci_capture', 'captured_utc':datetime.now(timezone.utc).isoformat(), 'head':HEAD, 'current_pr_head_at_capture':pr['head']['sha'], 'project':records[0], 'self_capture':records[1], 'native_six_lane_execution_verified':len(records[0]['jobs']) == 6 and all(job.get('required_execution_verified') and job['conclusion'] == 'success' for job in records[0]['jobs']), 'preserved_local_full_suite':prior['local_full_suite_snapshot'], 'preserved_self_inner_outcome':prior['current_self_verification'], 'gate_limit':'Hosted successes do not erase local full exit 1. Self workflow success certifies capture integrity only; preserved SHADOW_NON_GATING receipt exit 1 remains failed. Historical head evidence is not promoted to any future integration head.', 'source_edits_or_gate_execution':False}
record['files'] = {p.name:{'sha256':digest(p),'bytes':p.stat().st_size} for p in OUT.iterdir() if p.is_file()}
(OUT / 'final-ci-record.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'record':str(OUT / 'final-ci-record.json'), 'head':HEAD, 'native_verified':record['native_six_lane_execution_verified'], 'project':[(j['name'],j['conclusion']) for j in records[0]['jobs']], 'self_workflow':records[1]['conclusion'], 'local_exit_preserved':record['preserved_local_full_suite']['exit'], 'self_inner_exit_preserved':record['preserved_self_inner_outcome']['receipt_summary']['exit_code']}))
