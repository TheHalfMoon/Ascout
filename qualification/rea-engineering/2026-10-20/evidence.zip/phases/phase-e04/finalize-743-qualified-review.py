import hashlib
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent/'browser'
SOURCE = ROOT/'review-final-743787b4-20261022T014143Z'
CI = ROOT/'ci-final-743787b4-20261024T021811Z'
HEAD = '743787b40fc443d2cb442b5355aa24695a1afb9a'
BASE = '23fe4037a31f37d78d3add4b08f8393a4ac40671'
BASELINE = 'ea93553a5423fd47f12a6bf282820dd199b994d4'
RUNS = ROOT.parent/'runs'
LOCAL_PATH = RUNS/'e04-resumed-full-suite-aff592b7-376c-4f45-950a-7797cc2eab10.json'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*args):
    p = subprocess.run(['rtk','proxy','git',*args],cwd=REPO,capture_output=True)
    assert p.returncode == 0, (args,p.returncode,p.stderr)
    return p.stdout

prior = json.loads((ROOT/'qualification-pending-local-20261024T021935Z.json').read_text())
assert git('rev-parse','HEAD').decode().strip() == HEAD
assert git('merge-base',BASE,HEAD).decode().strip() == BASE
assert not git('status','--porcelain').strip()
assert git('diff',BASE,HEAD).rstrip() == (SOURCE/'feature.diff').read_bytes().rstrip()
for group in ['feature_hash_continuity','incoming_E02_bindings_match_final_review']:
    for path,digest in prior['integration'][group].items():
        assert sha(REPO/path) == digest, path
failure_blobs = {}
for path in ['tests/git-tree-digest.test.ts','tests/t107-self-verification-harness.contract.test.ts','src/git.ts','src/check.ts','benchmarks/self-verify.mjs','vitest.config.ts','package.json','package-lock.json']:
    states = {}
    for ref in [BASELINE,BASE,HEAD]:
        raw = git('show',ref+':'+path)
        states[ref] = {'blob':git('rev-parse',ref+':'+path).decode().strip(),'sha256':hashlib.sha256(raw).hexdigest()}
    assert len({entry['blob'] for entry in states.values()}) == 1, path
    assert sha(REPO/path) == states[HEAD]['sha256'], path
    failure_blobs[path] = states

local = json.loads(LOCAL_PATH.read_text())
assert local['state'] == 'EXECUTED' and local['exit'] == 1 and local['source_unchanged']
assert not local['individual_deadlines_changed']
assert local['source_start'] == local['source_end']
assert local['source_start']['head'] == HEAD and not local['source_start']['status']
for stream in ['stdout','stderr']:
    assert sha(RUNS/local[stream]) == local[stream+'_sha256']
stdout = (RUNS/local['stdout']).read_text(encoding='utf-8')
stderr = (RUNS/local['stderr']).read_text(encoding='utf-8')
assert 'EPERM' not in stderr and 'Worker exited unexpectedly' not in stderr
failures = re.findall(r' FAIL  ([^\r\n]+)\r?\nError: Test timed out in (\d+)ms\.',stderr)
assert len(failures) == 4
assert sum('tests/git-tree-digest.test.ts' in test for test,budget in failures) == 3
assert sum('tests/t107-self-verification-harness.contract.test.ts' in test for test,budget in failures) == 1
assert sorted(int(budget) for test,budget in failures) == [5000,5000,15000,15000]
failed_observations = [line for line in stdout.splitlines() if line.startswith(' ×')]
assert len(failed_observations) == 4
browser_pass = [line for line in stdout.splitlines() if line.startswith(' ✓ tests/browser-text-assertion.')]
assert len(browser_pass) == 10
summary = [line for line in stdout.splitlines() if any(term in line for term in ['Test Files  ','Tests  ','Duration  '])]
assert any('2 failed | 239 passed (241)' in line for line in summary)
assert any('4 failed | 2346 passed | 34 skipped (2384)' in line for line in summary)
ci = json.loads((CI/'current-ci-record.json').read_text())
assert ci['native_six_lane_execution_verified'] and ci['head'] == HEAD and ci['base'] == BASE
for path,entry in ci['files'].items():
    assert sha(CI/path) == entry['sha256'], path
native_failure_coverage = []
for job in ci['project']['jobs']:
    content = Path(job['log']).read_text(encoding='utf-8')
    lines = [line for line in content.splitlines() if any(path in line for path in ['tests/git-tree-digest.test.ts','tests/t107-self-verification-harness.contract.test.ts'])]
    assert all(any(path in line for line in lines) for path in ['tests/git-tree-digest.test.ts','tests/t107-self-verification-harness.contract.test.ts'])
    native_failure_coverage.append({'job':job['name'],'conclusion':job['conclusion'],'lines':lines})

current_local = {'metadata':str(LOCAL_PATH),'metadata_sha256':sha(LOCAL_PATH),'native_exit':1,'result':'FAIL','state':'EXECUTED','source_unchanged':True,'source_start':local['source_start'],'source_end':local['source_end'],'argv':local['argv'],'wall_seconds':local['wall_seconds'],'individual_deadlines_changed':False,'summary':summary,'failures':[{'test':test,'native_deadline_ms':int(budget),'observed_failure':'native test timeout'} for test,budget in failures],'failure_stdout':failed_observations,'browser_feature_passes':browser_pass,'all_10_E04_tests_passed':True,'stdout':str(RUNS/local['stdout']),'stdout_sha256':local['stdout_sha256'],'stderr':str(RUNS/local['stderr']),'stderr_sha256':local['stderr_sha256'],'EPERM_or_worker_crash_observed':False}
record = {
 'schema_version':1,
 'kind':'final_exact_head_integrated_E04_task_qualification_with_residual_E00_debt',
 'captured_utc':datetime.now(timezone.utc).isoformat(),
 'repository':str(REPO),'head':HEAD,'base':BASE,'tree':ci['tree'],
 'source_review_verdict':'CLEAR',
 'task_qualification_verdict':'E04_ELIGIBLE_WITH_EXPLICIT_RESIDUAL_E00_DEBT',
 'task_eligible_under_reviewed_criteria':True,
 'merge_approval':False,
 'overall_Spec018_complete':False,
 'overall_local_host_qualification':'BLOCKED_UNRESOLVED_EXISTING_TIMING_DEBT; LOCAL_FULL_REMAINS_FAIL',
 'findings':{'must_fix':[],'worth_considering':[],'skip_it':[]},
 'integration':prior['integration'],
 'bars':{
   **prior['bars'],
   'correctness':'CLEAR: complete source/delta review, unchanged feature bindings, all 10 E04 cases passed in the actual final local full run and all six native CI lanes. The incoming E02 five-file range matches its final review and does not alter browser runtime imports/state. Four local native deadlines remain explicit unrelated Git/T107 observations, not E04 PASS or proven host-only failures.',
   'product':'CLEAR: one minimal exact_text subset meets canonical Spec018 scope. Real exact/empty/literal/role, broken-state retention, expiry, mismatch/ambiguous/invalid/missing targets, shared resolver deadline, source/session rejection, unavailable free-text and disposal cases executed successfully on the final integrated source. No visibility, LLM, durable retry ledger or release claim added.'
 },
 'ocr':prior['ocr'],
 'current_hosted_ci':ci,
 'current_local_full_control':current_local,
 'current_local_typecheck_build':prior['local_typecheck_build'],
 'failure_source_continuity':{'refs':[BASELINE,BASE,HEAD],'all_eight_test_runtime_config_files_identical':True,'files':failure_blobs,'meaning':'Failing test definitions, underlying Git/check/self-runtime implementation, test config and exact package/lock bytes are unchanged from original control baseline through current main and candidate. This establishes ownership/scope continuity; it is not by itself causal proof for wall-clock overruns.'},
 'same_failed_test_files_in_hosted_full_controls':native_failure_coverage,
 'failure_reconciliation':{
   'local_outcome':'Completed native exit 1 remains FAIL: four native deadline failures, with no EPERM/worker crash in the final stderr.',
   'task_relation':'No failing test invokes the added E04 assertion path; candidate-only feature diff is six browser source/test/doc files. Failures lie in unchanged Git-tree and private-runtime fixtures and were observed in earlier baseline/local controls. No E04 or cross-feature regression was demonstrated.',
   'hosted_outcome':'Six actual exact-head full native suites passed with original platform conditions and timeout configuration. Both Windows lanes passed all 241 files, including the two locally failing test files. Linux/macOS all executed their applicable complete suites. These are genuine passing controls, not aggregate-only metadata.',
   'cause_limit':'Existing synchronous Git/native fixture cost and timing sensitivity are source-supported. Earlier explicit host OOM/pagefile errors are retained context, not proof that OOM caused these four timeouts. Residual local-host/environment/performance causes remain E00 diagnosis debt; no sole-cause conclusion or local green claimed.',
   'canonical_gate_interpretation':'Applicable complete native qualification is established by six real candidate controls. No mandatory passing-on-this-PC gate was found in user/governance/task text. The promised local full execution is now complete and retained as failure. Known unrelated debt remains separately tracked under CONTRIBUTING and Spec018; E00 and whole-Spec closure are not declared complete.',
   'unchanged_contracts':'No deadline, skip, suppression, platform conditional, package/lock/workflow, production Git path or admission rule was changed; no unlanded #589/#614 code imported. No green retry loop or cleanup-as-causal-fix claim.'
 },
 'gate_applicability_review':{'file':str(ROOT/'local-full-gate-applicability-review.json'),'sha256':sha(ROOT/'local-full-gate-applicability-review.json'),'key_clauses':['User directive section 7: canonical complete suite; retain every failure/limitation; verify CI; merge only after required gates.','CONTRIBUTING.md:58 explicitly separates product/task failures from unrelated known infrastructure/historical debt; :95 permits separately owned blocker/debt without weakening cases.','Spec018 plan.md:39 final integrated control plus independently tracked existing failures; :41 exact reviews, six-lane CI and material-finding reconciliation.','Spec018 plan.md:11 host limitation is E00 blocker; task table gives E04 no E00 dependency.','ps-close step 2 requires a post-forward-merge green full suite. Six real final-head complete native controls provide it; local red is separately reconciled, never rewritten.']},
 'self_verification':'Source/tree/base/receipt/upload digest-bound SHADOW_NON_GATING capture SUCCESS; inner receipt exit 1 T082/T087 remains FAIL. This fulfills only the canonical capture-integrity contract, not a clean receipt claim.',
 'preserved_history':{'old_4a_completed_local_FAIL':prior['historical_local_full_failure'],'interrupted_743_control':prior['interrupted_local_full_control'],'old_4a_CI':'phase-e04/ci-final-4a8ad4c6-20261022T013650Z/final-ci-record.json','earlier_pending_reviews':'Preserved without rewrite in prior timestamped captures.'},
 'review_inventory':prior['review_inventory'],
 'root_remaining_effects':['Publish final full-control logs, source/CI/review evidence and honest task/E00 status durably before merge.','Refresh exact live main/base/head, worktree purity, review inventory, effective authority and actual unchanged success conclusions immediately before any guarded merge.','After eligible merge, verify canonical main, ordered parents/tree/signature/PR state and applicable integrated post-merge tests.','Keep E00/local timing debt BLOCKED and whole Spec018 not COMPLETE until separately resolved under its own acceptance.'],
 'lineage':prior['lineage'],
 'panel_manifest':prior['panel_manifest'],
 'limits':'Review-qualified task eligibility is not a merge command or release approval. D1 did not approve this work. Same-model/provider lineage is disclosed; no provider independence claimed. Source and actual log/artifact hashes were verified, no check/build/install/source mutation/GitHub write/merge performed by this judge.'
}
OUT = ROOT/'final-close-review-743787b4-20261024.json'
OUT.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'review':str(OUT),'source':'CLEAR','task_qualification':record['task_qualification_verdict'],'local_exit':1,'local_failed_tests':len(failures),'feature_tests_passed':len(browser_pass),'native_CI_lanes_passed':6,'unchanged_failure_surface_files':len(failure_blobs),'Spec018_complete':False}))
