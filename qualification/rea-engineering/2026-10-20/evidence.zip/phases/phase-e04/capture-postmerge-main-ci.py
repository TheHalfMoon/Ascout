import hashlib
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent/'browser'
HEAD = '4688ecc5188cc5c4ccf811ce10be04b9156c5e8b'
RUN = 40055049859
OUT = ROOT/'postmerge-main-4688'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
OUT.mkdir(parents=True)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def run(args,name):
    p = subprocess.run(['rtk','proxy',*args],cwd=REPO,capture_output=True)
    (OUT/name).write_bytes(p.stdout)
    (OUT/(name+'.stderr')).write_bytes(p.stderr)
    assert p.returncode == 0, (args,p.returncode,p.stderr)
    return p.stdout

def api(path,name):
    return json.loads(run(['gh','api','repos/TheHalfMoon/Ascout/'+path],name))

metadata = api('actions/runs/'+str(RUN),'run.json')
assert metadata['head_sha'] == HEAD
jobs = api('actions/runs/'+str(RUN)+'/jobs?per_page=100','jobs.json')['jobs']
assert len(jobs) == 6
api('commits/'+HEAD+'/check-runs?per_page=100','check-runs.json')
proof = json.loads((ROOT.parent/'merges/641.json').read_text())
assert proof['merge'] == HEAD and proof['tree_equal']
assert proof['ordered_parents'] == ['23fe4037a31f37d78d3add4b08f8393a4ac40671','743787b40fc443d2cb442b5355aa24695a1afb9a']
assert proof['github_signature_verification']['verified']
lane_records = []
all_complete = all(job['status'] == 'completed' for job in jobs)
for job in jobs:
    record = {key:job[key] for key in ['id','name','status','conclusion']}
    steps = {step['name']:step['conclusion'] for step in job['steps']}
    record['steps'] = steps
    if all_complete:
        logname = str(job['id'])+'.log'
        log = run(['gh','api','repos/TheHalfMoon/Ascout/actions/jobs/'+str(job['id'])+'/logs'],logname).decode('utf-8')
        clean = re.sub(r'\x1b\[[0-9;]*m','',log)
        record['log'] = str(OUT/logname)
        record['log_sha256'] = sha(OUT/logname)
        record['log_bytes'] = (OUT/logname).stat().st_size
        record['summary'] = [line for line in clean.splitlines() if any(term in line for term in ['Test Files ', '      Tests ', 'Duration ', 'browser-text-assertion.', 'conservative-selection-data.', 'assurance-test-stryker-output.', 'git-tree-digest.test.ts','t107-self-verification-harness.contract.test.ts','EXPECTED_SHA:'])]
        test = 'Test (Windows bounded workers)' if 'windows' in job['name'] else 'Test'
        required = ['Guard exact source','Install exact lockfile','Provision exact Chromium runtime','Typecheck',test,'Build']
        record['required_steps'] = {name:steps.get(name) for name in required}
        record['exact_source_guard'] = 'EXPECTED_SHA: '+HEAD in clean
        record['commands_verified'] = all(term in clean for term in ['> tsc -p tsconfig.json --noEmit','> tsc -p tsconfig.json'])
        record['integrated_test_files_present'] = all(name in clean for name in ['tests/browser-text-assertion.contract.test.ts','tests/browser-text-assertion.integration.test.ts','tests/conservative-selection-data.contract.test.ts','tests/conservative-selection-data.native.test.ts','tests/assurance-test-stryker-output.test.ts','tests/git-tree-digest.test.ts','tests/t107-self-verification-harness.contract.test.ts'])
        record['complete_suite_summary_present'] = 'Test Files ' in clean and '      Tests ' in clean
        record['required_execution_verified'] = job['conclusion'] == 'success' and all(value == 'success' for value in record['required_steps'].values()) and all(record[key] for key in ['exact_source_guard','commands_verified','integrated_test_files_present','complete_suite_summary_present'])
    lane_records.append(record)
qualified = all_complete and metadata['status'] == 'completed' and metadata['conclusion'] == 'success' and all(job.get('required_execution_verified') for job in lane_records)
record = {'kind':'postmerge_main_exact_head_native_CI_capture','captured_utc':datetime.now(timezone.utc).isoformat(),'head':HEAD,'tree':proof['merge_tree'],'run':RUN,'attempt':metadata['run_attempt'],'workflow_status':metadata['status'],'workflow_conclusion':metadata['conclusion'],'actual_six_native_lanes_verified':qualified,'verdict':'PASS_ACTUAL_SIX_NATIVE_LANES' if qualified else 'PENDING_OR_FAIL_SEE_ACTUAL_JOBS','merge_proof':str(ROOT.parent/'merges/641.json'),'merge_proof_sha256':sha(ROOT.parent/'merges/641.json'),'jobs':lane_records,'local_full_control':'Independent root main-control run; no result inferred here. Prior candidate local exit 1/four deadline failures remain retained. E00 timing debt and whole-Spec completion are separate.','lineage':'Read-only native CI/merge-proof capture; no source edit, local check, install, Git mutation, provider independence, D1 gate, GitHub write or merge.','files':{p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in OUT.iterdir() if p.is_file()}}
(OUT/'postmerge-ci-review.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'review':str(OUT/'postmerge-ci-review.json'),'qualified':qualified,'workflow':metadata['status'],'jobs':[(job['name'],job['status'],job['conclusion']) for job in lane_records]}))
