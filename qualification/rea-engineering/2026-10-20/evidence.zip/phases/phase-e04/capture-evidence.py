import hashlib
import json
import pathlib
import subprocess
from datetime import datetime, timezone

root = pathlib.Path(__file__).resolve().parent.parent / "browser"
out = pathlib.Path(__file__).resolve().parent

def git(*args):
    return subprocess.run(["rtk", "proxy", "git", *args], cwd=root, check=True,
                          capture_output=True, text=True, encoding="utf-8").stdout.strip()

paths = [
    "src/browser/executor.ts", "src/browser/playwright-adapter.ts",
    "tests/browser-text-assertion.contract.test.ts",
    "tests/browser-text-assertion.integration.test.ts",
    "docs/browser-playwright-adapter.md", "docs/qualification/REA-E04.md",
]
integration = (root / paths[3]).read_bytes()
fixture_definition = b"\n".join(line for line in integration.splitlines()
    if line.startswith(b"const PAGE =") or line.startswith(b"  response.end("))
logs = ["npm-ci.log", "red.log", "typecheck-first.log", "green-first.log",
        "green-expanded.log", "build.log", "browser.log", "typecheck-exact.log",
        "build-exact.log", "browser-exact.log"]
manifest = {
    "captured_utc": datetime.now(timezone.utc).isoformat(),
    "base": "ea93553a5423fd47f12a6bf282820dd199b994d4",
    "source_head": git("rev-parse", "HEAD"),
    "source_tree": git("rev-parse", "HEAD^{tree}"),
    "branch": git("branch", "--show-current"),
    "worktree_status": git("status", "--short"),
    "source_sha256": {path: hashlib.sha256((root / path).read_bytes()).hexdigest() for path in paths},
    "fixture_definition_sha256": hashlib.sha256(fixture_definition).hexdigest(),
    "fixture_hash_scope": "UTF-8 bytes of PAGE constant and route response definition lines, joined by LF",
    "logs_sha256": {path: hashlib.sha256((out / path).read_bytes()).hexdigest() for path in logs},
    "commands": [
        "rtk proxy powershell -NoProfile -Command npm ci --ignore-scripts --no-audit --no-fund",
        "rtk proxy powershell -NoProfile -Command npx vitest run tests/browser-text-assertion.contract.test.ts tests/browser-text-assertion.integration.test.ts",
        "rtk proxy powershell -NoProfile -Command npm run typecheck",
        "rtk proxy powershell -NoProfile -Command npm run build",
        "rtk proxy powershell -NoProfile -Command npx vitest run browser --fileParallelism=false",
        "rtk git diff --check",
    ],
    "results": {
        "red": {"exit_code": 1, "test_files_failed": 2, "tests_failed": 6, "tests_passed": 2},
        "first_green": {"exit_code": 0, "test_files_passed": 2, "tests_passed": 8},
        "expanded_green": {"exit_code": 0, "test_files_passed": 2, "tests_passed": 10},
        "exact_typecheck": {"exit_code": 0},
        "exact_build": {"exit_code": 0},
        "exact_browser": {"exit_code": 0, "test_files_passed": 17, "tests_passed": 160},
    },
    "limits": ["Builder did not run complete native suite, publish, push, open PR, merge or review gates.",
               "Initial RED preserved; exact source evidence applies only to source_head.",
               "No donor research rerun or new dependencies; real installed pinned Playwright/Chromium loopback fixture."],
}
(out / "evidence-exact.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"source_head": manifest["source_head"], "worktree_status": manifest["worktree_status"],
                  "fixture_definition_sha256": manifest["fixture_definition_sha256"]}))
