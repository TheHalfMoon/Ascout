import hashlib
import io
import json
import re
import subprocess
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'ci-integrated'
REPO = ROOT.parent/'browser'
RUN = 39627705866
HEAD = '4a8ad4c6a49b4355e45b73abc32327c0f093c74a'

def gh(path):
    result = subprocess.run(['rtk','proxy','gh','api',path],cwd=REPO,capture_output=True)
    assert result.returncode == 0, result.stderr
    return result.stdout

listing = gh(f'repos/TheHalfMoon/Ascout/actions/runs/{RUN}/artifacts?per_page=100')
(OUT/'workflow-artifacts.json').write_bytes(listing)
artifacts = json.loads(listing)['artifacts']
selected = [a for a in artifacts if a['name'] == 'self-verification-'+HEAD]
assert len(selected) == 1
artifact = selected[0]
raw = gh(f"repos/TheHalfMoon/Ascout/actions/artifacts/{artifact['id']}/zip")
path = OUT/f"self-artifact-{artifact['id']}.zip"
path.write_bytes(raw)
digest = hashlib.sha256(raw).hexdigest()
job = json.loads((OUT/f'{RUN}-jobs.json').read_text())['jobs'][0]
log = (OUT/(str(job['id'])+'.log')).read_text(encoding='utf-8')
uploaded = re.search(r'SHA256 digest of uploaded artifact is ([a-f0-9]{64})',log)
assert uploaded and uploaded[1] == digest
destination = OUT/'self-artifact'
destination.mkdir(exist_ok=True)
members = []
with zipfile.ZipFile(io.BytesIO(raw)) as archive:
    for member in archive.infolist():
        assert member.filename in ['self-verification-receipt.json','self-verification-envelope.json','selector-shadow-observation.json']
        data = archive.read(member)
        target = destination/member.filename
        target.write_bytes(data)
        members.append({'name':member.filename,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
metadata = {'file':str(path),'artifact_id':artifact['id'],'bytes':len(raw),'sha256':digest,'github_uploaded_sha256':uploaded[1],'matches_github_uploaded_digest':True,'members':members}
(OUT/'artifact-download.json').write_text(json.dumps(metadata,indent=2)+'\n',encoding='utf-8')
envelope = json.loads((destination/'self-verification-envelope.json').read_text())
receipt = json.loads((destination/'self-verification-receipt.json').read_text())
print(json.dumps({'artifact':metadata,'classification':envelope['classification'],'receipt_exit':receipt['summary']['exit_code'],'findings':receipt['findings']}))
