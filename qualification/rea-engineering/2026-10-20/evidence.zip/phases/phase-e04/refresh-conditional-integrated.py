import hashlib
import json
import re
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'ci-integrated'
RUNS = ROOT.parent/'runs'
HEAD = '4a8ad4c6a49b4355e45b73abc32327c0f093c74a'
BASE = '36d1e504b300780d68b7bb692f90179e79b8c8bb'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

report = read(ROOT/'close-review-integrated.json')
assert report['head'] == HEAD and report['base'] == BASE
previous = ROOT/'close-review-integrated-queued.json'
if not previous.exists():
    previous.write_bytes((ROOT/'close-review-integrated.json').read_bytes())
project = read(OUT/'39627705872-run.json')
project_jobs = read(OUT/'39627705872-jobs.json')['jobs']
self_run = read(OUT/'39627705866-run.json')
self_jobs = read(OUT/'39627705866-jobs.json')['jobs']
assert project['head_sha'] == HEAD and self_run['head_sha'] == HEAD
assert len(project_jobs) == 6 and len(self_jobs) == 1
assert self_jobs[0]['conclusion'] == 'success'
completed = []
for job in project_jobs:
    item = {key:job[key] for key in ['id','name','status','conclusion']}
    item['steps'] = [{key:step[key] for key in ['name','status','conclusion']} for step in job['steps']]
    log = OUT/(str(job['id'])+'.log')
    if job['status'] == 'completed' and log.exists() and log.stat().st_size:
        text = re.sub(r'\x1b\[[0-9;]*m','',log.read_text(encoding='utf-8'))
        assert 'EXPECTED_SHA: '+HEAD in text
        item.update({'log':str(log),'log_sha256':digest(log),'log_bytes':log.stat().st_size,'exact_head_guard':HEAD,'summary':[line for line in text.splitlines() if any(k in line for k in ['Test Files','      Tests ','   Duration','browser-text-assertion'])]})
        steps = {step['name']:step['conclusion'] for step in job['steps']}
        test = 'Test (Windows bounded workers)' if 'windows' in job['name'] else 'Test'
        item['required_step_success'] = all(steps.get(name)=='success' for name in ['Guard exact source','Install exact lockfile','Provision exact Chromium runtime','Typecheck',test,'Build'])
    completed.append(item)
artifact = read(OUT/'artifact-download.json')
envelope_path = OUT/'self-artifact/self-verification-envelope.json'
receipt_path = OUT/'self-artifact/self-verification-receipt.json'
envelope = read(envelope_path)
receipt = read(receipt_path)
assert envelope['classification'] == 'SHADOW_NON_GATING'
assert envelope['verifier_head_sha'] == HEAD and envelope['subject_target_head_sha'] == HEAD
assert envelope['event_base_tip_sha'] == BASE and envelope['subject_merge_base_sha'] == BASE
assert envelope['subject_target_tree_sha'] == report['tree']
assert envelope['receipt_sha256'] == digest(receipt_path)
assert envelope['receipt_exit_code'] == receipt['summary']['exit_code']
assert artifact['matches_github_uploaded_digest']
full_path = RUNS/'e04-integrated-full-suite-49eb825f-ebe0-482e-b56c-a08ad537930e.json'
full = read(full_path)
assert full['source_start']['head'] == HEAD and full['source_end']['head'] == HEAD
assert full['source_unchanged'] and full['exit'] == 1
logs = {}
for stream in ['stdout','stderr']:
    log = RUNS/full[stream]
    assert digest(log) == full[stream+'_sha256']
    logs[stream] = {'file':str(log),'sha256':digest(log),'bytes':log.stat().st_size}
controls_path = ROOT/'integrated-local-controls.json'
controls = read(controls_path)
assert controls['head'] == HEAD and controls['result'] == 'FAIL'
full_summary = [item for item in controls['controls'] if item['task']=='full-suite'][0]
assert full_summary['record_sha256'] == digest(full_path)
report['captured_utc'] = datetime.now(timezone.utc).isoformat()
report['verdict'] = 'SOURCE_AND_OCR_CLEAR_LOCAL_FULL_FAIL_HOSTED_QUALIFICATION_PENDING_NOT_MERGE_ELIGIBLE'
report['merge_eligible'] = False
report['qualification'] = {'current_head_native_full_suite':'LOCAL_FAIL_PRESERVED; current hosted six-lane qualification incomplete','current_head_local_typecheck_build':'PASS_VERIFIED_SOURCE_AND_LOG_HASHES','current_head_hosted_project_ci':'PENDING: actual per-job records mixed completed/in_progress/queued; aggregate queued metadata lags actual execution','current_head_self_verification':'PASS_CAPTURE_INTEGRITY_ONLY; actual receipt exit '+str(receipt['summary']['exit_code'])+' retained without promotion','previous_head_native_full_ci':'HISTORICAL_PASS_ONLY_AT_4b64b8ec; not promoted to current head','all_required_gates_cleared':False}
report['local_full_suite_snapshot'] = {'metadata':str(full_path),'metadata_sha256':digest(full_path),'state':full['state'],'exit':full['exit'],'source_start':full['source_start'],'source_end':full['source_end'],'source_unchanged':full['source_unchanged'],'argv':full['argv'],'wall_seconds':full['wall_seconds'],'outer_capture_deadline_seconds':full['outer_capture_deadline_seconds'],'individual_deadlines_changed':full['individual_deadlines_changed'],'summary':full_summary['summary'],'failures':full_summary['failures'],'logs':logs,'controls_summary':str(controls_path),'controls_summary_sha256':digest(controls_path),'gate':'FAIL_PRESERVED; three unchanged existing deadline failures require E00 reconciliation; no source defect/host-cause conclusion inferred solely from this result. No global timeout/skip/suppression change; no EPERM in this run as reported by root factual summary.'}
report['hosted_snapshot'] = {'captured_utc':report['captured_utc'],'head':HEAD,'project_run':project['id'],'project_aggregate_status':project['status'],'project_aggregate_conclusion':project['conclusion'],'project_jobs':completed,'self_run':self_run['id'],'self_aggregate_status':self_run['status'],'self_aggregate_conclusion':self_run['conclusion'],'self_jobs':[{key:job[key] for key in ['id','name','status','conclusion']} for job in self_jobs],'aggregate_lag_observed':project['status']=='queued' and any(job['status']!='queued' for job in project_jobs),'interpretation':'Actual per-job metadata and retained completed-job logs show real execution despite lagging workflow aggregate. Incomplete lanes are not passed.'}
report['current_self_verification'] = {'run_id':self_run['id'],'job_id':self_jobs[0]['id'],'job_conclusion':'success','log':str(OUT/(str(self_jobs[0]['id'])+'.log')),'log_sha256':digest(OUT/(str(self_jobs[0]['id'])+'.log')),'envelope':envelope,'receipt_summary':receipt['summary'],'receipt_findings':receipt['findings'],'artifact':artifact,'source_and_receipt_digest_bound':True,'inner_clean_pass':receipt['summary']['exit_code']==0,'gate_contract':'Spec006 FR-006-010 explicitly permits source-bound 0/1/3/4 shadow captures. Successful job means capture integrity, not clean receipt verdict. Current T082 failure remains a failure; raw test exception is not included in the three-member uploaded artifact.'}
report['next_actions'] = ['Wait for current remaining actual Project CI jobs; retain full logs and inspect each source guard, test/typecheck/build result before claiming hosted qualification.','Reconcile the completed local exit-1 control within E00, preserving all three failed deadlines and prior controls. Hosted success cannot relabel this local failure.','Preserve current shadow inner failure and source-bound archive, refresh reviews/head/base/source cleanliness, and publish a truthful close update.','Do not merge until all actual applicable gates and failure reconciliation are clear.']
report['evidence_hashes'] = {str(path.relative_to(OUT)):{'sha256':digest(path),'bytes':path.stat().st_size} for path in OUT.rglob('*') if path.is_file()}
for name in ['close-review-integrated.json','close-review.json']:
    temporary = ROOT/(name+'.tmp')
    temporary.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    temporary.replace(ROOT/name)
print(json.dumps({'report':str(ROOT/'close-review-integrated.json'),'verdict':report['verdict'],'jobs':[{key:job[key] for key in ['id','name','status','conclusion']} for job in project_jobs],'local_full_exit':full['exit'],'self_inner_exit':receipt['summary']['exit_code'],'self_artifact_sha256':artifact['sha256']}))
