import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent/'browser'
SOURCE = ROOT/'review-final-743787b4-20261022T014143Z'
CI = ROOT/'ci-final-743787b4-20261024T021811Z'
HEAD = '743787b40fc443d2cb442b5355aa24695a1afb9a'
BASE = '23fe4037a31f37d78d3add4b08f8393a4ac40671'
OUT = ROOT/('qualification-pending-local-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'.json')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*args):
    p = subprocess.run(['rtk','proxy','git',*args],cwd=REPO,capture_output=True)
    assert p.returncode == 0, p.stderr
    return p.stdout

prior = json.loads((SOURCE/'source-review-pending.json').read_text())
assert git('rev-parse','HEAD').decode().strip() == HEAD
assert git('merge-base',BASE,HEAD).decode().strip() == BASE
assert not git('status','--porcelain').strip()
assert git('show','-s','--format=%P',HEAD).decode().split() == prior['integration']['parents']
assert git('diff',BASE,HEAD).rstrip() == (SOURCE/'feature.diff').read_bytes().rstrip()
assert git('diff',prior['integration']['parents'][0],HEAD).rstrip() == (SOURCE/'integration.diff').read_bytes().rstrip()
for group in ['feature_hash_continuity','incoming_E02_bindings_match_final_review']:
    for path,digest in prior['integration'][group].items():
        assert sha(REPO/path) == digest, path

ci = json.loads((CI/'current-ci-record.json').read_text())
assert ci['head'] == HEAD and ci['base'] == BASE
assert ci['pr_head'] == HEAD and ci['pr_base'] == BASE
assert ci['native_six_lane_execution_verified']
assert ci['self_artifact']['envelope']['receipt_exit_code'] == 1
for path,entry in ci['files'].items():
    assert sha(CI/path) == entry['sha256'], path
local = []
for name in ['e04-final-typecheck-cb1655cb-723b-4d11-81a7-3c05c25b63a3.json','e04-final-build-5edcbab4-7787-4985-9526-8c00ab33fb45.json']:
    path = ROOT.parent/'runs'/name
    metadata = json.loads(path.read_text())
    assert metadata['source_start']['head'] == HEAD and metadata['source_end']['head'] == HEAD
    assert metadata['exit'] == 0 and metadata['source_unchanged']
    for stream in ['stdout','stderr']:
        assert sha(path.parent/metadata[stream]) == metadata[stream+'_sha256']
    local.append({'metadata':str(path),'sha256':sha(path),'observed_outcome':'PASS','record':metadata})
lost_path = ROOT.parent/'runs/e04-final-full-suite-db98dd05-ed7b-4dda-af02-975223ca81f6.json'
lost = json.loads(lost_path.read_text())
stdout = lost_path.parent/lost['stdout']
stderr = lost_path.parent/lost['stderr']
text = stdout.read_text(encoding='utf-8',errors='replace')
lost_record = {'metadata':str(lost_path),'metadata_sha256':sha(lost_path),'raw_metadata_state':lost['state'],'native_exit':lost.get('exit'),'observed_outcome':'INTERRUPTED_CAPTURE_UNKNOWN_NATIVE_EXIT_WITH_FAILURE_OBSERVATIONS','record':lost,'observed_failures':[line for line in text.splitlines() if line.startswith(' ×') or 'git init -q failed' in line],'stderr':stderr.read_text(encoding='utf-8',errors='replace'),'stdout_sha256':sha(stdout),'stderr_sha256':sha(stderr),'summary_absent':not any(term in text for term in ['Test Files ','Tests  ']),'limits':'Metadata remains stale RUNNING. Root reports capture session gone; no final result or native exit is available. Observed failed test lines and worker exit are failures/incomplete execution, never PASS. No source-end capture, no completed suite qualification, and no root-cause proof follows from this record.'}
threads = json.loads((CI/'review-threads.json').read_text())['data']['repository']['pullRequest']['reviewThreads']
reviews = json.loads((CI/'reviews.json').read_text())
comments = json.loads((CI/'inline-comments.json').read_text())
record = {
 'kind':'refreshed_exact_head_integrated_review_hosted_clear_local_control_pending',
 'captured_utc':datetime.now(timezone.utc).isoformat(),'head':HEAD,'base':BASE,'tree':ci['tree'],
 'source_review':'CLEAR','hosted_native_qualification':'PASS_VERIFIED_SIX_ACTUAL_LANES','local_full_qualification':'PENDING_FRESH_COMPLETED_CONTROL_AND_FAILURE_RECONCILIATION','merge_eligible':False,
 'findings':{'must_fix':[],'worth_considering':[],'skip_it':[]},
 'prior_source_review':str(SOURCE/'source-review-pending.json'),'prior_source_review_sha256':sha(SOURCE/'source-review-pending.json'),
 'fresh_source_bindings':{'clean':True,'final_head_and_parents_verified':True,'base_is_ancestor':True,'feature_and_integration_diff_bytes_equal_prior_review':True,'six_E04_and_five_E02_file_hashes_reverified':True},
 'bars':prior['bars'],'ocr':prior['ocr'],'integration':prior['integration'],
 'current_hosted_ci':ci,
 'self_interpretation':'Verified current source/tree/base and receipt/upload hashes; successful Self workflow is the canonical Spec006 SHADOW_NON_GATING capture gate. Inner exit 1 and repeated T082/T087 package-content failure are preserved. Native Project CI success does not rewrite that receipt.',
 'local_typecheck_build':local,'interrupted_local_full_control':lost_record,
 'historical_local_full_failure':{'source':'phase-e04/close-review-integrated.json','head':'4a8ad4c6a49b4355e45b73abc32327c0f093c74a','exit':1,'failed_tests':3,'meaning':'Retained historical completed local failure; neither erased nor promoted to the final 743 head outcome.'},
 'review_inventory':{'submitted_reviews':len(reviews),'inline_comments':len(comments),'threads':threads['totalCount'],'has_next_page':threads['pageInfo']['hasNextPage']},
 'qualification_limits':['Fresh current-head local full control is still required by root; the lost capture cannot satisfy it.','Explicit host OOM evidence supports a host limitation hypothesis but does not prove every test failure has that cause.','No D1 approval, provider independence, release-readiness, merge approval or GitHub mutation is claimed.'],
 'lineage':prior['lineage'],'panel_manifest':prior['panel_manifest'],
 'next':'Root completes exact-head local full control with unchanged deadlines and reconciles all material observations. Then refresh final qualification with that actual result; do not infer local green from six hosted successes.'
}
OUT.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'review':str(OUT),'source':'CLEAR','hosted_native':'6 verified success','local_full':'pending fresh control; interrupted unknown exit retained','self_inner_exit':1,'reviews':len(reviews),'threads':threads['totalCount'],'native_summaries':[{ 'name':job['name'],'summary':[line for line in job['summary'] if 'Test Files ' in line or '      Tests ' in line]} for job in ci['project']['jobs']]}))
