import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'review-final-743787b4-20261022T014143Z'
REPO = ROOT.parent/'browser'
capture = json.loads((OUT/'capture.json').read_text())
e02 = json.loads((ROOT.parent/'phase-e02/final-close-review.json').read_text())
e02_bindings = {}
for path, prior in e02['source']['five_file_bindings'].items():
    actual = hashlib.sha256((REPO/path).read_bytes()).hexdigest()
    assert actual == prior['committed_sha256'], path
    e02_bindings[path] = actual
rules = (OUT/'ocr-rules.log').read_text()
assert 'src/browser/executor.ts' in rules and 'tests/browser-text-assertion.integration.test.ts' in rules
assert 'docs/qualification/REA-E04.md' in rules
record = {
 'kind':'fresh_final_integration_source_review_qualification_pending',
 'captured_utc':datetime.now(timezone.utc).isoformat(),
 'base':capture['base'],'head':capture['head'],
 'source_review_verdict':'CLEAR',
 'qualification_verdict':'PENDING_CURRENT_HEAD_LOCAL_AND_HOSTED_EXECUTION',
 'merge_eligible':False,
 'findings':{'must_fix':[],'worth_considering':[],'skip_it':[]},
 'integration':{
   'parents':['4a8ad4c6a49b4355e45b73abc32327c0f093c74a','23fe4037a31f37d78d3add4b08f8393a4ac40671'],
   'feature_hash_continuity':capture['feature_hashes'],
   'feature_files_unchanged':True,
   'incoming_E02_bindings_match_final_review':e02_bindings,
   'incoming_scope':'Exactly five E02 files: selection policy, three focused test files and qualification documentation. No incoming browser source changes. E01/E03 already present in old 4a head remain unchanged by this five-file delta.',
   'interaction':'E02 affects native changed-path test planning and remains separate from browser executor/runtime imports, session state, locator authority and text equality. Whole-suite execution is still required because both enter the same package and self-verification consumes native planning.',
   'purity':'Current-base feature range is exactly the six original E04 files. No workflow, package, lockfile, security policy, CLI or unrelated production file changes.'
 },
 'bars':{
   'correctness':'CLEAR_STATIC: primitive bounded request validation precedes resolver work; session/source admission exact; raw text equality only; remaining monotonic budget covers resolver/read/comparison; disposal and malformed/missing/ambiguous targets cannot pass. E02 import has no browser call-path or shared-state interaction. Current execution gates pending.',
   'parsimony':'CLEAR: one additive exact_text kind, existing response/text-read/resolver/disposal primitives reused. No dependency, speculative visibility/value type, ledger, new navigation authority or integration abstraction.',
   'product':'CLEAR: canonical Spec018 plan explicitly admits one minimal subset. Complete 36-line contract and 145-line real Chromium fixture review covers literal/empty/whitespace/code data, broken state retention, target expiry, mismatch/ambiguity/invalid selector/missing target, resolver overrun/shared deadline, malformed/foreign requests, unavailable free text and disposal. No model oracle/global PASS/release claim.',
   'security':'CONTINUITY_CLEAR: all six exact feature hashes match initial distinct fresh-context security review. New five-file E02 range matches separately reviewed final E02 bytes and adds no browser trust boundary. This combined integration judge is same-provider local review, not a new provider-independent security certification.'
 },
 'ocr':{
   'method':'Installed Alibaba CLI delegate preview for exact final base/head, followed by delegate rule over all six paths; actual emitted rules applied manually. No external OCR model review claimed.',
   'preview':str(OUT/'ocr-preview.log'),'rules':str(OUT/'ocr-rules.log'),
   'reviewable':2,'total':6,
   'coverage':[
      {'files':['src/browser/executor.ts','src/browser/playwright-adapter.ts'],'method':'Actual TypeScript rules applied to complete feature diff; no finding'},
      {'files':['tests/browser-text-assertion.contract.test.ts','tests/browser-text-assertion.integration.test.ts'],'preview_exclusion':'default_path','method':'Separate complete manual coverage with actual emitted TypeScript rules; assertions test intended behavior and negative controls, no finding'},
      {'files':['docs/browser-playwright-adapter.md','docs/qualification/REA-E04.md'],'preview_exclusion':'unsupported_ext','method':'Separate complete manual coverage with emitted default correctness/security/performance/maintainability/test-coverage rules; limitations/source/historical pending statements correctly scoped, no finding'}
    ]
 },
 'product_sources':{
   'canonical_packet':'Ascout/specs/018-rea-engineering-qualification/{spec.md,plan.md,tasks.md,IMPLEMENTATION_SCOPE.md}',
   'PRODUCT_and_CLAUDE':'Absent, as verified and confirmed by root; canonical Spec018 plus relevant Spec016 objective are the product bar.',
   'scope':'The later founder direction allows eligible autonomous maintenance merges, with actual gates retained and no separate mandatory provider-independence gate established.'
 },
 'initial_hosted_snapshot':[
    {key:run[key] for key in ['id','name','head_sha','status','conclusion']}
    for run in json.loads((OUT/'runs.json').read_text())['workflow_runs']
 ],
 'preserved_historical_evidence':{
   'old_4a_final_ci':'../ci-final-4a8ad4c6-20261022T013650Z/final-ci-record.json',
   'old_local_full':'Exit 1, three unchanged Git/T107 deadline cases remains a historical failure; not relabeled by hosted six-lane success.',
   'old_self_inner':'SHADOW_NON_GATING capture exit 1 T082 remains failed; green workflow was capture integrity only.',
   'no_promotion':'Neither historical native passes nor historical local failures determine the new-head outcome.'
 },
 'lineage':{'fresh_context':True,'implementation_author':False,'provider_independent':False,'d1_as_gate':False,'actions':'Source/OCR/CI reads only; external evidence writes; no local check execution, installation, source changes, Git mutation, GitHub write, approval or merge.'},
 'panel_manifest':'panel: integrated fresh-context local combined judge; separate prior security review bound by exact unchanged hashes; no provider independence claimed',
 'next':'Wait for root exact-head local full/typecheck/build and complete current Project CI six lanes plus source-bound Self artifact before final qualification review.'
}
record['evidence_hashes']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.iterdir() if p.is_file()}
(OUT/'source-review-pending.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(str(OUT/'source-review-pending.json'))
