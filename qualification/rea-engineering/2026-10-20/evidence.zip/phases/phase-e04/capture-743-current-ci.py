import hashlib
import io
import json
import re
import subprocess
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent/'browser'
HEAD = '743787b40fc443d2cb442b5355aa24695a1afb9a'
BASE = '23fe4037a31f37d78d3add4b08f8393a4ac40671'
PROJECT = 39707089974
SELF = 39707089999
OUT = ROOT/('ci-final-'+HEAD[:8]+'-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
OUT.mkdir()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def run(args,name):
    p = subprocess.run(['rtk','proxy',*args],cwd=REPO,capture_output=True)
    (OUT/name).write_bytes(p.stdout)
    (OUT/(name+'.stderr')).write_bytes(p.stderr)
    assert p.returncode == 0, (args,p.returncode,p.stderr)
    return p.stdout

def api(path,name):
    return json.loads(run(['gh','api','repos/TheHalfMoon/Ascout/'+path],name))

pr = api('pulls/641','pr.json')
api('pulls/641/reviews?per_page=100','reviews.json')
api('pulls/641/comments?per_page=100','inline-comments.json')
query = 'query { repository(owner:"TheHalfMoon",name:"Ascout") { pullRequest(number:641) { reviewThreads(first:100) { totalCount pageInfo { hasNextPage endCursor } nodes { isResolved isOutdated path line comments(first:100) { nodes { body url } } } } } } }'
run(['gh','api','graphql','-f','query='+query],'review-threads.json')
api('commits/'+HEAD+'/check-runs?per_page=100','check-runs.json')
records = []
for rid in [PROJECT,SELF]:
    metadata = api('actions/runs/'+str(rid),str(rid)+'-run.json')
    assert metadata['head_sha'] == HEAD
    jobs = api('actions/runs/'+str(rid)+'/jobs?per_page=100',str(rid)+'-jobs.json')
    lane_records = []
    for job in jobs['jobs']:
        record = {k:job[k] for k in ['id','name','status','conclusion']}
        steps = {step['name']:step['conclusion'] for step in job['steps']}
        record['steps'] = steps
        if job['status'] == 'completed':
            logname = str(job['id'])+'.log'
            log = run(['gh','api','repos/TheHalfMoon/Ascout/actions/jobs/'+str(job['id'])+'/logs'],logname).decode('utf-8')
            clean = re.sub(r'\x1b\[[0-9;]*m','',log)
            record['log'] = str(OUT/logname)
            record['log_sha256'] = sha(OUT/logname)
            record['summary'] = [line for line in clean.splitlines() if any(term in line for term in ['Test Files ', '      Tests ', 'Duration ', 'browser-text-assertion.', 'conservative-selection-data.', 'assurance-test-stryker-output.', 'EXPECTED_SHA:'])]
            if rid == PROJECT:
                test = 'Test (Windows bounded workers)' if 'windows' in job['name'] else 'Test'
                names = ['Guard exact source','Install exact lockfile','Provision exact Chromium runtime','Typecheck',test,'Build']
                record['required_steps'] = {name:steps.get(name) for name in names}
                record['exact_source_guard'] = 'EXPECTED_SHA: '+HEAD in clean
                record['commands_verified'] = all(term in clean for term in ['> tsc -p tsconfig.json --noEmit','> tsc -p tsconfig.json'])
                record['integrated_test_files_present'] = all(name in clean for name in ['tests/browser-text-assertion.contract.test.ts','tests/browser-text-assertion.integration.test.ts','tests/conservative-selection-data.contract.test.ts','tests/conservative-selection-data.native.test.ts','tests/assurance-test-stryker-output.test.ts'])
                record['required_execution_verified'] = all(value == 'success' for value in record['required_steps'].values()) and all(record[key] for key in ['exact_source_guard','commands_verified','integrated_test_files_present'])
        lane_records.append(record)
    records.append({'id':rid,'head':metadata['head_sha'],'status':metadata['status'],'conclusion':metadata['conclusion'],'attempt':metadata['run_attempt'],'jobs':lane_records})

artifacts = api('actions/runs/'+str(SELF)+'/artifacts?per_page=100','workflow-artifacts.json')['artifacts']
selected = [item for item in artifacts if item['name'] == 'self-verification-'+HEAD]
assert len(selected) == 1
artifact = selected[0]
zipname = 'self-artifact-'+str(artifact['id'])+'.zip'
raw = run(['gh','api','repos/TheHalfMoon/Ascout/actions/artifacts/'+str(artifact['id'])+'/zip'],zipname)
self_job = records[1]['jobs'][0]
log = Path(self_job['log']).read_text(encoding='utf-8')
uploaded = re.search(r'SHA256 digest of uploaded artifact is ([a-f0-9]{64})',log)
assert uploaded and uploaded[1] == sha(OUT/zipname)
DEST = OUT/'self-artifact'
DEST.mkdir()
members = []
with zipfile.ZipFile(io.BytesIO(raw)) as archive:
    for member in archive.infolist():
        assert member.filename in ['self-verification-receipt.json','self-verification-envelope.json','selector-shadow-observation.json']
        data = archive.read(member)
        (DEST/member.filename).write_bytes(data)
        members.append({'name':member.filename,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
envelope = json.loads((DEST/'self-verification-envelope.json').read_text())
receipt = json.loads((DEST/'self-verification-receipt.json').read_text())
tree = run(['git','rev-parse',HEAD+'^{tree}'],'tree.log').decode().strip()
assert envelope['classification'] == 'SHADOW_NON_GATING'
assert envelope['verifier_head_sha'] == HEAD and envelope['subject_target_head_sha'] == HEAD
assert envelope['subject_target_tree_sha'] == tree and envelope['verifier_head_tree_sha'] == tree
assert envelope['event_base_tip_sha'] == BASE and envelope['subject_merge_base_sha'] == BASE
assert envelope['receipt_exit_code'] == receipt['summary']['exit_code']
assert envelope['receipt_sha256'] == sha(DEST/'self-verification-receipt.json')
artifact_record = {'file':str(OUT/zipname),'artifact_id':artifact['id'],'bytes':len(raw),'sha256':sha(OUT/zipname),'github_uploaded_sha256':uploaded[1],'members':members,'envelope':envelope,'receipt_summary':receipt['summary'],'findings':receipt['findings'],'inner_clean_pass':receipt['summary']['exit_code'] == 0,'meaning':'Source-bound SHADOW_NON_GATING capture; workflow success means capture integrity. Inner receipt outcome remains as observed.'}
(OUT/'artifact-record.json').write_text(json.dumps(artifact_record,indent=2)+'\n',encoding='utf-8')
record = {'kind':'exact_current_head_ci_capture','captured_utc':datetime.now(timezone.utc).isoformat(),'base':BASE,'head':HEAD,'tree':tree,'pr_head':pr['head']['sha'],'pr_base':pr['base']['sha'],'project':records[0],'self':records[1],'native_six_lane_execution_verified':len(records[0]['jobs']) == 6 and all(job.get('required_execution_verified') and job['conclusion'] == 'success' for job in records[0]['jobs']),'self_artifact':artifact_record,'local_gates':'Pending independent root result, not inferred from hosted success.','files':{str(p.relative_to(OUT)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in OUT.rglob('*') if p.is_file()}}
(OUT/'current-ci-record.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'record':str(OUT/'current-ci-record.json'),'native_verified':record['native_six_lane_execution_verified'],'jobs':[(job['name'],job['conclusion']) for job in records[0]['jobs']],'self_inner_exit':receipt['summary']['exit_code'],'findings':[{'test':item.get('rule_or_test_id'),'path':item.get('path')} for item in receipt['findings']]}))
