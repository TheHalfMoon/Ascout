import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'browser'
BASE = '23fe4037a31f37d78d3add4b08f8393a4ac40671'
HEAD = '743787b40fc443d2cb442b5355aa24695a1afb9a'
OLD = '4a8ad4c6a49b4355e45b73abc32327c0f093c74a'
OUT = ROOT / ('review-final-' + HEAD[:8] + '-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
OUT.mkdir()
OCR = '<USERPROFILE>/AppData/Roaming/npm/node_modules/@alibaba-group/open-code-review/bin/ocr.js'

def run(args, name):
    p = subprocess.run(['rtk','proxy',*args], cwd=REPO, capture_output=True)
    (OUT/name).write_bytes(p.stdout)
    (OUT/(name+'.stderr')).write_bytes(p.stderr)
    assert p.returncode == 0, (args, p.returncode, p.stderr)
    return p.stdout.decode('utf-8').strip()

def git(*args, name):
    return run(['git',*args],name)

assert git('rev-parse','HEAD',name='head.log') == HEAD
assert not git('status','--porcelain',name='worktree.log')
assert git('merge-base',BASE,HEAD,name='merge-base.log') == BASE
git('show','-s','--format=%H%n%T%n%P%n%B',HEAD,name='merge-identity.log')
git('diff',BASE,HEAD,name='feature.diff')
git('diff',OLD,HEAD,name='integration.diff')
git('diff','--check',BASE,HEAD,name='diff-check.log')
git('diff','--name-status',BASE,HEAD,name='changed-paths.log')
git('diff','--name-status',OLD,HEAD,name='integration-paths.log')
manifest = json.loads((ROOT/'evidence-exact.json').read_text(encoding='utf-8'))
hashes = {}
for path, expected in manifest['source_sha256'].items():
    actual = hashlib.sha256((REPO/path).read_bytes()).hexdigest()
    assert expected == actual, path
    assert not git('diff',OLD,HEAD,'--',path,name='continuity-'+Path(path).name+'.log')
    hashes[path] = actual
assert set(git('diff','--name-only',BASE,HEAD,name='feature-paths.log').splitlines()) == set(hashes)
run(['node',OCR,'delegate','preview','--from',BASE,'--to',HEAD],'ocr-preview.log')
run(['node',OCR,'delegate','rule',*hashes],'ocr-rules.log')
api = 'repos/TheHalfMoon/Ascout/'
for path,name in [('pulls/641','pr.json'),('commits/'+HEAD+'/check-runs?per_page=100','check-runs.json'),('actions/runs?head_sha='+HEAD+'&per_page=30','runs.json')]:
    run(['gh','api',api+path],name)
record = {'kind':'exact_final_head_source_capture', 'captured_utc':datetime.now(timezone.utc).isoformat(),'base':BASE,'head':HEAD,'previous_head':OLD,'feature_hashes':hashes,'feature_continuity':True,'source_worktree_clean':True,'ci_status':'PENDING_INITIAL_SNAPSHOT_ONLY','local_qualification':'PENDING_ROOT_RUNS','files':{p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in OUT.iterdir() if p.is_file()}}
(OUT/'capture.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'capture':str(OUT/'capture.json'),'feature_files':len(hashes),'head':HEAD}))
