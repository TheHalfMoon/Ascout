const { spawnSync } = require('node:child_process');
const { createHash } = require('node:crypto');
const { readFileSync, realpathSync, writeFileSync } = require('node:fs');
const { join } = require('node:path');
const root = join(__dirname, '..', 'selection');
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const git = args => {
  const r = spawnSync('git', args, { cwd: root, encoding: 'utf8' });
  if (r.status !== 0) throw new Error(r.stderr);
  return r.stdout.trim();
};
const paths = ['src/selection.ts', 'tests/pre-run-widening.integration.test.ts', 'tests/conservative-selection-data.contract.test.ts', 'tests/conservative-selection-data.native.test.ts', 'docs/qualification/REA-E02.md'];
const base = 'ea93553a5423fd47f12a6bf282820dd199b994d4';
writeFileSync(join(__dirname, 'red.source.selection.ts'), git(['show', `${base}:src/selection.ts`]));
const lockHash = hash(readFileSync(join(root, 'package-lock.json')));
const installedSourceLockHash = hash(readFileSync(join(root, '..', 'Ascout', 'package-lock.json')));
const manifest = {
  observedAt: new Date().toISOString(), head: git(['rev-parse', 'HEAD']), base,
  status: git(['status', '--porcelain']), sourceFiles: Object.fromEntries(paths.map(path => [path, hash(readFileSync(join(root, path)))])),
  node: process.version, platform: process.platform, arch: process.arch,
  dependencies: { nodeModulesRealpath: realpathSync(join(root, 'node_modules')), lockHash, installedSourceLockHash, identicalLockReuse: lockHash === installedSourceLockHash, cleanMachine: false },
  concurrency: 'Bounded native fixture permitted by root while canonical-main serial full control remained active; no performance claim.',
  d1: { available: true, security_risk: 'low', advisoryOnly: true, independentGateSatisfied: false },
  pending: ['Full source-branch native control scheduled serially by root', 'Fresh-context local panels', 'Canonical admission', 'Hosted CI blocked by account billing/spending state', 'Historical independent-provider review gate'],
};
writeFileSync(join(__dirname, 'source-manifest.json'), JSON.stringify(manifest, null, 2));
process.stdout.write(JSON.stringify(manifest, null, 2));
