"""Read-only final hosted reconciliation; no source/test/install changes."""
from pathlib import Path
import datetime, hashlib, io, json, re, subprocess, zipfile

PHASE = Path(__file__).resolve().parent
ENG = PHASE.parent
SOURCE = ENG / 'selection'
HEAD = '589fef09358d84cf42edd99e639c59e5c249ca6d'
BASE = '36d1e504b300780d68b7bb692f90179e79b8c8bb'
RUN = 39628893299
CI = PHASE / 'ci-integrated' / '20261022T013337Z'
OUT = CI / 'final-reconciliation'
OUT.mkdir(exist_ok=False)
REPO = 'repos/TheHalfMoon/Ascout/'

def sha(data): return hashlib.sha256(data).hexdigest()
def save(name, value): (OUT / name).write_text(json.dumps(value, indent=2) + '\n')
def raw(name, args, cwd=None):
    command = ['rtk', 'proxy', *args]
    result = subprocess.run(command, cwd=cwd, capture_output=True, timeout=60)
    (OUT / name).write_bytes(result.stdout)
    (OUT / (name + '.stderr')).write_bytes(result.stderr)
    assert result.returncode == 0, (name, result.returncode)
    return result.stdout
def api(name, path): return json.loads(raw(name, ['gh', 'api', REPO + path]))
def git(name, *args): return raw(name, ['git', *args], SOURCE)
def relative(path): return path.relative_to(PHASE).as_posix()

prior = json.loads((PHASE / 'close-review.json').read_bytes())
static = json.loads((PHASE / 'ci-integrated' / 'static-capture.json').read_bytes())
manifest = json.loads((PHASE / 'p1-source-manifest.json').read_bytes())
bindings = {}
for file, old in static['source_bindings'].items():
    data = git(file.replace('/', '_') + '.head', 'show', HEAD + ':' + file)
    working = (SOURCE / file).read_bytes()
    bindings[file] = {'committed_sha256': sha(data), 'working_sha256': sha(working),
        'prior_review_sha256': old['committed_sha256'], 'prior_91_sha256': manifest['sourceFiles'][file],
        'identical_to_prior_review_and_91': sha(data) == sha(working) == old['committed_sha256'] == manifest['sourceFiles'][file]}
source_head = git('source-head.log', 'rev-parse', 'HEAD').decode().strip()
status = git('source-status.log', 'status', '--porcelain=v1').decode().strip()
diff = git('exact-range.diff', 'diff', '--no-ext-diff', BASE, HEAD)
diffcheck = git('diff-check.log', 'diff', '--check', BASE, HEAD)
pr = api('pr.json', 'pulls/639')

project = json.loads((CI / '39628893533-run.json').read_bytes())
jobs = json.loads((CI / '39628893533-jobs.json').read_bytes())['jobs']
assert project['head_sha'] == HEAD and project['status'] == 'completed' and project['conclusion'] == 'success'
assert len(jobs) == 6
log_checks = []
for job in jobs:
    assert job['head_sha'] == HEAD and job['status'] == 'completed' and job['conclusion'] == 'success'
    path = CI / (str(job['id']) + '.log')
    data = path.read_bytes()
    text = re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', data.decode('utf-8-sig'))
    required = ['Guard exact source', 'Typecheck', 'Build', 'Test (Windows bounded workers)' if 'windows' in job['name'] else 'Test']
    steps = {s['name']: s for s in job['steps']}
    checks = {'all_required_actual_steps_success': all(steps[s]['conclusion'] == 'success' for s in required),
        'head_present': HEAD in text, 'guard_present': 'EXPECTED_SHA: ' + HEAD in text,
        'typecheck_command': 'Run npm run typecheck' in text,
        'test_command': 'Run npm test' in text,
        'native_runner': '> vitest run' in text,
        'build_command': 'Run npm run build' in text,
        'test_summary_present': 'Test Files' in text and 'Tests' in text,
        'complete_job_log': 'Cleaning up orphan processes' in text}
    assert all(checks.values()), (job['id'], checks)
    log_checks.append({'job_id': job['id'], 'name': job['name'], 'head': job['head_sha'],
        'conclusion': job['conclusion'], 'log': relative(path), 'bytes': len(data), 'sha256': sha(data),
        'required_actual_steps': required, 'checks': checks,
        'summary_lines': [line for line in text.splitlines() if 'Test Files' in line or re.search(r'\bTests\s+\d', line)]})

selfrun = json.loads((CI / '39628893299-run.json').read_bytes())
selfjobs = json.loads((CI / '39628893299-jobs.json').read_bytes())['jobs']
assert selfrun['head_sha'] == HEAD and selfrun['status'] == 'completed' and selfrun['conclusion'] == 'success'
assert len(selfjobs) == 1 and selfjobs[0]['head_sha'] == HEAD and selfjobs[0]['conclusion'] == 'success'
listing = api('self-artifacts-listing.json', f'actions/runs/{RUN}/artifacts?per_page=100')
matches = [a for a in listing['artifacts'] if a['name'] == 'self-verification-' + HEAD and not a['expired']]
assert len(matches) == 1
artifact = matches[0]
archive = raw('self-artifact.zip', ['gh', 'api', REPO + 'actions/artifacts/' + str(artifact['id']) + '/zip'])
assert artifact['digest'] == 'sha256:' + sha(archive)
z = zipfile.ZipFile(io.BytesIO(archive))
assert z.testzip() is None
allowed = {'self-verification-envelope.json', 'self-verification-receipt.json', 'selector-shadow-observation.json'}
files = [i for i in z.infolist() if not i.is_dir()]
assert len(files) == 3 and {Path(i.filename).name for i in files} == allowed
assert sum(i.file_size for i in files) < 20 * 1024 * 1024
for item in files:
    value = z.read(item)
    json.loads(value)
    (OUT / Path(item.filename).name).write_bytes(value)
envelope = json.loads((OUT / 'self-verification-envelope.json').read_bytes())
receiptbytes = (OUT / 'self-verification-receipt.json').read_bytes()
receipt = json.loads(receiptbytes)
commit = api('head-commit.json', 'commits/' + HEAD)
assert envelope['receipt_sha256'] == sha(receiptbytes)
assert envelope['verifier_head_sha'] == envelope['subject_target_head_sha'] == HEAD
assert envelope['verifier_head_tree_sha'] == envelope['subject_target_tree_sha'] == commit['commit']['tree']['sha']
assert envelope['classification'] == 'SHADOW_NON_GATING'
assert envelope['receipt_exit_code'] == receipt['summary']['exit_code']
assert envelope['receipt_exit_code'] in [0, 1, 3, 4]
selfsummary = {'run_id': RUN, 'attempt': selfrun['run_attempt'], 'conclusion': selfrun['conclusion'],
    'artifact_id': artifact['id'], 'artifact_digest': artifact['digest'], 'archive_digest_matches_api': True,
    'receipt_digest_matches_envelope': True, 'head_and_tree_match_current_commit': True,
    'envelope': envelope, 'receipt_summary': receipt['summary'],
    'tasks': [{k: t.get(k) for k in ['task_id', 'status', 'exit_code', 'reason_code', 'observations']} for t in receipt['tasks']],
    'findings': receipt['findings'], 'file_hashes': {name: sha((OUT / name).read_bytes()) for name in allowed},
    'notice': 'Spec006 permits successful valid source-bound capture for exits0/1/3/4. Green capture is not a clean inner receipt or release approval.'}
save('self-capture-summary.json', selfsummary)
assert source_head == HEAD and status == ''
assert all(v['identical_to_prior_review_and_91'] for v in bindings.values())
assert sha(diff) == prior['review_scope']['exact_diff_sha256']
localpath = PHASE / 'integrated-local-controls.json'
local = json.loads(localpath.read_bytes())
assert local['head'] == HEAD and local['result'] == 'PASS'
assert all(t['native_exit'] == 0 and t['source_unchanged'] for t in local['controls'])
for control in local['controls']:
    candidates = list((ENG / 'runs').glob(control['execution_id'] + '.json'))
    assert len(candidates) == 1
    assert sha(candidates[0].read_bytes()) == control['record_sha256']

result = {'task': 'REA-E02 PR639 final exact-head hosted qualification reconciliation',
    'captured_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'head': HEAD, 'base': BASE, 'verdict': 'CLEAR',
    'meaning': 'Prior source/local review remains applicable unchanged; actual exact-head Project CI6/6 and valid Self Verification capture now complete. Root retains durable publication and immediate premerge authority checks.',
    'merge_approval': False, 'github_writes_or_merge': False, 'source_edits_or_local_controls': False,
    'lineage': 'Fresh context same session model/provider as prior local panel; no provider independence claimed.',
    'prior_review': 'close-review.json', 'prior_review_sha256': sha((PHASE / 'close-review.json').read_bytes()),
    'source': {'head': source_head, 'working_status': status, 'exact_diff_sha256': sha(diff),
        'same_diff_as_prior_review': True, 'five_file_bindings': bindings, 'all_five_unchanged': True},
    'live_pr': {'head': pr['head']['sha'], 'base': pr['base']['sha'], 'state': pr['state'],
        'merged': pr['merged'], 'mergeable': pr.get('mergeable'), 'mergeable_state': pr.get('mergeable_state'),
        'notice': 'Observed API state only; root must recheck immediately before any merge.'},
    'project_ci': {'run_id': project['id'], 'attempt': project['run_attempt'], 'head': HEAD,
        'status': project['status'], 'conclusion': project['conclusion'], 'six_actual_job_logs': log_checks,
        'capture': relative(CI / 'summary.json')},
    'self_verification': {'run_id': RUN, 'head': HEAD, 'status': selfrun['status'], 'conclusion': selfrun['conclusion'],
        'artifact': artifact['id'], 'inner_exit': envelope['receipt_exit_code'], 'classification': envelope['classification'],
        'summary': relative(OUT / 'self-capture-summary.json'), 'receipt_summary': receipt['summary'],
        'disposition': 'VALID_SHADOW_CAPTURE_WITH_INNER_RESULT_PRESERVED'},
    'local_proof': {'record': 'integrated-local-controls.json', 'sha256': sha(localpath.read_bytes()),
        'result': 'PASS', 'all_three_original_record_hashes_verified': True,
        'full_suite': '239 passed files;2340 passed tests;34 skipped;native exit0;EXECUTED_RECOVERED',
        'limits': prior['qualification']['integrated_local_full']['capture_limits']},
    'prior_failures_retained': {'review': 'close-review.json', 'local_91_full': 'FAIL16tests7files;not relabeled',
        'local_91_selected_recheck': 'FAIL2T107deadline cases plus secondaryEPERM;not relabeled',
        'interrupted_and_recovered': 'Original CAPTURE_PARENT_INTERRUPTED and EXECUTED_RECOVERED records retained',
        'old_self': 'Old91 green capture retained with innerexit1/packagingFAIL;does not qualify exact589',
        'e00': 'Older failure cause remains tracked separately;no clearance claim',
        'separate_e04': 'Separate E04 result not reclassified by E02 success'},
    'panel': prior['panel'], 'findings': [], 'worth_considering': [], 'skip_it': [],
    'pending_root_actions': ['Durable qualification publication', 'Immediate live main/head/check and policy verification before merge'],
    'manifest': 'panel:light combined prior fresh same-provider inline correctness/parsimony/product CLEAR,unchanged diff and five hashes reverified;security not triggered;actual hosted6/6 and exact Self capture verified;no independent-provider,release or merge approval claim'}
assert pr['head']['sha'] == HEAD and pr['base']['sha'] == BASE
result['panel']['product']['result'] = 'CLEAR'
save('source-and-log-checks.json', {'source_bindings': bindings, 'project_log_checks': log_checks})
final = PHASE / 'final-close-review.json'
assert not final.exists()
final.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'verdict': result['verdict'], 'final': str(final), 'project_jobs': len(log_checks),
    'self_artifact': artifact['id'], 'inner_exit': envelope['receipt_exit_code'], 'receipt_summary': receipt['summary']}))
