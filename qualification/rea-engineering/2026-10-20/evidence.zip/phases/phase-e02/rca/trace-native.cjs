const fs = require("node:fs");
const path = require("node:path");
const { spawn } = require("node:child_process");
const [traceDirectory, ...args] = process.argv.slice(2);
if (!traceDirectory || args.length === 0) throw new Error("trace directory and native argv required");
fs.mkdirSync(traceDirectory, { recursive: true });
const preload = path.join(__dirname, "safe-child-trace.cjs");
const child = spawn(process.execPath, args, {
  cwd: process.cwd(), windowsHide: true, shell: false, stdio: "inherit",
  env: { ...process.env, ASCOUT_RCA_TRACE_DIRECTORY: path.resolve(traceDirectory), NODE_OPTIONS: `--require=${preload}` },
});
child.once("error", () => { process.exitCode = 2; });
child.once("close", (status) => { process.exitCode = status ?? 2; });
