const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const root = __dirname;
const hash = (p) => crypto.createHash("sha256").update(fs.readFileSync(p)).digest("hex");
const captures = [
  ["trace-e02", "e02-t107-two-case-trace-cded98d1-f7d8-4792-ab98-4e054692b0d3"],
  ["trace-baseline", "baseline-t107-two-case-trace-af7b380c-7ba1-4d9a-a406-1c33a496d553"],
];
const summary = [];
for (const [directory, capture] of captures) {
  const record = JSON.parse(fs.readFileSync(path.join(root, "../../runs", capture + ".json"), "utf8"));
  const output = fs.readFileSync(path.join(root, "../../runs", record.stdout), "utf8").replace(/\u001b\[[0-9;]*m/gu, "");
  const tests = output.split(/\r?\n/u).map((line) => line.match(/[✓×] .* > T107 exact-tree self-verification harness > (.*) (\d+)ms$/u))
    .filter(Boolean).map((m) => ({ name: m[1], reported_duration_ms: Number(m[2]) }));
  const traceFiles = fs.readdirSync(path.join(root, directory)).map((name) => {
    const file = path.join(root, directory, name);
    return { name, sha256: hash(file), events: fs.readFileSync(file, "utf8").trim().split("\n").filter(Boolean).map(JSON.parse) };
  });
  const worker = traceFiles.find((file) => file.events.some((e) => e.event === "fixture-rm-start"));
  if (!worker) throw new Error("fixture worker trace absent");
  let pending = new Map();
  let operations = [];
  let cleanup = [];
  let testIndex = 0;
  const summarized = [];
  const flush = () => {
    if (operations.length === 0) return;
    const byOperation = {};
    for (const op of operations) {
      const item = byOperation[op.operation] ??= { count: 0, total_ms: 0, maximum_ms: 0 };
      item.count += 1; item.total_ms += op.duration_ms; item.maximum_ms = Math.max(item.maximum_ms, op.duration_ms);
    }
    const childTime = operations.reduce((sum, op) => sum + op.duration_ms, 0);
    summarized.push({ ...tests[testIndex++], by_operation: byOperation,
      total_measured_process_call_ms: childTime,
      longest_process_calls: [...operations].sort((a, b) => b.duration_ms - a.duration_ms).slice(0, 8),
      cleanup_events: cleanup,
    });
    operations = []; cleanup = [];
  };
  let cleaning = false;
  for (const e of worker.events) {
    if (e.event === "sync-start" || e.event === "spawn-start") {
      if (cleaning) { flush(); cleaning = false; }
      pending.set(e.id, e);
    } else if (["sync-end", "sync-error", "child-close", "child-error"].includes(e.event)) {
      const begin = pending.get(e.id);
      if (begin) {
        pending.delete(e.id);
        operations.push({ operation: begin.operation, mode: begin.event, start_ms: begin.offset_ms,
          duration_ms: e.offset_ms - begin.offset_ms, status: e.status ?? null,
          cwd_kind: begin.cwd_kind, cwd_alias: begin.cwd_alias });
      }
    } else if (e.event.startsWith("fixture-rm-")) {
      cleaning = true;
      cleanup.push(e);
    }
  }
  flush();
  summary.push({ capture_id: capture, source_start: record.source_start,
    source_end: record.source_end, source_unchanged: record.source_unchanged, exit: record.exit,
    wall_seconds: record.wall_seconds, selected_cases: 2, intentional_name_filter_exclusions: 32,
    test_summary: output.split(/\r?\n/u).filter((line) => /Test Files|Tests |Duration/u.test(line)),
    trace_worker_file: worker.name, tests: summarized,
    trace_manifest: traceFiles.map(({ name, sha256, events }) => ({ name, sha256, count: events.length })),
  });
}
const result = { method: "Monotonic child-process call/close timing and owned fixture-delete snapshots only; no live process scanning or resource sampling",
  limitations: ["Trace overhead is nonzero and not benchmark-qualified.", "Filesystem calls, synchronous fixture copying, event-loop lag and OS actors are not separately measured.", "No timeout or cleanup EPERM occurred in these replays; cancellation causality remains unproved.", "trace-e02 also preserves one preload-only process trace from the separately retained initial quoting-error launch; only the worker trace with fixture deletions is summarized.", "Per-operation sums measure wall time around process calls, not CPU time or process-launch-only cost."],
  preload_sha256: hash(path.join(root, "safe-child-trace.cjs")), wrapper_sha256: hash(path.join(root, "trace-native.cjs")),
  captures: summary,
};
fs.writeFileSync(path.join(root, "two-case-trace-comparison.json"), JSON.stringify(result, null, 2) + "\n");
console.log(JSON.stringify(summary.map((s) => ({ id: s.capture_id, exit: s.exit, tests: s.tests.map((t) => ({ name: t.name, duration_ms: t.reported_duration_ms,
  process_calls_ms: Math.round(t.total_measured_process_call_ms), cleanup_with_active_children: t.cleanup_events.filter((e) => e.active_children?.length > 0).length,
  longest: t.longest_process_calls.slice(0, 3) })) })), null, 2));
