// Diagnostic-only preload: safe labels/timings, never full argv, paths or env.
const fs = require("node:fs");
const path = require("node:path");
const cp = require("node:child_process");
const { syncBuiltinESMExports } = require("node:module");
const traceDir = process.env.ASCOUT_RCA_TRACE_DIRECTORY;
if (traceDir) {
  const append = fs.appendFileSync.bind(fs);
  const traceFile = path.join(traceDir, `${process.pid}.jsonl`);
  const started = process.hrtime.bigint();
  const active = new Map();
  const aliases = new Map();
  let next = 0;
  const emit = (data) => append(traceFile, JSON.stringify({
    pid: process.pid, offset_ms: Number(process.hrtime.bigint() - started) / 1e6,
    ...data,
  }) + "\n");
  const kind = (value) => {
    const text = typeof value === "string" ? value : "";
    if (/ascout-t107-output-/u.test(text)) return "t107-output-parent";
    if (/ascout-t107-production-missing-/u.test(text)) return "t107-production-output";
    if (/ascout-t107-(?:repo|template)-/u.test(text)) return "t107-repository";
    if (/ascout-self-verify-head-/u.test(text)) return "private-runtime";
    return "other";
  };
  const alias = (value) => {
    if (typeof value !== "string") return null;
    if (!aliases.has(value)) aliases.set(value, `path:${aliases.size + 1}`);
    return aliases.get(value);
  };
  const label = (file, args = []) => {
    const binary = typeof file === "string" ? path.basename(file).toLowerCase() : "other";
    if (binary === "git" || binary === "git.exe") {
      const verbs = new Set(["init", "config", "add", "commit", "rev-parse", "status", "cat-file", "write-tree", "diff", "merge-base", "reset", "clean", "worktree", "show", "ls-files", "hash-object", "for-each-ref", "check-attr", "check-ignore"]);
      return "git:" + (args.find((arg) => verbs.has(arg)) ?? "other");
    }
    if (binary === "node" || binary === "node.exe") {
      if (args.includes("--input-type=commonjs") && args.includes("-e")) return "node:bound-publisher";
      if (args.some((arg) => typeof arg === "string" && /npm-cli\.js$/u.test(arg))) return "node:npm";
      return "node:other";
    }
    return "other";
  };
  emit({ event: "preload-start" });
  for (const name of ["spawnSync", "execFileSync"]) {
    const original = cp[name];
    cp[name] = function(file, args, options) {
      const id = ++next;
      const operation = label(file, args);
      emit({ event: "sync-start", id, operation, cwd_kind: kind(options?.cwd), cwd_alias: alias(options?.cwd) });
      try {
        const result = original.apply(this, arguments);
        emit({ event: "sync-end", id, operation, status: typeof result?.status === "number" ? result.status : null });
        return result;
      } catch (error) {
        emit({ event: "sync-error", id, operation, error_code: typeof error?.code === "string" ? error.code : null });
        throw error;
      }
    };
  }
  const spawn = cp.spawn;
  cp.spawn = function(file, args, options) {
    const id = ++next;
    const operation = label(file, args);
    emit({ event: "spawn-start", id, operation, cwd_kind: kind(options?.cwd), cwd_alias: alias(options?.cwd) });
    const child = spawn.apply(this, arguments);
    active.set(id, { id, operation, cwd_alias: alias(options?.cwd), cwd_kind: kind(options?.cwd) });
    child.once("spawn", () => emit({ event: "spawned", id, operation }));
    child.once("error", (error) => emit({ event: "child-error", id, operation, error_code: typeof error?.code === "string" ? error.code : null }));
    child.once("close", (status, signal) => {
      active.delete(id);
      emit({ event: "child-close", id, operation, status, signal });
    });
    if (operation === "node:bound-publisher") {
      let pending = "";
      const allowed = new Set(["READY", "COMMIT_READY", "CONFIRM_READY", "RELEASE_READY", "FINALIZE_READY", "COMMITTED", "ROLLED_BACK"]);
      child.stdout?.on("data", (chunk) => {
        pending = (pending + String(chunk)).slice(-8192);
        const lines = pending.split(/\r?\n/u);
        pending = lines.pop() ?? "";
        for (const line of lines) if (allowed.has(line)) emit({ event: "publisher-marker", id, marker: line });
      });
    }
    return child;
  };
  const rmSync = fs.rmSync;
  fs.rmSync = function(target, options) {
    const targetKind = kind(target);
    if (targetKind === "other") return rmSync.apply(this, arguments);
    const id = ++next;
    emit({ event: "fixture-rm-start", id, target_kind: targetKind, target_alias: alias(target), active_children: [...active.values()] });
    try {
      const result = rmSync.apply(this, arguments);
      emit({ event: "fixture-rm-end", id });
      return result;
    } catch (error) {
      emit({ event: "fixture-rm-error", id, error_code: typeof error?.code === "string" ? error.code : null });
      throw error;
    }
  };
  syncBuiltinESMExports();
  process.once("exit", () => emit({ event: "process-exit", active_children: [...active.values()] }));
}
