"""Audit retained local captures; does not launch product commands."""
from pathlib import Path
import datetime
import hashlib
import json
import re

OUT = Path(__file__).resolve().parent
PHASE = OUT.parent
ENG = PHASE.parent
RUNS = ENG / 'runs'
HEAD = '589fef09358d84cf42edd99e639c59e5c249ca6d'
IDENTITY = 'e02-integrated-full-suite-ad3e0acb-1cbf-49d0-ba13-67ca4f464294'

def sha(data):
    return hashlib.sha256(data).hexdigest()

recovered_path = RUNS / (IDENTITY + '-recovered.json')
original_path = RUNS / (IDENTITY + '.json')
recovered = json.loads(recovered_path.read_bytes())
original = json.loads(original_path.read_bytes())
restored = dict(original)
for key in ['capture_parent_tool_exit', 'native_exit_at_interruption', 'recovery_record', 'interruption_notice']:
    restored.pop(key, None)
restored['state'] = 'RUNNING'
# qualify_native.py used Windows write_text; recovery read and hashed its CRLF bytes.
restored_bytes = (json.dumps(restored, indent=2) + '\n').replace('\n', '\r\n').encode()
stdout = (RUNS / recovered['stdout']).read_bytes()
stderr = (RUNS / recovered['stderr']).read_bytes()
text = stdout.decode('utf-8', errors='replace')
summary_lines = [line.strip() for line in text.splitlines() if re.match(r'^\s*(Test Files|Tests |Duration )', line)]
failure_markers = [line for line in text.splitlines() if re.match(r'^\s*(FAIL\s|Failed Tests|\u00d7\s|\u276f\s)', line)]
checks = {
    'recovered_state_executed': recovered['state'] == 'EXECUTED_RECOVERED',
    'actual_windows_wait_exit_zero': recovered['exit'] == 0,
    'source_unchanged_exact_head': recovered['source_start'] == recovered['source_end'] and recovered['source_unchanged'] and recovered['source_start']['head'] == HEAD,
    'stdout_sha256_matches': sha(stdout) == recovered['stdout_sha256'],
    'stderr_sha256_matches': sha(stderr) == recovered['stderr_sha256'],
    'stderr_empty': len(stderr) == 0,
    'original_record_hash_matches_pretransition_bytes': sha(restored_bytes) == recovered['original_capture_record_sha256'],
    'original_wrapper_interruption_preserved': original['state'] == 'CAPTURE_PARENT_INTERRUPTED' and original['capture_parent_tool_exit'] == 1 and original['native_exit_at_interruption'] is None,
    'complete_native_summary_present': 'Test Files  239 passed (239)' in summary_lines and 'Tests  2340 passed | 34 skipped (2374)' in summary_lines,
    'no_actual_failure_markers': not failure_markers,
}
assert all(checks.values()), checks
controls = json.loads((PHASE / 'integrated-local-controls.json').read_bytes())
control_audit = []
for control in controls['controls']:
    record = RUNS / (control['execution_id'] + '.json')
    data = json.loads(record.read_bytes())
    entry = {'task': control['task'], 'record': str(record.relative_to(ENG)),
             'record_sha256_matches_summary': sha(record.read_bytes()) == control['record_sha256'],
             'native_exit': data['exit'], 'state': data['state'],
             'exact_source_unchanged': data['source_start'] == data['source_end'] and data['source_unchanged'] and data['source_start']['head'] == HEAD}
    for stream in ['stdout', 'stderr']:
        raw = (RUNS / data[stream]).read_bytes()
        entry[stream + '_hash_matches'] = sha(raw) == data[stream + '_sha256'] == control[stream + '_sha256']
    assert entry['record_sha256_matches_summary'] and entry['native_exit'] == 0 and entry['exact_source_unchanged'] and entry['stdout_hash_matches'] and entry['stderr_hash_matches']
    control_audit.append(entry)

evidence_paths = [recovered_path, original_path, RUNS / recovered['stdout'], RUNS / recovered['stderr'], ENG / 'recover_native_capture.py', ENG / 'qualify_native.py', PHASE / 'integrated-local-controls.json']
audit = {
    'reviewed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'head': HEAD, 'result': 'LOCAL_NATIVE_PASS_FACTUALLY_SUPPORTED_HOSTED_GATES_PENDING',
    'checks': checks, 'controls': control_audit, 'full_native_summary': summary_lines,
    'full_native_exit': 0, 'wall_seconds_from_original_start': recovered['wall_seconds_from_original_start'],
    'capture_method_review': {
        'reviewed_files': ['recover_native_capture.py', 'qualify_native.py', '../venv/Lib/site-packages/psutil/_pswindows.py:860', '../venv/Lib/site-packages/psutil/__init__.py:1342'],
        'actual_method': 'Recovery attaches psutil.Process to the recorded PID, checks Node executable name, creation time within 15 seconds of recorded start, npm-cli.js/test command markers, absent parent and unchanged source, then blocks on Windows Process.wait. Installed psutil Windows implementation obtains an exit code through native proc_wait/GetExitCodeProcess; exit0 is recorded rather than inferred from terminal text.',
        'bounded_identity_limits': 'The recovery script does not compare complete argv/cwd or a create-time value previously recorded at initial launch; it checks timestamp proximity and command markers. This is a local factual capture with disclosed guard limits, not an independently authenticated execution receipt.',
        'no_new_execution': 'Recovery script contains no Popen or test rerun, no source mutation or process termination. Its Git reads bind source at attachment/end. Original stdout/stderr file handles continue to belong to the surviving native command.',
        'original_wrapper': 'CAPTURE_PARENT_INTERRUPTED/tool exit1 remains separate. Original wrapper success is not claimed. Original pretransition bytes reconstructed with Windows CRLF match the hash bound by recovery.',
        'duration_limit': '726.213 seconds is wall time from the recorded second-resolution original start through capture completion; native Vitest reports720.19 seconds. No performance or sampling claim.',
    },
    'prior_failures_preserved': ['Original91 full16failure control remains FAIL', 'Original91 selected seven-file recheck with2deadline failures/EPERM remains FAIL', 'Separate E04 current full3deadline failures remain separate evidence'],
    'interpretation': 'Current integrated589 local typecheck/build/full all pass. This later result neither explains the older deadlines nor relabels them. Hosted six-lane qualification and current self-capture remain pending; no approval, merge or release claim.',
    'lineage': 'Fresh inherited session model; same provider lineage; read-only evidence audit.',
    'evidence_hashes': {str(path.relative_to(ENG)): {'sha256': sha(path.read_bytes()), 'bytes': path.stat().st_size} for path in evidence_paths},
}
(PHASE / 'local-reconciliation.json').write_text(json.dumps(audit, indent=2) + '\n')
report_path = PHASE / 'close-review.json'
report = json.loads(report_path.read_text())
report['updated_utc'] = audit['reviewed_utc']
report['verdict'] = 'SOURCE_AND_LOCAL_QUALIFICATION_CLEAR_HOSTED_GATES_CONDITIONAL'
report['merge_ready'] = False
report['qualification']['integrated_local_full'] = {'record': str(recovered_path.relative_to(ENG)), 'state': recovered['state'], 'native_exit': 0, 'source_unchanged': True, 'passed_files': 239, 'passed_tests': 2340, 'skipped_tests': 34, 'stderr_bytes': 0, 'reconciliation': 'local-reconciliation.json', 'original_wrapper_state': 'CAPTURE_PARENT_INTERRUPTED', 'capture_limits': audit['capture_method_review']['bounded_identity_limits']}
report['qualification']['latest_exact_head_capture'] = 'ci-integrated/20261021T161724Z/summary.json'
report['qualification']['latest_exact_head_observed_utc'] = '2026-10-21T16:17:24Z'
report['qualification']['latest_exact_head_state'] = 'Actual job119321383145 Ubuntu24/node24 SUCCESS with exact589 guard/typecheck/native test/build and retained log; Ubuntu22 and both Windows jobs running, both Mac jobs queued. Self job119321381708 capture running after guard/build success. Project aggregate still queued; actual jobs establish progress, not overall completion.'
report['qualification']['latest_self_artifact_state'] = 'Current39628893299 artifacts total_count0 at capture; no inner receipt result yet.'
report['qualification']['pending'] = ['Remaining exact589 six-lane native/typecheck/build job conclusions and actual logs', 'Current self-verification valid capture/artifact and truthful inner-result accounting', 'Root final live-main/head/gate verification before any merge', 'E00 older failure cause remains independently tracked']
report_path.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'result': audit['result'], 'checks': checks, 'controls': control_audit, 'close_verdict': report['verdict']}))
