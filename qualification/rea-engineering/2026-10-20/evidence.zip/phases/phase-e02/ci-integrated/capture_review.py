"""Read-only source and hosted evidence capture; no local test execution."""
from pathlib import Path
import concurrent.futures
import datetime
import hashlib
import json
import subprocess
import sys

OUT = Path(__file__).resolve().parent
ENG = OUT.parent.parent
SOURCE = ENG / 'selection'
BASE = '36d1e504b300780d68b7bb692f90179e79b8c8bb'
HEAD = '589fef09358d84cf42edd99e639c59e5c249ca6d'
OLD = '91ef95ddcf6127ef139557081950c112a15c54ac'
REPO = 'repos/TheHalfMoon/Ascout'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def capture(name, args, cwd=None):
    command = ['rtk', 'proxy', *args]
    result = subprocess.run(command, cwd=cwd, capture_output=True, timeout=60)
    (OUT / name).write_bytes(result.stdout)
    (OUT / (name + '.stderr')).write_bytes(result.stderr)
    return {'command': command, 'exit': result.returncode,
            'sha256': sha(result.stdout), 'bytes': len(result.stdout)}

def static():
    requests = {
        'exact-range.diff': (['git', 'diff', '--no-ext-diff', BASE, HEAD], SOURCE),
        'diff-check.log': (['git', 'diff', '--check', BASE, HEAD], SOURCE),
        'merge-commit.log': (['git', 'show', '--no-patch', '--format=raw', HEAD], SOURCE),
        'working-status.log': (['git', 'status', '--porcelain=v1'], SOURCE),
        'pr.json': (['gh', 'api', REPO + '/pulls/639'], None),
        'reviews.json': (['gh', 'api', REPO + '/pulls/639/reviews'], None),
        'inline-comments.json': (['gh', 'api', REPO + '/pulls/639/comments'], None),
        'old91-self-jobs.json': (['gh', 'api', REPO + '/actions/runs/39484966569/attempts/2/jobs'], None),
        'old91-self-artifacts.json': (['gh', 'api', REPO + '/actions/runs/39484966569/artifacts'], None),
        'old91-self-job.log': (['gh', 'api', REPO + '/actions/jobs/118960182192/logs'], None),
        'old91-self.zip': (['gh', 'api', REPO + '/actions/artifacts/12310168400/zip'], None),
        'ocr-preview.log': (['node', '<USERPROFILE>/AppData/Roaming/npm/node_modules/@alibaba-group/open-code-review/bin/ocr.js', 'delegate', 'preview', '--from', BASE, '--to', HEAD], SOURCE),
        'ocr-rules.log': (['node', '<USERPROFILE>/AppData/Roaming/npm/node_modules/@alibaba-group/open-code-review/bin/ocr.js', 'delegate', 'rule', 'src/selection.ts', 'tests/conservative-selection-data.contract.test.ts', 'tests/conservative-selection-data.native.test.ts', 'tests/pre-run-widening.integration.test.ts', 'docs/qualification/REA-E02.md'], SOURCE),
    }
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        records = dict(pool.map(lambda item: (item[0], capture(item[0], *item[1])), requests.items()))
    files = json.loads((OUT.parent / 'p1-source-manifest.json').read_text())['sourceFiles']
    bindings = {}
    for file, old_hash in files.items():
        at_head = subprocess.run(['rtk', 'proxy', 'git', 'show', HEAD + ':' + file], cwd=SOURCE, capture_output=True, check=True).stdout
        at_old = subprocess.run(['rtk', 'proxy', 'git', 'show', OLD + ':' + file], cwd=SOURCE, capture_output=True, check=True).stdout
        bindings[file] = {'committed_sha256': sha(at_head), 'working_sha256': sha((SOURCE / file).read_bytes()),
                          'unchanged_since_91': at_head == at_old, 'prior_manifest_sha256': old_hash}
    self_dir = OUT / 'old91-self' / ('self-verification-' + OLD)
    envelope = json.loads((self_dir / 'self-verification-envelope.json').read_bytes())
    receipt_bytes = (self_dir / 'self-verification-receipt.json').read_bytes()
    receipt = json.loads(receipt_bytes)
    artifact = json.loads((OUT / 'old91-self-artifacts.json').read_bytes())['artifacts'][0]
    old_summary = {
        'run_id': 39484966569, 'attempt': 2, 'job_id': 118960182192,
        'capture_job_conclusion': 'success', 'artifact_id': artifact['id'],
        'zip_sha256': sha((OUT / 'old91-self.zip').read_bytes()),
        'zip_digest_matches_api': 'sha256:' + sha((OUT / 'old91-self.zip').read_bytes()) == artifact['digest'],
        'file_hashes': {p.name: {'sha256': sha(p.read_bytes()), 'bytes': p.stat().st_size} for p in self_dir.glob('*.json')},
        'receipt_digest_matches_envelope': sha(receipt_bytes) == envelope['receipt_sha256'],
        'envelope': envelope, 'inner_summary': receipt['summary'], 'selection': receipt['selection'],
        'tasks': [{k: t[k] for k in ['task_id', 'status', 'exit_code', 'observations']} for t in receipt['tasks']],
        'findings': receipt['findings'],
        'disposition': 'SHADOW_NON_GATING valid capture; inner exit 1 / packaging FAIL retained; not a clean check',
    }
    (OUT / 'old91-self-summary.json').write_text(json.dumps(old_summary, indent=2) + '\n')
    summary = {'captured_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'base': BASE, 'head': HEAD, 'source_bindings': bindings, 'captures': records,
               'all_five_feature_files_unchanged_since_91': all(v['unchanged_since_91'] for v in bindings.values()),
               'old_self_summary': 'old91-self-summary.json'}
    (OUT / 'static-capture.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary))

def ci():
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    folder = OUT / stamp
    folder.mkdir()
    requests = {'head-runs.json': REPO + '/actions/runs?head_sha=' + HEAD,
                'check-runs.json': REPO + '/commits/' + HEAD + '/check-runs'}
    for run in [39628893533, 39628893299]:
        requests[str(run) + '-run.json'] = REPO + '/actions/runs/' + str(run)
        requests[str(run) + '-jobs.json'] = REPO + '/actions/runs/' + str(run) + '/jobs'
    records = {}
    for name, endpoint in requests.items():
        records[name] = capture(str(folder.relative_to(OUT) / name), ['gh', 'api', endpoint])
    summary = {'captured_utc': stamp, 'head': HEAD, 'records': records, 'runs': []}
    for run in [39628893533, 39628893299]:
        r = json.loads((folder / (str(run) + '-run.json')).read_bytes())
        jobs = json.loads((folder / (str(run) + '-jobs.json')).read_bytes())['jobs']
        summary['runs'].append({k: r[k] for k in ['id', 'head_sha', 'status', 'conclusion', 'run_attempt', 'html_url']})
        summary['runs'][-1]['jobs'] = [{k: j[k] for k in ['id', 'name', 'head_sha', 'status', 'conclusion', 'steps']} for j in jobs]
        for job in jobs:
            if job['status'] == 'completed':
                capture(str(folder.relative_to(OUT) / (str(job['id']) + '.log')), ['gh', 'api', REPO + '/actions/jobs/' + str(job['id']) + '/logs'])
    (folder / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary))

if __name__ == '__main__':
    {'static': static, 'ci': ci}[sys.argv[1]]()
