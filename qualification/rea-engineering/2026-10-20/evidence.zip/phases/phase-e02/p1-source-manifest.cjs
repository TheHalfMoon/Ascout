const { spawnSync } = require('node:child_process');
const { createHash } = require('node:crypto');
const { readFileSync, realpathSync, writeFileSync } = require('node:fs');
const { join } = require('node:path');
const root = join(__dirname, '..', 'selection');
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const git = args => {
  const r = spawnSync('git', args, { cwd: root, encoding: 'utf8' });
  if (r.status !== 0) throw new Error(r.stderr);
  return r.stdout.trim();
};
const paths = ['src/selection.ts', 'tests/pre-run-widening.integration.test.ts', 'tests/conservative-selection-data.contract.test.ts', 'tests/conservative-selection-data.native.test.ts', 'docs/qualification/REA-E02.md'];
const initialCandidate = '7ea4a9fa7dd2f44f31046297151943f1fdf99ead';
writeFileSync(join(__dirname, 'p1-red.source.selection.ts'), git(['show', `${initialCandidate}:src/selection.ts`]));
const original = JSON.parse(readFileSync(join(__dirname, 'source-manifest.json'), 'utf8'));
const manifest = {
  observedAt: new Date().toISOString(), head: git(['rev-parse', 'HEAD']), initialCandidate, canonicalBase: original.base,
  status: git(['status', '--porcelain']), sourceFiles: Object.fromEntries(paths.map(path => [path, hash(readFileSync(join(root, path)))])),
  node: process.version, platform: process.platform, arch: process.arch,
  dependencies: { nodeModulesRealpath: realpathSync(join(root, 'node_modules')), lockHash: hash(readFileSync(join(root, 'package-lock.json'))), installedSourceLockHash: hash(readFileSync(join(root, '..', 'Ascout', 'package-lock.json'))), cleanMachine: false },
  priorEvidence: 'Original source-manifest.json, final-summary.json and every original stdout/receipt remain unmodified; p1-* and native-p1-* retain forward-fix evidence.',
  pending: original.pending,
};
writeFileSync(join(__dirname, 'p1-source-manifest.json'), JSON.stringify(manifest, null, 2));
process.stdout.write(JSON.stringify(manifest, null, 2));
