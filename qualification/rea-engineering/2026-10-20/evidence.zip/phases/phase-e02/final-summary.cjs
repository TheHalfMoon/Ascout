const { readFileSync, writeFileSync, readdirSync } = require('node:fs');
const { createHash } = require('node:crypto');
const { join, relative } = require('node:path');
const { spawnSync } = require('node:child_process');
const read = p => JSON.parse(readFileSync(join(__dirname, p), 'utf8'));
const manifest = read('source-manifest.json');
const commands = Object.fromEntries(['red', 'native-final-head', 'focused-final-head', 'typecheck-final-head', 'build-final-head'].map(name => [name, read(`${name}.json`)]));
const receipt = read('native-final-head/receipt.json');
const native = Object.fromEntries(['working-full', 'mutated-related', 'mutated-full'].map(name => {
  const command = read(`native-final-head/${name}.command.json`);
  const result = read(`native-final-head/${name}.results.json`);
  return [name, { ...command, tests: result.numTotalTests, failures: result.numFailedTests }];
}));
const hashes = {};
function visit(dir) {
  for (const item of readdirSync(dir, { withFileTypes: true })) {
    const file = join(dir, item.name);
    if (item.isDirectory()) visit(file);
    else if (file !== join(__dirname, 'final-summary.json')) hashes[relative(__dirname, file).replaceAll('\\', '/')] = createHash('sha256').update(readFileSync(file)).digest('hex');
  }
}
visit(__dirname);
const finalGit = spawnSync('git', ['status', '--porcelain'], { cwd: join(__dirname, '..', 'selection'), encoding: 'utf8' });
const summary = { head: manifest.head, finalWorkingTreeStatus: finalGit.stdout.trim(), commands, native, selection: receipt.selection, sourceStable: JSON.stringify(receipt.source.start) === JSON.stringify(receipt.source.end), testTask: receipt.tasks.find(t => t.task_id === 'test'), fixture: read('native-final-head/fixture.json'), hashes, pending: manifest.pending };
writeFileSync(join(__dirname, 'final-summary.json'), JSON.stringify(summary, null, 2));
process.stdout.write(JSON.stringify({ head: summary.head, finalWorkingTreeStatus: summary.finalWorkingTreeStatus, exits: Object.fromEntries(Object.entries(commands).map(([k,v])=>[k,v.status])), native: Object.fromEntries(Object.entries(native).map(([k,v])=>[k,{exit:v.exit,tests:v.tests,failures:v.failures}])), sourceStable: summary.sourceStable, selection: summary.selection, retainedArtifacts: Object.keys(hashes).length }, null, 2));
