const { readFileSync, writeFileSync, readdirSync } = require('node:fs');
const { createHash } = require('node:crypto');
const { join, relative } = require('node:path');
const { spawnSync } = require('node:child_process');
const read = p => JSON.parse(readFileSync(join(__dirname, p), 'utf8'));
const source = read('p1-source-manifest.json');
const commands = Object.fromEntries(['p1-red', 'native-p1-red', 'p1-focused-final', 'native-p1-final', 'p1-typecheck-final', 'p1-build-final'].map(label => [label, read(`${label}.json`)]));
const controls = Object.fromEntries(['working-full', 'mutated-related', 'mutated-full', 'cross-working-full', 'cross-mutated-package-only', 'cross-mutated-full'].map(label => {
  const command = read(`native-p1-final/${label}.command.json`);
  const results = read(`native-p1-final/${label}.results.json`);
  return [label, { ...command, tests: results.numTotalTests, failures: results.numFailedTests }];
}));
const receipts = Object.fromEntries(['receipt', 'cross-receipt'].map(label => {
  const receipt = read(`native-p1-final/${label}.json`);
  return [label, { source: receipt.source, sourceStable: JSON.stringify(receipt.source.start) === JSON.stringify(receipt.source.end), selection: receipt.selection, test: receipt.tasks.find(t => t.task_id === 'test') }];
}));
const hashes = {};
function walk(dir) {
  for (const item of readdirSync(dir, { withFileTypes: true })) {
    const file = join(dir, item.name);
    if (item.isDirectory()) walk(file);
    else hashes[relative(__dirname, file).replaceAll('\\', '/')] = createHash('sha256').update(readFileSync(file)).digest('hex');
  }
}
walk(join(__dirname, 'native-p1-final'));
const git = spawnSync('git', ['status', '--porcelain'], { cwd: join(__dirname, '..', 'selection'), encoding: 'utf8' });
const summary = { head: source.head, finalWorkingTreeStatus: git.stdout.trim(), source, commands, controls, receipts, hashes, pending: source.pending };
writeFileSync(join(__dirname, 'p1-final-summary.json'), JSON.stringify(summary, null, 2));
process.stdout.write(JSON.stringify({ head: summary.head, clean: summary.finalWorkingTreeStatus === '', commands: Object.fromEntries(Object.entries(commands).map(([k,v]) => [k,v.status])), controls: Object.fromEntries(Object.entries(controls).map(([k,v]) => [k, { exit: v.exit, tests: v.tests, failures: v.failures }])), selections: Object.fromEntries(Object.entries(receipts).map(([k,v]) => [k, { selection: v.selection, status: v.test.status, sourceStable: v.sourceStable }])) }, null, 2));
