"""Use existing live read-only gates with the Task024 authority reference."""
import pathlib

path = pathlib.Path(__file__).with_name('premerge_timing.py')
source = path.read_text(encoding='utf-8').replace('Task021', 'Task024')
exec(compile(source, str(path), 'exec'))
