"""Bind actual Self inner truth and coverage dispositions without relabeling."""
import collections, hashlib, json, pathlib

root = pathlib.Path(__file__).resolve().parent
directory = root / 'cleanup-ci-self-only-14d8d22'
path = directory / 'self-verification-receipt.json'
raw = path.read_bytes()
receipt = json.loads(raw)
summary = json.loads((directory / 'summary.json').read_text())
assert hashlib.sha256(raw).hexdigest() == summary['self_artifact']['members'][path.name]['sha256']
groups = collections.Counter((item['path'], item['state'], item.get('reason')) for item in receipt['exercise']['records'])
result = {'kind': 'TASK024_ACTUAL_SELF_INNER_OBSERVATIONS', 'head': summary['head'], 'tree': summary['tree'], 'artifact_id': summary['self_artifact']['artifact_id'], 'receipt_sha256': hashlib.sha256(raw).hexdigest(), 'inner_summary': receipt['summary'], 'findings': receipt['findings'], 'exercise_totals': {key: value for key, value in receipt['exercise'].items() if key != 'records'}, 'exercise_groups': [{'path': path, 'state': state, 'reason': reason, 'count': count} for (path, state, reason), count in sorted(groups.items(), key=lambda item: repr(item[0]))], 'selector': summary['self_artifact']['selector_comparison'], 'notice': 'Actual inner FAIL/exit1 and materially_incomplete remain literal. The added historical qualification MJS has unresolved mapping records, not production coverage or ignored-code success. Existing packaging finding reproduces3/3; bounded artifact lacks raw exception bodies, so historical cause is unproved. No receipt/selector relabeling, admission, merge or release approval.'}
(root / 'cleanup-self-inner-observations.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
print(json.dumps(result, indent=2))
