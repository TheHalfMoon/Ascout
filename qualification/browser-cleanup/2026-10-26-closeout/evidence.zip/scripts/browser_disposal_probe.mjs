// Read-only diagnostic over the existing public runtime and supported Playwright API.
import { createHash } from 'node:crypto';
import { createServer } from 'node:http';
import { readFileSync, writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';

const [repoArg, outputArg] = process.argv.slice(2);
const repo = resolve(repoArg);
const output = resolve(outputArg);
const require = createRequire(join(repo, 'package.json'));
const { chromium } = require('playwright');
const { launchPlaywrightSession } = await import(pathToFileURL(join(repo, 'dist/browser/playwright-adapter.js')).href);
const { createSessionIdentity, createActionRequest, createTextAssertionRequest } = await import(pathToFileURL(join(repo, 'dist/browser/executor.js')).href);
const originalLaunch = chromium.launch;
const observations = [];
let browser;
const timed = (target, name, label) => {
  const original = target[name];
  target[name] = async function (...args) {
    const start = performance.now();
    try { return await original.apply(this, args); }
    finally { observations.push({ operation: label, elapsed_ms: performance.now() - start }); }
  };
};
chromium.launch = async function (...args) {
  browser = await originalLaunch.apply(this, args);
  const originalNewContext = browser.newContext;
  browser.newContext = async function (...contextArgs) {
    const context = await originalNewContext.apply(this, contextArgs);
    timed(context, 'close', 'BrowserContext.close');
    return context;
  };
  timed(browser, 'close', 'Browser.close');
  return browser;
};
const server = createServer((_request, response) => response.end('<!doctype html><div id="result">ready</div>'));
let runtime;
let first;
let pending;
try {
  await new Promise((done) => server.listen(0, '127.0.0.1', done));
  const identity = createSessionIdentity({ application_origin: `http://127.0.0.1:${server.address().port}`, browser_profile: 'chromium-default', engine: { name: 'chromium', channel: 'bundled-chromium', version: '1.63.0' }, environment: { arch: process.arch, os: process.platform, runtime: 'node', runtime_version: process.versions.node }, session_id: 'session-probe', source_identity: 'tree:owned-disposal-probe' });
  runtime = await launchPlaywrightSession(identity, { headless: true });
  const navigation = await runtime.executeAction(createActionRequest({ kind: 'navigate', request_id: 'nav', session_id: identity.session_id, target: '/', timeout_ms: 30000, value: null }), (target) => '#' + target);
  if (navigation.status !== 'ok') throw new Error('owned navigation failed');
  pending = runtime.executeTextAssertion(createTextAssertionRequest({ kind: 'exact_text', request_id: 'text', session_id: identity.session_id, source_identity: identity.source_identity, target: 'absent', expected_text: 'ready', timeout_ms: 1000 }), (target) => '#' + target);
  const start = performance.now();
  let firstSettled = false;
  first = runtime.dispose().finally(() => { firstSettled = true; });
  await runtime.dispose();
  const secondReturned = { first_dispose_settled: firstSettled, actual_browser_connected: browser.isConnected(), runtime_is_connected: runtime.isConnected(), elapsed_ms: performance.now() - start };
  await first;
  const assertion = await pending;
  const sha = (path) => createHash('sha256').update(readFileSync(path)).digest('hex');
  const result = { kind: 'SUPPORTED_API_DIAGNOSTIC_ONLY', observed_utc: new Date().toISOString(), head: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: repo, encoding: 'utf8' }).trim(), source_sha256: sha(join(repo, 'src/browser/playwright-adapter.ts')), compiled_sha256: sha(join(repo, 'dist/browser/playwright-adapter.js')), helper_sha256: sha(new URL(import.meta.url)), playwright_version: require('playwright/package.json').version, when_second_dispose_returned: secondReturned, when_first_dispose_returned: { actual_browser_connected: browser.isConnected(), elapsed_ms: performance.now() - start }, assertion_status: assertion.status, observations, limitations: 'Diagnostic wrapping of supported API calls, no source changes or process capture. Does not reproduce or identify the cause of the historical 5000ms full-suite disposal timeout. The second disposal observation is distinct concurrent-call behavior; no repair or qualification verdict.' };
  writeFileSync(output, JSON.stringify(result, null, 2) + '\n');
  process.stdout.write(JSON.stringify(result) + '\n');
} finally {
  await first;
  await pending;
  await runtime?.dispose();
  chromium.launch = originalLaunch;
  server.closeAllConnections();
  await new Promise((done, reject) => server.close((error) => error ? reject(error) : done()));
}
