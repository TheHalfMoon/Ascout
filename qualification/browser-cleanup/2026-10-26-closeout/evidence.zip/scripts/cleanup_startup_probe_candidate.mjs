// Read-only public API diagnostic; synthetic resource handles, no browser launch.
import { createRequire } from 'node:module';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, realpathSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';

const root = dirname(fileURLToPath(import.meta.url));
const repo = realpathSync(process.argv[2]);
const require = createRequire(join(repo, 'package.json'));
const { chromium } = require('playwright');
const { launchPlaywrightSession } = await import(pathToFileURL(join(repo, 'dist/browser/playwright-adapter.js')).href);
const original = chromium.launch;
const records = [];
try {
  for (const phase of ['newContext', 'newPage']) {
    const expected = new Error('Synthetic startup failure at ' + phase);
    let browserCloseCalls = 0;
    let contextCloseCalls = 0;
    const context = {
      newPage: async () => { throw expected; },
      close: async () => { contextCloseCalls++; },
    };
    chromium.launch = async () => ({
      version: () => 'synthetic-owned-browser',
      newContext: async () => { if (phase === 'newContext') throw expected; return context; },
      close: async () => { browserCloseCalls++; },
    });
    let caught;
    try { await launchPlaywrightSession({}, { headless: true }); }
    catch (error) { caught = error; }
    if (caught !== expected) throw new Error('Diagnostic did not traverse the expected public startup path');
    records.push({ phase, original_error_preserved: true, browser_close_calls: browserCloseCalls, context_close_calls: contextCloseCalls });
  }
} finally { chromium.launch = original; }
const sha = path => createHash('sha256').update(readFileSync(path)).digest('hex');
const result = { kind: 'TASK024_SUPPORTED_PUBLIC_API_DIAGNOSTIC_ONLY', head: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: repo, encoding: 'utf8' }).trim(), source_sha256: sha(join(repo, 'src/browser/playwright-adapter.ts')), compiled_sha256: sha(join(repo, 'dist/browser/playwright-adapter.js')), helper_sha256: sha(fileURLToPath(import.meta.url)), playwright_version: require('playwright/package.json').version, records, notice: 'Synthetic handles returned through the existing Playwright API object; no real browser, provisioning, process capture or production/test mutation. Records owned-browser close attempts on these source paths, not frequency of actual Chromium startup failures or the historical full-suite timeout cause. Not native browser qualification or a test PASS.' };
writeFileSync(join(root, 'cleanup-startup-candidate.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result));

if (records.some(record => record.browser_close_calls !== 1)) process.exitCode = 1;
