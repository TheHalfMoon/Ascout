"""Bind completed Task024 native captures without flattening native failures."""
import hashlib, json, pathlib, re

root = pathlib.Path(__file__).resolve().parent
runs = root.parent / 'engineering/runs'
records = []
for path in sorted(runs.glob('cleanup-repair-*.json')):
    capture = json.loads(path.read_text())
    assert capture['state'] == 'EXECUTED' and capture['source_unchanged']
    streams = {}
    for name in ['stdout', 'stderr']:
        data = (runs / capture[name]).read_bytes()
        assert hashlib.sha256(data).hexdigest() == capture[name + '_sha256']
        streams[name] = data.decode('utf-8')
    summaries = [re.sub(chr(27) + r'\[[0-?]*[ -/]*[@-~]', '', line) for line in streams['stdout'].splitlines() if any(token in line for token in ['Test Files ', '      Tests ', 'Duration '])]
    records.append({'capture': path.name, 'native_exit': capture['exit'], 'wall_seconds': capture['wall_seconds'], 'source_start': capture['source_start'], 'source_end': capture['source_end'], 'source_unchanged': capture['source_unchanged'], 'stdout_sha256': capture['stdout_sha256'], 'stderr_sha256': capture['stderr_sha256'], 'test_summaries': summaries})
assert len(records) == 11
result = {'kind': 'TASK024_ACTUAL_NATIVE_CAPTURE_INDEX', 'records': records, 'notice': 'Native exit is authoritative, not the outer capture wrapper exit. RED and full-suite T107 deadline FAIL retained. Synthetic startup observations and supported real-browser disposal probe are separate diagnostics, not native test qualification or historical timing causality. No release or all-pass claim.'}
(root / 'cleanup-qualification-summary.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
print(json.dumps({'captures': len(records), 'native_exits': [item['native_exit'] for item in records]}))
