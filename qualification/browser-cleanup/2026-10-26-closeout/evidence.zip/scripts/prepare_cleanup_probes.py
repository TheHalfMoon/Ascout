"""Derive separate Task024 controls without overwriting any earlier probe or report."""
import hashlib, json, pathlib

root = pathlib.Path(__file__).resolve().parent
sha = lambda data: hashlib.sha256(data).hexdigest()
startup = root / 'cleanup_startup_probe.mjs'
assert sha(startup.read_bytes()) == 'b567b1807ecab02af6efc664ed8a7a353dfb22a467b8741eee8e162ed4bfc3d8'
candidate = startup.read_text().replace("'cleanup-startup-ownership-diagnostic.json'", "'cleanup-startup-candidate.json'")
candidate = candidate.replace('Shows missing owned-browser close attempts on these source paths', 'Records owned-browser close attempts on these source paths')
candidate += "\nif (records.some(record => record.browser_close_calls !== 1)) process.exitCode = 1;\n"
target = root / 'cleanup_startup_probe_candidate.mjs'
if target.exists():
    assert target.read_bytes() == candidate.encode()
else:
    target.write_bytes(candidate.encode())

original = root.parent / 'engineering/phase-e04/testerarmy-control.mjs'
assert sha(original.read_bytes()) == 'bfd38ca3ce933c5a72fdc0dfc7d7aedde8b3ab71f637701c80fe7563d6373100'
source = original.read_text()
old = "const output=dirname(fileURLToPath(import.meta.url));\nconst engineering=dirname(output),work=dirname(engineering),repo=join(engineering,'browser');"
new = """const [repoArg, toolsArg, outputArg] = process.argv.slice(2);
const repo=resolve(repoArg),tools=resolve(toolsArg),output=resolve(outputArg);
if(dirname(output)!==dirname(fileURLToPath(import.meta.url)) || !output.split(/[\\\\/]/).at(-1).startsWith('cleanup-testerarmy-'))throw Error('Unexpected output containment');
await mkdir(output,{recursive:false});
await writeFile(join(output,'.ascout-owned-testerarmy-output'),randomUUID());"""
assert source.count(old) == 1
source = source.replace(old, new).replace("join(work,'npm-tools',", 'join(tools,')
source = source.replace("join(work,'npm-tools/", "join(tools,'")
source = source.replace("'engineering-e04-'", "'ascout-cleanup-'")
source = source.replace('await mkdir(fixtureRoot,{recursive:false});', "await mkdir(fixtureRoot,{recursive:false});\nawait writeFile(join(fixtureRoot,'.ascout-owned-testerarmy-fixture'),randomUUID());")
source = source.replace("env:{...process.env,CI:'true'", "env:{...Object.fromEntries(Object.entries(process.env).filter(([key])=>!/(?:_API_KEY|_TOKEN|_SECRET|_PASSWORD|^OPENAI_|^ANTHROPIC_|^DASHSCOPE_)/i.test(key))),CI:'true'")
assert 'join(work,' not in source and 'const engineering=' not in source
driver = root / 'cleanup_testerarmy_control.mjs'
assert not driver.exists()
driver.write_bytes(source.encode())
result = {'initial_startup_helper_sha256': sha(startup.read_bytes()), 'candidate_startup_helper_sha256': sha(target.read_bytes()), 'original_testerarmy_driver_sha256': sha(original.read_bytes()), 'candidate_testerarmy_driver_sha256': sha(driver.read_bytes()), 'notice': 'Own existing independent fixture driver adapted only to explicit current repository/tools/fresh output paths, distinct owned fixture prefix/markers and filtered provider-secret child environment. Fixed assertions, retries0, workers1, 15s test/1s assertion/45s child budgets and positive/negative/zero-model checks remain unchanged. No earlier file, output, package, lock or installed dependency changed. Synthetic startup baseline helper/result preserved separately.'}
(root / 'cleanup-probe-provenance.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
print(json.dumps(result))
