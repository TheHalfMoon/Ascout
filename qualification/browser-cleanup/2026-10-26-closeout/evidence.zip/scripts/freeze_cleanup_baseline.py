"""Read-only Task024 baseline bindings before project tests or source changes."""
import datetime, hashlib, json, pathlib, subprocess

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
base = '96c18b3a300c844e9766d272e8eb4f5c3a790e63'
sha = lambda data: hashlib.sha256(data).hexdigest()
def git(*args):
    return subprocess.check_output(['rtk', 'proxy', 'git', *args], cwd=repo)
assert git('rev-parse', 'HEAD').decode().strip() == base
names = ['src/browser/playwright-adapter.ts', 'tests/browser-playwright-adapter.contract.test.ts', 'tests/browser-playwright.integration.test.ts', 'tests/browser-text-assertion.integration.test.ts', 'tests/browser-text-assertion.contract.test.ts', 'tests/browser-executor.contract.test.ts', 'tests/t107-self-verification-harness.contract.test.ts', 'tests/npm-package-content.test.ts', 'package.json', 'package-lock.json', 'tsconfig.json', 'vitest.config.ts', '.github/workflows/ci.yml', '.github/workflows/self-verify.yml', 'CONTRIBUTING.md', '.specify/memory/constitution.md']
records = []
for name in names:
    data = git('show', base + ':' + name)
    assert data == (repo / name).read_bytes()
    records.append({'path': name, 'sha256': sha(data), 'bytes': len(data)})
compiled = repo / 'dist/browser/playwright-adapter.js'
assert sha(compiled.read_bytes()) == 'fcfcfdfd1ce9d37a193887730952bad5b6973129ef4e78b559b6efe87c83b20b'
prior = {}
for name in ['index-publication-receipt-1d65483.json', 'index-closing-sidecars-readback-1d65483.json']:
    data = (root / name).read_bytes()
    parsed = json.loads(data)
    assert parsed['head'] == '1d65483e0bbe8291bc1ceb6d62285d277dde2355'
    prior[name] = {'sha256': sha(data), 'actual_remote_observation': parsed}
result = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'base': base, 'base_tree': git('rev-parse', 'HEAD^{tree}').decode().strip(), 'source_bindings': records, 'compiled_adapter_sha256': sha(compiled.read_bytes()), 'predecessor_actual_remote_readback': prior, 'status': git('status', '--porcelain=v1', '--untracked-files=all').decode(), 'notice': 'Prospective read-only bindings; current dirty/untracked changes must be planning documents only. No test/source implementation, native qualification PASS or authority grant. Existing version/provisioning/authority/test/deadline contracts frozen.'}
(root / 'cleanup-baseline-bindings.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
print(json.dumps({'base': base, 'source_bindings': len(records), 'compiled_adapter_sha256': result['compiled_adapter_sha256'], 'predecessor_remote_files': 8}))
