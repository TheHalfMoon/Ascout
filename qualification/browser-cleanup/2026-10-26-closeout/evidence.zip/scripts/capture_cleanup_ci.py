"""Task024 exact-source hosted execution, including its 12 new test cases."""
import pathlib

path = pathlib.Path(__file__).with_name('capture_timing_ci.py')
source = path.read_text(encoding='utf-8')
assert source.count('2425') == 1
source = source.replace("'timing-ci-'", "'cleanup-ci-'").replace('TASK021_ACTUAL_', 'TASK024_ACTUAL_')
source = source.replace('2425', '2462')
source = source.replace('native_files = [', "native_files = ['git-index-observation.test.ts', 'browser-cleanup-ownership.test.ts', ")
exec(compile(source, str(path), 'exec'))
