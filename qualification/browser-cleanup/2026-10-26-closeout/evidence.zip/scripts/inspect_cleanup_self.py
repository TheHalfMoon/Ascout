"""Read completed Task024 shadow capture while native lanes remain pending."""
import pathlib

path = pathlib.Path(__file__).with_name('inspect_dependency_self.py')
source = path.read_text(encoding='utf-8').replace('dependency-self-', 'cleanup-ci-self-only-').replace('TASK022_ACTUAL_', 'TASK024_ACTUAL_')
exec(compile(source, str(path), 'exec'))
