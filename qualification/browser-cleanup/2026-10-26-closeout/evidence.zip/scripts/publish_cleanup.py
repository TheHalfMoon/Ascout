"""Explicit Task024 evidence derivatives and one inspected synthetic PNG."""
import ast, hashlib, json, pathlib, re, struct, subprocess, sys, zipfile, zlib

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
producer = root / 'publish_dependencies.py'
assert hashlib.sha256(producer.read_bytes()).hexdigest() == '87d1e9597dc89e9727821808a7790089d50b4574c012aa1f30f6a9f8770b32d1'
close = sys.argv[1:] == ['--close']
assert sys.argv[1:] in [[], ['--close']]
destination = repo / ('qualification/browser-cleanup/2026-10-26-closeout' if close else 'qualification/browser-cleanup/2026-10-26')
destination.mkdir(parents=True, exist_ok=True)
members, records = {}, []
sha = lambda data: hashlib.sha256(data).hexdigest()
module = ast.parse(producer.read_text())
functions = [node for node in module.body if isinstance(node, ast.FunctionDef) and node.name in ['minimize', 'sanitize', 'add']]
assert len(functions) == 3
exec(compile(ast.Module(body=functions, type_ignores=[]), str(producer), 'exec'))
for source in sorted((root.parent / 'engineering/runs').glob('cleanup-repair-*.json')):
    capture = json.loads(source.read_text())
    assert capture['state'] == 'EXECUTED' and capture['source_unchanged']
    add('runs/' + source.name, source)
    for stream in ['stdout', 'stderr']:
        path = source.parent / capture[stream]
        assert sha(path.read_bytes()) == capture[stream + '_sha256']
        add('runs/' + path.name, path)
for source in sorted(root.glob('cleanup-*.json')):
    if any(token in source.name for token in ['publication-receipt', 'publication-review', 'closing-review', 'derivative-verification']):
        continue
    add('context/' + source.name, source)
for source in sorted(root.glob('cleanup-tool-*.txt')):
    add('tools/' + source.name, source)
add('context/browser-disposal-api-probe.json', root / 'browser-disposal-api-probe.json')
for directory in sorted(path for path in root.glob('cleanup-ci-*') if path.is_dir()):
    for source in sorted(directory.iterdir()):
        if source.suffix in ['.json', '.log', '.txt']:
            add('ci/' + directory.name + '/' + source.name, source)
# This exact image was visually inspected. Permit no arbitrary binary, browser
# profile or metadata-bearing PNG; verify chunks, CRCs and the known bytes.
inspection = json.loads((root / 'cleanup-testerarmy-inspection.json').read_text())
tester = root / 'cleanup-testerarmy-88675d2'
png_count = 0
for source in sorted(path for path in tester.rglob('*') if path.is_file()):
    relative = source.relative_to(tester).as_posix()
    key = 'testerarmy/' + relative
    if source.suffix == '.png':
        assert relative == inspection['path']
        raw = source.read_bytes()
        assert len(raw) == inspection['bytes'] == 8277
        assert sha(raw) == inspection['sha256'] == '316031e41745c3f39e2b78ca8aef0a8b1f789e95e1cb6f73c3709ee630ef6843'
        assert raw[:8] == b'\x89PNG\r\n\x1a\n'
        offset, chunks = 8, []
        while offset < len(raw):
            length = struct.unpack('>I', raw[offset:offset + 4])[0]
            kind = raw[offset + 4:offset + 8]
            payload = raw[offset + 8:offset + 8 + length]
            crc = struct.unpack('>I', raw[offset + 8 + length:offset + 12 + length])[0]
            assert kind in [b'IHDR', b'IDAT', b'IEND'] and zlib.crc32(kind + payload) == crc
            if kind == b'IHDR':
                assert struct.unpack('>II', payload[:8]) == (1280, 720)
            chunks.append(kind)
            offset += length + 12
        assert offset == len(raw) and chunks[0] == b'IHDR' and chunks[-1] == b'IEND'
        assert key not in members
        members[key] = raw
        records.append({'path': key, 'original_sha256': sha(raw), 'published_sha256': sha(raw), 'bytes': len(raw), 'transformed': False, 'inspected_synthetic_png': True})
        png_count += 1
    elif source.suffix in ['.json', '.txt', '.ts', '.html']:
        add(key, source)
    else:
        assert source.name == '.ascout-owned-testerarmy-output'
assert png_count == 1
for name in ['package.json', 'package-lock.json']:
    add('toolchain/' + name, root.parent / 'npm-tools' / name)
scripts = ['publish_cleanup.py', 'publish_dependencies.py', 'summarize_cleanup.py', 'capture_cleanup_frontier.py', 'capture_timing_frontier.py', 'freeze_cleanup_baseline.py', 'cleanup_startup_probe.mjs', 'cleanup_startup_probe_candidate.mjs', 'browser_disposal_probe.mjs', 'prepare_cleanup_probes_initial.py', 'prepare_cleanup_probes.py', 'cleanup_testerarmy_control.mjs', 'capture_cleanup_tools.py', 'capture_timing_tools.py', 'capture_cleanup_ci.py', 'capture_timing_ci.py', 'premerge_cleanup.py', 'premerge_timing.py', 'verify_cleanup_publication.py', 'verify_timing_publication.py']
for name in scripts:
    add('scripts/' + name, root / name)
add('scripts/qualify_native.py', root.parent / 'engineering/qualify_native.py')
if close:
    number = json.loads((root / 'cleanup-pr-number.json').read_text())['number']
    for suffix in ['.json', '-premerge.json']:
        add('merges/' + str(number) + suffix, root.parent / 'engineering/merges' / (str(number) + suffix))
    add('scripts/record_merge.py', root.parent / 'engineering/record_merge.py')
manifest = {'authority': 'TASK024_QUALIFICATION_OBSERVATIONS_ONLY', 'notice': 'Explicit text/JSON public derivatives using the frozen minimizer, plus one exact hash/CRC/chunk-bound visually inspected synthetic failure PNG. Homes/emails/personal author/committer/raw signature profiles minimized, including nested JSON. Original and published hashes retained. Exact pre-existing auxiliary toolchain lock included; it is not an Ascout dependency change. No opaque archives, installed packages, graph DB/cache, browser profile, private REA expansion or account/usage data. RED, full T107 timeout, negative E2E and preparation errors remain visible. No historical cause, speedup, source authentication, provider-independent certification, merge or release approval.', 'records': records}
members['MANIFEST.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
archive = destination / 'evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name, data in sorted(members.items()):
        info = zipfile.ZipInfo(name, date_time=(2000, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        output.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
with zipfile.ZipFile(archive) as output:
    assert len(output.namelist()) == len(set(output.namelist())) and output.testzip() is None
    for record in records:
        assert sha(output.read(record['path'])) == record['published_sha256']
lock = {'zip_sha256': sha(archive.read_bytes()), 'members': len(members), 'source_head': subprocess.check_output(['rtk', 'proxy', 'git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip(), 'notice': manifest['notice']}
(destination / 'evidence-lock.json').write_bytes((json.dumps(lock, indent=2) + '\n').encode())
print(json.dumps(lock))
