"""Separate Task024 live frontier namespace; preserve all older task inputs."""
import pathlib

path = pathlib.Path(__file__).with_name('capture_timing_frontier.py')
source = path.read_text(encoding='utf-8').replace('timing-frontier-', 'cleanup-frontier-').replace('Task021', 'Task024')
exec(compile(source, str(path), 'exec'))
