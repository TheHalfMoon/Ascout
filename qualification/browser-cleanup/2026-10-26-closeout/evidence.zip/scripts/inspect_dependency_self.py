"""Read only the completed Self capture while native lanes remain pending."""
import pathlib

path = pathlib.Path(__file__).with_name('capture_timing_ci.py')
source = path.read_text(encoding='utf-8')
needle = "for run_id in [project_run] + ([] if postmerge else [self_run]):"
assert needle in source
source = source.replace(needle, 'for run_id in [self_run]:')
source = source.replace("'timing-ci-'", "'dependency-self-'")
source = source.replace('TASK021_ACTUAL_EXACT_HEAD_CI', 'TASK022_ACTUAL_SELF_ONLY_CAPTURE')
source = source.replace("'six_actual_native_full_suites_verified':", "'native_full_suites_not_inspected_by_this_self_only_reader':")
source = source.replace("summary['six_actual_native_full_suites_verified']", "summary['native_full_suites_not_inspected_by_this_self_only_reader']")
exec(compile(source, str(path), 'exec'))
