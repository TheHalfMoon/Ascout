"""Download actual Task024 public files and verify bytes and every member."""
import pathlib

path = pathlib.Path(__file__).with_name('verify_timing_publication.py')
source = path.read_text(encoding='utf-8').replace('qualification/git-head-query/', 'qualification/browser-cleanup/').replace('2026-10-24', '2026-10-26').replace('timing-publication-receipt-', 'cleanup-publication-receipt-').replace('Task021', 'Task024')
exec(compile(source, str(path), 'exec'))
