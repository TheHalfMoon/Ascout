"""Task024 local tools with a separate namespace and exact source/base bindings."""
import pathlib

path = pathlib.Path(__file__).with_name('capture_timing_tools.py')
source = path.read_text(encoding='utf-8').replace('e855b16b668d490cf6e3b5bfbe11b0e36724ae0d', '88675d2fa6425ac4938a2da2e931aed57559bb65').replace('92433f7039393d6a08b8f993bc50da8470de2b5c', '96c18b3a300c844e9766d272e8eb4f5c3a790e63').replace('timing-tool-', 'cleanup-tool-').replace('timing-graft-graph', 'cleanup-graft-graph').replace('src/git.ts', 'src/browser/playwright-adapter.ts').replace('tests/git-identity.test.ts', 'tests/browser-cleanup-ownership.test.ts')
exec(compile(source, str(path), 'exec'))
