"""Reuse frozen Task024 producer only after actual canonical/postmerge proof."""
import ast, hashlib, json, pathlib, sys

root = pathlib.Path(__file__).resolve().parent
producer = root / 'publish_cleanup.py'
assert hashlib.sha256(producer.read_bytes()).hexdigest() == 'd9ac004ea469dfd2b10922fd707abff19bc72f1d454feac2d17eabeb564ae479'
assert sys.argv[1:] == []
number = json.loads((root / 'cleanup-pr-number.json').read_text())['number']
proof = json.loads((root.parent / 'engineering/merges' / (str(number) + '.json')).read_text())
assert proof['tree_equal'] and proof['github_signature_verification']['verified']
postmerge = json.loads((root / ('cleanup-ci-postmerge-' + proof['merge'][:7]) / 'summary.json').read_text())
assert postmerge['head'] == proof['merge'] and postmerge['all_actual_jobs_success'] and postmerge['six_actual_native_full_suites_verified']
assert len(postmerge['jobs']) == 6
source = ast.parse(producer.read_text(encoding='utf-8'))
for node in source.body:
    if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'scripts' for target in node.targets):
        assert isinstance(node.value, ast.List)
        node.value.elts.extend(ast.Constant(name) for name in ['publish_cleanup_closeout.py', 'cleanup_review_sidecars.py', 'verify_cleanup_sidecars.py', 'inspect_cleanup_self.py', 'inspect_dependency_self.py', 'inspect_cleanup_receipt.py'])
        break
else:
    raise AssertionError('Frozen scripts declaration not found')
# These finalized final-head reviews/readbacks are deliberately outside the
# earlier frozen packet; include them forward, without changing original bytes.
extra_names = ['cleanup-publication-review-ee4fbb7.json', 'cleanup-publication-review-final-14d8d22.json', 'cleanup-publication-receipt-14d8d22.json']
extra = ast.parse('\n'.join('add(' + repr('prior-final/' + name) + ', root / ' + repr(name) + ')' for name in extra_names)).body
for index, node in enumerate(source.body):
    if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'manifest' for target in node.targets):
        source.body[index:index] = extra
        break
else:
    raise AssertionError('Frozen manifest declaration not found')
ast.fix_missing_locations(source)
sys.argv = [str(producer), '--close']
exec(compile(source, str(producer), 'exec'))
