"""Task027 distinct read-only frontier namespace; no old observation overwrite."""
import pathlib

path = pathlib.Path(__file__).with_name('capture_timing_frontier.py')
source = path.read_text(encoding='utf-8').replace('timing-frontier-', 'clean-state-frontier-').replace('Task021', 'Task027')
exec(compile(source, str(path), 'exec'))
