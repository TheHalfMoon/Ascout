"""Read-only Task027 baseline after actual final Task026 remote proof."""
import datetime, hashlib, json, pathlib, subprocess

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
sha = lambda data: hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['rtk', 'proxy', 'git', *args], cwd=repo)

assert git('rev-parse', 'HEAD').decode().strip() == '36768f4ffe1e2c18492cb3a8fdccd9274c2c615a'
assert git('status', '--porcelain') == b''
core = json.loads((root / 'native-timing-publication-receipt-55976e3.json').read_text())
side = json.loads((root / 'native-timing-closing-sidecars-readback-55976e3.json').read_text())
assert core['head'] == side['head'] == '55976e3efa5346f0da86440a0fe5022832ab4934'
assert core['all_member_hashes_crc_json_python_verified'] and core['remote_bytes_equal_local'] and core['members'] == 108
assert side['remote_ref_and_all_sidecar_bytes_verified'] and len(side['records']) == 7
previous = json.loads((root / 'native-timing-baseline.json').read_text())
bindings = {name: sha((repo / name).read_bytes()) for name in previous['bindings']}
assert bindings == previous['bindings']
entries = {}
for entry in git('ls-tree', '-r', '-z', 'HEAD', '--', 'src', 'tests', 'benchmarks').split(b'\0'):
    if entry:
        metadata, path = entry.split(b'\t', 1)
        entries[path.decode()] = metadata.decode()
assert entries == previous['frozen_git_entries'] and len(entries) == 434
full_path = root.parent / 'engineering/runs/packaging-repair-full-suite-681272cd-34ec-485e-ad9a-3193e8c86c48.json'
full = json.loads(full_path.read_text())
assert full['state'] == 'EXECUTED' and full['exit'] == 1 and full['source_unchanged']
for stream in ['stdout', 'stderr']:
    assert sha((full_path.parent / full[stream]).read_bytes()) == full[stream + '_sha256']
harness = root.parent / 'engineering/qualify_native.py'
assert sha(harness.read_bytes()) == '326d0fa4e1f850173cbb20bcfc92f621352f092166773533e7adac2108a2465a'
tools = []
for argv in [['C:/Program Files/nodejs/node.exe', '--version'], ['C:/Program Files/nodejs/node.exe', 'C:/Program Files/nodejs/node_modules/npm/bin/npm-cli.js', '--version'], ['git', '--version']]:
    result = subprocess.run(['rtk', 'proxy', *argv], cwd=repo, capture_output=True, timeout=30)
    tools.append({'argv': argv, 'exit': result.returncode, 'stdout': result.stdout.decode(), 'stderr': result.stderr.decode()})
diagnosis = root / 'native-timing-observations.json'
assert sha(diagnosis.read_bytes()) == '61d5c345ca4b4eb60f0696c33909b89f8870d349b6158d27107dfe7a3942059f'
record = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'head': git('rev-parse', 'HEAD').decode().strip(), 'tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
    'bindings': bindings, 'baseline_git_entries': entries, 'source_tree': git('rev-parse', 'HEAD:src').decode().strip(),
    'predecessor_core': core, 'predecessor_sidecars': side, 'prior_full_capture': full,
    'prior_full_capture_sha256': sha(full_path.read_bytes()), 'harness_sha256': sha(harness.read_bytes()),
    'tool_observations': tools, 'prior_diagnostic_sha256': sha(diagnosis.read_bytes()),
    'prior_diagnostic_driver_sha256': '67c73278bc649e1e2d4473084739c23707034b71942eb5824811d1155784522e',
    'permitted_future_existing_source_path': 'benchmarks/self-verify.mjs',
    'permitted_future_new_test_path': 'tests/self-verify-clean-state.native.test.ts',
    'official_node_references': previous['official_references'],
    'notice': 'Read-only source/version/predecessor/failure preparation. No new test, observer driver, fixture/probe or source edit. Actual final Task026108member3core+7sidecar readback55976e3 precedes this task. All434 current entries and16 controls match predecessor. Future source/test authority requires prospective plan audit, different consistency and bounded direct-user-derived authorization. Prior localFAIL12 and diagnosis limitations remain; no historical cause, speedup, provider-independent certification or release claim.'}
path = root / 'clean-state-baseline.json'
assert not path.exists()
path.write_bytes((json.dumps(record, indent=2) + '\n').encode())
print(json.dumps({'head': record['head'], 'entries': len(entries), 'controls': len(bindings), 'predecessor': core['head'], 'tool_observations': tools}))
