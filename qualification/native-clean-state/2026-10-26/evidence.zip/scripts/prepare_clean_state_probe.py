"""Adapt the reviewed Task026 source after Task027 gates; never execute a control."""
import hashlib, pathlib

root = pathlib.Path(__file__).resolve().parent
original = root / 'native_timing_probe.mjs'
assert hashlib.sha256(original.read_bytes()).hexdigest() == '67c73278bc649e1e2d4473084739c23707034b71942eb5824811d1155784522e'
source = original.read_text(encoding='utf-8')
before = "const [mode, repositoryArgument] = process.argv.slice(2);\nassert(['launch-before', 'baseline', 'observer', 'launch-after'].includes(mode));"
assert source.count(before) == 1
source = source.replace(before, "const [phase, repositoryArgument, benchmarkHash] = process.argv.slice(2);\nassert(['baseline', 'candidate'].includes(phase));\nassert(/^[a-f0-9]{64}$/.test(benchmarkHash));\nconst mode = 'observer';")
before = "const benchmarkHash = '6efbee04780061f1bb100837369d1e55e5756754007b2b7936f4cc6faa33ea82';\n"
assert source.count(before) == 1
source = source.replace(before, '')
source = source.replace("id: mode + '-' + randomUUID(), mode,", "id: 'clean-state-' + phase + '-' + randomUUID(), phase, mode,")
source = source.replace("stages: mode.startsWith('launch-') ? [] :", 'stages:')
source = source.replace('fixture_commands: [], launch_samples: [], owned_fixtures: [],', 'fixture_commands: [], owned_fixtures: [],')
lines = source.splitlines(keepends=True)
assert sum('  launch_plan:' in line for line in lines) == 1
source = ''.join(line for line in lines if '  launch_plan:' not in line)
start = source.index("  if (mode.startsWith('launch-')) {", source.index('\ntry {\n'))
end = source.index('  } else {\n', start) + len('  } else {\n')
source = source[:start] + source[end:]
before = "    record.diagnostic_result = 'INDEPENDENT_POSITIVE_ASSERTIONS_RETURNED';\n  }\n} catch (error) {"
assert source.count(before) == 1
source = source.replace(before, "    record.diagnostic_result = 'INDEPENDENT_POSITIVE_ASSERTIONS_RETURNED';\n} catch (error) {")
source = source.replace('Owned independent reproduction only. Source/tests/deadlines unchanged.', 'Owned independent invocation-budget control. Expected benchmark/fixture inputs stay fixed within this control; existing test deadlines unchanged.')
source = source.replace("join(dirname(driver), 'native-timing-output')", "join(dirname(driver), 'clean-state-output')")
metric = r'''
const gitChildren = record.observer.children.filter(child => child.command === 'git');
const fixtureGit = record.fixture_commands.filter(command => command.file === 'git');
const npmChildren = record.observer.children.filter(child => child.command === process.execPath
  && Array.isArray(child.argv) && basename(String(child.argv[0])) === 'npm-cli.js');
const expectedNpm = [['ci', '--ignore-scripts', '--no-audit', '--no-fund', '--offline'], ['run', 'build']];
const npmMatches = npmChildren.length === 2 && npmChildren.every((child, index) =>
  JSON.stringify(child.argv.slice(1)) === JSON.stringify(expectedNpm[index]));
const qualified = record.diagnostic_result === 'INDEPENDENT_POSITIVE_ASSERTIONS_RETURNED'
  && record.errors.length === 0 && record.observer.qualification === 'DIRECT_CHILD_EVENTS_OBSERVED'
  && record.observer.faults.length === 0 && record.observer.restored
  && record.driver_source_unchanged && record.benchmark_source_unchanged && record.fixture_source_unchanged
  && record.observer.children.every(child => child.close_observed && child.native_code === 0
    && child.native_signal === null && child.error === null && !child.synchronous_throw
    && ['prepare_exact_runtime', 'release_exact_runtime'].includes(child.phase))
  && fixtureGit.length === 10 && fixtureGit.length === record.fixture_commands.length
  && fixtureGit.every(command => command.state === 'RETURNED' && command.native_status === 0 && command.native_signal === null)
  && gitChildren.length + npmChildren.length === record.observer.children.length && npmMatches
  && gitChildren.filter(child => child.phase === 'release_exact_runtime').length === 1;
record.invocation_budget = {
  criterion: 'At most23 Git invocations and exactly2 original npm invocations in the complete positive case',
  maximum_git_invocations: 23, expected_npm_invocations: 2,
  fixture_git_invocations: fixtureGit.length, async_git_invocations: gitChildren.length,
  total_git_invocations: fixtureGit.length + gitChildren.length, npm_invocations: npmChildren.length,
  inputs_and_original_outcomes_qualified: qualified,
  status: !qualified ? 'NOT_EVALUATED_UNQUALIFIED_CONTROL'
    : fixtureGit.length + gitChildren.length <= 23 ? 'PASS' : 'FAIL',
  notice: 'Structural benchmark criterion only. A qualified baseline budget FAIL is expected RED; assertion return/native child success are separate. Not an original Vitest result, elapsed-time target, historical cause or release certification.'
};
if (record.invocation_budget.status !== 'PASS') process.exitCode = 1;
'''
marker = "const output = join(dirname(driver), 'clean-state-output');"
assert source.count(marker) == 1
source = source.replace(marker, metric + '\n' + marker)
before = 'case_wall_ms: record.case_wall_ms ?? null, observer:'
assert source.count(before) == 1
source = source.replace(before, 'case_wall_ms: record.case_wall_ms ?? null, invocation_budget: record.invocation_budget, observer:')
destination = root / 'clean_state_probe.mjs'
assert not destination.exists()
destination.write_bytes(source.encode())
print(hashlib.sha256(destination.read_bytes()).hexdigest())
