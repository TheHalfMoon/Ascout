"""Actual local Alibaba scope preview/rules; never a model review."""
import datetime,hashlib,json,os,pathlib,subprocess

root=pathlib.Path(__file__).resolve().parent
repo=root.parent/'engineering/main-control'
head=subprocess.check_output(['rtk','proxy','git','rev-parse','HEAD'],cwd=repo).decode().strip()
assert head.startswith('c80bb24')
ocr=pathlib.Path.home()/'AppData/Roaming/npm/node_modules/@alibaba-group/open-code-review/bin/ocr.js'
commands=[('alibaba-preview',['C:/Program Files/nodejs/node.exe',str(ocr),'delegate','preview','--from','36768f4ffe1e2c18492cb3a8fdccd9274c2c615a','--to',head]),
 ('alibaba-rules',['C:/Program Files/nodejs/node.exe',str(ocr),'delegate','rule','benchmarks/self-verify.mjs'])]
records=[]
for label,argv in commands:
    result=subprocess.run(['rtk','proxy',*argv],cwd=repo,env={**os.environ,'DO_NOT_TRACK':'1'},capture_output=True,timeout=180)
    for stream in ['stdout','stderr']:
        (root/('clean-state-tool-'+label+'.'+stream+'.txt')).write_bytes(getattr(result,stream))
    records.append({'label':label,'argv':argv,'exit':result.returncode,'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(result.stderr).hexdigest()})
record={'observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'commands':records,
 'notice':'Actual free local Alibaba preview/rule lookup only; output is scope/rule evidence, not Claude/provider/model code review or gate approval. PStack separate fresh OpenAI source/boundary reviews provide visible inline bars, shared provider lineage remains explicit. D1 earlier actual fixture review advisory only, not final source/security certification. Graft/TesterArmy/browser implementation is unchanged by Task027: no fresh unrelated build/E2E claimed; historical bound evidence retained and actual full-suite browser failure remains open. No paid services, cloud runtime, new dependencies or UA-P07.'}
(root/'clean-state-tool-execution.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
print(json.dumps(record))
