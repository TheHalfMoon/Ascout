"""Task027 explicit public derivatives; retain all adverse observations."""
import ast,hashlib,json,pathlib,re,subprocess,zipfile

root=pathlib.Path(__file__).resolve().parent
repo=root.parent/'engineering/main-control'
destination=repo/'qualification/native-clean-state/2026-10-26'
producer=root/'publish_dependencies.py'
sha=lambda value:hashlib.sha256(value).hexdigest()
assert sha(producer.read_bytes())=='87d1e9597dc89e9727821808a7790089d50b4574c012aa1f30f6a9f8770b32d1'
members,records={},[]
functions=[n for n in ast.parse(producer.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in ['minimize','sanitize','add']]
assert len(functions)==3
exec(compile(ast.Module(body=functions,type_ignores=[]),str(producer),'exec'))
for source in sorted((root.parent/'engineering/runs').glob('clean-state-*.json')):
    capture=json.loads(source.read_text())
    assert capture['state']=='EXECUTED' and capture['source_unchanged']
    add('runs/'+source.name,source)
    for stream in ['stdout','stderr']:
        path=source.parent/capture[stream]
        assert sha(path.read_bytes())==capture[stream+'_sha256']
        add('runs/'+path.name,path)
for directory in ['clean-state-output','clean-state-routing-output']:
    for source in sorted((root/directory).iterdir()):
        assert source.suffix in ['.json','.txt'] and source.is_file()
        add('observations/'+directory+'/'+source.name,source)
        if directory=='clean-state-routing-output' and source.suffix=='.json':
            control=json.loads(source.read_text())
            parent=pathlib.Path(control['owned_root'])
            marker=json.loads((parent/'.owner.json').read_text())
            assert marker['owner']==control['owner_uuid']
            runner=pathlib.Path(control['runner_output'])
            assert runner.resolve().parent==parent.resolve() and runner.name=='runner-results.json'
            assert not runner.is_symlink() and runner.is_file()
            add('observations/runner/'+control['id']+'.json',runner)
context=['baseline','frontier-refresh','plan-audit-89c65d0','consistency-64f2e49','control-review-895f8ea','git-reference','pre-candidate','controls','first-full-suite','source-correctness-50ec459','boundary-review-50ec459','fixture-delta-31b7b26','controller-delta-a92ba66','controller-final-delta-63b6c91','d1-observation','reporter-failure','reporter-delta-eea51d4','diagnostic-results','source-review-c80bb24','security-review-c80bb24','source-qualification','tool-execution']
for name in context:
    add('context/clean-state-'+name+'.json',root/('clean-state-'+name+'.json'))
for source in sorted(root.glob('clean-state-tool-*.txt')):
    add('tools/'+source.name,source)
scripts=['publish_clean_state.py','publish_dependencies.py','freeze_clean_state_baseline.py','capture_clean_state_frontier.py','capture_timing_frontier.py','clean_state_git_reference.py','prepare_clean_state_probe.py','lock_clean_state_probe.py','record_clean_state_review.py','bind_clean_state_candidate.py','record_clean_state_controls.py','record_clean_state_full_failure.py','record_clean_state_reporter_failure.py','record_clean_state_diagnostics.py','record_clean_state_qualification.py','capture_clean_state_tools.py','capture_clean_state_ci.py','capture_timing_ci.py','verify_clean_state_publication.py','verify_timing_publication.py','clean_state_probe.mjs','clean_state_routing_control.mjs','clean_state_routing_control_17a2e8.mjs','clean_state_routing_control_15afba.mjs','clean_state_routing_control_16bf3f8.mjs']
for name in scripts:
    add('scripts/'+name,root/name)
add('scripts/qualify_native.py',root.parent/'engineering/qualify_native.py')
manifest={'authority':'TASK027_BOUND_DIAGNOSTIC_AND_SOURCE_QUALIFICATION_ONLY',
 'notice':'Explicit minimized text/JSON derivatives; original/published hashes retained. Includes initial full FAIL6 plus hook, failed TS5112 invocation, structural budget RED/GREEN, every adverse source/controller report and unqualified native-init reporter capture. Expected negative child failures and filtered cases remain failures/filtered, never original-case PASS. Source/driver leaf identity does not mean prior controls ran on later whole trees. Installed manual references/hash only, no raw full documentation/cache/private REA or installed dependencies. D1 advisory, Alibaba preview/rules scope only; no provider-independent certification, historical root-cause resolution, statistical speedup, host exoneration, deadline/authority waiver, full-suite erasure or release approval. Original unknown repository-recognition failure cannot be reconstructed from a discarded filesystem. All owned raw artifacts retained pending actual remote proof.',
 'records':records}
members['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
archive=destination/'evidence.zip'
assert not archive.exists(), 'Do not overwrite a frozen publication packet'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as output:
    for name,data in sorted(members.items()):
        info=zipfile.ZipInfo(name,date_time=(2000,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
        output.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
with zipfile.ZipFile(archive) as output:
    assert len(output.namelist())==len(set(output.namelist())) and output.testzip() is None
    for item in records:assert sha(output.read(item['path']))==item['published_sha256']
lock={'zip_sha256':sha(archive.read_bytes()),'members':len(members),
 'source_head':subprocess.check_output(['rtk','proxy','git','rev-parse','HEAD'],cwd=repo).decode().strip(),'notice':manifest['notice']}
(destination/'evidence-lock.json').write_bytes((json.dumps(lock,indent=2)+'\n').encode())
print(json.dumps(lock))
