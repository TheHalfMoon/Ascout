"""Record qualified forward checks and retain every earlier adverse outcome."""
import datetime,hashlib,json,pathlib,subprocess

root=pathlib.Path(__file__).resolve().parent
repo=root.parent/'engineering/main-control'
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['rtk','proxy','git',*args],cwd=repo)
head=git('rev-parse','HEAD').decode().strip()
assert head=='b90d14c3b55ff5a8d6cffcbb1fd571386e6896b2'
assert not git('status','--porcelain').strip()
benchmark='151eb52a59ee68674b3f4000c47ee6e5282ac573ed8d872d0909a5498ce188ad'
test='dafd92e594e8a8a0a2ec082e1115073855bdaed81e0d0be7e1b5fd3d0f95c5b8'
assert sha((repo/'benchmarks/self-verify.mjs').read_bytes())==benchmark
assert sha((repo/'tests/self-verify-clean-state.native.test.ts').read_bytes())==test
baseline=json.loads((root/'clean-state-baseline.json').read_text())
entries={row.split(b'\t',1)[1].decode():row.split(b'\t',1)[0].decode() for row in git('ls-tree','-r','-z','HEAD','--','src','tests','benchmarks').split(b'\0') if row}
assert set(entries)==set(baseline['baseline_git_entries'])|{'tests/self-verify-clean-state.native.test.ts'}
assert all(entries[name]==value for name,value in baseline['baseline_git_entries'].items() if name!='benchmarks/self-verify.mjs')
assert all(sha((repo/name).read_bytes())==digest for name,digest in baseline['bindings'].items() if name!='benchmarks/self-verify.mjs')
captures=[]
for name in ['submodule-fixture-types','submodule-fixture-check','dependency-audit']:
    files=list((root.parent/'engineering/runs').glob('clean-state-'+name+'-*.json'));assert len(files)==1
    path=files[0];data=json.loads(path.read_text())
    assert data['state']=='EXECUTED' and data['exit']==0 and data['source_unchanged'] and data['source_start']['head']==head
    for stream in ['stdout','stderr']:
        assert sha((path.parent/data[stream]).read_bytes())==data[stream+'_sha256']
    captures.append({'name':name,'file':path.name,'sha256':sha(path.read_bytes()),'native_exit':data['exit'],'wall_seconds':data['wall_seconds'],'stdout_sha256':data['stdout_sha256'],'stderr_sha256':data['stderr_sha256']})
    stdout=(path.parent/data['stdout']).read_text()
    if name=='submodule-fixture-check':assert '7 passed (7)' in stdout and '1 passed (1)' in stdout
    if name=='dependency-audit':
        audit=json.loads(stdout)
        assert audit['metadata']['vulnerabilities']['total']==0
        audit_summary=audit['metadata']
record={'schema_version':1,'observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'checked_head':head,'checked_tree':git('rev-parse','HEAD^{tree}').decode().strip(),'benchmark_sha256':benchmark,'native_test_sha256':test,
 'frozen_other_git_entries':433,'frozen_other_control_hashes':15,'forward_captures':captures,'dependency_audit':audit_summary,
 'review_bindings':{'source':{'head':'c80bb24308483c0ef1fff07c44e92c2a42968a8a','sha256':'b128a77c21a0171fa11bd55d66ee1d396395b43c777ed21536ab42eea2825edf'},
 'boundary_security':{'head':'c80bb24308483c0ef1fff07c44e92c2a42968a8a','sha256':'8f54e21365b9374ad6ff979d472d11ac93b1d5b3b56fc7aa3398b13c364bb526'}},
 'interpretation':'The new fixture setup defect is corrected and all seven cases now pass with the status-row/diff0 oracle intact. Routing/real native failure retention controls have separate earlier exact-leaf proof, not execution on this later whole tree. Strict source typing/build and T107 controls bind unchanged source leaves; no redundant repeat claimed. Original full suite remains native1/2429pass6fail34skip plus hook. Earlier new assertion FAIL and reporter UNQUALIFIED remain preserved. Original repository-recognition cause is unknown because the original fixture was discarded; retained new evidence cannot recover it. No candidate exoneration or full-suite green inferred.',
 'limits':['No statistical speedup/historical root-cause/host-cause claim','Index-flag cases preserve flags while another tracked path is dirty; not exhaustive flagged-only equivalence','Windows numeric inode values may lose integer precision, disclosed by boundary review; no replacement/escape observed','Shared OpenAI source/boundary review lineage is role separation, not provider-independent certification','D1 advisory; Alibaba local preview/rules are not model review','Final integrated/publication/CI/Self/live eligibility/canonical/postmerge/closing remote gates pending; E00/release BLOCKED']}
(root/'clean-state-source-qualification.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
(repo/'qualification/native-clean-state/2026-10-26/source-qualification.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
print(json.dumps({'forward':'7PASS','audit_vulnerabilities':0,'frozen_entries':433,'old_failures':'PRESERVED'}))
