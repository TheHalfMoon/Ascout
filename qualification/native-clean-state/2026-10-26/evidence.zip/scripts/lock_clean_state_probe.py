"""Bind actual pre-control source after authority; no fixture or project test execution."""
import datetime, hashlib, json, pathlib, subprocess

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
sha = lambda data: hashlib.sha256(data).hexdigest()
assert subprocess.check_output(['rtk', 'proxy', 'git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == 'e05dc58d142e84842372f85dcd49d9b08651d1ec'
baseline = json.loads((root / 'clean-state-baseline.json').read_text())
for name, expected in baseline['bindings'].items():
    assert sha((repo / name).read_bytes()) == expected
driver = root / 'clean_state_probe.mjs'
test = repo / 'tests/self-verify-clean-state.native.test.ts'
record = {'recorded_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'authority_head': 'e05dc58d142e84842372f85dcd49d9b08651d1ec',
    'parent_reviewed_driver_sha256': '67c73278bc649e1e2d4473084739c23707034b71942eb5824811d1155784522e',
    'driver_sha256': sha(driver.read_bytes()), 'driver_bytes': len(driver.read_bytes()),
    'driver_archive_member_intended': 'scripts/clean_state_probe.mjs', 'archive_state': 'NOT_YET_ARCHIVED_OR_PUBLISHED',
    'baseline_benchmark_sha256': baseline['bindings']['benchmarks/self-verify.mjs'],
    'original_fixture_source_sha256': baseline['bindings']['tests/t107-self-verification-harness.contract.test.ts'],
    'new_native_test': {'path': str(test.relative_to(repo)), 'sha256': sha(test.read_bytes()), 'cases_planned': 7, 'execution': 'NOT_EXECUTED'},
    'control_sequence': [{'phase': 'baseline', 'state': 'NOT_EXECUTED', 'benchmark_sha256': baseline['bindings']['benchmarks/self-verify.mjs']}, {'phase': 'candidate', 'state': 'NOT_EXECUTED', 'benchmark_sha256': 'MUST_BE_BOUND_BEFORE_CANDIDATE_CONTROL'}],
    'maximum_git_invocations': 23, 'expected_npm_invocations': 2,
    'review_state': 'FRESH_CONCRETE_CONTROL_AND_FIXTURE_REVIEW_PENDING_BEFORE_EXECUTION',
    'notice': 'Actual driver/test source is bound after completed prospective gates and bounded user authority. No original Vitest outcome or source repair claimed. Driver syntax checked only; no fixture/control/new test executed. Budget RED requires qualified original positive outcomes plus actual observed count>23, not just any nonzero exit. Missing observer/source/native integrity is NOT_EVALUATED, never a budget PASS. Archive member is intended packet-relative location, not current tracked source or publication proof. Existing source/tests/deadlines unchanged at this baseline; only the named new native file added. All later native equivalence/source/CI/governance/canonical/remote gates and E00/release blockers remain.'}
destination = repo / 'qualification/native-clean-state/2026-10-26/probe-source-lock.json'
assert not destination.exists()
destination.parent.mkdir(parents=True, exist_ok=True)
destination.write_bytes((json.dumps(record, indent=2) + '\n').encode())
print(json.dumps(record))
