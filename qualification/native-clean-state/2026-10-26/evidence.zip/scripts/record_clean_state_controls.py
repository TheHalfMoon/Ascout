"""Record actual RED/GREEN and focused outcomes before the complete native suite."""
import datetime, hashlib, json, pathlib

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
sha = lambda data: hashlib.sha256(data).hexdigest()
sequence = []
for phase, expected, expected_exit in [('baseline', 29, 1), ('candidate', 23, 0)]:
    inputs = list((root / 'clean-state-output').glob('clean-state-' + phase + '-*.json'))
    captures = list((root.parent / 'engineering/runs').glob('clean-state-cost-' + phase + '-*.json'))
    assert len(inputs) == len(captures) == 1
    observation = json.loads(inputs[0].read_text())
    capture = json.loads(captures[0].read_text())
    assert capture['state'] == 'EXECUTED' and capture['exit'] == expected_exit and capture['source_unchanged']
    for stream in ['stdout', 'stderr']:
        assert sha((captures[0].parent / capture[stream]).read_bytes()) == capture[stream + '_sha256']
    budget = observation['invocation_budget']
    assert budget['inputs_and_original_outcomes_qualified'] and budget['total_git_invocations'] == expected and budget['npm_invocations'] == 2
    assert budget['status'] == ('FAIL' if phase == 'baseline' else 'PASS')
    assert observation['diagnostic_result'] == 'INDEPENDENT_POSITIVE_ASSERTIONS_RETURNED' and not observation['errors']
    sequence.append({'phase': phase, 'capture': captures[0].name, 'capture_sha256': sha(captures[0].read_bytes()),
        'observation': inputs[0].name, 'observation_sha256': sha(inputs[0].read_bytes()),
        'source_head': capture['source_start']['head'], 'benchmark_sha256': observation['benchmark_sha256'],
        'native_exit': capture['exit'], 'native_wall_seconds': capture['wall_seconds'], 'case_wall_ms': observation['case_wall_ms'],
        'fixture_tree': observation['fixture']['headTree'], 'budget': budget, 'direct_async_children': len(observation['observer']['children']),
        'observer_qualification': observation['observer']['qualification'], 'original_assertions': observation['diagnostic_result']})
assert sequence[0]['fixture_tree'] == sequence[1]['fixture_tree'] == 'd37787697024a7e5076d97a456c8894f3d483a78'
captures = []
for path in sorted((root.parent / 'engineering/runs').glob('clean-state-*.json')):
    value = json.loads(path.read_text())
    assert value['state'] == 'EXECUTED' and value['source_unchanged']
    captures.append({'file': path.name, 'sha256': sha(path.read_bytes()), 'exit': value['exit'], 'wall_seconds': value['wall_seconds'], 'source_head': value['source_start']['head']})
record = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'sequence': sequence,
    'captures': captures, 'driver_sha256': '1ad5e1ffb73963c7f96e00ca4d6e4814a38a4f91256ed22aa1c7eda696e6ca08',
    'implementation_head': '8b3493b088abf004773ea03b0ed20fe6162b707e', 'implementation_benchmark_sha256': '151eb52a59ee68674b3f4000c47ee6e5282ac573ed8d872d0909a5498ce188ad',
    'new_native_baseline': {'native_exit': 0, 'passed': 7, 'skipped': 0},
    'focused_candidate': {'native_exit': 0, 'passed': 32, 'existing_windows_skips': 9, 'files_passed': 2},
    'compiler_invocation_limit': {'initial_native_exit': 1, 'diagnostic': 'TS5112: explicit file arguments require --ignoreConfig; file checking did not run.', 'corrected_explicit_invocation_native_exit': 0, 'source_or_config_changed': False},
    'full_suite_state': 'PLANNED_NOT_EXECUTED',
    'notice': 'Qualified29Git baseline budgetRED/native1 and23Git candidateGREEN/native0 preserve original positive outcomes and two npm operations. Six native Git launches removed in the clean representative path, no integrity checkpoint removed. Ordered elapsed samples24070.9895/7719.3759ms are descriptive only, not statistical speedup/observer-overhead/historical cause. Original Vitest result is not executed by these cost controls. Source433other entries15non-target controls and all old tests/deadlines/config/authority unchanged. Complete local suite, source/security/integrated/privacy reviews, exact-head CI/Self/livegovernance/canonical/closingremote remain; original fullFAIL12/provenance/selector debt and E00/release BLOCKED.'}
destination = repo / 'qualification/native-clean-state/2026-10-26/local-controls.json'
assert not destination.exists()
destination.write_bytes((json.dumps(record, indent=2) + '\n').encode())
(root / 'clean-state-controls.json').write_bytes((json.dumps(record, indent=2) + '\n').encode())
state = '''Last updated: 2026-10-26 Asia/Riyadh · Branch: ps/rea-clean-state-observation

## Current state

Canonical main36768f4 after CLOSED_CANONICAL Task026/PR648, final55976e3 remote proof verified before this task. Task027 prospective gates/authority/control review complete. Benchmark implementation8b3493b SHA151eb52a changes only the named private clean-state helper: fresh HEAD/index and every checkpoint retained; complete clean/untracked-only status avoids redundant diffs, ambiguous rows retain original native diff decisions. All433other existing entries/15controls and old tests/deadlines/config/authority frozen.

## Actual local controls

Seven new native baseline cases pass. Candidate focused native run exits0:32passed/9existing Windows skips/2files. Strict source typing/build0. Supplemental compiler first invocation failsTS5112 before checking the named file; preserved, corrected explicit --ignoreConfig invocation0 without source/config change.

Exactly one observed baseline and candidate: qualified29Git budgetRED/native1 with original assertions returned, then23Git budgetGREEN/native0 with original assertions returned. Two npm operations and equal fixture tree retained; direct async children21to15. Case elapsed24070.9895ms/7719.3759ms is descriptive, not a speedup/statistical/causal claim. No original Vitest case result inferred from the cost controls.

## Next steps and blockers

One complete serial local suite with original case deadlines and adequate outer budget. No reviewers/inference/install/audit/samplers alongside it; preserve all literal outcomes. Then fresh source/security/integrated/publication review, actual exact-head CI/Self/live guard, canonical/postmerge/closing remote gates. Full suite has not run on this candidate yet. Prior FAIL12/1599.021s and Task024 provenance/selector limitations remain; E00/release BLOCKED. No paid service/dependency/cloud/global config/UA-P07/admission/policy waiver/release authority. Raw controls/fixtures retained.
'''
(repo / 'STATE.md').write_bytes(state.encode())
for name in ['specs/027-native-clean-state-observation/spec.md', 'specs/027-native-clean-state-observation/tasks.md']:
    path = repo / name
    text = path.read_text()
    text = '\n'.join(('Status: bounded repair8b3493b implemented; baseline29Git RED and candidate23Git GREEN, typing/build/focused native controls complete. Full local suite/source/security/final review/CI/Self/governance/canonical/remote gates pending; E00/release BLOCKED.' if line.startswith('Status:') else line) for line in text.splitlines()) + '\n'
    text += '\nCurrent controls: qualification/native-clean-state/2026-10-26/local-controls.json preserves actual native/inner/budget outcomes. Prior prospective and pre-execution statements remain historical. No release or historical-cause claim.\n'
    path.write_bytes(text.encode())
path = repo / 'ROADMAP.md'
text = path.read_text().replace('prospective gates/user authority complete; concrete control review clear; new native baseline and benchmark repair pending;', 'bounded repair8b3493b; qualified29Git RED/23Git GREEN, typing/build/focused controls verified; full-suite/review/CI/canonical/remote gates pending;')
path.write_bytes(text.encode())
print(json.dumps({'baseline_git': 29, 'candidate_git': 23, 'native_focused': '32pass9existing_skips', 'full_suite': 'PLANNED_NOT_EXECUTED'}))
