"""Bind all once-only fixture diagnostics without promoting failures."""
from pathlib import Path
import datetime,hashlib,json,subprocess

root=Path(__file__).resolve().parent
repo=root.parent/'engineering/main-control'
sha=lambda value:hashlib.sha256(value).hexdigest()
names=['routing-negative','native-init-negative','native-init-reporter-correction','seven-case-diagnostic']
captures=[]
for name in names:
    paths=list((root.parent/'engineering/runs').glob('clean-state-'+name+'-*.json'));assert len(paths)==1
    path=paths[0]; data=json.loads(path.read_text())
    assert data['state']=='EXECUTED' and data['source_unchanged'] and not data['source_start']['status']
    for stream in ['stdout','stderr']:
        assert sha((path.parent/data[stream]).read_bytes())==data[stream+'_sha256']
    captures.append({'name':name,'file':path.name,'sha256':sha(path.read_bytes()),'exit':data['exit'],
      'wall_seconds':data['wall_seconds'],'source_head':data['source_start']['head'],
      'stdout_sha256':data['stdout_sha256'],'stderr_sha256':data['stderr_sha256']})
assert [x['exit'] for x in captures]==[0,1,0,1]
control_records=[]
for path in sorted((root/'clean-state-routing-output').glob('*.json')):
    data=json.loads(path.read_text())
    control_records.append({'file':path.name,'sha256':sha(path.read_bytes()),'driver_sha256':data['driver_sha256'],
       'mode':data['mode'],'child_exit':data['child_exit'],'counts':data['runner_counts'],
       'qualification':data['qualification'],'retained_identity_verified':data['retained_identity_verified']})
last=json.loads(next((root.parent/'engineering/runs').glob('clean-state-seven-case-diagnostic-*.json')).read_text())
stdout=(root.parent/'engineering/runs'/last['stdout']).read_text()
stderr=(root.parent/'engineering/runs'/last['stderr']).read_text()
assert '1 failed | 6 passed (7)' in stdout and 'AssertionError: expected false to be true' in stderr
assert stderr.count('ASCOUT_T027_RETAINED_FAILED_FIXTURE ')==2
manual=Path('C:/Program Files/Git/ucrt64/share/doc/git-doc/git-config.html')
record={'schema_version':1,'recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'captures':captures,'controls':control_records,
 'positive_followup':{'native_exit':1,'passed':6,'failed':1,'total':7,
  'failure':'New explicit status-row assertion false in untracked-only submodule case, before reconstruct is invoked. Both owned roots retained with bounded metadata. No timeout or native Git initialization error repeated in this run.',
  'diagnosis':'Fixture explicitly sets diff.ignoreSubmodules=untracked; that configuration hides nested untracked status here, so the newly added row assertion did not establish the intended ambiguity. Installed Git manual documents git diff default untracked handling when unset. Correct the new positive fixture to exercise native defaults and keep both native diff0 and a real status row as independent assertions; retain explicit untracked-ignore configuration in the tracked-edit rejection case. This is a fixture setup correction, not removal/weakening of its assertion.'},
 'reference':{'source':'installed Git2.56.0.windows.3 git-config manual','file':'git-config.html','sha256':sha(manual.read_bytes()),
  'reference_url':'https://git-scm.com/docs/git-config','retrieval':'Installed local manual read; remote URL not fetched; no raw full manual published.'},
 'limits':'Original full-suite repository-recognition cause remains unknown and its filesystem was discarded by the original fixture. Positive diagnostic FAIL is retained; negative-control qualification does not erase it or original full FAIL6 plus hook. No additional cost control, routing retry, deadline/config/global state/production change, phase/merge/release approval.'}
(root/'clean-state-diagnostic-results.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
(repo/'qualification/native-clean-state/2026-10-26/diagnostic-results.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
print(json.dumps({'native_exits':[x['exit'] for x in captures],'positive':'FAIL1/6PASS','preserved':True}))
