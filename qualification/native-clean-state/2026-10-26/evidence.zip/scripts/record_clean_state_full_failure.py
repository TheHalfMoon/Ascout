"""Preserve actual complete-suite failure before any diagnosis or forward fix."""
import datetime, hashlib, json, pathlib

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
path = root.parent / 'engineering/runs/clean-state-full-suite-f006f8f7-f9ff-4047-87ef-8f677055f337.json'
capture = json.loads(path.read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
assert capture['state'] == 'EXECUTED' and capture['exit'] == 1 and capture['source_unchanged']
assert capture['source_start']['head'] == '1a8e2a49292f99ab64dd201708787e32886c5efb'
streams = {}
for name in ['stdout', 'stderr']:
    data = (path.parent / capture[name]).read_bytes()
    assert sha(data) == capture[name + '_sha256']
    streams[name] = data.decode('utf-8')
assert '6 failed | 2429 passed | 34 skipped (2469)' in streams['stdout']
assert '5 failed | 241 passed (246)' in streams['stdout']
assert 'Hook timed out in 10000ms' in streams['stderr']
assert 'fatal: --local can only be used inside a git repository' in streams['stderr']
assert 'GitIdentityError: unable to read Git index for tree digest' in streams['stderr']
failed_root = pathlib.Path(r'<USERPROFILE>/AppData/Local/Temp/ascout-t027-2IyRH3')
record = {'recorded_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'capture': path.name, 'capture_sha256': sha(path.read_bytes()), 'source_head': capture['source_start']['head'],
    'source_tree': capture['source_start']['head_tree'], 'native_exit': 1, 'state': 'EXECUTED',
    'wall_seconds': capture['wall_seconds'], 'source_unchanged': True,
    'stdout_sha256': capture['stdout_sha256'], 'stderr_sha256': capture['stderr_sha256'],
    'summary': {'passed_tests': 2429, 'failed_tests': 6, 'existing_skips': 34, 'total_tests': 2469, 'passed_files': 241, 'failed_files': 5, 'total_files': 246, 'additional_failed_suite_hook': 1},
    'failures': [
        {'file': 'tests/vitest-check.integration.test.ts', 'case': 'publishes resolved branch evidence and makes a branch-only miss exit 4', 'diagnostic': 'Test timed out in 15000ms'},
        {'file': 'tests/jest-check.integration.test.ts', 'case': 'runs project-local findRelatedTests and binds JSON plus LCOV while remaining fail-closed before widening/exercise', 'diagnostic': 'Test timed out in 90000ms'},
        {'file': 'tests/jest-check.integration.test.ts', 'case': 'keeps optional branch fields absent when LCOV has genuine line-only coverage', 'diagnostic': 'Test timed out in 15000ms'},
        {'file': 'tests/conservative-selection-data.native.test.ts', 'case': 'catches a seeded data failure with full native execution and an observed full runCheck pass', 'diagnostic': 'GitIdentityError: unable to read Git index for tree digest'},
        {'file': 'tests/self-verify-clean-state.native.test.ts', 'case': 'retains native diff treatment of a submodule containing only untracked files', 'diagnostic': 'Fixture git config --local commit.gpgSign false failed: fatal: --local can only be used inside a git repository'},
        {'file': 'tests/browser-text-assertion.integration.test.ts', 'case': 'fails an in-flight assertion on disposal and refuses reuse', 'diagnostic': 'Test timed out in 5000ms'}
    ],
    'hook': {'file': 'tests/browser-text-assertion.integration.test.ts', 'phase': 'afterAll runtime disposal', 'diagnostic': 'Hook timed out in 10000ms'},
    'new_control_stage': {'failure_site': 'fixture() config initialization, before reconstruct(subject) is invoked in that case', 'failed_root_exists_at_explicit_readback': failed_root.exists(), 'failed_git_directory_exists_at_explicit_readback': (failed_root / '.git').exists(), 'forensic_contents': 'UNAVAILABLE: root no longer present; original new-test afterEach was configured to remove owned fixtures. No deletion actor or environmental cause inferred from absence.'},
    'notice': 'Literal complete local FAIL, not a truncated capture or qualified whole-suite success. No failure/skip/deadline change or repeat-to-green. New fixture failure remains owned by Task027 and blocks its qualification; earlier focused passes and structural23Git metric do not erase it. Source flow locates its failure before the changed benchmark function is invoked in that case, without exonerating all candidate contributions or explaining filesystem/native Git behavior. Other failures and browser hook remain unresolved. Historical FAIL12 and provenance/selector debt retained. Raw captures preserved; no new cleanup. E00/release BLOCKED.'}
destination = repo / 'qualification/native-clean-state/2026-10-26/first-full-suite.json'
assert not destination.exists()
destination.write_bytes((json.dumps(record, indent=2) + '\n').encode())
(root / 'clean-state-first-full-suite.json').write_bytes((json.dumps(record, indent=2) + '\n').encode())
state = '''Last updated: 2026-10-27 Asia/Riyadh · Branch: ps/rea-clean-state-observation

## Current state

Canonical main36768f4 after CLOSED_CANONICAL Task026/PR648 and verified final55976e3 remote proof. Task027 prospective gates/authority/control review complete; bounded benchmark8b3493b SHA151eb52a and new native regression file are implemented. All433other entries/15controls and existing tests/deadlines/config/authority frozen. Source branch was pushed at1a8e2a4 before the complete run.

## Actual qualification

Qualified native invocation-budget baseline29Git RED and candidate23Git GREEN, two original npm operations and positive assertions retained. New native baseline7passed; focused candidate32passed/9existing skips. Canonical typing/build0; supplemental first compiler invocationTS5112 retained and corrected explicit invocation0. No statistical speedup or historical-cause claim.

Complete serial local suite f006f8f7 at1a8e2a4 genuinely FAILED: native1/1955.9508359s,2429passed/6failed/34existing skips/2469cases/246files,5failed files plus browser afterAll hook failure. Source start/end clean and equal; both stream hashes verified. Failures: Vitest15s, Jest90s/15s, runtime-data Git-index error, NEW submodule-fixture Git repository-recognition error, browser disposal5s and teardown10s. See qualification/native-clean-state/2026-10-26/first-full-suite.json. No source mutation or parallel reviewers/inference/audits/installs/samplers during the run.

## Next steps and blockers

Own the new fixture failure: it occurred during native fixture config initialization before that case invoked the changed benchmark API. Its root is no longer present at exact-path readback, and no filesystem contents were retained by the original new-test cleanup. Preserve the full FAIL and diagnose without guessing a host cause, skipping/relabeling or retrying to green. Correct any demonstrated fixture/evidence defect, then run only justified affected checks. Fixed cost baseline/candidate are already consumed; do not repeat them merely for green.

Fresh source/native-boundary security, integrated/publication reviews, actual final-head CI/Self/live governance/canonical/postmerge/closing remote gates remain. No PR or merge yet. Earlier FAIL12 and provenance/selector limitations remain; E00/release BLOCKED. No paid service/dependency/cloud/global config/UA-P07/admission/policy waiver or release authority. Raw captures and supported owned artifacts retained; no unlocated cleanup.
'''
(repo / 'STATE.md').write_bytes(state.encode())
for name in ['specs/027-native-clean-state-observation/spec.md', 'specs/027-native-clean-state-observation/tasks.md']:
    path = repo / name
    text = path.read_text()
    text = '\n'.join(('Status: complete candidate suite FAIL1/1955.951s:2429passed/6failed/34existing skips/2469cases, plus browser hook failure. Own new fixture failure remains unresolved despite earlier focused/budget passes. Source/review/CI/governance/canonical/remote gates pending; E00/release BLOCKED.' if line.startswith('Status:') else line) for line in text.splitlines()) + '\n'
    text += '\nActual complete-suite update: qualification/native-clean-state/2026-10-26/first-full-suite.json preserves all six test failures and additional hook failure; no qualified whole-suite success or historical-cause claim.\n'
    path.write_bytes(text.encode())
path = repo / 'ROADMAP.md'
text = path.read_text().replace('bounded repair8b3493b; qualified29Git RED/23Git GREEN, typing/build/focused controls verified; full-suite/review/CI/canonical/remote gates pending;', 'bounded repair8b3493b;29Git RED/23Git GREEN; complete localFAIL6plus hook/1955.951s retained, own new fixture failure unresolved; review/CI/canonical/remote gates pending;')
path.write_bytes(text.encode())
print(json.dumps({'full_native_exit': 1, 'passed': 2429, 'failed': 6, 'skipped': 34, 'hook_failures': 1, 'failed_fixture_exists': failed_root.exists()}))
