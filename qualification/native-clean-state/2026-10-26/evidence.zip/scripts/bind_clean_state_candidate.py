"""Preserve qualified baseline RED and bind exact candidate inputs before one observation."""
import datetime, hashlib, json, pathlib, subprocess

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
sha = lambda data: hashlib.sha256(data).hexdigest()
baseline = json.loads((root / 'clean-state-baseline.json').read_text())
assert subprocess.check_output(['rtk', 'proxy', 'git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == '8b3493b088abf004773ea03b0ed20fe6162b707e'
assert not subprocess.check_output(['rtk', 'proxy', 'git', 'status', '--porcelain'], cwd=repo).strip()
entries = {}
for entry in subprocess.check_output(['rtk', 'proxy', 'git', 'ls-tree', '-r', '-z', 'HEAD', '--', 'src', 'tests', 'benchmarks'], cwd=repo).split(b'\0'):
    if entry:
        metadata, path = entry.split(b'\t', 1)
        entries[path.decode()] = metadata.decode()
target = 'benchmarks/self-verify.mjs'
added = 'tests/self-verify-clean-state.native.test.ts'
assert set(entries) == set(baseline['baseline_git_entries']) | {added}
assert all(entries[name] == metadata for name, metadata in baseline['baseline_git_entries'].items() if name != target)
for name, expected in baseline['bindings'].items():
    if name != target:
        assert sha((repo / name).read_bytes()) == expected
assert sha((root / 'clean_state_probe.mjs').read_bytes()) == '1ad5e1ffb73963c7f96e00ca4d6e4814a38a4f91256ed22aa1c7eda696e6ca08'
benchmark_hash = sha((repo / target).read_bytes())
assert benchmark_hash == '151eb52a59ee68674b3f4000c47ee6e5282ac573ed8d872d0909a5498ce188ad'
captures = {}
names = ['clean-state-native-baseline', 'clean-state-cost-baseline', 'clean-state-typecheck', 'clean-state-build', 'clean-state-test-types', 'clean-state-test-types-explicit-config', 'clean-state-focused-native']
for name in names:
    paths = list((root.parent / 'engineering/runs').glob(name + '-*.json'))
    if name == 'clean-state-test-types':
        paths = [path for path in paths if '-explicit-config-' not in path.name]
    assert len(paths) == 1, name
    path = paths[0]
    capture = json.loads(path.read_text())
    assert capture['state'] == 'EXECUTED' and capture['source_unchanged']
    assert capture['exit'] == (1 if name in ['clean-state-cost-baseline', 'clean-state-test-types'] else 0)
    for stream in ['stdout', 'stderr']:
        assert sha((path.parent / capture[stream]).read_bytes()) == capture[stream + '_sha256']
    captures[name] = {'file': path.name, 'sha256': sha(path.read_bytes()), 'exit': capture['exit'], 'wall_seconds': capture['wall_seconds'], 'source_head': capture['source_start']['head']}
records = list((root / 'clean-state-output').glob('clean-state-baseline-*.json'))
assert len(records) == 1
observation = json.loads(records[0].read_text())
assert observation['diagnostic_result'] == 'INDEPENDENT_POSITIVE_ASSERTIONS_RETURNED' and not observation['errors']
assert observation['invocation_budget']['inputs_and_original_outcomes_qualified'] and observation['invocation_budget']['status'] == 'FAIL'
assert observation['invocation_budget']['total_git_invocations'] == 29 and observation['invocation_budget']['npm_invocations'] == 2
assert not list((root.parent / 'engineering/runs').glob('clean-state-cost-candidate-*.json'))
assert not list((root / 'clean-state-output').glob('clean-state-candidate-*.json'))
record = {'recorded_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'implementation_head': '8b3493b088abf004773ea03b0ed20fe6162b707e', 'implementation_tree': '8889ca2a49cb1f1abfbe9467dcb748263438aa97',
    'benchmark_sha256': benchmark_hash, 'driver_sha256': '1ad5e1ffb73963c7f96e00ca4d6e4814a38a4f91256ed22aa1c7eda696e6ca08',
    'original_fixture_source_sha256': baseline['bindings']['tests/t107-self-verification-harness.contract.test.ts'],
    'new_test_sha256': sha((repo / added).read_bytes()), 'other_existing_entries_unchanged': 433, 'other_control_hashes_unchanged': 15,
    'completed_captures': captures, 'baseline_observation': {'file': records[0].name, 'sha256': sha(records[0].read_bytes()), 'budget': observation['invocation_budget'], 'case_wall_ms': observation['case_wall_ms']},
    'candidate_state': 'EXACT_INPUTS_BOUND_NOT_EXECUTED',
    'notice': 'All actual outcomes preserved before one candidate observation. Baseline qualified29Git budget FAIL/native1 is structural RED with original assertions returned; not original VitestFAIL. Seven new baseline cases native0 and candidate focused32pass9existing skips native0; strict source typing/build0. First supplemental compiler command native1/TS5112 before file checking retained; separate corrected explicit --ignoreConfig invocation0, no config/source relaxation. Existing source/test/deadline/authority scope remains. Timings are descriptive, not speedup/statistical/historical cause. Candidate, complete local suite and later review/CI/governance/canonical/remote gates pending; E00/release BLOCKED.'}
destination = repo / 'qualification/native-clean-state/2026-10-26/candidate-input-lock.json'
assert not destination.exists()
destination.write_bytes((json.dumps(record, indent=2) + '\n').encode())
(root / 'clean-state-pre-candidate.json').write_bytes((json.dumps(record, indent=2) + '\n').encode())
print(json.dumps({'implementation': record['implementation_head'], 'candidate_benchmark': benchmark_hash, 'baseline_git': 29, 'candidate': record['candidate_state']}))
