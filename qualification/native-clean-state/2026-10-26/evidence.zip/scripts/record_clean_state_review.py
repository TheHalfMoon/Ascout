"""Reconcile current control review before native execution; input hashes unchanged."""
import hashlib, json, pathlib

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
path = repo / 'qualification/native-clean-state/2026-10-26/probe-source-lock.json'
value = json.loads(path.read_text())
assert hashlib.sha256((root / 'clean_state_probe.mjs').read_bytes()).hexdigest() == value['driver_sha256']
review = root / 'clean-state-control-review-895f8ea.json'
assert hashlib.sha256(review.read_bytes()).hexdigest() == '7e2a27412d022917743497682c5efa62c9a0ea29e8cb34420dcffcd95b5b5f59'
assert value['review_state'] == 'FRESH_CONCRETE_CONTROL_AND_FIXTURE_REVIEW_PENDING_BEFORE_EXECUTION'
value.update(review_state='FRESH_CONCRETE_CONTROL_FAITHFULNESS_CLEAR_BEFORE_EXECUTION',
    reviewed_head='895f8ea03660feb11177f5444f82f3c4c2cf50c6',
    review_original_sha256='7e2a27412d022917743497682c5efa62c9a0ea29e8cb34420dcffcd95b5b5f59')
path.write_bytes((json.dumps(value, indent=2) + '\n').encode())
state = '''Last updated: 2026-10-26 Asia/Riyadh · Branch: ps/rea-clean-state-observation

## Current state

Canonical main36768f4 after focused CLOSED_CANONICAL Task026/PR648; finalized closing reviews and actual final108member three-core-file/seven-sidecar remote proof55976e3 verified before this task. All434 existing entries and16controls remain unchanged. Task027 final PLAN_CLEAR89c65d0, different CONSISTENCY_CLEAR64f2e49 and bounded user-derived authoritye05dc58 preceded the new test/driver. Concrete control/fixture review at895f8ea is clear before native execution.

## In flight

Seven native public-API regression cases and one adapted supported own-process observer are bound. Existing tests/deadlines/config/authority and benchmark implementation remain unchanged. Exactly one observed baseline and one candidate cost control are planned around the genuine source change; target<=23Git and two original npm invocations, not an elapsed-time or original Vitest result. Native submodule/path/index/error equivalence remains an implementation proof obligation.

## Next steps

Run the new native baseline cases, then the one reviewed observed budget baseline serially without reviewers/inference/install/audit/sampler work. Preserve actual outcomes and qualified budget RED independently of original assertion return. Only then make the bounded benchmark repair, semantic controls and one fixed candidate observation. Strict typing/build, one complete unchanged-budget serial suite, fresh source/security/integrated/publication reviews and actual CI/Self/liveguard/canonical/closing remote gates remain.

## Blockers / open issues

Prior complete local FAIL12/1599.021s remains unexplained; Task024 provenance gaps and selector comparison unavailability remain. E00/release BLOCKED. No statistical speedup, observer-overhead or historical causation claim. No paid service, new dependency/cloud runtime, global configuration, unsupported REA/OS capture, UA-P07, changed-surface admission, policy waiver or release authority. Existing raw captures/fixtures retained.
'''
(repo / 'STATE.md').write_bytes(state.encode())
path = repo / 'ROADMAP.md'
text = path.read_text().replace('prospective plan only; final audit/different consistency/authority pending before tests/driver/source; every integrity checkpoint and existing deadline frozen;', 'prospective gates/user authority complete; concrete control review clear; new native baseline and benchmark repair pending; every integrity checkpoint and existing deadline frozen;')
path.write_bytes(text.encode())
