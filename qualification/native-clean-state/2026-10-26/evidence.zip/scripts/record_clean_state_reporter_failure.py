"""Preserve an actual diagnostic capture defect before correcting its reporter."""
from pathlib import Path
import hashlib,json,shutil

root=Path(__file__).resolve().parents[2]
external=root/'work/rc-repair'
repo=root/'work/engineering/main-control'
sha=lambda b:hashlib.sha256(b).hexdigest()
controller=external/'clean_state_routing_control.mjs'
original=controller.read_bytes()
assert sha(original)=='16bf3f8d3ad334c52877b7fcd3f4f4f463ecaa2d291a4ca131168fad01d7c7e9'
archive=external/'clean_state_routing_control_16bf3f8.mjs'
if archive.exists():assert archive.read_bytes()==original
else:archive.write_bytes(original)
records=[]
for name in ['routing-negative','native-init-negative']:
    files=list((root/'work/engineering/runs').glob('clean-state-'+name+'-*.json'))
    assert len(files)==1
    capture=json.loads(files[0].read_text())
    assert capture['source_unchanged'] and capture['source_start']['status']==''
    for stream in ['stdout','stderr']:
        assert sha((files[0].parent/capture[stream]).read_bytes())==capture[stream+'_sha256']
    records.append({'capture_file':files[0].name,'capture_sha256':sha(files[0].read_bytes()),
      'source_head':capture['source_start']['head'],'native_controller_exit':capture['exit'],
      'wall_seconds':capture['wall_seconds'],'stdout_sha256':capture['stdout_sha256'],
      'stderr_sha256':capture['stderr_sha256']})
controls=[]
for mode in ['routing','native-init-failure']:
    files=list((external/'clean-state-routing-output').glob(mode+'-*.json'));assert len(files)==1
    data=json.loads(files[0].read_text())
    controls.append({'mode':mode,'record_file':files[0].name,'record_sha256':sha(files[0].read_bytes()),
      'qualification':data['qualification'],'child_exit':data['child_exit'],'runner_counts':data['runner_counts'],
      'sentinel_unchanged':data['sentinel_unchanged'],'native_failure_diagnostics_count':len(data['native_failure_diagnostics']),
      'retained_manifests_count':len(data['retained_manifests'])})
assert controls[0]['qualification']=='EXPECTED_ROUTING_REJECTION_AND_SENTINEL_INTEGRITY_OBSERVED'
assert controls[1]['qualification']=='UNQUALIFIED'
assert controls[1]['child_exit']==1
reporter=repo/'node_modules/vitest/dist/chunks/index.UpGiHP7g.js'
record={'schema_version':1,'state':'ACTUAL_SECOND_CONTROL_UNQUALIFIED_REPORTER_EVIDENCE_MISSING',
 'original_controller_sha256':sha(original),'captures':records,'controls':controls,
 'installed_reporter_source_sha256':sha(reporter.read_bytes()),
 'evidence':'Vitest4.1.12 JSON reporter emits assertion errors and counts but has no console-log reporting callback. The actual child failed on the intended unknown hash algorithm, but its console failure metadata and retention manifest were absent from both captured streams and the JSON assertion report. Read-only exact-root inspection observed the named failed fixture still present; that later observation cannot replace missing failure-time ownership proof.',
 'next_scope':'Preserve this literal native controller1/child1 UNQUALIFIED result and exact16bf3f8 source. Change only the external driver to add the built-in default reporter alongside JSON. After concrete delta review and a recorded input lock, allow exactly one corrected native-init-failure evidence run, then the originally planned seven-case diagnostic followup if qualified. Do not repeat the already qualified routing control or either fixed cost observation. No test/deadline/config/environment changes.',
 'limits':'No original error reproduction, root-cause resolution, full-suite success, phase/release or governance approval. All raw captures and owned artifacts retained.'}
(external/'clean-state-reporter-failure.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
(repo/'qualification/native-clean-state/2026-10-26/reporter-failure.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
updated=original.replace(b"'--reporter=json', '--outputFile='",b"'--reporter=default', '--reporter=json', '--outputFile='")
assert updated!=original
controller.write_bytes(updated)
print(json.dumps({'preserved_controller_sha256':sha(original),'corrected_controller_sha256':sha(updated),'record_sha256':sha((external/'clean-state-reporter-failure.json').read_bytes())}))
