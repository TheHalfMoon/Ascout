import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { createHash, randomUUID } from 'node:crypto';
import { closeSync, fstatSync, lstatSync, mkdirSync, mkdtempSync, openSync, readFileSync, readdirSync, readSync, realpathSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const [mode, repositoryArgument] = process.argv.slice(2);
assert(['routing', 'native-init-failure'].includes(mode));
assert(repositoryArgument);
const repository = resolve(repositoryArgument);
const sha = value => createHash('sha256').update(value).digest('hex');
const driver = fileURLToPath(import.meta.url);
const driverHash = sha(readFileSync(driver));
const test = join(repository, 'tests/self-verify-clean-state.native.test.ts');
const benchmark = join(repository, 'benchmarks/self-verify.mjs');
const testHash = '3647548270f21db4dd97eff3c690c23693f21ca6e6302358c4886ffa670c1cb9';
const benchmarkHash = '151eb52a59ee68674b3f4000c47ee6e5282ac573ed8d872d0909a5498ce188ad';
assert.equal(sha(readFileSync(test)), testHash);
assert.equal(sha(readFileSync(benchmark)), benchmarkHash);
assert.equal(process.env.GIT_DIR, undefined);
const owner = randomUUID();
const root = mkdtempSync(join(tmpdir(), 'ascout-t027-routing-'));
const victim = join(root, 'redirected-git');
mkdirSync(victim);
writeFileSync(join(root, '.owner.json'), JSON.stringify({ owner }), { flag: 'wx' });
writeFileSync(join(victim, 'keep.txt'), owner, { flag: 'wx' });
const initial = lstatSync(victim);
const initialLeaf = lstatSync(join(victim, 'keep.txt'));
const canonical = realpathSync(victim);
const destination = join(dirname(driver), 'clean-state-routing-output');
mkdirSync(destination, { recursive: true });
const id = mode + '-' + owner;
const runnerOutput = join(root, 'runner-results.json');
const npmCli = join(dirname(process.execPath), 'node_modules', 'npm', 'bin', 'npm-cli.js');
const argv = [npmCli, 'test', '--', '--maxWorkers=1', 'tests/self-verify-clean-state.native.test.ts',
  '--testNamePattern', 'preserves tracked contamination precedence', '--reporter=json', '--outputFile=' + runnerOutput];
const injection = mode === 'routing' ? { GIT_DIR: victim } : { GIT_DEFAULT_HASH: 'ascout-invalid-hash' };
const child = spawnSync(process.execPath, argv, {
  cwd: repository, env: { ...process.env, ...injection }, timeout: 120000,
  windowsHide: true, encoding: null, maxBuffer: 8 * 1024 * 1024,
});
const stdout = child.stdout ?? Buffer.alloc(0);
const stderr = child.stderr ?? Buffer.alloc(0);
// Forward and persist original child evidence before any fallible inspection.
process.stdout.write(stdout);
process.stderr.write(stderr);
writeFileSync(join(destination, id + '.stdout.txt'), stdout, { flag: 'wx' });
writeFileSync(join(destination, id + '.stderr.txt'), stderr, { flag: 'wx' });
const inspectionErrors = [];
let runner = null;
let parseError = null;
try { runner = JSON.parse(readFileSync(runnerOutput, 'utf8')); }
catch (error) { parseError = String(error?.message ?? error); }
let identityMatches = false;
let entries = null;
let sentinelUnchanged = false;
try {
  const current = lstatSync(victim);
  identityMatches = current.isDirectory() && !current.isSymbolicLink()
    && current.dev === initial.dev && current.ino === initial.ino && realpathSync(victim) === canonical;
  if (identityMatches) {
    entries = readdirSync(victim).slice(0, 32);
    if (JSON.stringify(entries) === JSON.stringify(['keep.txt'])) {
      const leafPath = join(victim, 'keep.txt');
      const leaf = lstatSync(leafPath);
      assert(leaf.isFile() && !leaf.isSymbolicLink() && leaf.dev === initialLeaf.dev && leaf.ino === initialLeaf.ino && leaf.size === initialLeaf.size);
      assert.equal(realpathSync(leafPath), join(canonical, 'keep.txt'));
      const handle = openSync(leafPath, 'r');
      try {
        const opened = fstatSync(handle);
        assert(opened.isFile() && opened.dev === initialLeaf.dev && opened.ino === initialLeaf.ino && opened.size === initialLeaf.size);
        const payload = Buffer.alloc(initialLeaf.size + 1);
        const bytes = readSync(handle, payload, 0, payload.length, 0);
        sentinelUnchanged = bytes === initialLeaf.size && sha(payload.subarray(0, bytes)) === sha(owner);
      } finally { closeSync(handle); }
    }
  }
} catch (error) { inspectionErrors.push({ stage: 'owned_sentinel', code: error?.code ?? null, message: String(error?.message ?? error).slice(0, 512) }); }
const assertions = Array.isArray(runner?.testResults)
  ? runner.testResults.flatMap(result => Array.isArray(result?.assertionResults) ? result.assertionResults : []) : [];
const selected = assertions.filter(result => result?.status === 'failed');
const failureMessages = Array.isArray(selected[0]?.failureMessages) ? selected[0].failureMessages.filter(value => typeof value === 'string') : [];
const originalFailure = Boolean(child.status === 1 && child.signal === null && !child.error
  && runner?.numTotalTests === 7 && runner?.numPendingTests === 6
  && runner?.numFailedTests === 1 && runner?.numPassedTests === 0 && selected.length === 1
  && typeof selected[0].fullName === 'string' && selected[0].fullName.includes('preserves tracked contamination precedence')
  && failureMessages.some(message => message.includes(mode === 'routing'
    ? 'fixture_git_routing_environment: GIT_DIR' : 'unknown hash algorithm'))
  && (mode === 'routing' || failureMessages.some(message => message.includes('ascout-invalid-hash'))));
const diagnostic = (tag) => {
  const text = (child.stderr ?? Buffer.alloc(0)).toString('utf8');
  return text.split(/\r?\n/u).filter(line => line.includes(tag)).flatMap(line => {
    try {
      const value = JSON.parse(line.slice(line.indexOf(tag) + tag.length).trim());
      return value !== null && typeof value === 'object' && !Array.isArray(value) ? [value] : [];
    }
    catch { return []; }
  });
};
const nativeFailures = diagnostic('ASCOUT_T027_FIXTURE_GIT_FAILURE');
const retained = diagnostic('ASCOUT_T027_RETAINED_FAILED_FIXTURE');
let retainedIdentityVerified = false;
if (mode === 'native-init-failure' && retained.length === 1) {
  try {
    const owned = retained[0].initial;
    assert.equal(resolve(dirname(owned.root)), resolve(tmpdir()));
    assert.equal(owned.root.startsWith(join(tmpdir(), 'ascout-t027-')), true);
    const stat = lstatSync(owned.root);
    retainedIdentityVerified = stat.isDirectory() && !stat.isSymbolicLink()
      && stat.dev === owned.dev && stat.ino === owned.ino && realpathSync(owned.root) === owned.canonical;
  } catch { retainedIdentityVerified = false; }
}
const expectedDiagnostics = mode === 'routing' ? nativeFailures.length === 0 && retained.length === 0
  : nativeFailures.length === 1 && nativeFailures[0].native_status === 128 && nativeFailures[0].native_signal === null
    && nativeFailures[0].argv?.includes('init') && retainedIdentityVerified;
let endingTestHash = null;
let endingBenchmarkHash = null;
let endingDriverHash = null;
try {
  endingTestHash = sha(readFileSync(test));
  endingBenchmarkHash = sha(readFileSync(benchmark));
  endingDriverHash = sha(readFileSync(driver));
} catch (error) { inspectionErrors.push({ stage: 'ending_sources', code: error?.code ?? null, message: String(error?.message ?? error).slice(0, 512) }); }
const qualified = Boolean(originalFailure && expectedDiagnostics && sentinelUnchanged && inspectionErrors.length === 0
  && endingTestHash === testHash && endingBenchmarkHash === benchmarkHash && endingDriverHash === driverHash);
const record = {
  id, mode, finished_at_utc: new Date().toISOString(), repository, driver_sha256: driverHash, ending_driver_sha256: endingDriverHash,
  test_sha256: testHash, benchmark_sha256: benchmarkHash, ending_test_sha256: endingTestHash, ending_benchmark_sha256: endingBenchmarkHash,
  owned_root: root, owner_uuid: owner, victim, initial: { dev: initial.dev, ino: initial.ino, canonical },
  argv: [process.execPath, ...argv], child_exit: child.status, child_signal: child.signal,
  child_error: child.error ? { code: child.error.code ?? null, message: child.error.message } : null,
  runner_output: runnerOutput, runner_parse_error: parseError,
  runner_counts: runner ? { total: runner.numTotalTests, passed: runner.numPassedTests, failed: runner.numFailedTests, pending: runner.numPendingTests } : null,
  selected_failures: selected, stdout_sha256: sha(stdout), stderr_sha256: sha(stderr),
  stdout_state: child.stdout === null ? 'NOT_OBSERVED' : 'CAPTURED', stderr_state: child.stderr === null ? 'NOT_OBSERVED' : 'CAPTURED',
  inspection_errors: inspectionErrors,
  owned_victim_identity_matches: identityMatches, observed_victim_entries: entries,
  sentinel_unchanged: sentinelUnchanged, expected_original_failure_observed: originalFailure,
  native_failure_diagnostics: nativeFailures, retained_manifests: retained, retained_identity_verified: retainedIdentityVerified,
  qualification: !qualified ? 'UNQUALIFIED' : mode === 'routing'
    ? 'EXPECTED_ROUTING_REJECTION_AND_SENTINEL_INTEGRITY_OBSERVED' : 'NATIVE_INIT_FAILURE_AND_OWNED_RETENTION_OBSERVED',
  retained: true,
  notice: 'Owned adversarial controls only: child-local GIT_DIR rejection before fixture mutation or child-local invalid GIT_DEFAULT_HASH causing a real native Git init failure. One selected test fails, six cases filtered, never passed. Native original error and failure-time metadata/retention remain explicit. This is not reproduction or resolution of the earlier unknown repository-recognition failure, original test PASS, full-suite success or release approval. No retries, existing deadline changes, OS capture, global configuration or unowned repository mutation. Independent child bound120s; original case30s unchanged. All artifacts retained pending remote proof.',
};
writeFileSync(join(destination, id + '.json'), JSON.stringify(record, null, 2) + '\n', { flag: 'wx' });
process.stdout.write(JSON.stringify({ record: join(destination, id + '.json'), child_exit: child.status, qualification: record.qualification, sentinel_unchanged: sentinelUnchanged }) + '\n');
process.exitCode = qualified ? 0 : 1;
