"""Installed Git manual bindings and paraphrases only; no full documentation publication."""
import datetime, hashlib, json, pathlib, subprocess

root = pathlib.Path(__file__).resolve().parent
manual_root = pathlib.Path(subprocess.check_output(['rtk', 'proxy', 'git', '--html-path']).decode().strip())
version = subprocess.check_output(['rtk', 'proxy', 'git', '--version']).decode().strip()
assert version == 'git version 2.56.0.windows.3'
records = []
for name in ['git-status', 'git-diff']:
    path = manual_root / (name + '.html')
    data = path.read_bytes()
    records.append({'installed_manual': str(path), 'official_reference_url': 'https://git-scm.com/docs/' + name,
        'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'access': 'Read installed Git-distributed HTML directly; no network service invoked.'})
text = (manual_root / 'git-status.html').read_text(encoding='utf-8')
assert '_porcelain_format_version_1' in text and 'untracked-files' in text and 'ignore-submodules' in text
record = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'git_version_observation': version,
    'records': records, 'paraphrased_facts': [
        'Porcelain v1 is a stable script-oriented output format describing staged, working-tree and untracked state; untracked entries have the ?? status prefix.',
        'Explicit --untracked-files=all and --ignored=no select all nonignored untracked files while retaining tracked observations.',
        'Porcelain v1 provides stable color/root-relative output semantics; quoted or unusual paths must not be misclassified from filename content.',
        'Submodule changes have native status semantics and may be affected by ignore configuration; equivalence with the existing diff/status checks must be proven rather than inferred from similar names.'
    ], 'notice': 'Read-only reference preparation. Installed manuals bound to actual files shipped with observed Git2.56.0.windows.3, not a claim that web URLs were fetched or that manuals authenticate the executable. Raw full manual pages stay outside publication. Paraphrases do not prove native equivalence, authorize code or certify security/release.'}
path = root / 'clean-state-git-reference.json'
assert not path.exists()
path.write_bytes((json.dumps(record, indent=2) + '\n').encode())
print(json.dumps(record))
