"""Actual Task027 closing core/member readback at an immutable branch revision."""
import pathlib

path=pathlib.Path(__file__).with_name('verify_timing_publication.py')
source=path.read_text(encoding='utf-8').replace('qualification/git-head-query/2026-10-24','qualification/native-clean-state/2026-10-27').replace('timing-publication-receipt-','clean-state-closing-publication-receipt-')
exec(compile(source,str(path),'exec'))
