"""Actual Task027 closing review sidecars and optional readback-record bytes."""
import pathlib

path=pathlib.Path(__file__).with_name('verify_index_closing_sidecars.py')
source=path.read_text(encoding='utf-8').replace('qualification/git-index-observation/2026-10-25-closeout','qualification/native-clean-state/2026-10-27-closeout').replace('index-closing-sidecars-readback-','clean-state-closing-sidecars-readback-')
exec(compile(source,str(path),'exec'))
