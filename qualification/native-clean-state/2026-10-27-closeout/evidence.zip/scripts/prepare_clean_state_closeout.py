"""Record actual Task027 canonical proof; closing gates still required."""
import hashlib,json,pathlib,subprocess

root=pathlib.Path(__file__).resolve().parent
repo=root.parent/'engineering/main-control'
proof=json.loads((root.parent/'engineering/merges/649.json').read_text())
assert proof['head']=='dae521a8b11bef40fe8bfc430d7e098dedfd3f61'
assert proof['tree_equal'] and proof['github_signature_verification']['verified']
def git(*args):return subprocess.check_output(['rtk','proxy','git',*args],cwd=repo)
assert git('rev-parse','HEAD').decode().strip()==proof['merge']
assert not git('status','--porcelain').strip()
final=json.loads((root/('clean-state-ci-'+proof['head'][:7])/'summary.json').read_text())
post=json.loads((root/('clean-state-ci-postmerge-'+proof['merge'][:7])/'summary.json').read_text())
assert all(s['all_actual_jobs_success'] and s['six_actual_native_full_suites_verified'] for s in [final,post])
assert len(final['jobs'])==7 and len(post['jobs'])==6
self_view=json.loads((root/'clean-state-self-inspection.json').read_text())
assert self_view['head']==proof['head'] and self_view['receipt_summary']['exit_code']==1
assert self_view['receipt_summary']['completeness']=='materially_incomplete'
assert self_view['test_task']['status']=='FLAKY'
assert self_view['test_task']['observations']=={'runs':2,'failures':1}
sha=lambda value:hashlib.sha256(value).hexdigest()
baseline=json.loads((root/'clean-state-baseline.json').read_text())
assert all(sha((repo/name).read_bytes())==digest for name,digest in baseline['bindings'].items() if name!='benchmarks/self-verify.mjs')
entries={row.split(b'\t',1)[1].decode():row.split(b'\t',1)[0].decode() for row in git('ls-tree','-r','-z','HEAD','--','src','tests','benchmarks').split(b'\0') if row}
assert set(entries)==set(baseline['baseline_git_entries'])|{'tests/self-verify-clean-state.native.test.ts'}
assert all(entries[name]==value for name,value in baseline['baseline_git_entries'].items() if name!='benchmarks/self-verify.mjs')
prefix='qualification/native-clean-state/2026-10-27-closeout'
report=f'''# Task027 canonical clean-state closeout

Status: MERGED_CANONICAL. Closing correctness/privacy reviews and actual closing remote readback remain pending. E00/release remain BLOCKED; Self inner evidence is adverse and materially incomplete.

[PR649](https://github.com/TheHalfMoon/Ascout/pull/649) merged ordinarily at {proof['merge']}, with ordered parents {', '.join(proof['ordered_parents'])}. Reviewed and merge trees both equal {proof['merge_tree']}; GitHub-reported signature verification is valid. The last-moment guard verified exact head/base/main, seven actual successful workflow checks, no changes-requested review or unresolved thread, and ordinary merge eligibility. No force/admin/admission, UA-P07 or governance waiver. Concurrent branches remained untouched. Initial final-head three-core-file/six-sidecar readback verified all118 members before merge; actual receipts are included here.

The benchmark change avoids two redundant Git diffs at each clean checkpoint while preserving fresh HEAD/index checks, all call sites and reliable native errors. Ambiguous/tracked porcelain rows still use the original staged/unstaged diff decisions before untracked rejection. The fixed controls observed29Git RED versus23Git GREEN, both with2 original npm operations and functional assertions returned. Only structural six-launch reduction is established. No statistical speedup, observer overhead, OS/host cause, historical root cause, hostile-concurrent-writer immunity or identical native-fault ordering is claimed.

All433 other source/test/benchmark entries and15 nontarget control hashes are frozen. Source typecheck/build0 and focused32passed/9existing Windows skips bind unchanged source leaves. The first supplemental TS5112 invocation remains native1 before checking; its corrected invocation passed. The complete local f006f8f7 run remains native1/1955.9508359s:2429passed/6failed/34existing skips/2469tests/246files plus browser afterAll hook failure. Literal failures include Vitest15s, Jest90s/15s, runtime-data Git-index identity error, the new submodule fixture's Git repository-recognition error, browser disposal5s and teardown10s. Candidate contributions are not exonerated. The original new fixture failed before reconstruction; its filesystem was discarded by original cleanup and the native cause remains UNKNOWN.

Forward test-fixture corrections reject inherited Git routing before mutation, bind operations to owned metadata/worktrees, preserve original native exceptions, record bounded lstat metadata and retain failed roots. Routing negative qualified with actual child1/one failed/six filtered and unchanged owned sentinel. First real native-init capture remains controller1/child1 UNQUALIFIED because JSON-only reporting omitted console diagnostics. Corrected default-plus-JSON capture qualified with original Git128/error, metadata and retained ownership. Three adverse unexecuted controller drafts and reviews remain. These intentional child failures are never original-case passes.

The first seven-case diagnostic remains native1/6passed/1failed: explicit diff.ignoreSubmodules=untracked hid the required positive status row. Both owned roots were retained. The fixture correction moves that explicit setting into the tracked-edit negative case; positive native diff0 and actual status-row assertions remain. Final strict typing0 and7passed atb90d14c qualify this setup correction; no old case/deadline/assertion/config/dependency/workflow/authority change or blind full-suite/cost repeat occurred. Index-flag scope is narrow and Windows numeric inode precision remains disclosed. Earlier exact-leaf controls are not represented as running on a later whole tree.

Fresh source/boundary, integrated/publication and final metadata reviews found no scoped must-fix. The actual fresh CI review followed an earlier unavailable review attempt that produced no judgment; no paid fallback or D1 substitution. D1 is advisory only; actual Alibaba local preview/rules are not model review. Graft/TesterArmy/browser implementation is unchanged by Task027, and no fresh unrelated execution is claimed. These OpenAI role-separated reviews share provider lineage and do not constitute provider-independent certification.

Final head {proof['head']} and canonical {proof['merge']} each have six actual complete native hosted suites verified from raw logs: exact source guards/lockfile/Chromium setup/typecheck/test/build,2469 cases across246 files, and the inherited17-file presence inventory. Every platform's actual pass/skip counts and file summaries are retained. This is twelve actual native suites plus one valid shadow workflow capture, not thirteen clean test suites. Postmerge success does not erase local failures or Self's inner result.

**Actual Self inner result: exit1, FLAKY, materially_incomplete.** One installed-Chromium executable contract failed once across its two recorded runs. Its source finding remains introduced_by_change UNKNOWN. The three-JSON artifact has verified advertised digest, CRC and source/tree/base/receipt bindings, but excludes referenced raw testJSON/LCOV/stdout payloads; the original failure message and payload hashes cannot be independently reconstructed from it. Cause remains UNKNOWN. Effective FR-006 through FR-010 accept valid adverse SHADOW_NON_GATING capture; no universal inner-zero merge gate was invented or waived. E00/release qualification remains open. Selector comparison is UNAVAILABLE_FULL_SUITE_CONTRACT, never MATCHED. Current results do not retroactively resolve Task024's63 unresolved provenance lines.

Actual Self inspection:

```json
{json.dumps(self_view,indent=2)}
```

The forward minimized packet preserves all original adverse controls, final/canonical raw logs, actual Self JSON, finalized reviews, merge proof and initial remote receipts, with original/published hashes. Opaque archives, full installed manuals, dependency/cache/browser profiles, private REA expansion, personal quota/account data and credentials are excluded. Homes/emails/personal authors/raw signatures are minimized; this is neither original-source authentication nor universal secret detection. All raw inputs and owned artifacts remain retained. No paid service, new dependency, required cloud runtime, global configuration change, unsupported REA capture, security-phase waiver, UA-P07, release or deployment authority. Focused closure requires finalized closing reviews and actual remote proof before any next-task source mutation.
'''
def write(name,text):
    path=repo/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(text.encode())
write(prefix+'/REPORT.md',report)
write('STATE.md',f'''Last updated: 2026-10-27 Asia/Riyadh · Branch: evidence/native-clean-state-postmerge-20261027

Task027/PR649 MERGED_CANONICAL at{proof['merge']}; exact reviewed/merge tree, parents/signature and twelve actual final/canonical native suites verified. Fixed29Git RED/23Git GREEN with2npm; final fixture7passed.433other entries/15controls frozen. Closing correctness/privacy and actual remote readback remain before focused closure or next-task source mutation.

Self inner exit1/FLAKY/materially incomplete (installed-Chromium contract2runs1failure); valid SHADOW_NON_GATING capture under actual policy, not clean qualification. Original local fullFAIL6plus hook, prior diagnosticFAIL and reporterUNQUALIFIED, unknown original fixture/nativebrowser causes, Task024 provenance and unavailable selector comparison remain. E00/release BLOCKED. No paidfallback, D1 gate, deadline/admission/UA-P07 waiver or raw artifact disposal. Full actual evidence: {prefix}/REPORT.md.
''')
for name in ['specs/027-native-clean-state-observation/spec.md','specs/027-native-clean-state-observation/tasks.md']:
    text=(repo/name).read_text()
    text='\n'.join((f'Status: MERGED_CANONICAL PR649/{proof["merge"]}; twelve actual native suites verified; Self inner1/FLAKY/materially incomplete retained. Closing reviews/remote proof pending; E00/release BLOCKED.' if line.startswith('Status:') else line) for line in text.splitlines())+'\n'
    write(name,text+f'\nCanonical update: PR649 merged ordinarily at{proof["merge"]}; actual shadow failure preserved. Closing reviews/remote proof pending; see {prefix}/REPORT.md.\n')
lines=(repo/'ROADMAP.md').read_text().splitlines()
for i,line in enumerate(lines):
    if '/ Task027-T01 ' in line:
        lines[i]=f'| REA-E00 / Task027-T01 native clean-state observation | MERGED_CANONICAL PR649/main{proof["merge"][:7]}; twelve actual native suites; Self inner1/FLAKY/materially incomplete and localFAIL6plus hook retained; closing reviews/remote proof pending; E00/release BLOCKED | [closeout]({prefix}/REPORT.md) |'
write('ROADMAP.md','\n'.join(lines)+'\n')
path=repo/'docs/qualification/REA-E00-native-timing.md'
write(str(path.relative_to(repo)),path.read_text()+f'\n\nTask027 canonical update: PR649/main{proof["merge"][:7]}, twelve actual native suites verified. Self inner1/FLAKY/materially incomplete, local fullFAIL6plus hook and unknown causes retained. Closing reviews/remote proof pending; E00/release BLOCKED. See [canonical closeout](../../{prefix}/REPORT.md).\n')
print(json.dumps({'merge':proof['merge'],'status':'MERGED_CANONICAL_CLOSING_GATES_PENDING','self_inner_exit':1}))
