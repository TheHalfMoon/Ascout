"""Forward Task027 evidence after verified ordinary merge and canonical suites."""
import ast,hashlib,json,pathlib

root=pathlib.Path(__file__).resolve().parent
producer=root/'publish_clean_state.py'
assert hashlib.sha256(producer.read_bytes()).hexdigest()=='b892a8cd8ee1fe0331839741049b4868ffa71a30f957e5bab3ed2abe109fac0d'
number=json.loads((root/'clean-state-pr-number.json').read_text())['number']
assert number==649
proof=json.loads((root.parent/'engineering/merges'/f'{number}.json').read_text())
assert proof['tree_equal'] and proof['github_signature_verification']['verified']
post=json.loads((root/('clean-state-ci-postmerge-'+proof['merge'][:7])/'summary.json').read_text())
assert post['head']==proof['merge'] and post['all_actual_jobs_success'] and post['six_actual_native_full_suites_verified'] and len(post['jobs'])==6
source=producer.read_text(encoding='utf-8').replace("destination=repo/'qualification/native-clean-state/2026-10-26'","destination=repo/'qualification/native-clean-state/2026-10-27-closeout'")
assert source!=producer.read_text(encoding='utf-8')
tree=ast.parse(source)
extra=ast.parse('''
for directory in sorted(path for path in root.glob('clean-state-ci-*') if path.is_dir()):
    for path in sorted(directory.iterdir()):
        if path.suffix in ['.json','.log','.txt']:
            add('ci/'+directory.name+'/'+path.name,path)
for path in sorted(root.glob('clean-state-*.json')):
    if any(token in path.name for token in ['integrated-review-','publication-review-','final-delta-','publication-receipt-','sidecars-readback-','self-inspection','frontier-premerge','frontier-resume-','frontier-postmerge','pr-number','ci-review-','final-pr-review-observation']):
        add('final/'+path.name,path)
for suffix in ['.json','-premerge.json']:
    add('merges/'+str(number)+suffix,root.parent/'engineering/merges'/(str(number)+suffix))
for name in ['publish_clean_state_closeout.py','prepare_clean_state_closeout.py','clean_state_review_sidecars.py','publish_clean_state_final_review.py','verify_clean_state_sidecars.py','verify_index_closing_sidecars.py','verify_clean_state_closing_publication.py','verify_clean_state_closing_sidecars.py','inspect_clean_state_self.py','capture_clean_state_pr_reviews.py','capture_packaging_pr_reviews.py','premerge_clean_state.py','premerge_timing.py']:
    add('scripts/'+name,root/name)
add('scripts/record_merge.py',root.parent/'engineering/record_merge.py')
''').body
for index,node in enumerate(tree.body):
    if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='manifest' for t in node.targets):
        tree.body[index:index]=extra
        break
else:raise AssertionError('Manifest assignment missing')
ast.fix_missing_locations(tree)
exec(compile(tree,str(producer),'exec'))
