"""Actual Task027 reviews, threads and automated-provider limitations."""
import pathlib

path=pathlib.Path(__file__).with_name('capture_packaging_pr_reviews.py')
source=path.read_text(encoding='utf-8').replace("'647'","'649'").replace('number:647','number:649')
source=source.replace('31e9c88c55cd3d9043ff37096cfd9926d6691063','dae521a8b11bef40fe8bfc430d7e098dedfd3f61').replace('fe3064afabb18cffbc1d5a8e7f0b5396be7b28c2','36768f4ffe1e2c18492cb3a8fdccd9274c2c615a')
source=source.replace('packaging-final-pr-review-observation.json','clean-state-final-pr-review-observation.json')
exec(compile(source,str(path),'exec'))
