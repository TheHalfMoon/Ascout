"""Compare frozen pre-CI and actual final premerge governance/frontier observations."""
import hashlib, json, pathlib

root = pathlib.Path(__file__).resolve().parent
before_path = root / 'index-frontier-before-ci.json'
after_path = root / 'index-frontier-premerge.json'
before, after = json.loads(before_path.read_text()), json.loads(after_path.read_text())
governing = ['main', 'main_tree', 'main_protected', 'protection_query_exit', 'protection_message', 'rulesets', 'issue618', 'governing_file_sha256']
assert all(before[key] == after[key] for key in governing)
old_prs = {item['number']: item for item in before['open_prs']}
new_prs = {item['number']: item for item in after['open_prs']}
def refs(value):
    return {line.split()[1]: line.split()[0] for line in value['remote_head_refs']}
old_refs, new_refs = refs(before), refs(after)
record = {'main': after['main'], 'governing_facts_unchanged': governing, 'added_prs': sorted(new_prs.keys() - old_prs.keys()), 'removed_prs': sorted(old_prs.keys() - new_prs.keys()), 'changed_existing_prs': [number for number in old_prs.keys() & new_prs.keys() if old_prs[number] != new_prs[number]], 'added_refs': sorted(new_refs.keys() - old_refs.keys()), 'removed_refs': sorted(old_refs.keys() - new_refs.keys()), 'changed_refs': {name: {'before': old_refs[name], 'after': new_refs[name]} for name in old_refs.keys() & new_refs.keys() if old_refs[name] != new_refs[name]}, 'before_sha256': hashlib.sha256(before_path.read_bytes()).hexdigest(), 'premerge_sha256': hashlib.sha256(after_path.read_bytes()).hexdigest(), 'notice': 'Point-in-time read-only comparison, no authority grant. Executor must inspect concurrent changes for relevant overlap and separately verify actual final head/base/checks/reviews/threads/mergeability. Absent protection does not waive governance.'}
(root / 'index-frontier-merge-comparison.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps(record))
