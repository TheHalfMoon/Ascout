"""Read-only final CI qualification checks; writes this judge's report only."""
import datetime, hashlib, json, pathlib, re, subprocess, zipfile

ROOT = pathlib.Path(__file__).resolve().parent
REPO = ROOT.parent / 'engineering/main-control'
CI = ROOT / 'index-ci-5e8ad93'
HEAD = '5e8ad936fad4d1c8db0068cada9d64d6ba480d98'
BASE = '62e588adda04dda1a517742fe10af352e5dfa83f'
SOURCE = 'a6baed464db522962e8d4e2e08ae6cb0fd24cd1b'
sha = lambda b: hashlib.sha256(b).hexdigest()
load = lambda p: json.loads(p.read_bytes())

def git(*args):
    return subprocess.check_output(['rtk', 'proxy', 'git', '-C', str(REPO), *args])

def api(endpoint):
    return json.loads(subprocess.check_output(['rtk', 'proxy', 'gh', 'api', endpoint]))

assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert git('status', '--porcelain=v1') == b''
tree = git('rev-parse', HEAD + '^{tree}').decode().strip()
assert tree == '725de8c34aa34f01a5e121641c6960f7406fb481'
paths = git('diff', '--name-only', BASE, HEAD).decode().splitlines()
assert all(p in {'src/git.ts', 'tests/git-index-observation.test.ts', 'ROADMAP.md', 'STATE.md', 'docs/qualification/REA-E00-index.md'} or p.startswith(('specs/023-git-index-observation/', 'qualification/git-index-observation/')) for p in paths)
assert git('diff', SOURCE, HEAD, '--', 'src', 'tests', 'package.json', 'package-lock.json', '.github', '.specify', 'CONTRIBUTING.md') == b''
assert git('diff', '--name-only', BASE, HEAD, '--', 'tests').decode().splitlines() == ['tests/git-index-observation.test.ts']
assert git('diff', BASE, HEAD, '--', 'package.json', 'package-lock.json', '.github', '.specify', 'CONTRIBUTING.md', 'vitest.config.ts', 'tsconfig.json') == b''

summary = load(CI / 'summary.json')
assert (summary['head'], summary['tree'], summary['base']) == (HEAD, tree, BASE)
jobs_checked = []
for run_id, expected_count in [(40189086978, 6), (40189086992, 1)]:
    run = load(CI / f'run-{run_id}.json')
    assert run['head_sha'] == HEAD and run['event'] == 'pull_request' and run['status'] == 'completed' and run['conclusion'] == 'success'
    jobs = load(CI / f'jobs-{run_id}.json')
    assert jobs['total_count'] == len(jobs['jobs']) == expected_count
    for job in jobs['jobs']:
        item = next(x for x in summary['jobs'] if x['id'] == job['id'])
        raw = (CI / item['log']).read_bytes()
        assert sha(raw) == item['sha256'] and len(raw) == item['bytes']
        text = re.sub(chr(27) + r'\[[0-?]*[ -/]*[@-~]', '', raw.decode())
        steps = {s['name']: s['conclusion'] for s in job['steps']}
        assert all(steps.get(k) == 'success' for k in item['required_steps'])
        assert job['conclusion'] == 'success' and item['exact_source_guard_verified']
        assert ('EXPECTED_SHA: ' if expected_count == 6 else 'PR_HEAD_SHA: ') + HEAD in text
        if expected_count == 6:
            assert re.search(r'Tests\s+\d+ passed[^\r\n]*\(2450\)', text)
            assert re.search(r'Test Files[^\r\n]*\(244\)', text)
            assert all(s in text for s in ['git-index-observation.test.ts', 'vitest run', '> tsc -p tsconfig.json --noEmit', '> tsc -p tsconfig.json'])
            assert ('npm test -- --maxWorkers=1' if 'windows' in job['name'] else 'Run npm test') in text
        jobs_checked.append({'id': job['id'], 'name': job['name'], 'log_sha256': sha(raw), 'actual_native_summaries': item['native_summaries']})

artifact = next(a for a in load(CI / 'self-artifacts.json')['artifacts'] if a['id'] == 12597607878)
raw = (CI / 'self-artifact-12597607878.zip').read_bytes()
assert sha(raw) == '71041fbd21d4a798863d2e6bf515e7f1105976aa9d218bd863266619fe8e160e'
assert artifact['digest'] == 'sha256:' + sha(raw) and not artifact['expired']
self_log = (CI / 'job-121156038671.log').read_text()
assert 'SHA256 digest of uploaded artifact is ' + sha(raw) in self_log
with zipfile.ZipFile(CI / 'self-artifact-12597607878.zip') as z:
    assert set(z.namelist()) == {'self-verification-envelope.json', 'self-verification-receipt.json', 'selector-shadow-observation.json'}
    assert len(z.namelist()) == 3 and z.testzip() is None
    assert all(z.read(n) == (CI / n).read_bytes() for n in z.namelist())
envelope = load(CI / 'self-verification-envelope.json')
receipt = load(CI / 'self-verification-receipt.json')
selector = load(CI / 'selector-shadow-observation.json')
assert envelope['verifier_head_sha'] == envelope['subject_target_head_sha'] == HEAD
assert envelope['verifier_head_tree_sha'] == envelope['subject_target_tree_sha'] == tree
assert envelope['event_base_tip_sha'] == envelope['subject_merge_base_sha'] == BASE
assert envelope['receipt_sha256'] == sha((CI / 'self-verification-receipt.json').read_bytes())
assert receipt['source']['start'] == receipt['source']['end']
assert receipt['source']['start']['head_sha'] == BASE
assert receipt['summary']['exit_code'] == envelope['receipt_exit_code'] == 1
assert receipt['summary']['completeness'] == 'complete'
test = next(t for t in receipt['tasks'] if t['task_id'] == 'test')
assert test['status'] == 'FAIL' and test['observations'] == {'runs': 3, 'failures': 3}
assert all(t['execution_admission'] == 'normal' and not t['command_surface_changed'] for t in receipt['tasks'])
assert next(t for t in receipt['tasks'] if t['task_id'] == 'typecheck')['status'] == 'PASS'
assert len(receipt['findings']) == 1 and receipt['findings'][0]['path'] == 'tests/npm-package-content.test.ts'
assert receipt['findings'][0]['introduced_by_change'] == 'unknown'
assert selector['comparison']['reason_code'] == 'UNAVAILABLE_FULL_SUITE_CONTRACT' and not selector['comparison']['available']
assert selector['source']['subject_target_head_sha'] == HEAD and selector['source']['receipt_sha256'] == envelope['receipt_sha256']
evidence_ids = {e['evidence_id'] for e in receipt['evidence']}
assert all(e in evidence_ids for t in receipt['tasks'] for e in t['evidence_ids'])
assert all(e in evidence_ids for f in receipt['findings'] for e in f['evidence_ids'])

native = load(next((ROOT.parent / 'engineering/runs').glob('index-repair-full-suite-*.json')))
assert native['exit'] == 1 and native['source_unchanged']
assert native['source_start']['head'] == native['source_end']['head'] == SOURCE
for stream in ('stdout', 'stderr'):
    data = (ROOT.parent / 'engineering/runs' / native[stream]).read_bytes()
    assert sha(data) == native[stream + '_sha256']

prior = load(ROOT / 'index-final-integration-5e8ad93.json')
assert sha((ROOT / 'index-final-integration-5e8ad93.json').read_bytes()) == 'd322e8981e0ccf29cbb548f72e76163121403fef8fd0adbb9c8937ecebc2bb93'
assert prior['findings']['must_fix'] == []
main = api('repos/TheHalfMoon/Ascout/branches/main')
pr = api('repos/TheHalfMoon/Ascout/pulls/645')
reviews = api('repos/TheHalfMoon/Ascout/pulls/645/reviews')
rulesets = api('repos/TheHalfMoon/Ascout/rulesets')
issue = api('repos/TheHalfMoon/Ascout/issues/618')
assert main['commit']['sha'] == pr['base']['sha'] == BASE and pr['head']['sha'] == HEAD

report = {
    'schema_version': 1, 'task': 'Task023-T01', 'review_kind': 'fresh exact-final-head focused CI and qualification gate judgment',
    'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head': HEAD, 'tree': tree, 'base': BASE,
    'verdict': 'NO_ACTIONABLE_FOCUSED_CI_FINDINGS_REMAINING_CANONICAL_GATES_REQUIRED',
    'findings': {'must_fix': [], 'worth_considering': [], 'skip_it': []},
    'checks': [
        'Exact immutable clean head/tree and bounded 19-path scope verified. Product/new test match qualified a6baed4 byte-for-byte; every existing test/deadline, dependency/lock, workflow, authority and configuration is frozen.',
        'Independently checked original run metadata, seven jobs/required successful steps, original log bytes/hashes, source guards, actual compiler/build/test commands, all six 2450-case/244-file full summaries and new25-case file execution. These are actual runs, not an aggregate green-status inference.',
        'Independently checked original Self ZIP digest against artifact metadata and upload log, exact three members/CRC/local extraction equality, head/tree/base/receipt/selector bindings and resolvable receipt evidence references.',
        'Read actual native local full FAIL payload and verified original stdout/stderr hashes and unchanged a6baed4 source bindings. Hosted passes do not erase that failure.',
        'Read prospective task/spec/plan/constitution/CONTRIBUTING and finalized fresh source/security/integration/publication reconciliation. No demonstrated in-scope regression identified; neither historical causality nor candidate contribution is established.',
        'CI reader preparation assertion failure and forward repair are retained. Revised wrapper changes only task namespace/count/new test requirement of frozen reader; no product, tests, workflow, remote execution or result was changed.'
    ],
    'actual_hosted_jobs': jobs_checked,
    'self': {'classification': envelope['classification'], 'artifact_id': 12597607878, 'zip_sha256': sha(raw), 'inner_exit': 1, 'completeness': 'complete', 'typecheck': 'PASS', 'test': 'FAIL', 'test_observations': test['observations'], 'finding': receipt['findings'][0]['rule_or_test_id'], 'introduced_by_change': 'unknown', 'selector': 'UNAVAILABLE_FULL_SUITE_CONTRACT', 'source_note': 'Verifier and target are exact5e8ad93. Self harness materializes target working state against base62; stable receipt source HEAD remains base by design. This is not evidence from a baseline-only product run.', 'limitations': 'The bounded three-member artifact does not retain the packaging exception or referenced raw test-result/output bodies. Prior direct-Vitest npm_execpath context does not prove this historical failure cause. Green workflow proves shadow capture integrity, not a passing inner receipt.'},
    'local_full': {'native_exit': 1, 'seconds': 772.9023288999451, 'passed': 2415, 'failed': 1, 'existing_skips': 34, 'cases': 2450, 'files': 244, 'failure': 'T103 invalid_taken deadline15000ms; reported22242ms', 'status': 'FAIL', 'causality': 'unknown; no assertion result or candidate exoneration inferred'},
    'focused_contract_judgment': 'Task023 prospectively requires running and preserving the complete native control and repairing/blocking on a demonstrated in-scope regression. It does not replace E00 final passing-local-suite qualification. The bounded source/query change, fresh reviews, native comparisons and six actual hosted suites identify no demonstrated new regression. Unknown timeout/packaging causality remains unknown and explicitly owned debt. This judgment grants no merge or release approval.',
    'live_observation': {'main': main['commit']['sha'], 'pr_head': pr['head']['sha'], 'pr_base': pr['base']['sha'], 'pr_state': pr['state'], 'draft': pr['draft'], 'submitted_reviews': len(reviews), 'main_protected': main['protected'], 'rulesets_count': len(rulesets), 'issue618_state': issue['state'], 'issue618_updated_at': issue['updated_at'], 'threads': 'Separate direct live GraphQL read observed totalCount0, no next page, at exact5e8ad93/base62. No unresolved inline threads observed.', 'policy': 'Issue618 scopes UA-P06 section16; this task changes native Git metadata and is outside UA-P06. No universal Claude/provider/age gate invented. Absent protection/rulesets is not a governance waiver.'},
    'remaining_gates': [
        'Executor must recheck current exact head/main/base, effective governance, all submitted reviews/threads/checks and ordinary guarded eligibility. PR was draft at this review; no merge approval is given.',
        'An eligible ordinary head-matched merge still requires canonical ordered-parent/tree/signature/main/PR-state proof and all six actual postmerge suites.',
        'Sanitized closing evidence plus fresh closing reviews and actual remote core/review-sidecar byte/hash readback remain required before focused canonical close, next-task mutation or disposable cleanup.',
        'E00 and release remain BLOCKED until an actual passing final complete local suite and all applicable integrated qualification; current inner Self failure and unavailable selector remain visible.'
    ],
    'merge_approval': False, 'release_approval': False, 'e00_release_state': 'BLOCKED', 'gate_waivers': [],
    'limitations': ['Fresh scoped context shares OpenAI provider/model lineage; this is not provider independence or D1/security certification.', 'Reviewer performed read-only Git/GitHub/file inspection and hash/CRC/JSON checks only. No product tests, inference, installs, remote writes, repository mutations, UA-P07 authority or changed-command-surface admission.', 'Prior source/security/publication reviewers retain their exact scopes. This judge checked already downloaded original CI bytes; did not independently download all logs/ZIP again. Live PR/main/reviews/rulesets/issue were queried directly.', 'Referenced raw Self bodies are absent from bounded artifact, so schema-resolvable IDs do not assert independent availability of those raw bodies.', 'First reviewer verification script assumed nested native stream metadata and stopped with TypeError before any report write; corrected to actual filename plus stream_sha256 fields. This was an inspection error, not a product execution or changed qualification result.']
}
out = ROOT / 'index-ci-review-5e8ad93.json'
out.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'report': out.name, 'sha256': sha(out.read_bytes()), 'verdict': report['verdict']}))
