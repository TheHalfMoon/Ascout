"""Reuse the frozen Task023 producer, adding canonical/CI/reproduction evidence."""
import ast, hashlib, json, pathlib, sys

root = pathlib.Path(__file__).resolve().parent
producer = root / 'publish_index.py'
assert hashlib.sha256(producer.read_bytes()).hexdigest() == 'b745fd167fdc881a855f37e5a2ddc3c5a8b12010c1811ee2cd0fc69bc67f9924'
assert sys.argv[1:] == []
number = json.loads((root / 'index-pr-number.json').read_text())['number']
proof = json.loads((root.parent / 'engineering/merges' / (str(number) + '.json')).read_text())
postmerge = json.loads((root / ('index-ci-postmerge-' + proof['merge'][:7]) / 'summary.json').read_text())
assert proof['tree_equal'] and proof['github_signature_verification']['verified']
assert postmerge['head'] == proof['merge'] and postmerge['all_actual_jobs_success'] and postmerge['six_actual_native_full_suites_verified']
assert len(postmerge['jobs']) == 6
source = ast.parse(producer.read_text(encoding='utf-8'))
for node in source.body:
    if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'scripts' for target in node.targets):
        assert isinstance(node.value, ast.List)
        node.value.elts.extend(ast.Constant(name) for name in ['publish_index_closeout.py', 'index_review_sidecars.py', 'verify_index_sidecars.py', 'index-baseline-module.mjs', 'inspect_index_self.py', 'inspect_dependency_self.py', 'compare_index_frontier.py', 'review_index_final_ci.py'])
        break
else:
    raise AssertionError('Frozen producer scripts declaration not found')
ast.fix_missing_locations(source)
sys.argv = [str(producer), '--close']
exec(compile(source, str(producer), 'exec'))
