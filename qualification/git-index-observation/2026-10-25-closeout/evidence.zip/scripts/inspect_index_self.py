"""Inspect the completed exact-head Self artifact without implying native CI passed."""
import pathlib

path = pathlib.Path(__file__).with_name('inspect_dependency_self.py')
source = path.read_text(encoding='utf-8').replace('dependency-self-', 'index-ci-self-only-').replace('TASK022_ACTUAL_', 'TASK023_ACTUAL_')
exec(compile(source, str(path), 'exec'))
