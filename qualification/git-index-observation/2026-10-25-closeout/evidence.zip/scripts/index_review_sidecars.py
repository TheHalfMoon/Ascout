"""Publish completed Task023 review derivatives without rewriting the frozen ZIP."""
import ast, hashlib, json, pathlib, re

root = pathlib.Path(__file__).resolve().parent
destination = root.parent / 'engineering/main-control/qualification/git-index-observation/2026-10-25'
producer = root / 'publish_dependencies.py'
assert hashlib.sha256(producer.read_bytes()).hexdigest() == '87d1e9597dc89e9727821808a7790089d50b4574c012aa1f30f6a9f8770b32d1'
module = ast.parse(producer.read_text())
functions = [node for node in module.body if isinstance(node, ast.FunctionDef) and node.name in ['minimize', 'sanitize', 'add']]
members, records = {}, []
sha = lambda data: hashlib.sha256(data).hexdigest()
exec(compile(ast.Module(body=functions, type_ignores=[]), str(producer), 'exec'))
for name, expected in [('index-final-integration-97dc5ee.json', 'ebc3656849c078f1541c4eec091d1962be3b976520401fe32c8808a5d98a3c88'), ('index-publication-review-97dc5ee.json', 'b719b53c079a4d5ac80bc7834e989288bc69e20d97f3f4e18528a5e28a945ebc')]:
    source = root / name
    assert sha(source.read_bytes()) == expected
    add(name, source)
for name, data in members.items():
    (destination / name).write_bytes(data)
(destination / 'review-manifest.json').write_text(json.dumps({'reviewed_head': '97dc5ee069091f855682d71ad7fcb968cdf7aaaf', 'records': records, 'notice': 'Finalized fresh context review observations; shared OpenAI lineage. No merge approval, release readiness or gate waiver. Frozen81-member ZIP unchanged.'}, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'sidecars': len(members), 'records': records}))
