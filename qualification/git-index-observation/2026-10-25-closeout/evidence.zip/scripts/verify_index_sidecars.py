"""Verify actual remote completed-review bytes at a bound Task023 branch head."""
import base64, datetime, hashlib, json, pathlib, subprocess, sys

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
head, branch = sys.argv[1:]
prefix = 'qualification/git-index-observation/2026-10-25'
def get(path):
    return json.loads(subprocess.check_output(['rtk', 'proxy', 'gh', 'api', 'repos/TheHalfMoon/Ascout/' + path]))
assert get('commits/' + branch)['sha'] == head
records = []
manifest = json.loads((repo / prefix / 'review-manifest.json').read_text())
for name in ['review-manifest.json'] + [item['path'] for item in manifest['records']]:
    assert pathlib.PurePosixPath(name).name == name and name.endswith('.json')
    item = get('contents/' + prefix + '/' + name + '?ref=' + head)
    remote = base64.b64decode(item['content'])
    assert remote == (repo / prefix / name).read_bytes()
    json.loads(remote)
    digest = hashlib.sha256(remote).hexdigest()
    if name != 'review-manifest.json':
        expected = next(value for value in manifest['records'] if value['path'] == name)
        assert digest == expected['published_sha256'] and len(remote) == expected['bytes']
    records.append({'path': name, 'git_blob': item['sha'], 'sha256': digest, 'bytes': len(remote)})
result = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head': head, 'branch': branch, 'prefix': prefix, 'remote_ref_and_all_sidecar_bytes_verified': True, 'records': records, 'notice': 'Review evidence durability only; no security certification, merge approval or release readiness.'}
(root / ('index-sidecars-readback-' + head[:7] + '.json')).write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result))
