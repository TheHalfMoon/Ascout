"""Prepare an owned, ignored canonical build for paired public-API diagnostics."""
import datetime, hashlib, io, json, pathlib, subprocess, tarfile, uuid

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
base = '62e588adda04dda1a517742fe10af352e5dfa83f'
owner = str(uuid.uuid4())
destination = repo / '.ascout' / ('index-baseline-' + owner)
destination.mkdir(parents=True, exist_ok=False)
assert destination.resolve().parent == (repo / '.ascout').resolve() and not destination.is_symlink()
archive = subprocess.check_output(['rtk', 'proxy', 'git', 'archive', base, 'src', 'package.json', 'tsconfig.json'], cwd=repo)
records = []
with tarfile.open(fileobj=io.BytesIO(archive)) as source:
    for entry in source.getmembers():
        relative = pathlib.PurePosixPath(entry.name)
        assert not relative.is_absolute() and '..' not in relative.parts and '\\' not in entry.name and ':' not in entry.name
        target = destination.joinpath(*relative.parts)
        assert target.resolve().is_relative_to(destination.resolve())
        if entry.isdir():
            target.mkdir(parents=True, exist_ok=True)
        else:
            assert entry.isfile()
            data = source.extractfile(entry).read()
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            records.append({'path': entry.name, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)})
(destination / '.ascout-owned-diagnostic-baseline').write_text(owner)
result = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'base': base, 'owner': owner, 'destination': str(destination), 'archive_sha256': hashlib.sha256(archive).hexdigest(), 'files': records, 'notice': 'Own canonical source copied by Git archive into an owned ignored .ascout artifact directory, no symlink/dependency installation or production/test mutation. Native compiler uses existing ancestor node_modules. Diagnostic only; no qualifying suite/release result or historical-cause proof. No disposable deletion before remote evidence verification.'}
(root / 'index-diagnostic-baseline.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
print(json.dumps({'base': base, 'destination': str(destination), 'files': len(records), 'archive_sha256': result['archive_sha256']}))
