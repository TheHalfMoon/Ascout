// Paired public runCheck diagnostic; synthetic runner, not native-suite qualification.
import childProcess from 'node:child_process';
import { syncBuiltinESMExports } from 'node:module';
import { createHash, randomUUID } from 'node:crypto';
import { mkdirSync, mkdtempSync, readFileSync, realpathSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { basename, dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = dirname(fileURLToPath(import.meta.url));
const repo = realpathSync(process.argv[2]);
const baseline = JSON.parse(readFileSync(join(root, 'index-diagnostic-baseline.json')));
const hash = value => createHash('sha256').update(value).digest('hex');
for (const record of baseline.files) {
  if (hash(readFileSync(join(baseline.destination, record.path))) !== record.sha256) throw new Error('Baseline source changed');
}
const frozen = JSON.parse(readFileSync(join(root, 'index-baseline-bindings.json')));
if (hash(readFileSync(join(baseline.destination, 'dist/git.js'))) !== frozen.baseline_module_sha256) throw new Error('Canonical compiled Git does not match frozen baseline');
const original = childProcess.spawnSync;
function git(cwd, argv) {
  const result = original('git', argv, { cwd, encoding: 'utf8', shell: false, timeout: 10000, windowsHide: true });
  if (result.error || result.status !== 0) throw new Error('Diagnostic Git failed: ' + argv[0]);
  return result.stdout.trim();
}
const source = { head: git(repo, ['rev-parse', 'HEAD']), candidate_git_sha256: hash(readFileSync(join(repo, 'dist/git.js'))), candidate_check_sha256: hash(readFileSync(join(repo, 'dist/check.js'))), baseline_git_sha256: frozen.baseline_module_sha256, baseline_check_sha256: hash(readFileSync(join(baseline.destination, 'dist/check.js'))) };
const fixture = mkdtempSync(join(realpathSync(tmpdir()), 'ascout-index-t103-diagnostic-'));
if (dirname(realpathSync(fixture)) !== realpathSync(tmpdir()) || realpathSync(fixture) !== resolve(fixture) || !basename(fixture).startsWith('ascout-index-t103-diagnostic-')) throw new Error('Unexpected fixture containment');
const { writePackageNodeCommandShim } = await import(pathToFileURL(join(repo, 'tests/helpers/native-command-shim.ts')).href);
const setupStart = performance.now();
for (const path of ['src', 'node_modules/vitest', 'node_modules/@vitest/coverage-v8', 'node_modules/fake-vitest']) mkdirSync(join(fixture, path), { recursive: true });
writeFileSync(join(fixture, '.gitignore'), '.ascout/\nnode_modules/\n');
writeFileSync(join(fixture, 'package.json'), JSON.stringify({ name: 't103-vitest-invalid_taken', private: true, type: 'module', devDependencies: { vitest: '4.1.10', '@vitest/coverage-v8': '4.1.10' } }));
for (const name of ['vitest', '@vitest/coverage-v8']) writeFileSync(join(fixture, 'node_modules', name, 'package.json'), JSON.stringify({ name, version: '4.1.10' }));
const lcov = 'SF:src/used.js\nDA:1,1\nBRDA:1,0,0,invalid\nend_of_record\n';
const runner = [
  'import { mkdirSync, writeFileSync } from "node:fs";',
  'import { dirname } from "node:path";',
  'const output = process.argv.find((arg) => arg.startsWith("--outputFile="))?.slice("--outputFile=".length);',
  'const coverageDir = process.argv.find((arg) => arg.startsWith("--coverage.reportsDirectory="))?.slice("--coverage.reportsDirectory=".length);',
  'if (!output || !coverageDir) process.exit(64);',
  'mkdirSync(dirname(output), { recursive: true });',
  'mkdirSync(coverageDir, { recursive: true });',
  'writeFileSync(output, JSON.stringify({ numTotalTests: 1, testResults: [] }));',
  `writeFileSync(coverageDir + "/lcov.info", ${JSON.stringify(lcov)});`,
].join('\n');
writeFileSync(join(fixture, 'node_modules/fake-vitest/index.mjs'), runner + '\n');
writePackageNodeCommandShim(join(fixture, 'node_modules/.bin'), 'vitest', '../fake-vitest/index.mjs');
writeFileSync(join(fixture, 'src/used.js'), 'export function used() { return 2; }\n');
for (const args of [['init', '-q'], ['config', 'user.name', 'Ascout T103 Fixture'], ['config', 'user.email', 't103@example.invalid'], ['add', '.'], ['commit', '-qm', 'baseline']]) git(fixture, args);
writeFileSync(join(fixture, 'src/used.js'), 'export function used() { return 1 + 1; }\n');
const setupMs = performance.now() - setupStart;
const owner = randomUUID();
writeFileSync(join(fixture, '.git/ascout-owned-t103-diagnostic'), owner);
let commands = null;
childProcess.spawnSync = function(file, argv, options) {
  const start = performance.now();
  const result = original(file, argv, options);
  if (commands && file === 'git') commands.push({ argv: [...argv], milliseconds: performance.now() - start, status: result.status, error: result.error?.name ?? null });
  return result;
};
syncBuiltinESMExports();
const checks = {
  baseline: (await import(pathToFileURL(join(baseline.destination, 'dist/check.js')).href)).runCheck,
  candidate: (await import(pathToFileURL(join(repo, 'dist/check.js')).href)).runCheck,
};
const samples = [];
try {
  for (const [label, runCheck] of Object.entries(checks)) {
    commands = [];
    const start = performance.now();
    const outcome = await runCheck(fixture);
    const milliseconds = performance.now() - start;
    const receipt = outcome.receipt;
    const test = receipt.tasks.find(task => task.task_type === 'test');
    if (test?.status !== 'ERROR' || test.reason_code !== 'vitest_evidence_invalid' || receipt.summary.exit_code !== 2 || receipt.summary.completeness !== 'unknown_due_to_error' || receipt.exercise.branch_records !== undefined) throw new Error('Controlled invalid branch refusal changed');
    samples.push({ label, milliseconds, git_launches: commands.length, git_milliseconds: commands.reduce((sum, command) => sum + command.milliseconds, 0), commands, task: { status: test.status, reason_code: test.reason_code, execution_admission: test.execution_admission }, summary: receipt.summary, source_start: receipt.source_start, source_end: receipt.source_end, receipt });
    commands = null;
  }
} finally {
  childProcess.spawnSync = original;
  syncBuiltinESMExports();
}
if (source.head !== git(repo, ['rev-parse', 'HEAD']) || source.candidate_git_sha256 !== hash(readFileSync(join(repo, 'dist/git.js'))) || source.candidate_check_sha256 !== hash(readFileSync(join(repo, 'dist/check.js')))) throw new Error('Candidate source changed');
const result = { observed_at_utc: new Date().toISOString(), source, baseline_subject: baseline.base, fixture, owner, setup_milliseconds: setupMs, helper_sha256: hash(readFileSync(fileURLToPath(import.meta.url))), fixture_helper_sha256: hash(readFileSync(join(repo, 'tests/helpers/native-command-shim.ts'))), samples, limitations: 'Two serial public runCheck executions on one controlled T103-shaped fixture using a synthetic Vitest metadata/runner, no dependencies installed. Node built-in TypeScript stripping loads the existing unchanged fixture helper. Canonical baseline sources/build are owned ignored diagnostic artifacts; runtime dependencies resolve to the existing physical ancestor install. Git counts observe public spawnSync calls, not all OS descendants. No admission flag, source/test/deadline mutation, unsupported process capture or REA safety bypass. Setup is measured once; cleanup is deliberately not executed, so these are not original 15-second test-case timings. Cache/order/OS activity and exact historical cause are not isolated. Full nativeFAIL remains FAIL, no test/release PASS or causal exoneration. Owned artifacts retained pending verified remote publication.' };
writeFileSync(join(root, 'index-runcheck-comparison.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ source, setup_milliseconds: setupMs, samples: samples.map(({ label, milliseconds, git_launches, git_milliseconds, task, summary }) => ({ label, milliseconds, git_launches, git_milliseconds, task, summary })) }));
