"""Download actual Task023 public files and verify every archive member."""
import pathlib

path = pathlib.Path(__file__).with_name('verify_timing_publication.py')
source = path.read_text(encoding='utf-8').replace('qualification/git-head-query/', 'qualification/git-index-observation/').replace('2026-10-24', '2026-10-25').replace('timing-publication-receipt-', 'index-publication-receipt-').replace('Task021', 'Task023')
exec(compile(source, str(path), 'exec'))
