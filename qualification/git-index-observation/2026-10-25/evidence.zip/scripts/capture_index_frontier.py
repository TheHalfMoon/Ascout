"""Separate Task023 read-only live frontier snapshots."""
import pathlib

path = pathlib.Path(__file__).with_name('capture_timing_frontier.py')
source = path.read_text(encoding='utf-8').replace('timing-frontier-', 'index-frontier-').replace('Task021', 'Task023')
exec(compile(source, str(path), 'exec'))
