// Same-fixture baseline/candidate diagnostic through public Node/Git APIs only.
import childProcess from 'node:child_process';
import { syncBuiltinESMExports } from 'node:module';
import { createHash, randomUUID } from 'node:crypto';
import { mkdirSync, mkdtempSync, readFileSync, realpathSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { basename, dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = dirname(fileURLToPath(import.meta.url));
const repo = realpathSync(process.argv[2]);
const baseline = join(root, 'index-baseline-module.mjs');
const candidate = join(repo, 'dist/git.js');
const hash = value => createHash('sha256').update(value).digest('hex');
const binding = JSON.parse(readFileSync(join(root, 'index-baseline-bindings.json')));
if (hash(readFileSync(baseline)) !== binding.baseline_module_sha256) throw new Error('Baseline module changed');
const original = childProcess.spawnSync;
const setupEnv = { ...process.env, GIT_CONFIG_GLOBAL: '/dev/null', GIT_CONFIG_SYSTEM: '/dev/null', GIT_TERMINAL_PROMPT: '0', GIT_AUTHOR_DATE: '2026-10-25T00:00:00Z', GIT_COMMITTER_DATE: '2026-10-25T00:00:00Z' };
function git(cwd, argv) {
  const result = original('git', argv, { cwd, env: setupEnv, encoding: 'utf8', shell: false, windowsHide: true, timeout: 10000 });
  if (result.error || result.status !== 0) throw new Error('Diagnostic setup Git failed: ' + argv[0]);
  return result.stdout.trim();
}
const source = { head: git(repo, ['rev-parse', 'HEAD']), source_sha256: hash(readFileSync(join(repo, 'src/git.ts'))), candidate_module_sha256: hash(readFileSync(candidate)), baseline_module_sha256: hash(readFileSync(baseline)) };
const fixture = mkdtempSync(join(realpathSync(tmpdir()), 'ascout-index-benchmark-'));
if (dirname(realpathSync(fixture)) !== realpathSync(tmpdir()) || realpathSync(fixture) !== resolve(fixture) || !basename(fixture).startsWith('ascout-index-benchmark-')) throw new Error('Unexpected fixture containment');
git(fixture, ['init', '-q', '--initial-branch=main', '--object-format=sha1']);
for (const [key, value] of [['user.name', 'Ascout Test'], ['user.email', 'fixture.invalid'], ['commit.gpgSign', 'false'], ['core.autocrlf', 'false']]) git(fixture, ['config', key, value]);
for (const key of ['core.attributesFile', 'core.excludesFile']) {
  const path = join(fixture, '.git', key.replace('.', '-'));
  writeFileSync(path, '');
  git(fixture, ['config', key, path]);
}
const hooks = join(fixture, '.git', 'empty-hooks');
mkdirSync(hooks);
git(fixture, ['config', 'core.hooksPath', hooks]);
writeFileSync(join(fixture, 'tracked.txt'), 'base\n');
git(fixture, ['add', '--all']);
git(fixture, ['commit', '-q', '-m', 'base']);
const owner = randomUUID();
writeFileSync(join(fixture, '.git', 'ascout-owned-index-benchmark'), owner);
let commands = null;
childProcess.spawnSync = function(file, argv, options) {
  const start = performance.now();
  const result = original(file, argv, options);
  if (commands && file === 'git') commands.push({ argv: [...argv], milliseconds: performance.now() - start, status: result.status, error: result.error?.name ?? null });
  return result;
};
syncBuiltinESMExports();
const readers = {
  baseline: (await import(pathToFileURL(baseline).href)).readTreeDigestV1,
  candidate: (await import(pathToFileURL(candidate).href)).readTreeDigestV1,
};
const samples = [];
try {
  for (const modified of [false, true]) {
    if (modified) writeFileSync(join(fixture, 'tracked.txt'), 'changed\n');
    for (const [label, read] of Object.entries(readers)) {
      for (let iteration = 0; iteration < 5; iteration++) {
        commands = [];
        const start = performance.now();
        const output = read(fixture);
        const milliseconds = performance.now() - start;
        if (output.tracked_index_entry_count !== 1 || output.unstaged_changed_count !== Number(modified) || output.included_untracked_count !== 0) throw new Error('Unexpected native fixture semantics');
        samples.push({ label, modified, iteration, milliseconds, git_launches: commands.length, output, commands });
        commands = null;
      }
    }
  }
} finally {
  childProcess.spawnSync = original;
  syncBuiltinESMExports();
}
for (const modified of [false, true]) {
  const selected = samples.filter(sample => sample.modified === modified);
  if (new Set(selected.map(sample => JSON.stringify(sample.output))).size !== 1) throw new Error('Baseline/candidate native output mismatch');
  for (const sample of selected) {
    const expected = sample.label === 'baseline' ? (modified ? 14 : 12) : (modified ? 12 : 10);
    if (sample.git_launches !== expected || sample.commands.some(command => command.status !== 0 || command.error)) throw new Error('Unexpected actual native query budget/result');
  }
}
if (source.head !== git(repo, ['rev-parse', 'HEAD']) || source.source_sha256 !== hash(readFileSync(join(repo, 'src/git.ts'))) || source.candidate_module_sha256 !== hash(readFileSync(candidate))) throw new Error('Source/module changed during diagnostic');
const summary = Object.keys(readers).map(label => ({ label, reads: samples.filter(sample => sample.label === label).length, git_launches: samples.filter(sample => sample.label === label).reduce((sum, sample) => sum + sample.git_launches, 0), milliseconds: samples.filter(sample => sample.label === label).reduce((sum, sample) => sum + sample.milliseconds, 0) }));
const result = { observed_at_utc: new Date().toISOString(), source, helper_sha256: hash(readFileSync(fileURLToPath(import.meta.url))), fixture, owner, fixture_head: git(fixture, ['rev-parse', 'HEAD']), outputs_equal: true, summary, samples, limitations: 'Instrumented public Node spawnSync/syncBuiltinESMExports diagnostic only; no OS process capture or REA safety bypass. Counts are native Git launch invocations through the existing runner, not all OS descendants. Same controlled fixture and exact output, five reads per module/state; serial order/cache/OS activity may affect latency. No claim of isolated historical cause, native-suite PASS, security certification or release readiness. Owned fixture retained pending remote evidence verification and contained cleanup.' };
writeFileSync(join(root, 'index-native-comparison.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ source, outputs_equal: true, summary }));
