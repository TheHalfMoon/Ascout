"""Read-only source/module bindings before Task023 source implementation."""
import datetime, hashlib, json, pathlib, subprocess

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
sha = lambda value: hashlib.sha256(value).hexdigest()
def git(*args):
    return subprocess.check_output(['rtk', 'proxy', 'git', *args], cwd=repo)
base = '62e588adda04dda1a517742fe10af352e5dfa83f'
names = ['src/git.ts', 'package.json', 'package-lock.json', 'tests/git-tree-digest.test.ts', 'tests/drift.contract.test.ts', 'tests/git-identity.test.ts', 'tests/cli-contract.test.ts', 'tests/t107-self-verification-harness.contract.test.ts']
tracked = set(git('ls-files', '-z').decode().split('\0'))
names = [name for name in names if name in tracked]
records = []
for name in names:
    native = git('show', base + ':' + name)
    assert native == (repo / name).read_bytes()
    records.append({'path': name, 'sha256': sha(native), 'bytes': len(native)})
module = (repo / 'dist/git.js').read_bytes()
target = root / 'index-baseline-module.mjs'
assert not target.exists()
target.write_bytes(module)
result = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'base': base, 'planning_head': git('rev-parse', 'HEAD').decode().strip(), 'source_bindings': records, 'baseline_module': target.name, 'baseline_module_sha256': sha(module), 'baseline_module_notice': 'Existing native build from dependency source4384867; src/git.ts and package/lock bytes match current canonical base62e588a. Preserve this module before candidate rebuild. Diagnostic binding, not a new qualification PASS.'}
(root / 'index-baseline-bindings.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
print(json.dumps(result))
