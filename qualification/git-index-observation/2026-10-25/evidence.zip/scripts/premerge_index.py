"""Use existing live read-only gates with the Task023 authority reference."""
import pathlib

path = pathlib.Path(__file__).with_name('premerge_timing.py')
source = path.read_text(encoding='utf-8').replace('Task021', 'Task023')
exec(compile(source, str(path), 'exec'))
