"""Task023 wrapper around the frozen local source-tool execution method."""
import pathlib

path = pathlib.Path(__file__).with_name('capture_timing_tools.py')
source = path.read_text(encoding='utf-8').replace('e855b16b668d490cf6e3b5bfbe11b0e36724ae0d', 'a6baed464db522962e8d4e2e08ae6cb0fd24cd1b').replace('92433f7039393d6a08b8f993bc50da8470de2b5c', '62e588adda04dda1a517742fe10af352e5dfa83f').replace('timing-tool-', 'index-tool-').replace('timing-graft-graph', 'index-graft-graph').replace('tests/git-identity.test.ts', 'tests/git-index-observation.test.ts')
exec(compile(source, str(path), 'exec'))
