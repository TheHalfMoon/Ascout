"""Read-only preparation: compare native combined index/visibility records."""
import datetime, hashlib, json, pathlib, subprocess, time

root = pathlib.Path(__file__).resolve().parent
prior = json.loads((root / 'dependency-drift-native-diagnostic.json').read_text())
fixture = pathlib.Path(prior['samples'][0]['fixture'])
assert (fixture / '.ascout-owned-drift-diagnostic').read_text() == prior['samples'][0]['owner']
observations = []
for args in [['ls-files', '--stage', '-z'], ['ls-files', '-v', '-z'], ['ls-files', '--stage', '-v', '-z']]:
    start = time.perf_counter()
    result = subprocess.run(['rtk', 'proxy', 'git', *args], cwd=fixture, capture_output=True, check=True)
    observations.append({'argv': args, 'stdout_hex': result.stdout.hex(), 'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(), 'milliseconds': (time.perf_counter() - start) * 1000})
stage, visibility, combined = [bytes.fromhex(item['stdout_hex']).split(b'\0')[:-1] for item in observations]
assert len(stage) == len(visibility) == len(combined) > 0
assert stage == [record[2:] for record in combined]
assert visibility == [record[:2] + record.split(b'\t', 1)[1] for record in combined]
result = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'fixture_owner': prior['samples'][0]['owner'], 'observations': observations, 'ordinary_index_records_equal': True, 'limits': 'Read-only native preparation on one retained ordinary-index fixture. Not a product implementation, plan authorization, native-suite PASS, hostile-path/visibility qualification or historical-cause proof. No source, fixture, policy or deadline changes.'}
(root / 'index-query-preparation.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
print(json.dumps(result))
