"""Task023 exact-source hosted execution, including its 25 new test cases."""
import pathlib

path = pathlib.Path(__file__).with_name('capture_timing_ci.py')
source = path.read_text(encoding='utf-8')
assert source.count('(2425)') == 1
source = source.replace("'timing-ci-'", "'index-ci-'").replace('TASK021_ACTUAL_', 'TASK023_ACTUAL_')
source = source.replace('(2425)', '(2450)')
source = source.replace("native_files = [", "native_files = ['git-index-observation.test.ts', ")
exec(compile(source, str(path), 'exec'))
