"""Task023 bounded plaintext evidence using the previously reviewed minimizer."""
import ast, hashlib, json, pathlib, re, subprocess, sys, zipfile

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
producer = root / 'publish_dependencies.py'
assert hashlib.sha256(producer.read_bytes()).hexdigest() == '87d1e9597dc89e9727821808a7790089d50b4574c012aa1f30f6a9f8770b32d1'
close = sys.argv[1:] == ['--close']
assert sys.argv[1:] in [[], ['--close']]
destination = repo / ('qualification/git-index-observation/2026-10-25-closeout' if close else 'qualification/git-index-observation/2026-10-25')
destination.mkdir(parents=True, exist_ok=True)
members, records = {}, []
sha = lambda value: hashlib.sha256(value).hexdigest()
module = ast.parse(producer.read_text())
functions = [node for node in module.body if isinstance(node, ast.FunctionDef) and node.name in ['minimize', 'sanitize', 'add']]
assert len(functions) == 3
exec(compile(ast.Module(body=functions, type_ignores=[]), str(producer), 'exec'))
for source in sorted((root.parent / 'engineering/runs').glob('index-repair-*.json')):
    capture = json.loads(source.read_text())
    assert capture['state'] == 'EXECUTED' and capture['source_unchanged']
    add('runs/' + source.name, source)
    for stream in ['stdout', 'stderr']:
        path = source.parent / capture[stream]
        assert sha(path.read_bytes()) == capture[stream + '_sha256']
        add('runs/' + path.name, path)
for source in sorted(root.glob('index-*.json')):
    if any(token in source.name for token in ['publication-receipt', 'publication-review', 'closing-review', 'derivative-verification']):
        continue
    add('context/' + source.name, source)
for source in sorted(root.glob('index-tool-*.txt')):
    add('tools/' + source.name, source)
for directory in sorted(path for path in root.glob('index-ci-*') if path.is_dir()):
    for source in sorted(directory.iterdir()):
        if source.suffix in ['.json', '.log', '.txt']:
            add('ci/' + directory.name + '/' + source.name, source)
scripts = ['publish_index.py', 'publish_dependencies.py', 'summarize_index.py', 'capture_index_frontier.py', 'capture_timing_frontier.py', 'freeze_index_baseline.py', 'index_query_preparation.py', 'index_query_benchmark.mjs', 'prepare_index_baseline.py', 'index_runcheck_diagnostic_initial.mjs', 'index_runcheck_diagnostic.mjs', 'capture_index_tools.py', 'capture_timing_tools.py', 'capture_index_ci.py', 'capture_timing_ci.py', 'premerge_index.py', 'premerge_timing.py', 'verify_index_publication.py', 'verify_timing_publication.py']
for name in scripts:
    source = root / name
    key = 'scripts/' + name
    add(key, source)
    if name in ['index_runcheck_diagnostic_initial.mjs', 'index_runcheck_diagnostic.mjs']:
        # This exact reserved address is a public synthetic fixture identity,
        # already present in canonical test source. Preserve executable bytes.
        original = source.read_bytes()
        fixture_identity = b't103' + b'@' + b'example.invalid'
        assert original.count(fixture_identity) == 1
        assert members[key].count(b'<PUBLIC_EMAIL_OMITTED>') == 1
        # The minimizer includes the leading apostrophe in its email match.
        assert members[key] == original.replace(b"'" + fixture_identity, b'<PUBLIC_EMAIL_OMITTED>')
        restored = members[key].replace(b'<PUBLIC_EMAIL_OMITTED>', b"'" + fixture_identity)
        assert restored == original
        members[key] = restored
        records[-1].update(published_sha256=sha(restored), bytes=len(restored), transformed=False, public_reserved_fixture_identity_retained=True)
add('scripts/qualify_native.py', root.parent / 'engineering/qualify_native.py')
if close:
    number = json.loads((root / 'index-pr-number.json').read_text())['number']
    for suffix in ['.json', '-premerge.json']:
        source = root.parent / 'engineering/merges' / (str(number) + suffix)
        add('merges/' + source.name, source)
    add('scripts/record_merge.py', root.parent / 'engineering/record_merge.py')
manifest = {'authority': 'TASK023_QUALIFICATION_OBSERVATIONS_ONLY', 'notice': 'Bounded public plaintext derivatives, original and published hashes. Homes/emails/personal author/committer/raw signature profiles minimized, including nested JSON. The exact reserved <PUBLIC_EMAIL_OMITTED> identity is retained only in two known public fixture scripts after byte equality checks. No opaque archives, installed packages, graph database, private REA expansion or private account/usage data. No historical failure erasure, authentication of originals, provider-independent certification, merge or release approval.', 'records': records}
members['MANIFEST.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
archive = destination / 'evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name, data in sorted(members.items()):
        info = zipfile.ZipInfo(name, date_time=(2000, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        output.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
with zipfile.ZipFile(archive) as output:
    assert len(output.namelist()) == len(set(output.namelist())) and output.testzip() is None
    for record in records:
        assert sha(output.read(record['path'])) == record['published_sha256']
lock = {'zip_sha256': sha(archive.read_bytes()), 'members': len(members), 'source_head': subprocess.check_output(['rtk', 'proxy', 'git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip(), 'notice': manifest['notice']}
(destination / 'evidence-lock.json').write_bytes((json.dumps(lock, indent=2) + '\n').encode())
print(json.dumps(lock))
