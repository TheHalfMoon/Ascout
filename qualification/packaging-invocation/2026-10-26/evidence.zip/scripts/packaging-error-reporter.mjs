import { writeFileSync } from 'node:fs';

export default class PackagingErrorReporter {
  onTestCaseResult(testCase) {
    writeFileSync(process.env.ASCOUT_OWNED_ERROR_REPORT, JSON.stringify(testCase.result(), null, 2) + '\n');
  }
}
