"""Forward execution reconciliation in the authorized Task025 documentation scope."""
import pathlib

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
def write(name, text):
    path = repo / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(text.encode())
def replace(name, before, after):
    path = repo / name
    text = path.read_text()
    assert text.count(before) == 1, name
    write(name, text.replace(before, after))
replace('specs/025-packaging-invocation-compatibility/spec.md', 'Status: PROPOSED, planning only.', 'Status: IMPLEMENTED at899be8181899ffc618f159e60d2e98413ab6f776; qualification in progress, complete native suite FAIL retained.')
replace('specs/025-packaging-invocation-compatibility/tasks.md', 'Status: planning only. Steps2–8 pending; no project tests or helper edits authorized yet. Old controls retain their actual old source. No full-suite PASS, cause, merge or release claim.', 'Status: steps1–6 executed after finalized prospective gates and bounded authority. Helper/import-only source899be81; real direct RED1/npm-before0, GREEN0/npm-after0, owned exit42 negative remains native1 with structured cause, typing/build0, one complete native1/2416passed/12deadline failures/34existing skips. D1 advisory and OCR preview/rules actual; fresh combined source and separate subprocess/security reviews clear within scope. Step7 integrated/publication/final-head CI/Self/eligibility and step8 canonical/postmerge/closing remote outcomes remain pending. All failures and unproved causes retained; E00/release BLOCKED.')
replace('ROADMAP.md', 'prospective planning only; fresh audit/consistency and bounded authority precede project tests/helper edits; E00/release BLOCKED', 'implemented at899be81 after fresh prospective gates; direct/npm controls and typing/build pass, owned negative fails honestly; full native FAIL12deadlines retained; final integration/publication/CI/canonical/remote gates pending; E00/release BLOCKED')
write('STATE.md', '''Last updated: 2026-10-26 Asia/Riyadh · Branch: ps/rea-packaging-invocation-compatibility

## Current state

Canonical main remains fe3064afabb18cffbc1d5a8e7f0b5396be7b28c2 after ordinary PR646. Focused Task024 is CLOSED_CANONICAL: ordered parents/tree/valid signature, six actual final-head and six postmerge native suites, closing correctness/privacy and actual final3core+7sidecar/166member readback at1ba2e924cfe85320f03def575b1279bb79d27bee before Task025 mutation. Old evidence stays on its closing branch. Completed REA/Spec018/Durable Harness and all historical failures remain preserved.

Task025 prospective audit01443ef PLAN_CLEAR and different consistency64b38a3 CONSISTENCY_CLEAR were finalized before bounded direct-user-derived authority96e1af4 and new tests/helper edits. Minimal source899be8181899ffc618f159e60d2e98413ab6f776 changes only imports/runNpm in the existing packaging test: inherited explicit npmCLI route preserved; absent/empty metadata uses existing cross-spawn7.0.6 sync, errors/status/signal/output retained as cause. All production,256other test entries,15other controls and complete assertion/parser/fixture/60000ms deadline tail remain frozen. No dependencies/config/workflows/authority/admission/global environment changed.

## Actual qualification

Current unchanged96e direct RED native1/15.310s with missing npm_execpath error; canonical npm-before0/20.699s. Source899 direct GREEN0/13.621s, npm-after0/12.735s, strict source typing0/5.207s, build0/6.097s, supplemental existing-test typing0/1.983s. Owned npm exit42 negative remains native1; first collector's visible-output assertion false because default reporter omitted cause, retained. Public reporter-only followup independently confirms actual status42/nullsignal/original stdout/stderr in cause and native1/12.458s. No project-test seam or retry to green.

One unchanged complete serial native run681272cd exited1/1599.021s:2416passed/12deadline failures/34existing skips/2462cases/245files. Failing files: T107,Jest integration,Vitest integration,Git tree digest,Git diff,drift. Every final diagnostic is a literal existing deadline failure. Agent reviewers/inference/install/audit/resource sampling paused during run; no OS exclusivity/CPU/RSS/process-tree measurement. Causes and candidate contribution UNPROVED; no full rerun to green. This FAIL and historical local/Self failures/incompleteness remain E00/release blockers.

Fresh source combined correctness/product/parsimony and separate subprocess/security inline-bar reviews clear within authored scope; shared OpenAI lineage, no provider-independent certification. D1 actual advisory only; Alibaba actual local preview/rules0 (0reviewable/10total, test excluded by default), no Claude/model-provider review. Existing Task024 Graft/TesterArmy source-equivalent evidence retained with no fresh execution claimed. Actual exact-lock npm production/all audits0, zero known vulnerabilities reported; no install or lock change.

## Next steps

Finalize minimized evidence/documentation, fresh integrated/publication/final-delta reviews, focused PR and actual final-head six native CI suites plus Self artifact/inner truth. Live governance/head/base/reviews/thread eligibility precedes ordinary guarded merge; canonical parents/tree/signature and actual postmerge suites, fresh closing reviews and remote byte/member/sidecar verification precede task closure/disposal. No current CI, merge, closure or release claim yet.

Task024 owned Graft cache cleanup followed actual final remote proof; raw evidence retained, unlocated TesterArmy fixture not guessed/deleted. Both Task025 negative fixture roots/markers retained until remote verification. Original dirty checkout, private REA expansion and unrelated projects/branches untouched. No UA-P07, admission injection, paid service, required cloud runtime or release/deployment authority. Effective governance remains in force.
''')
write('specs/025-packaging-invocation-compatibility/SOURCE_REVIEWS.md', '''# Source reviews and execution reconciliation

At immutable899be8181899ffc618f159e60d2e98413ab6f776, treef8438e68024631753e7d5a5f72f71c39c7c7df1c, fresh combined correctness/product/parsimony review finalized original packaging-correctness-899be81.json SHA256f75f168d96d38146408a94774b5e5e60935d9530f266e1062cc00438a8776306. A separate fresh subprocess/security judge finalized packaging-security-899be81.json SHA2568a025897c77188c11d9aa37dbf81434351a1e301930ba01355189280478e27e6. Root read/hashed reports after final messages. No material authored-code findings; frozen controls and real positive/negative outcomes checked.

CLAUDE.md/PRODUCT.md capability mappings are absent; explicit PStack inline bars ran in fresh contexts, all sharing OpenAI lineage. No external provider/security-phase/merge/release authority is implied. Empty metadata, launch errors and signals were assessed statically; executed negative proves nonzero status/cause retention, not all possible environments.

The complete native suite genuinely FAILED:2416passed/12existing deadline failures/34existing skips/2462cases/245files/1599.021s. The file-local helper has no demonstrated path to the six failed files, but this is not causal exoneration, host diagnosis or PASS. Historical local/Self failures stay literal. Integrated/publication/final-head CI/Self/governance/canonical/remote gates remain pending. E00/release BLOCKED.
''')
report = '''# Task025 packaging invocation qualification

Base canonicalfe3064afabb18cffbc1d5a8e7f0b5396be7b28c2; source899be8181899ffc618f159e60d2e98413ab6f776, treef8438e68024631753e7d5a5f72f71c39c7c7df1c. Task024 closing bytes/ref were actually verified at1ba2e92 before planning. Audit01443ef and different consistency64b38a3 finalized before bounded authority96e1af4 and project tests/helper edits.

The existing real package-content case rejected legitimate direct Vitest invocation when inherited npm_execpath was absent. Only its imports/runNpm changed: retain the inherited explicit Node/npmCLI route; otherwise use already pinned cross-spawn7.0.6 sync. Failed launch/status/signal completion fails visibly and keeps the original result as cause. All production,256other test entries,15other frozen controls, manifests/lock/config/workflows/authority remain unchanged. Parser/assertion/fixture/deadline tail SHA256d48fe5601a03a344ae368744e87f5764422605530f327307c4d8e49cdec8fc59 remains byte-identical, including60000ms. No package assertion, skip, retry, dependency or admission change.

| Actual control | Native exit | Seconds | Observed outcome |
| --- | --- | --- | --- |
| Direct unchanged96e RED | 1 | 15.310 | Explicit missing npm_execpath error |
| Canonical npm unchanged96e | 0 | 20.699 | Complete real packaging case passed |
| Direct source899 GREEN | 0 | 13.621 | Complete real packaging case passed |
| Canonical npm source899 | 0 | 12.735 | Complete real packaging case passed |
| Source strict typing | 0 | 5.207 | No diagnostics |
| Build | 0 | 6.097 | No diagnostics |
| Existing test strict typing | 0 | 1.983 | No diagnostics |
| Owned exit42/default reporter | 1 | 8.014 | Status42 visible; collector output-field predicate false, retained |
| Owned exit42/public error reporter | 1 | 12.458 | Failed unchanged case, status42/null signal/stdout/stderr in original cause |
| Complete unchanged serial suite | 1 | 1599.021 | 2416passed/12deadline failures/34existing skips/2462cases/245files |
| Exact-lock production npm audit | 0 | 38.172 | Zero known vulnerabilities reported |
| Exact-lock all npm audit | 0 | 4.810 | Zero known vulnerabilities reported |

The first negative collector overrequired cause output in the default renderer. It is preserved with its actual false predicate and native1. A separate public Vitest reporter observes the serialized original cause without changing the existing test; native failure remains1. Both child-only PATH shim roots/UUID markers are recorded and retained; no global PATH/config mutation. Positive controls execute compilation, real dry-run/pack/tar extraction and every existing package/binary assertion. Launch-error, signal and empty-string paths are statically reviewed, not separately claimed executed.

Complete native capture packaging-repair-full-suite-681272cd-34ec-485e-ad9a-3193e8c86c48 ran once, serially with agent reviewers/inference/installs/audits/samplers paused. Actual existing deadline failures: T1073,Jest2,Vitest1,Git tree digest3,Git diff1,drift2. Full raw diagnostics/streams are in the minimized evidence. Native1599.021s versus Vitest1594.58s, source start/end clean and unchanged. stdoutSHA2564faa5bb069beb45a7b1dc531e9f3c46d97b2e1b0527d6828596dc1802b8b4065; stderrSHA256098663293d9a879c70a3039a08c65d3ca94620f41121123e6d97d45755e17728. No full rerun, timeout/skip movement or failure relabeling. Causes and candidate contribution remain UNPROVED; no OS exclusivity, CPU/RSS/process-tree measurement or generic-host explanation is claimed. Both300s and900s outer captures would truncate this observed attempt, not resolve its failures.

Fresh combined source review originalSHA256f75f168d96d38146408a94774b5e5e60935d9530f266e1062cc00438a8776306 and separate subprocess/security originalSHA2568a025897c77188c11d9aa37dbf81434351a1e301930ba01355189280478e27e6 found no material authored-code issue. They retain fullFAIL and do not prove absence of contribution. Missing specialist capability mappings degrade visibly to PStack inline bars in fresh session-model contexts; shared OpenAI lineage is not provider-independent certification.

Actual local D1-600M triage is advisory only, never a gate. Actual Alibaba local preview/rules exited0:0reviewable/10total, test excluded by default, rule text retrieved; no Claude/model/provider review is claimed. Production and all-dependency free npm audits report0 known vulnerabilities at the exact unchanged lock, not security certification. No fresh Graft/TesterArmy execution is claimed for unchanged src/browser/toolchain; actual Task024 source-bound evidence remains at1ba2e92. Existing real browser/mutation/selection/accounting files were included in this full suite; only the listed six files failed.

The deterministic evidence archive includes explicit minimized text/JSON observations, original/derivative hashes and reproducible scripts. It excludes opaque Self ZIPs, installed dependencies/cache/graph DB/browser profiles/private REA expansion/account quota/credentials. Homes/emails/personal author/committer/raw signature payloads are minimized recursively using the frozen producer; minimization is not authentication or universal secret detection. Predecessor owned Graft cache was removed only after actual remote proof; raw captures retained and unlocated auxiliary fixture not guessed/deleted.

Status: focused implementation and source review complete; integrated/publication/final-delta review, actual final-head six native CI suites/Self artifact, live eligibility/ordinary guarded merge, canonical/postmerge/closing remote proof remain pending. Historical Task021–024 local/Self failures and incompleteness remain. E00/release BLOCKED. No UA-P07, admission injection, new policy/security authority, paid service, required cloud runtime, release or deployment approval.
'''
write('qualification/packaging-invocation/2026-10-26/REPORT.md', report)
write('docs/qualification/REA-E00-packaging.md', '''# REA-E00 packaging invocation compatibility

Task025 repairs a test-helper compatibility defect: direct Vitest can now execute the unchanged real npm packaging assertions without inherited npm_execpath. The explicit inherited npmCLI route is preserved; fallback uses existing cross-spawn7.0.6 and retains failed process results. All production/package/config/authority and complete case/deadline tail are unchanged.

See [actual qualification](../../qualification/packaging-invocation/2026-10-26/REPORT.md) and [prospective gates/source reviews](../../specs/025-packaging-invocation-compatibility/SOURCE_REVIEWS.md). Direct/npm controls and typing/build passed; owned exit42 remains native failure with original outputs. Complete local suite remains FAIL1:2416passed/12deadline failures/34existing skips/2462cases. No cause or candidate exoneration is proved.

Final integration/publication/CI/Self/governance/canonical/remote qualification remains pending. This is not E00 closure or release readiness. Historical failures/incompleteness, no-admission/UA-P07 and effective repository gates remain intact.
''')
print('Reconciled authorized Task025 execution docs; no source/test/control edit.')
