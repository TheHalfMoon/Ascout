import { spawnSync } from 'node:child_process';
import { createHash, randomUUID } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync, existsSync } from 'node:fs';
import { dirname, delimiter, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const driver = fileURLToPath(import.meta.url);
const repository = resolve(process.argv[2]);
const marker = randomUUID();
const ownedRoot = join(dirname(driver), `packaging-negative-${marker}`);
mkdirSync(ownedRoot);
writeFileSync(join(ownedRoot, 'OWNED_MARKER.txt'), marker + '\n');
const shim = join(ownedRoot, 'npm.cmd');
const shimBytes = Buffer.from('@echo off\r\necho ASCOUT_OWNED_NPM_STDOUT_42\r\necho ASCOUT_OWNED_NPM_STDERR_42 1>&2\r\necho invoked>"%~dp0invoked.txt"\r\nexit /b 42\r\n');
writeFileSync(shim, shimBytes);
if (process.platform !== 'win32') throw new Error('This independent owned control requires Windows');
const env = { ...process.env };
const pathKeys = Object.keys(env).filter(key => key.toUpperCase() === 'PATH');
const inheritedPath = pathKeys.map(key => env[key]).find(Boolean) ?? '';
for (const key of pathKeys) delete env[key];
for (const key of Object.keys(env)) if (key.toLowerCase() === 'npm_execpath') delete env[key];
env.PATH = ownedRoot + delimiter + inheritedPath;
const argv = ['node_modules/vitest/vitest.mjs', 'run', 'tests/npm-package-content.test.ts', '--maxWorkers=1'];
const started = new Date().toISOString();
const result = spawnSync(process.execPath, argv, { cwd: repository, env, encoding: 'utf8', windowsHide: true, maxBuffer: 8 * 1024 * 1024 });
const stdout = result.stdout ?? '';
const stderr = result.stderr ?? '';
process.stdout.write(stdout);
process.stderr.write(stderr);
const sha = value => createHash('sha256').update(value).digest('hex');
const observed = {
  started_at_utc: started, finished_at_utc: new Date().toISOString(),
  owned_root: ownedRoot, owned_marker: marker, driver_sha256: sha(readFileSync(driver)),
  helper_sha256: sha(readFileSync(join(repository, 'tests/npm-package-content.test.ts'))),
  shim_sha256: sha(shimBytes), command: [process.execPath, ...argv],
  child_only_path_prefix: ownedRoot, inherited_path_remainder_preserved: true,
  npm_execpath_absent_in_child: !Object.keys(env).some(key => key.toLowerCase() === 'npm_execpath'),
  npm_shim_invoked: existsSync(join(ownedRoot, 'invoked.txt')),
  native_status: result.status, native_signal: result.signal,
  native_error: result.error ? { name: result.error.name, message: result.error.message, code: result.error.code } : null,
  stdout_sha256: sha(stdout), stderr_sha256: sha(stderr),
  expected_failure_observed: result.status === 1 && result.signal === null && !result.error &&
    existsSync(join(ownedRoot, 'invoked.txt')) && (stdout + stderr).includes('npm invocation failed (status=42, signal=null)') &&
    (stdout + stderr).includes('ASCOUT_OWNED_NPM_STDOUT_42') && (stdout + stderr).includes('ASCOUT_OWNED_NPM_STDERR_42'),
  notice: 'Independent owned negative against unchanged real case. Actual child failure remains failure; no global PATH/config change, no retry or deadline change. Retain owned root until remote evidence verified.'
};
writeFileSync(join(ownedRoot, 'control.json'), JSON.stringify(observed, null, 2) + '\n');
writeFileSync(join(dirname(driver), 'packaging-negative-observation.json'), JSON.stringify(observed, null, 2) + '\n');
process.exitCode = result.status ?? 2;
