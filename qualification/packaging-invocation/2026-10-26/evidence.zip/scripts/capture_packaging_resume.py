"""Separate read-only Task025 frontier after the interrupted audit."""
import pathlib

path = pathlib.Path(__file__).with_name('capture_timing_frontier.py')
source = path.read_text(encoding='utf-8').replace('timing-frontier-', 'packaging-frontier-').replace('packaging-frontier-refresh.json', 'packaging-frontier-resume-20261026.json').replace('Task021', 'Task025')
exec(compile(source, str(path), 'exec'))
