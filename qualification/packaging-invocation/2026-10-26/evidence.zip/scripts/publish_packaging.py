"""Explicit minimized Task025 evidence; deterministic archive and original/derivative hashes."""
import ast, hashlib, json, pathlib, re, subprocess, sys, zipfile

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
producer = root / 'publish_dependencies.py'
assert hashlib.sha256(producer.read_bytes()).hexdigest() == '87d1e9597dc89e9727821808a7790089d50b4574c012aa1f30f6a9f8770b32d1'
close = sys.argv[1:] == ['--close']
assert sys.argv[1:] in [[], ['--close']]
destination = repo / ('qualification/packaging-invocation/2026-10-26-closeout' if close else 'qualification/packaging-invocation/2026-10-26')
destination.mkdir(parents=True, exist_ok=True)
members, records = {}, []
sha = lambda data: hashlib.sha256(data).hexdigest()
module = ast.parse(producer.read_text())
functions = [node for node in module.body if isinstance(node, ast.FunctionDef) and node.name in ['minimize', 'sanitize', 'add']]
assert len(functions) == 3
exec(compile(ast.Module(body=functions, type_ignores=[]), str(producer), 'exec'))
for path in sorted((root.parent / 'engineering/runs').glob('packaging-repair-*.json')):
    value = json.loads(path.read_text())
    assert value['state'] == 'EXECUTED' and value['source_unchanged']
    add('runs/' + path.name, path)
    for stream in ['stdout', 'stderr']:
        source = path.parent / value[stream]
        assert sha(source.read_bytes()) == value[stream + '_sha256']
        add('runs/' + source.name, source)
for path in sorted(root.glob('packaging-*.json')):
    if any(token in path.name for token in ['publication-', 'closing-review', 'sidecars-readback', 'derivative-verification']):
        continue
    add('context/' + path.name, path)
add('context/cleanup-disposable-cleanup.json', root / 'cleanup-disposable-cleanup.json')
for path in sorted(root.glob('packaging-tool-*.txt')):
    add('tools/' + path.name, path)
for directory in sorted(path for path in root.glob('packaging-ci-*') if path.is_dir()):
    for path in sorted(directory.iterdir()):
        if path.suffix in ['.json', '.log', '.txt']:
            add('ci/' + directory.name + '/' + path.name, path)
scripts = ['publish_packaging.py', 'publish_dependencies.py', 'summarize_packaging.py', 'freeze_packaging_baseline.py', 'capture_packaging_frontier.py', 'capture_packaging_resume.py', 'capture_timing_frontier.py', 'capture_packaging_tools.py', 'capture_packaging_ci.py', 'capture_timing_ci.py', 'premerge_packaging.py', 'premerge_timing.py', 'verify_packaging_publication.py', 'verify_timing_publication.py', 'packaging-negative-control-first.mjs', 'packaging-negative-control.mjs', 'packaging-error-reporter.mjs', 'cleanup_disposable.ps1']
scripts.append('reconcile_packaging_docs.py')
for name in scripts:
    add('scripts/' + name, root / name)
add('scripts/qualify_native.py', root.parent / 'engineering/qualify_native.py')
if close:
    number = json.loads((root / 'packaging-pr-number.json').read_text())['number']
    for suffix in ['.json', '-premerge.json']:
        add('merges/' + str(number) + suffix, root.parent / 'engineering/merges' / (str(number) + suffix))
    add('scripts/record_merge.py', root.parent / 'engineering/record_merge.py')
manifest = {'authority': 'TASK025_QUALIFICATION_OBSERVATIONS_ONLY', 'notice': 'Explicit text/JSON public derivatives through the frozen minimizer, with original/derivative hashes. Homes/emails/personal author/committer/raw signature payloads minimized recursively. Real RED, two native negative failures and first collector limitation, complete full12deadlineFAIL and34existing skips retained. No opaque archives, installed packages/cache/browser profiles/private REA expansion/account quota or credentials. D1 advisory, OCR local rules only, shared review lineage. Historical causes/candidate contribution UNPROVED; no release approval or authentication of minimized originals.', 'records': records}
members['MANIFEST.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
archive = destination / 'evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name, data in sorted(members.items()):
        info = zipfile.ZipInfo(name, date_time=(2000, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        output.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
with zipfile.ZipFile(archive) as output:
    assert len(output.namelist()) == len(set(output.namelist())) and output.testzip() is None
    assert all(not pathlib.PurePosixPath(name).is_absolute() and '..' not in pathlib.PurePosixPath(name).parts and '\\' not in name for name in output.namelist())
    for item in records:
        assert sha(output.read(item['path'])) == item['published_sha256']
lock = {'zip_sha256': sha(archive.read_bytes()), 'members': len(members), 'source_head': subprocess.check_output(['rtk', 'proxy', 'git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip(), 'notice': manifest['notice']}
(destination / 'evidence-lock.json').write_bytes((json.dumps(lock, indent=2) + '\n').encode())
print(json.dumps(lock))
