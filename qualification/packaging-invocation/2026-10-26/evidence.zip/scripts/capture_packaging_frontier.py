"""Task025 frontier namespace; no previous task input is overwritten."""
import pathlib

path = pathlib.Path(__file__).with_name('capture_timing_frontier.py')
source = path.read_text(encoding='utf-8').replace('timing-frontier-', 'packaging-frontier-').replace('Task021', 'Task025')
exec(compile(source, str(path), 'exec'))
