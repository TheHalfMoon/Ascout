"""Apply unchanged live gates with the current bounded maintenance task name."""
import pathlib

path = pathlib.Path(__file__).with_name('premerge_timing.py')
source = path.read_text(encoding='utf-8').replace('Task021', 'Task025')
exec(compile(source, str(path), 'exec'))
