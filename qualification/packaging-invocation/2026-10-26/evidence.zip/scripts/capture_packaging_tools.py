"""Actual local OCR preview/rules; no provider/model review or unrelated graph rebuild."""
import datetime, hashlib, json, os, pathlib, subprocess

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
head = subprocess.check_output(['rtk', 'proxy', 'git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip()
assert head == '899be8181899ffc618f159e60d2e98413ab6f776'
assert not subprocess.check_output(['rtk', 'proxy', 'git', 'status', '--porcelain'], cwd=repo).strip()
ocr = pathlib.Path.home() / 'AppData/Roaming/npm/node_modules/@alibaba-group/open-code-review/bin/ocr.js'
commands = [
    ('alibaba-preview', ['C:/Program Files/nodejs/node.exe', str(ocr), 'delegate', 'preview', '--from', 'fe3064afabb18cffbc1d5a8e7f0b5396be7b28c2', '--to', head]),
    ('alibaba-rules', ['C:/Program Files/nodejs/node.exe', str(ocr), 'delegate', 'rule', 'tests/npm-package-content.test.ts']),
]
records = []
for label, argv in commands:
    result = subprocess.run(['rtk', 'proxy', *argv], cwd=repo, env={**os.environ, 'DO_NOT_TRACK': '1'}, capture_output=True, timeout=180)
    for stream in ['stdout', 'stderr']:
        (root / ('packaging-tool-' + label + '.' + stream + '.txt')).write_bytes(getattr(result, stream))
    records.append({'label': label, 'argv': argv, 'exit': result.returncode, 'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(), 'stderr_sha256': hashlib.sha256(result.stderr).hexdigest()})
assert not subprocess.check_output(['rtk', 'proxy', 'git', 'status', '--porcelain'], cwd=repo).strip()
record = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head': head, 'commands': records, 'notice': 'Actual local Alibaba preview/rules only, not Claude or provider/model review. Default exclusions and limitations retained; fresh manual reviews cover authored helper. No fresh Graft/TesterArmy run: src/browser/auxiliary lock unchanged from actual Task024 source evidence. Local D1 separately advisory only. No release approval.'}
(root / 'packaging-tool-execution.json').write_bytes((json.dumps(record, indent=2) + '\n').encode())
print(json.dumps(record))
