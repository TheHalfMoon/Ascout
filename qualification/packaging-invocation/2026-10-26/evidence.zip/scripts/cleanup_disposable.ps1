$ErrorActionPreference = 'Stop'
$taskRoot = '<WORKSPACE>\work\rc-repair'
$core = Get-Content -LiteralPath (Join-Path $taskRoot 'cleanup-publication-receipt-1ba2e92.json') -Raw | ConvertFrom-Json
$sidecars = Get-Content -LiteralPath (Join-Path $taskRoot 'cleanup-closing-sidecars-readback-1ba2e92.json') -Raw | ConvertFrom-Json
$verifiedHead = '1ba2e924cfe85320f03def575b1279bb79d27bee'
if ($core.head -ne $verifiedHead -or $sidecars.head -ne $verifiedHead -or -not $core.remote_ref_verified -or -not $core.all_member_hashes_crc_json_python_verified -or -not $sidecars.remote_ref_and_all_sidecar_bytes_verified -or $core.members -ne 166 -or $sidecars.records.Count -ne 7) { throw 'Actual final remote evidence is required before disposal' }
$resolvedRoot = (Resolve-Path -LiteralPath $taskRoot).ProviderPath.TrimEnd('\')
$target = Join-Path $resolvedRoot 'cleanup-graft-graph'
$result = [ordered]@{ kind = 'TASK024_OWNED_DISPOSABLE_CLEANUP'; verified_head = $verifiedHead; path = $target; removed = $false; files = 0; bytes = 0; notice = 'Only the exact task-created Graft cache is disposable. Native build had completed and durable text results/commands are remotely verified. No process termination or unrelated cleanup. Raw TesterArmy fixture location was not captured; no unqualified fixture deletion attempted. Native capture originals and evidence inputs retained for reproducibility.' }
if (Test-Path -LiteralPath $target) {
    $resolvedTarget = (Resolve-Path -LiteralPath $target).ProviderPath
    if (-not $resolvedTarget.StartsWith($resolvedRoot + '\', [StringComparison]::OrdinalIgnoreCase) -or (Split-Path -Leaf $resolvedTarget) -ne 'cleanup-graft-graph') { throw 'Cache target escapes the exact owned root' }
    $items = @(Get-Item -LiteralPath $resolvedTarget -Force) + @(Get-ChildItem -LiteralPath $resolvedTarget -Recurse -Force)
    if (@($items | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }).Count -ne 0) { throw 'Reparse point in cache; refusing recursive deletion' }
    $files = @($items | Where-Object { -not $_.PSIsContainer })
    $result.files = $files.Count
    $result.bytes = ($files | Measure-Object -Property Length -Sum).Sum
    Remove-Item -LiteralPath $resolvedTarget -Recurse -Force
    if (Test-Path -LiteralPath $resolvedTarget) { throw 'Cache removal incomplete' }
    $result.removed = $true
}
$result.observed_at_utc = [DateTime]::UtcNow.ToString('o')
$json = $result | ConvertTo-Json -Depth 5
[IO.File]::WriteAllText((Join-Path $taskRoot 'cleanup-disposable-cleanup.json'), $json + "`n", [Text.UTF8Encoding]::new($false))
$json
