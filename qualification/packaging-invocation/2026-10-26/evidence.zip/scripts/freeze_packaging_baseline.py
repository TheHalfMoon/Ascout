"""Read-only Task025 source/control/predecessor bindings before planning changes."""
import datetime, hashlib, json, pathlib, subprocess

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
sha = lambda data: hashlib.sha256(data).hexdigest()
def git(*args):
    return subprocess.check_output(['rtk', 'proxy', 'git', *args], cwd=repo)
head = git('rev-parse', 'HEAD').decode().strip()
assert head == 'fe3064afabb18cffbc1d5a8e7f0b5396be7b28c2'
assert git('status', '--porcelain') == b''
paths = ['tests/npm-package-content.test.ts', 'tests/t107-self-verification-harness.contract.test.ts', 'tests/browser-cleanup-ownership.test.ts', 'src/process.ts', 'src/tools/vitest.ts', 'src/tools/vitest-rerun.ts', 'package.json', 'package-lock.json', 'tsconfig.json', 'vitest.config.ts', '.github/workflows/ci.yml', '.github/workflows/self-verify.yml', 'CONTRIBUTING.md', '.specify/memory/constitution.md', '.specify/PROVENANCE.md', 'benchmarks/self-verify.mjs']
bindings = {name: sha((repo / name).read_bytes()) for name in paths}
test = (repo / paths[0]).read_bytes()
assert bindings[paths[0]] == '8ae5d9d8161a0a79a58cc1fd078f0f6a0a0ce211886e2938d65f652885113f4a'
tail = sha(test.split(b'function parsePackResult', 1)[1])
assert tail == 'd48fe5601a03a344ae368744e87f5764422605530f327307c4d8e49cdec8fc59'
tests = {}
for entry in git('ls-tree', '-r', '-z', 'HEAD', '--', 'tests').split(b'\0'):
    if not entry: continue
    metadata, path = entry.split(b'\t', 1)
    tests[path.decode()] = metadata.decode()
close_head = '1ba2e924cfe85320f03def575b1279bb79d27bee'
core = json.loads((root / 'cleanup-publication-receipt-1ba2e92.json').read_text())
sidecars = json.loads((root / 'cleanup-closing-sidecars-readback-1ba2e92.json').read_text())
assert core['head'] == sidecars['head'] == close_head
assert core['all_member_hashes_crc_json_python_verified'] and sidecars['remote_ref_and_all_sidecar_bytes_verified'] and len(sidecars['records']) == 7
prior = []
for name in ['rc-repair-shadow-package-direct-red-75d29966-da2b-455e-ae78-88558e9bf73e.json', 'rc-repair-shadow-package-npm-control-7bedf795-16cc-44e5-8b6d-4a998d94256a.json']:
    path = root.parent / 'engineering/runs' / name
    capture = json.loads(path.read_text())
    assert capture['state'] == 'EXECUTED' and capture['source_unchanged']
    for stream in ['stdout', 'stderr']:
        assert sha((path.parent / capture[stream]).read_bytes()) == capture[stream + '_sha256']
    prior.append({'path': name, 'capture_sha256': sha(path.read_bytes()), 'capture': capture})
runtime = {name: sha((repo / name).read_bytes()) for name in ['node_modules/cross-spawn/package.json', 'node_modules/cross-spawn/index.js', 'node_modules/cross-spawn/lib/parse.js']}
assert json.loads((repo / 'node_modules/cross-spawn/package.json').read_text())['version'] == '7.0.6'
result = {'kind': 'TASK025_READ_ONLY_BASELINE', 'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head': head, 'tree': git('rev-parse', 'HEAD^{tree}').decode().strip(), 'status': '', 'source_tree': git('rev-parse', 'HEAD:src').decode().strip(), 'bindings': bindings, 'all_test_git_entries': tests, 'npm_case_assertion_and_deadline_tail_sha256': tail, 'installed_existing_cross_spawn_bindings': runtime, 'predecessor_core_readback': core, 'predecessor_sidecar_readback': sidecars, 'prior_packaging_observations': prior, 'notice': 'Read-only preparation, no new project test or helper/source edit. Prior direct RED/canonical npm control have their actual old source and stream bindings; they do not prove any particular bounded Self failure cause. Actual final Task024 closing bytes/ref/member/sidecars verified before this task. No new dependency, process/OS change, authority or admission.'}
path = root / 'packaging-baseline-bindings.json'
assert not path.exists()
path.write_bytes((json.dumps(result, indent=2) + '\n').encode())
print(json.dumps({'head': head, 'bindings': len(bindings), 'tests': len(tests), 'prior_native_exits': [entry['capture']['exit'] for entry in prior], 'predecessor_final_readback': close_head}))
