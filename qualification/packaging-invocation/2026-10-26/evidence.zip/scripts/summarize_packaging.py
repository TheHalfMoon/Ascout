"""Check exact Task025 source/capture truth; preserve failures and frozen assertions."""
import datetime, hashlib, json, pathlib, re, subprocess

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
runs = root.parent / 'engineering/runs'
sha = lambda data: hashlib.sha256(data).hexdigest()
def git(*args):
    return subprocess.check_output(['rtk', 'proxy', 'git', *args], cwd=repo)
baseline = json.loads((root / 'packaging-baseline-bindings.json').read_text())
head = git('rev-parse', 'HEAD').decode().strip()
assert git('rev-parse', 'HEAD:src').decode().strip() == baseline['source_tree']
for name, expected in baseline['bindings'].items():
    if name != 'tests/npm-package-content.test.ts':
        assert sha((repo / name).read_bytes()) == expected, name
for name, expected in baseline['installed_existing_cross_spawn_bindings'].items():
    assert sha((repo / name).read_bytes()) == expected, name
entries = {}
for line in git('ls-tree', '-r', '-z', 'HEAD', '--', 'tests').split(b'\0'):
    if line:
        meta, path = line.split(b'\t', 1)
        entries[path.decode()] = meta.decode()
assert set(entries) == set(baseline['all_test_git_entries'])
assert all(value == baseline['all_test_git_entries'][name] for name, value in entries.items() if name != 'tests/npm-package-content.test.ts')
tail = sha((repo / 'tests/npm-package-content.test.ts').read_bytes().split(b'function parsePackResult', 1)[1])
assert tail == baseline['npm_case_assertion_and_deadline_tail_sha256']
observations = []
for path in sorted(runs.glob('packaging-repair-*.json')):
    value = json.loads(path.read_text())
    assert value['state'] == 'EXECUTED' and value['source_unchanged']
    for stream in ['stdout', 'stderr']:
        assert sha((runs / value[stream]).read_bytes()) == value[stream + '_sha256']
    observations.append({'capture': path.name, 'capture_sha256': sha(path.read_bytes()), 'head': value['source_start']['head'], 'native_exit': value['exit'], 'wall_seconds': value['wall_seconds'], 'argv': value['argv']})
full = next(item for item in observations if item['capture'].startswith('packaging-repair-full-suite-'))
capture = json.loads((runs / full['capture']).read_text())
stdout = (runs / capture['stdout']).read_text()
stderr = (runs / capture['stderr']).read_text()
assert '12 failed | 2416 passed | 34 skipped (2462)' in stdout
assert '6 failed | 239 passed (245)' in stdout
assert stderr.count('Error: Test timed out in ') == 12
negative = json.loads((root / 'packaging-negative-observation.json').read_text())
assert negative['expected_failure_observed'] and negative['native_status'] == 1
first = json.loads((root / 'packaging-negative-observation-first.json').read_text())
assert not first['expected_failure_observed'] and first['native_status'] == 1
audits = []
for observation in observations:
    if '-audit-' in observation['capture']:
        value = json.loads((runs / observation['capture']).read_text())
        report = json.loads((runs / value['stdout']).read_text())
        assert value['exit'] == 0 and report['metadata']['vulnerabilities']['total'] == 0
        audits.append({'capture': observation['capture'], 'metadata': report['metadata']})
result = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head': head,
    'tree': git('rev-parse', 'HEAD^{tree}').decode().strip(), 'status': git('status', '--porcelain').decode(),
    'frozen_control_files_verified': len(baseline['bindings']) - 1, 'source_tree_unchanged': baseline['source_tree'],
    'test_git_entries': len(entries), 'other_test_entries_unchanged': len(entries) - 1, 'tail_sha256_unchanged': tail,
    'installed_existing_cross_spawn_bindings_verified': True, 'native_observations': observations,
    'complete_full_suite': {'native_exit': 1, 'passed': 2416, 'failed': 12, 'skipped': 34, 'total': 2462, 'files': 245,
        'failed_files': 6, 'all_failures_literal_deadlines': True, 'failure_diagnostics': stderr,
        'native_wall_seconds': capture['wall_seconds'], 'vitest_duration_seconds': 1594.58,
        'candidate_contribution_and_historical_causes': 'UNPROVED', 'agent_heavy_work_concurrent': False,
        'process_tree_sampling': False, 'os_exclusivity_claimed': False, 'repeated_until_green': False},
    'negative_control': {'first_native_exit': 1, 'first_overstrict_visible_output_check': False,
        'limitation': 'Default Vitest reporter did not print cause fields; original failed observation retained.',
        'structured_followup_native_exit': 1, 'npm_status': 42, 'signal': None,
        'original_cause_stdout_stderr_verified': True, 'reporter_only_change': True},
    'audits': audits, 'release': 'BLOCKED',
    'notice': 'Actual source-bound observations, not full-suite PASS, historical cause proof, candidate exoneration, provider-independent certification or merge/release approval. Existing source/tests/deadlines/skips preserved. No CPU/RSS/process-tree measurement. Failed collector assertion corrected forward only by inspecting the original error cause with public Vitest reporter API.'}
(root / 'packaging-native-summary.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
print(json.dumps({key: result[key] for key in ['head', 'frozen_control_files_verified', 'test_git_entries', 'other_test_entries_unchanged', 'tail_sha256_unchanged', 'release']}))
