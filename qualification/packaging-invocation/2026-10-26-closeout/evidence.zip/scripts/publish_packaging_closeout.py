"""Forward closeout packet only after actual canonical and six postmerge suite proof."""
import ast, hashlib, json, pathlib, sys

root = pathlib.Path(__file__).resolve().parent
producer = root / 'publish_packaging.py'
assert hashlib.sha256(producer.read_bytes()).hexdigest() == 'dab0211993cda93ebe1c09914a2441aea25a73f937305a0344329d6a7b40f450'
assert sys.argv[1:] == []
number = json.loads((root / 'packaging-pr-number.json').read_text())['number']
proof = json.loads((root.parent / 'engineering/merges' / (str(number) + '.json')).read_text())
assert proof['tree_equal'] and proof['github_signature_verification']['verified']
assert proof['head'] == '31e9c88c55cd3d9043ff37096cfd9926d6691063'
postmerge = json.loads((root / ('packaging-ci-postmerge-' + proof['merge'][:7]) / 'summary.json').read_text())
assert postmerge['head'] == proof['merge'] and postmerge['all_actual_jobs_success'] and postmerge['six_actual_native_full_suites_verified']
assert len(postmerge['jobs']) == 6
source = ast.parse(producer.read_text())
for node in source.body:
    if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'scripts' for target in node.targets):
        assert isinstance(node.value, ast.List)
        node.value.elts.extend(ast.Constant(name) for name in ['publish_packaging_closeout.py', 'prepare_packaging_closeout.py', 'packaging_review_sidecars.py', 'verify_packaging_sidecars.py', 'verify_cleanup_sidecars.py', 'inspect_packaging_self.py', 'capture_packaging_pr_reviews.py'])
        break
else:
    raise AssertionError('Frozen scripts declaration missing')
extra_names = ['packaging-publication-509d89e.json', 'packaging-publication-receipt-31e9c88.json', 'packaging-sidecars-readback-31e9c88.json']
extra = ast.parse('\n'.join('add(' + repr('prior-final/' + name) + ', root / ' + repr(name) + ')' for name in extra_names)).body
for index, node in enumerate(source.body):
    if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'manifest' for target in node.targets):
        source.body[index:index] = extra
        break
else:
    raise AssertionError('Frozen manifest declaration missing')
ast.fix_missing_locations(source)
sys.argv = [str(producer), '--close']
exec(compile(source, str(producer), 'exec'))
