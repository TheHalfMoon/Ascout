"""Actual immutable-head sidecar readback using the existing exact-byte method."""
import pathlib

path = pathlib.Path(__file__).with_name('verify_cleanup_sidecars.py')
source = path.read_text(encoding='utf-8').replace('qualification/browser-cleanup/2026-10-26', 'qualification/packaging-invocation/2026-10-26').replace("len(manifest['records']) == 4", "len(manifest['records']) == 3").replace('cleanup-sidecars-readback-', 'packaging-sidecars-readback-')
exec(compile(source, str(path), 'exec'))
