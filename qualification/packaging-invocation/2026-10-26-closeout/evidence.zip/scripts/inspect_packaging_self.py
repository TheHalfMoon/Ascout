"""Inspect actual bounded Self truth without inferring historical failure causes."""
import datetime, hashlib, json, pathlib

root = pathlib.Path(__file__).resolve().parent
directory = root / 'packaging-ci-31e9c88'
summary = json.loads((directory / 'summary.json').read_text())
receipt = json.loads((directory / 'self-verification-receipt.json').read_text())
envelope = json.loads((directory / 'self-verification-envelope.json').read_text())
selector = json.loads((directory / 'selector-shadow-observation.json').read_text())
assert summary['six_actual_native_full_suites_verified'] and summary['all_actual_jobs_success']
assert receipt['source']['start'] == receipt['source']['end']
assert receipt['source']['start']['head_sha'] == envelope['subject_merge_base_sha'] == 'fe3064afabb18cffbc1d5a8e7f0b5396be7b28c2'
assert envelope['subject_target_head_sha'] == envelope['verifier_head_sha'] == summary['head'] == '31e9c88c55cd3d9043ff37096cfd9926d6691063'
assert envelope['receipt_sha256'] == hashlib.sha256((directory / 'self-verification-receipt.json').read_bytes()).hexdigest()
assert receipt['summary']['exit_code'] == 0 and receipt['summary']['completeness'] == 'complete'
assert not receipt['findings']
test = next(task for task in receipt['tasks'] if task['task_type'] == 'test')
assert test['status'] == 'PASS' and test['exit_code'] == 0 and test['observations'] == {'runs': 1, 'failures': 0} and not test['output_truncated']
assert receipt['selection']['mode'] == 'full' and receipt['selection']['selected_test_count'] == receipt['selection']['total_test_count'] == 2462 and receipt['selection']['deselected_test_count'] == 0
assert receipt['exercise']['changed_executable_lines'] == receipt['exercise']['unresolved_lines'] == 0
assert selector['comparison']['reason_code'] == 'UNAVAILABLE_FULL_SUITE_CONTRACT'
result = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head': summary['head'],
    'actual_artifact': summary['self_artifact'], 'receipt_summary': receipt['summary'], 'selection': receipt['selection'],
    'test_task': {'status': test['status'], 'exit': test['exit_code'], 'duration_ms': test['duration_ms'], 'observations': test['observations'], 'output_truncated': test['output_truncated']},
    'exercise': receipt['exercise'], 'reconstructed_subject_head': receipt['source']['start']['head_sha'],
    'exact_target_head': envelope['subject_target_head_sha'], 'source_start_end_equal': True,
    'notice': 'Current actual Self exit0/complete only. Reconstructed base HEAD is correct contract behavior, not stale verification. Current test/docs-only change has0changed executable source lines; historical Task024 unresolved63lines and earlier failures are not retroactively closed. Selector comparison remains unavailable, not MATCHED. Independent exact-head CI and local FAIL remain distinct; no release certification.'}
(root / 'packaging-self-inspection.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
print(json.dumps({'head': result['head'], 'inner_exit': 0, 'completeness': 'complete', 'selected': 2462, 'selector': selector['comparison']['reason_code']}))
