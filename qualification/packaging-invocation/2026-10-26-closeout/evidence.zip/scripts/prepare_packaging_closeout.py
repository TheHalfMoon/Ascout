"""Write bounded factual closing docs only after actual canonical/postmerge proof."""
import hashlib, json, pathlib, subprocess

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
proof = json.loads((root.parent / 'engineering/merges/647.json').read_text())
assert proof['merge'] == '23abb92c3a37bd936c2d7386aa23ddc9d35a9579' and proof['tree_equal'] and proof['github_signature_verification']['verified']
post = json.loads((root / 'packaging-ci-postmerge-23abb92/summary.json').read_text())
assert post['head'] == proof['merge'] and post['all_actual_jobs_success'] and post['six_actual_native_full_suites_verified'] and len(post['jobs']) == 6
assert subprocess.check_output(['rtk', 'proxy', 'git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == proof['merge']
assert not subprocess.check_output(['rtk', 'proxy', 'git', 'status', '--porcelain'], cwd=repo).strip()
def write(name, text):
    path = repo / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(text.encode())
def replace(name, before, after):
    text = (repo / name).read_text()
    assert text.count(before) == 1, name
    write(name, text.replace(before, after))
prefix = 'qualification/packaging-invocation/2026-10-26-closeout'
report = '''# Task025 canonical packaging repair closeout

Status: MERGED_CANONICAL, six actual postmerge suites verified. Fresh closing correctness/privacy and closing remote readback remain pending; no CLOSED_CANONICAL or release claim yet.

[PR647](https://github.com/TheHalfMoon/Ascout/pull/647) merged ordinarily at2026-10-26T09:01:12Z. Canonical main23abb92c3a37bd936c2d7386aa23ddc9d35a9579 has ordered parentsfe3064afabb18cffbc1d5a8e7f0b5396be7b28c2 and31e9c88c55cd3d9043ff37096cfd9926d6691063, reviewed treef2d57a3c92a68b173e512aeae4c84f43979241ae and valid GitHub signature. Last-moment guard verified exact head/base/main, all7checks, MERGEABLE/CLEAN, zero submitted reviews/inline threads and unchanged effective governance. No force/admin/admission or UA-P07. Qodo trial-ended comment is an unavailable review; no paid service enabled.

## Focused repair and prospective authority

Task024 closing bytes/ref3core+7sidecar/166members were actually verified at1ba2e92 before this task. Prospective plan01443ef PLAN_CLEAR originalSHA256920fad74eac1bf524d40d77d4163c2ba2f9178a3e812a2023eee1b23b481d612 and different64b38a3 CONSISTENCY_CLEAR originalSHA25620bb5fdfc419abd8151501edcf3fd10b92ef752846c376e74a4b2bd4bb122fa2 preceded bounded user-derived authority96e1af4, new tests and source899be81. Initial reviewer availability interruption produced no verdict; generic limitation retained, no private quota data.

Only necessary imports/runNpm in tests/npm-package-content.test.ts changed. Nonempty inherited npm_execpath retains explicit Node/npmCLI route and options/error behavior. Absent/empty metadata uses existing cross-spawn7.0.6 sync; error/nonzero/missing status/signal rejects with original result/cause. No new dependency, shell:true construction, retry, global PATH/npm config or command admission. Source tree30bd51a5d566027174b3efdde3f29fc0e5e0d54a,15non-helper controls and256other tests-path Git entries remain unchanged. Complete parser/assertion/fixture/60000ms deadline tail SHA256d48fe5601a03a344ae368744e87f5764422605530f327307c4d8e49cdec8fc59 unchanged. Implemented helper whole-fileSHA2563f970a42fef3dd46155be172e7bdbc3473903758420c219d30ca4b6e71efdb1e. All production, manifests/lock/config/workflows/authority and existing skips frozen.

## Actual local qualification

Unchanged96e direct RED native1/15.310s with missing npm_execpath diagnostic; canonical npm-before0/20.699s. Source899 direct GREEN0/13.621s and canonical npm-after0/12.735s execute the complete real build/dry-run/pack/extract/manifest/binary/shebang case. Strict source typing0/5.207s, build0/6.097s and supplemental existing-test typing0/1.983s.

Owned npm shim exit42 first negative remains native1/8.014s. Collector predicate was false because the default reporter omitted cause output; original driver/observation retained. A separate public Vitest reporter-only followup remains native1/12.458s and observes original cause status42/null signal/stdout/stderr, with actual shim marker and source/driver/shim hashes. Both owned roots/UUID markers retained; no test seam/global PATH change. Empty metadata, launch-error and signal branches assessed statically, not separately claimed executed.

The single complete unchanged serial native capture681272cd genuinely FAILED: native1/1599.0206486s;2416passed/12existing deadline failures/34existing skips/2462cases/245files. Vitest1594.58s;6failed/239passed files. Actual12deadline diagnostics: T1073,Jest2,Vitest1,Git tree digest3,Git diff1,drift2. stdoutSHA2564faa5bb069beb45a7b1dc531e9f3c46d97b2e1b0527d6828596dc1802b8b4065; stderrSHA256098663293d9a879c70a3039a08c65d3ca94620f41121123e6d97d45755e17728. Source start/end clean899be81 and all stream hashes verified. Agent reviewers/inference/installs/audits/resource samplers paused during run; no OS exclusivity/CPU/RSS/process-tree measurement. No full rerun, deadline increase, skip or failure relabeling. Both300s and900s capture limits would truncate this observed attempt. Causes and candidate contribution remain UNPROVED; hosted success does not erase this FAIL or diagnose a host cause.

Actual exact-lock free npm production/all audits exit0 and report0known vulnerabilities; no install/lock change or security certification. Local D1 actual advisory only, never an approval gate. Alibaba local preview/rules0:0reviewable/10total, changed test default-excluded, rule text retained; no Claude/model/provider review. No fresh Graft/TesterArmy execution claimed for unchanged source/browser/auxiliary lock; actual Task024 evidence remains at its exact source.

## Final-head and canonical CI

Final-head Project40294189039 and Self40294189057 ran on exact31e9c88/treef2d57a3. Six actual native245file/2462case suites verify source guards, exact lock, pinned1.63.0 Chromium, typing/build and all16required regression files. Canonical postmerge Project40296380843 repeats the six actual suites on23abb92, with actual merge parents/tree/signature bound. No retry run is substituted.

| Actual platform, both Node22/24 | Final-head result per suite | Postmerge result per suite |
| --- | --- | --- |
| Windows2025 | 2428passed/34existing skips | 2428passed/34existing skips |
| macOS14 | 2435passed/27existing skips | 2435passed/27existing skips |
| Ubuntu24.04 | 2457passed/5existing skips | 2457passed/5existing skips |

Actual final Self artifact12636749312 originalZIP SHA256d37edd8362cfc240b4280cca5a46a807833daa60f2ca3e34ae9e1dc8b20aab5a has verified advertised/upload digest, CRC, exact3JSON members and source/tree/base/receipt/selector bindings. Receipt SHA256316a573e799dfca980e7142664fc57a4e5e0db453d3716523caa63fc6db32caa: innerexit0,complete,PASS2/NOT_APPLICABLE2,no findings. Actual test taskPASS/exit0/run1/failures0, fullselection2462/zero deselected. Receipt source HEADfe is the correct Spec006 reconstructed base with target31 staged treef2; source start/end equal, normal admission and no command-surface change. Current test/docs-only changed production executable lines0/unresolved0 does not retrospectively close historical Task02463unresolved provenance lines. Selector remains UNAVAILABLE_FULL_SUITE_CONTRACT, not MATCHED. Bounded Self ZIP omits referenced raw testJSON/LCOV payloads: receipt semantics/source/digests checked; their payload hashes cannot be independently recomputed from the ZIP. Separate six raw native CI logs establish actual full-suite execution.

## Reviews and durable evidence

Fresh source combined review originalSHA256f75f168d96d38146408a94774b5e5e60935d9530f266e1062cc00438a8776306 and separate subprocess/security8a025897c77188c11d9aa37dbf81434351a1e301930ba01355189280478e27e6 found no material authored-code issue. Integrated509 original9d7f59494823676cebda86658de4e8c9f585e635a9b4b7d7ca7a9d09c0fb6fdf found stale present-tense baseline wording; forward31 explicitly labels it historical and states actual helper hash, with no code/requirement change. Separate publication509 original12a31fe616b565a23462e06bd6a4715300cc8744146d54ee706fb1dae0fcbe74 clear, verifying all76members/75derivatives and28JSON/16Python/3JSsyntax checks. Fresh final-delta31 original681f2329e0f53c38a6250709fb880950958b284f1621e57440a0f0ec4547f529 confirms correction, sidecars and frozen archive. Fresh final CI/Self reviewer original9b24a379842458455477a5623551e0915df2cbb119e10c582c6d6c4eba0087cb independently verifies actual seven logs/rawSelf artifact/source/control bindings and finds no material in-scope regression or missing focused premerge qualification. It supplies no causal exoneration or merge/release authority.

Initial76member archive SHA2561a8ffc02bdf5eaa6b2e09e6fabeca5b7a0f12a2f1cdb2a1c13fa435352ae0a8c and3core+4sidecars were actually downloaded/byte/member/ref verified on GitHub at31e9c88 before merge. This forward packet preserves final/postmerge CI, final reviews, guarded merge proofs and those initial remote receipts. It uses the frozen minimizer with explicit original/derivative hashes; no opaque archives, installed dependencies/cache/graphDB/browser profiles/private REA/account quota/credentials. Homes/emails/personal author/committer/raw signature payloads minimized recursively; not authentication or universal secret detection. Raw captures/inputs and owned negative fixtures retained until actual closing remote verification. Prior Task024 exact owned Graft cache cleanup followed verified remote proof; unlocated auxiliary fixture not guessed/deleted.

CLAUDE.md/PRODUCT.md specialist mappings absent: PStack inline bars ran in fresh session-model contexts. Shared OpenAI lineage is not provider-independent certification. Qodo billing limitation is explicit, with no paid fallback. Historical Task021–024 local/Self failures and incompleteness remain intact; current Self success proves only its current subject. E00/release remain BLOCKED by unresolved local deadline debt and remaining qualification, not silently authorized by hosted success. No UA-P07, admission injection, new security phase, provider-policy waiver, required cloud product infrastructure, release or deployment authority. Fresh closing correctness/privacy and actual closing core/member/sidecar remote readback remain required before focused task closure, next canonical task or disposal.
'''
write(prefix + '/REPORT.md', report)
write('STATE.md', '''Last updated: 2026-10-26 Asia/Riyadh · Branch: evidence/packaging-postmerge-20261026

## Current state

Canonical main23abb92c3a37bd936c2d7386aa23ddc9d35a9579 after ordinary guarded PR647; expected ordered parents, reviewed treef2d57a3 and valid signature verified. Task025 helper-only packaging compatibility repair, prospective gates, actual direct/npm positive controls, honest exit42 negative, typing/build and fresh source/integration/publication/final-delta/CI reviews complete. Six actual final-head and six postmerge native2462case/245file suites pass. Current Self inner0/complete/fullselection2462; selector comparison remains unavailable.

## In flight

Task025 closing packet/reviews/remote readback pending. Initial76member3core+4sidecar bytes/ref actually verified at31e9c88. No focused CLOSED_CANONICAL or release claim until remaining gates complete. Source and all case/deadline controls remain frozen; original evidence/owned negative fixtures retained.

## Next steps

Fresh closing correctness/privacy, durable closing core/member/sidecar readback, then focused task closure and guarded owned disposable cleanup. Only afterward start the next canonical timing investigation from exact live main; no future source/test mutation yet.

## Blockers / open issues

Complete local native FAIL1/1599.021s:2416passed/12unchanged deadline failures/34existing skips/2462cases in6files. Historical local/Self failures and Task02463unresolved lines retained. Causes/contribution UNPROVED, no full rerun/budget/skip change or host exoneration. E00/release BLOCKED. Qodo billing unavailable; D1 advisory, OCR local rules only, shared reviewer lineage. No paid services, UA-P07, admission injection, policy/security-phase or release/deployment authority. Original dirty/private/unrelated projects untouched.
''')
replace('ROADMAP.md', 'implemented at899be81 after fresh prospective gates; direct/npm controls and typing/build pass, owned negative fails honestly; full native FAIL12deadlines retained; final integration/publication/CI/canonical/remote gates pending; E00/release BLOCKED', 'MERGED_CANONICAL PR647/main23abb92; reviewed tree/signature and six actual final-head plus six postmerge suites verified; current Self inner0/complete; full local FAIL12deadlines retained; closing reviews/remote pending; E00/release BLOCKED')
replace('specs/025-packaging-invocation-compatibility/spec.md', 'Status: IMPLEMENTED at899be8181899ffc618f159e60d2e98413ab6f776; qualification in progress, complete native suite FAIL retained.', 'Status: MERGED_CANONICAL PR647/main23abb92; six actual final-head and six postmerge suites verified, current Self inner0/complete. Closing reviews/remote remain pending; local full FAIL12deadlines and E00/release blockers retained.')
replace('specs/025-packaging-invocation-compatibility/tasks.md', 'Step7 integrated/publication/final-head CI/Self/eligibility and step8 canonical/postmerge/closing remote outcomes remain pending.', 'Step7 integrated/publication/final-delta/actual CI/Self/live eligibility and ordinary merge, plus canonical parents/tree/signature and six actual postmerge suites verified. Step8 fresh closing reviews and closing remote readback pending; no focused closure yet.')
write('docs/qualification/REA-E00-packaging.md', '''# REA-E00 packaging invocation compatibility

Task025 helper/import-only repair merged through guarded PR647 into canonical23abb92 with expected parents/reviewed tree/valid signature. Actual direct/npm package controls, strict source/test typing/build and six final-head plus six postmerge native suites pass. Owned npm exit42 remains a failed unchanged real case with its original outputs/cause preserved. Current Self inner0/complete/fullselection2462; selector comparison UNAVAILABLE_FULL_SUITE_CONTRACT.

[Canonical closing record](../../qualification/packaging-invocation/2026-10-26-closeout/REPORT.md) preserves the complete local FAIL1:2416passed/12deadline failures/34existing skips/2462cases/1599.021s, all original/derivative bindings and shared-review/tool limitations. No historical cause, candidate exoneration or retroactive coverage closure is proved. Historical local/Self failures remain intact.

Fresh closing reviews and actual closing remote byte/member/sidecar proof remain pending. E00/release BLOCKED; no UA-P07, admission injection, paid service or new policy/security/release authority.
''')
print('Prepared Task025 canonical/postmerge observations; closing review and remote gates pending.')
