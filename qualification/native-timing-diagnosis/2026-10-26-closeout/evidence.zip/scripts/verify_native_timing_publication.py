"""Read back actual immutable Task026 publication bytes."""
import pathlib

path = pathlib.Path(__file__).with_name('verify_timing_publication.py')
source = path.read_text(encoding='utf-8').replace('qualification/git-head-query/2026-10-24', 'qualification/native-timing-diagnosis/2026-10-26').replace('timing-publication-receipt-', 'native-timing-publication-receipt-')
exec(compile(source, str(path), 'exec'))
