"""Forward Task026 packet after actual canonical merge and six postmerge suites."""
import ast, hashlib, json, pathlib

root = pathlib.Path(__file__).resolve().parent
producer = root / 'publish_native_timing.py'
assert hashlib.sha256(producer.read_bytes()).hexdigest() == '9e94ad051218f4ef74e5171318ef3f47836b581217637ba671f0b50139ba48d5'
number = json.loads((root / 'native-timing-pr-number.json').read_text())['number']
proof = json.loads((root.parent / 'engineering/merges' / (str(number) + '.json')).read_text())
assert proof['tree_equal'] and proof['github_signature_verification']['verified']
post = json.loads((root / ('native-timing-ci-postmerge-' + proof['merge'][:7]) / 'summary.json').read_text())
assert post['head'] == proof['merge'] and post['all_actual_jobs_success'] and post['six_actual_native_full_suites_verified'] and len(post['jobs']) == 6
source = producer.read_text(encoding='utf-8').replace("destination = repo / 'qualification/native-timing-diagnosis/2026-10-26'", "destination = repo / 'qualification/native-timing-diagnosis/2026-10-26-closeout'")
assert source != producer.read_text(encoding='utf-8')
tree = ast.parse(source)
extra = ast.parse('''
for directory in sorted(path for path in root.glob('native-timing-ci-*') if path.is_dir()):
    for path in sorted(directory.iterdir()):
        if path.suffix in ['.json', '.log', '.txt']:
            add('ci/' + directory.name + '/' + path.name, path)
for path in sorted(root.glob('native-timing-*.json')):
    if any(token in path.name for token in ['results-review-', 'results-delta-', 'publication-review-', 'publication-receipt-', 'sidecars-readback-', 'self-inspection', 'frontier-premerge', 'pr-number', 'ci-review-', 'final-pr-review-observation']):
        add('final/' + path.name, path)
for suffix in ['.json', '-premerge.json']:
    add('merges/' + str(number) + suffix, root.parent / 'engineering/merges' / (str(number) + suffix))
for name in ['native-timing-ci-download-attempts.json', 'native-timing-ci-download-retry.stdout.txt', 'native-timing-ci-download-retry.stderr.txt']:
    add('download/' + name, root / name)
add('scripts/capture_native_timing_ci_retry.py', root / 'capture_native_timing_ci_retry.py')
for name in ['publish_native_timing_closeout.py', 'prepare_native_timing_closeout.py', 'reconcile_native_timing_observations.py', 'reconcile_native_timing_reviews.py', 'native_timing_review_sidecars.py', 'verify_native_timing_sidecars.py', 'verify_cleanup_sidecars.py', 'capture_native_timing_ci.py', 'capture_timing_ci.py', 'premerge_native_timing.py', 'premerge_timing.py', 'verify_native_timing_publication.py', 'verify_timing_publication.py', 'inspect_native_timing_self.py', 'capture_native_timing_pr_reviews.py', 'capture_packaging_pr_reviews.py']:
    add('scripts/' + name, root / name)
add('scripts/record_merge.py', root.parent / 'engineering/record_merge.py')
''').body
for index, node in enumerate(tree.body):
    if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'manifest' for target in node.targets):
        tree.body[index:index] = extra
        break
else:
    raise AssertionError('Frozen manifest declaration missing')
ast.fix_missing_locations(tree)
exec(compile(tree, str(producer), 'exec'))
