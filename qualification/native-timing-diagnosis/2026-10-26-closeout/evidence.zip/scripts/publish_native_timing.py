"""Explicit Task026 public derivatives; raw full official documentation excluded."""
import ast, hashlib, json, pathlib, re, subprocess, zipfile

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
destination = repo / 'qualification/native-timing-diagnosis/2026-10-26'
destination.mkdir(parents=True, exist_ok=True)
producer = root / 'publish_dependencies.py'
assert hashlib.sha256(producer.read_bytes()).hexdigest() == '87d1e9597dc89e9727821808a7790089d50b4574c012aa1f30f6a9f8770b32d1'
members, records = {}, []
sha = lambda data: hashlib.sha256(data).hexdigest()
functions = [node for node in ast.parse(producer.read_text()).body if isinstance(node, ast.FunctionDef) and node.name in ['minimize', 'sanitize', 'add']]
assert len(functions) == 3
exec(compile(ast.Module(body=functions, type_ignores=[]), str(producer), 'exec'))
for path in sorted((root.parent / 'engineering/runs').glob('native-timing-*.json')):
    value = json.loads(path.read_text())
    assert value['state'] == 'EXECUTED' and value['source_unchanged']
    add('runs/' + path.name, path)
    for stream in ['stdout', 'stderr']:
        source = path.parent / value[stream]
        assert sha(source.read_bytes()) == value[stream + '_sha256']
        add('runs/' + source.name, source)
for path in sorted((root / 'native-timing-output').glob('*.json')):
    add('observations/' + path.name, path)
context = ['native-timing-baseline.json', 'native-timing-frontier-refresh.json', 'native-timing-plan-audit-f0a9da6.json', 'native-timing-consistency-76f17b7.json', 'native-timing-driver-lock.json', 'native-timing-driver-lock-fixed.json', 'native-timing-driver-review-2e2d4f2.json', 'native-timing-driver-delta-0149520.json', 'native-timing-observations.json', 'native-timing-d1-observation.json', 'native-timing-tool-execution.json']
for name in context:
    add('context/' + name, root / name)
for path in sorted(root.glob('native-timing-tool-*.txt')):
    add('tools/' + path.name, path)
scripts = ['publish_native_timing.py', 'publish_dependencies.py', 'summarize_native_timing.py', 'freeze_native_timing_baseline.py', 'native_timing_docs.py', 'prepare_native_timing_plan.py', 'capture_native_timing_frontier.py', 'capture_timing_frontier.py', 'capture_native_timing_tools.py', 'native_timing_probe.mjs', 'native_timing_probe_2e2d4f2.mjs']
for name in scripts:
    add('scripts/' + name, root / name)
add('scripts/qualify_native.py', root.parent / 'engineering/qualify_native.py')
manifest = {'authority': 'TASK026_DIAGNOSTIC_OBSERVATIONS_ONLY', 'notice': 'Explicit source-bound text/JSON derivatives and actual diagnostic source, not product runtime. Frozen minimizer, original/published hashes and all four once-only native controls. Async streams/nested descendants unobserved; first unexecuted driver and adverse review retained. Raw full official documentation cache excluded; versioned references/hashes and paraphrased facts retained. Homes/emails/profile/raw signature data minimized, no opaque archives/cache/private REA/account quota/credentials. Native0 and independent assertions are not the original Vitest case PASS. No historical cause, observer-overhead, cold-start, speedup, host exoneration, repair authority, provider-independent certification or release approval.', 'records': records}
members['MANIFEST.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
archive = destination / 'evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name, data in sorted(members.items()):
        info = zipfile.ZipInfo(name, date_time=(2000, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        output.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
with zipfile.ZipFile(archive) as output:
    assert len(output.namelist()) == len(set(output.namelist())) and output.testzip() is None
    for item in records:
        assert sha(output.read(item['path'])) == item['published_sha256']
lock = {'zip_sha256': sha(archive.read_bytes()), 'members': len(members), 'source_head': subprocess.check_output(['rtk', 'proxy', 'git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip(), 'notice': manifest['notice']}
(destination / 'evidence-lock.json').write_bytes((json.dumps(lock, indent=2) + '\n').encode())
print(json.dumps(lock))
