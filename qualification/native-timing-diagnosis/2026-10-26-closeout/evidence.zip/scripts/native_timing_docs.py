"""Free direct versioned official Node documentation; read-only preparation, no probes."""
import datetime, hashlib, json, pathlib, urllib.error, urllib.request

root = pathlib.Path(__file__).resolve().parent
out = root / 'native-timing-official-docs'
out.mkdir(exist_ok=True)
records = []
for name, needles in [('module', ['syncBuiltinESMExports']), ('child_process', ['spawn', 'close'])]:
    url = 'https://nodejs.org/download/release/v24.19.0/docs/api/' + name + '.json'
    record = {'url': url, 'requested_node_version': '24.19.0', 'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    try:
        with urllib.request.urlopen(url, timeout=30) as response:
            raw = response.read(8 * 1024 * 1024 + 1)
            assert len(raw) <= 8 * 1024 * 1024
            record['http_status'] = response.status
        value = json.loads(raw)
        (out / (name + '.json')).write_bytes(raw)
        found = []
        def visit(item):
            if isinstance(item, list):
                for child in item: visit(child)
            elif isinstance(item, dict):
                label = str(item.get('name', ''))
                if any(needle.lower() in label.lower() for needle in needles) and item.get('desc'):
                    found.append({'name': label, 'text_excerpt': ' '.join(str(item['desc']).split()[:150]), 'meta': item.get('meta')})
                for child in item.values(): visit(child)
        visit(value)
        record.update(sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw), relevant_entries=found, state='RETRIEVED')
    except (OSError, ValueError, AssertionError) as error:
        record.update(state='UNQUALIFIED_RETRIEVAL', error_type=type(error).__name__, error=str(error))
    records.append(record)
result = {'records': records, 'notice': 'Read-only official documentation fetched directly with Python stdlib to honor zero-paid-services. No Firecrawl model/API service invoked. Exact requested version and any retrieval limitations retained; unsupported instrumentation stays unqualified. No project tests, fixture probes, source edits or production capability claims.'}
(root / 'native-timing-documentation.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
print(json.dumps(result))
