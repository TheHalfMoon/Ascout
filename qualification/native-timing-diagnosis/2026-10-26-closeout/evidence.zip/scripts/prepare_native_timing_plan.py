"""Prospective Task026 diagnosis-only packet; no diagnostic driver or fixture execution."""
import json, pathlib

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
baseline = json.loads((root / 'native-timing-baseline.json').read_text())
assert baseline['head'] == '23abb92c3a37bd936c2d7386aa23ddc9d35a9579' and len(baseline['frozen_git_entries']) == 434
def write(name, text):
    path = repo / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(text.encode())
prefix = 'specs/026-native-timing-diagnosis/'
write(prefix + 'spec.md', '''# Task026-T01: measure native launch and self-runtime preparation costs

Status: PROPOSED, planning only. Canonical base23abb92c3a37bd936c2d7386aa23ddc9d35a9579 after focused CLOSED_CANONICAL Task025/PR647. Its final closing3core+7sidecar/127member bytes/ref were actually verified at805d1623cddf3e9d14d32422e14151be22ff59e0 before this task. [Closing record](https://github.com/TheHalfMoon/Ascout/blob/805d1623cddf3e9d14d32422e14151be22ff59e0/qualification/packaging-invocation/2026-10-26-closeout/REPORT.md). No old closing commits enter this task history.

## Problem and constitution

The unchanged complete local run681272cd at source899be81 failed natively1 after1599.021s:2416passed/12existing deadline failures/34skips/2462cases/245files. Failed files were T107,Jest,Vitest,Git tree digest,Git diff,drift. Actual final-head and canonical six-platform/Node suites pass; current Self inner0/complete with full2462selection. Hosted success does not erase local failure or establish a host cause. Old300s/900s captures would truncate the observed1599s attempt; why individual cases exceed their unchanged budgets remains unproved. No whole-suite repeat merely to obtain green.

Measure before another repair. Static inspection finds repeated native Git operations and real exact-lock npm/build in T107 fixture/runtime preparation, but static counts are hypotheses until owned execution records them. This task diagnoses a bounded representative path; it cannot prove the cause of all12historical deadline failures or exonerate code/host contribution. All434 Git entries under src/tests/benchmarks and16controls are frozen, including all cases/deadlines/config/authority.

## Requirements and acceptance

1. Diagnose only. No product, existing test, benchmark harness, package/lock/config/workflow/authority/admission edit. No new dependency, service, cloud runtime, paid provider, global PATH/config, architecture or production feature. A demonstrated repair needs a separate prospectively bounded task.
2. Fresh final plan audit, different exact-head cross-artifact consistency/purity and bounded direct-user-derived authority precede diagnostic driver edits or fixture/probe executions. Read-only source/tool/official documentation preparation is already distinguished from tests. Node24.19.0/npm11.17.0/Git2.56.0.windows.3 are actual observations; native capture harnessSHA326d0fa4e1f850173cbb20bcfc92f621352f092166773533e7adac2108a2465a remains frozen.
3. Predetermine one fixed serial sequence: prelude5Node no-op launches and5Git version launches; one unobserved positive T107-style exact-H preparation case; one observed equivalent positive case; epilogue5Node no-op and5Git version launches. Preserve every planned/executed/not-executed state, native status/signal/error/output hashes, elapsed time, argv and source/driver/tool bindings. Do not select samples, retry to green, assert statistical significance, or infer observer overhead by subtracting two ordered samples. Fixed prelude/order/cache effects remain limitations.
4. Each positive case independently constructs the existing buildable two-commit fixture inside its timed case boundary, using original T107 fixture content, Git operations and positive API/assertion sequence. Include fixture construction, poisoning ignored subject dist/node_modules, original prepareExactHeadRuntime, result/source/runtime assertions and releaseExactHeadRuntime in case timing; preserve separately native outer wall time/import overhead. No fixture prewarming, shared template, moved setup, new mock runtime, network install, weakened assertion or relocated deadline. The independent reproduction is not the original Vitest case and must not be labeled its PASS. Compare its elapsed work with the existing15000ms budget only as an observation. Record actual B/H/tree per case; require equal tracked fixture trees and equivalent outcomes, without assuming timestamp-dependent commit IDs equal.
5. Observer uses only documented Node public APIs within its own explicitly launched diagnostic process: a delegating wrapper of CommonJS child_process.spawn synchronized to existing ESM bindings with module.syncBuiltinESMExports. Preserve argv/options/return/errors, original listeners and completion behavior; add passive public close/error records, restore in finally. Record own child command lifecycle/stage elapsed facts in memory, write after timed work. Do not consume/redirect original streams, add timers/retries, mutate OS/global environment or claim OS exclusivity/CPU/RSS measurements. No process enumeration, OS attachment, psutil/WMI sampling or bypass of unsupported REA Windows capture. If the observer cannot preserve the documented contract, mark traceUNQUALIFIED and proceed with truthful outer stage observations, not a custom process-capture workaround.
6. Real fixture repository/worktree operations stay inside freshly owned fixtures; the actual Ascout repository is read-only for imported benchmark source and hash checks. Record exact owned roots/UUID markers and public API-returned runtime paths; do not guess or delete unlocated fixtures or unrelated projects. Preserve all raw captures until minimized evidence is remotely verified. Existing runtime release remains an explicitly exercised behavior, not manual disposable cleanup. Preserve failures and incomplete traces, including launch errors/missing close events; never substitute a controller exit for inner truth.
7. Before native controls, run a fresh bounded review of observer/fixture faithfulness and safety. Run captures serially without reviewers/inference/installs/audits/samplers; no repeated local full suite, because project source/tests remain frozen. A later genuine code repair requires its own RED/GREEN, full-suite and governance gates. Produce a source-bound observation table that separates measured stage/command costs from hypotheses and maps precisely which historical failures are still unexplained.
8. Save explicit minimized evidence, original/derivative hashes, official source URLs/version/retrieval hashes and reproducible driver/capture scripts in GitHub. Source references are paraphrased; raw full documentation cache stays local. Fresh final interpretation/publication reviews, focused evidence PR, actual applicable exact-head CI/Self inner truth and live guarded governance/canonical/remote closeout remain required. D1 is advisory only; local OCR rules may exclude diagnostics, no provider review fabricated. Graft/product browser/TesterArmy infrastructure unchanged: retain exact prior evidence, no fresh execution claim. Same review lineage and missing/billing-limited providers remain explicit.

Allowed project paths: specs/026-native-timing-diagnosis/**; docs/qualification/REA-E00-native-timing.md; qualification/native-timing-diagnosis/**; ROADMAP.md; STATE.md. Diagnostic driver/control artifacts are evidence, not Ascout runtime exports. All src/tests/benchmarks, manifests/locks/config/workflows/authority, old research and unrelated projects/branches frozen. No UA-P07, admission injection, policy/security-phase waiver or release/deployment authority. E00/release BLOCKED.
''')
write(prefix + 'plan.md', '''# Technical plan and reduction

1. Start exact canonical23 only after actual final Task025805 remote proof. Freeze434 source/test/benchmark entries,16controls, actual prior full failure, native capture method and tool versions. Read official versioned Node module/child_process docs directly at zero service cost; record URLs/hashes and facts without publishing copied implementation/full pages.
2. Fresh final plan audit, different exact-head consistency/purity, then bounded direct-user-derived authority before diagnostic driver or fixture execution. No implied repair authority.
3. Implement one external owned Node driver with two fixed modes, baseline and observer, plus a fixed launch-cost control. Reuse T107 fixture content/operations and original exported benchmark APIs; no project export seam or test edit. Record driver SHA and immutable benchmark/fixture-source bindings before controls. Fresh independent faithfulness/safety review before timed work; resolve findings forward.
4. Execute fixed prelude, baseline, observer and epilogue serially through the unchanged native capture harness with adequate outer capture budget. Each case has its own full timed fixture construction and original positive checks/release; import time and whole process wall time remain separately visible. Observer only records public own-child API events and restores original exports; no process-tree/resource instrumentation. Record all outcomes, failures, incomplete/unexecuted work and mode limitations.
5. Compare actual stage/command elapsed facts and fixed launch samples. Identify dominant observed work only within this reproduction; original12failure causes/contribution remain unproved unless evidence directly supports a narrower conclusion. No speedup/statistical/cold-start/host-exoneration claim from two ordered observations. No code fix, deadline/skip movement or repeated full suite in this diagnosis-only task.
6. Source/control purity verification, actual advisory/rule tooling only where useful, fresh result-interpretation and publication reviews. Deterministic minimized packet, focused PR, actual applicable exact-head CI/Self source/inner truth, live eligibility and ordinary guarded merge if gates pass. Canonical and closing evidence/reviews/remote readback precede any next task or disposal.

Ponytail/YAGNI reduction: one owned reproduction and passive observer using existing Node APIs, no framework, scheduler, source profiler, OS instrumentation, fixture cache, new dependency or production diagnostic feature. No ADR needed: no architecture is changed. Observation limitations are outcomes, not reasons to invent a capture workaround.
''')
write(prefix + 'tasks.md', '''# Task026-T01

Depends on focused CLOSED_CANONICAL Task025/PR647/main23, final closing bytes/ref actually verified at805d162. E00/release BLOCKED.

1. Read-only frontier/source/control/tool/official-reference and predecessor/failure bindings.
2. Fresh final plan audit; different exact-head consistency/purity; bounded authority afterward.
3. Owned diagnostic driver and frozen driver/source lock; fresh observer/fixture-faithfulness review.
4. Fixed serial prelude/baseline/observer/epilogue controls with all actual native/inner/state/timing evidence.
5. Bounded interpretation, source/control purity and applicable tool limitations; no production repair or full-suite rerun.
6. Minimized reproducible evidence, fresh final interpretation/publication reviews and focused PR.
7. Actual applicable final-head CI/Self, live guarded governance/eligible merge, canonical and closing review/remote proof.

Status: prospective preparation only. No diagnostic driver, fixture probe, project test or production edit yet. Steps2–7 pending. Old local fullFAIL12 and current Self0/complete remain distinct; no historical cause or release claim.
''')
write(prefix + 'ANALYSIS.md', '''# Prospective cross-artifact analysis

Constitution/trust: all production/tests/benchmark/command authority frozen; owned independent diagnostic fixture only, no unsupported REA capture or paid service. Explicit actual127member3core+7sidecar805 predecessor proof precedes this task.

Evidence basis: actual single complete local FAIL12/1599s plus twelve actual hosted native passes and current Self0/complete. Broad host/candidate causes unproved. Representative T107 preparation is a bounded measurement target, not a surrogate PASS for the complete suite or an explanation of other failure files.

Reduction: existing Node/public benchmark APIs and original fixture semantics; fixed modes/sample order, no custom process framework, global patch, deadline movement, cache or source repair. Observer overhead/cache/order and incomplete traces are explicit limitations. Public observer is confined to its diagnostic process and never OS enumeration/attachment.

Closure: fresh prospective/faithfulness/final evidence judgments, applicable exact-head CI/Self inner truth and canonical/remote gates remain. Required checks run honestly on new evidence while old full FAIL remains preserved. Material scope change returns to prospective planning; no open user ambiguity blocks read-only preparation.
''')
write(prefix + 'checklists/requirements.md', '''# Requirements quality checklist

- [x] Exact canonical dependency and actual final predecessor readback identified.
- [x] All434 source/test/benchmark entries and16controls frozen; no repair authority inferred.
- [x] Fixed serial sample/case sequence, full timed fixture setup and original public API assertions specified.
- [x] Documented own-process observer contract and unsupported/incomplete outcome specified without REA bypass.
- [x] Raw native/inner failure, source/output/timing/owned-path bindings and interpretation limits required.
- [x] No new dependency/service, global change, deadline/skip movement or full-suite repeat-to-green.
- [x] Fresh prospective/faithfulness/final review, CI/Self/governance/canonical/remote gates required.
- [ ] Independent finalized plan audit.
- [ ] Different exact-head consistency/purity and bounded authority before driver/probes.
- [ ] Actual controls/reviews/publication/canonical/remote outcomes preserved.
''')
roadmap = (repo / 'ROADMAP.md').read_text()
old = 'implemented at899be81 after fresh prospective gates; direct/npm controls and typing/build pass, owned negative fails honestly; full native FAIL12deadlines retained; final integration/publication/CI/canonical/remote gates pending; E00/release BLOCKED'
assert roadmap.count(old) == 1
roadmap = roadmap.replace(old, 'focused CLOSED_CANONICAL PR647/main23abb92; six actual final-head and six postmerge suites, current Self0/complete, clear closing reviews and final3core+7sidecar/127member remote proof805d162; local fullFAIL12 retained; E00/release BLOCKED')
needle = '| Task020-T01 Ascout Durable Harness |'
assert roadmap.count(needle) == 1
roadmap = roadmap.replace(needle, '| REA-E00 / Task026-T01 native timing diagnosis | prospective only; all source/tests/benchmarks frozen, audit/consistency/authority precede owned probes; no repair authority; E00/release BLOCKED | [spec](specs/026-native-timing-diagnosis/spec.md) |\n' + needle)
write('ROADMAP.md', roadmap)
write('STATE.md', '''Last updated: 2026-10-26 Asia/Riyadh · Branch: ps/rea-native-timing-diagnosis

## Current state

Canonical main23abb92c3a37bd936c2d7386aa23ddc9d35a9579 after focused CLOSED_CANONICAL Task025/PR647. Expected parents/tree/valid signature, six actual final-head plus six postmerge2462case suites, current Self0/complete and clear closing reviews verified. Final805d1623cddf3e9d14d32422e14151be22ff59e0 closing3core+7sidecar/127member bytes/ref actually verified before this task; old closing commits not mixed here.

## In flight

Task026 prospective diagnosis-only preparation. All434 src/test/benchmark entries and16controls frozen, actual Node24.19/npm11.17/Git2.56 and versioned official Node APIs bound. No diagnostic driver, fixture probe, existing test or production edit. Fresh plan audit, different consistency/purity and bounded authority precede execution.

## Next steps

Complete prospective gates, then owned driver/faithfulness review and fixed serial launch-cost/T107-style public API measurements. Include full fixture setup inside timed work, preserve every failure/unfinished trace and observer/order/cache limitations. No full-suite repeat merely for green; any demonstrated repair is a separately bounded task. Durable minimized evidence, applicable reviews/CI/Self/canonical/remote gates remain.

## Blockers / open issues

Latest complete local native FAIL1/1599.021s:2416passed/12unchanged deadline failures/34existing skips/2462cases/245files. Historical failures/incompleteness and Task02463unresolved lines remain; causes/contribution UNPROVED. Selector comparison unavailable. E00/release BLOCKED. No paid provider, UA-P07, admission injection, unsupported Windows process capture, new policy/security/release authority or unrelated project mutation. Raw evidence/owned negative fixtures retained; no disposal claimed.
''')
print('Task026 prospective artifacts only; no driver/fixture/probe or existing source/test edit.')
