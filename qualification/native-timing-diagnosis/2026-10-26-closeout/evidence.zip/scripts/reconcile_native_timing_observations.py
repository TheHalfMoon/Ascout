"""Factual execution reconciliation; source and old full-failure truth stay frozen."""
import hashlib, json, pathlib, zipfile

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
summary = json.loads((root / 'native-timing-observations.json').read_text())
prefix = 'qualification/native-timing-diagnosis/2026-10-26'
lock = json.loads((repo / prefix / 'evidence-lock.json').read_text())
assert lock['members'] == 44 and lock['zip_sha256'] == '76799144cd8076bbcb38f4cdbb13f63ffc0cc859cb2ab8b8367923d9b23d1ffe'
with zipfile.ZipFile(repo / prefix / 'evidence.zip') as archive:
    assert hashlib.sha256(archive.read('scripts/native_timing_probe.mjs')).hexdigest() == summary['driver_sha256']
def write(name, text):
    path = repo / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(text.encode())
def replace(name, before, after):
    text = (repo / name).read_text()
    assert text.count(before) == 1, name
    write(name, text.replace(before, after))
report = '''# Task026 native timing diagnostic observations

Status: fixed diagnostic sequence executed; interpretation/publication/final-head CI/Self/governance/canonical/remote gates pending. E00/release BLOCKED. This diagnosis makes no product repair or original Vitest case PASS claim.

Canonical base23abb92c3a37bd936c2d7386aa23ddc9d35a9579. Prior Task025 is focused CLOSED_CANONICAL after actual final805d1623cddf3e9d14d32422e14151be22ff59e0 closing3core+7sidecar/127member verification. Source/tests/benchmarks434Git entries and16controls remain byte-bound to that base. Prospective planf0a9da6 audit originalSHA256a8b554be521de276b01d6b9aefff368082a6c2d34a56afff796b3eab2a1398cf, different76f17b7 consistency originalSHA256ff38ae2b63a6b851ecd024e1c35481ac9ac229abb2a5099aa168c3793af786bd, bounded authoritycd35f0b, then concrete driver/review precede controls. Chronology is recorded tool/conversation order plus immutable ancestry, not independently timestamp-authenticated.

## Executed fixed sequence

All four once-only captures ran serially at44d47acb48f75322e776f12202cbac4ae1af2097/tree763299b878181ada00fdf70466212d5e9cf15059, clean source start/end and unchanged native harness326d0fa4e1f850173cbb20bcfc92f621352f092166773533e7adac2108a2465a. UTC sequence13:19:28–13:20:58 on2026-10-26. All actual native exits0, no driver errors, all source-integrity checks true, original spawn bindings restored. Each launch control contains5Node no-op then5Git version launches, all20planned samples returned0. Raw samples remain in the packet. Outer capture3600s, original benchmark per-process20minute default and project test deadlines unchanged. No reviewers/inference/installs/audits/resource samplers ran alongside native controls; no OS exclusivity/CPU/RSS measurement claimed.

| Control | Native exit | Native process wall seconds | Independent case milliseconds | Original15000ms comparison |
| --- | --- | --- | --- | --- |
| launch-before | 0 | 2.569144 | not a fixture case | not applicable |
| baseline | 0 | 15.325576 | 15105.8276 | exceeded by105.8276ms |
| observer | 0 | 10.468053 | 10264.8785 | below budget in this observation |
| launch-after | 0 | 1.893593 | not a fixture case | not applicable |

Both independent positive cases returned all original T107-style private-runtime assertions and release. Fixture construction, ignored subject compiler/dist poisoning, original prepareExactHeadRuntime, root/head/tree/runtime assertions, second ignored subject mutation and release remain inside each case clock. Module import and native process overhead are separately visible. Added diagnostic timing/hash bookkeeping and lexical release guards are included or explicitly outside the original case boundary as recorded; this independent reproduction is not the original timed Vitest execution. No fixture prewarming/cache or original deadline movement.

| Stage | Baseline ms | Observer ms |
| --- | --- | --- |
| Full fixture construction | 2594.6123 | 2430.9458 |
| Ignored subject poison | 6.3841 | 5.8278 |
| Original exact-runtime preparation | 12300.0074 | 7633.7496 |
| Original positive assertions/mutation | 2.8446 | 2.3970 |
| Original runtime release with lexical guards | 201.4435 | 191.5303 |

Tracked fixture trees are equal:d37787697024a7e5076d97a456c8894f3d483a78. Actual per-case B/H IDs differ with independent commit metadata and remain recorded. Each case ran the original10synchronous fixture Git operations. Fresh roots/UUID identities are memory-journaled without nonignored markers; post-timing existence/realpath observations are explicitly post-timing. Fixture roots are retained. Original API runtime release is exercised behavior; no manual guessed or unrelated cleanup.

## Observed command-cost facts and limits

Observer logged21direct child lifecycles:18Git and2inclusive npm during preparation,1Git during release. Together with10directly captured original synchronous fixture Git operations, the observed case uses29Git invocations and2npm invocations. All21observed children closed with native0/null signal/no error; original CommonJS and ESM spawn bindings restored, no observer fault, DIRECT_CHILD_EVENTS_OBSERVED. Events are serial with no observed overlapping intervals. No stream data listeners, process enumeration/attachment, inherited observer injection, unsupported REA Windows capture or global PATH/config change.

Observed command intervals: fixture synchronous Git sum2415.3561ms; preparation Git sum3620.0404ms; release Git190.4033ms; total Git6225.7998ms. Inclusive npm ci --ignore-scripts --no-audit --no-fund --offline2887.6553ms and npm run build1099.8562ms, total3987.5115ms. Those API/child intervals include launch/wait/I/O/scheduling effects, not CPU time. Nested npm/build descendant lifecycles are not individually observed. Private asynchronous benchmark stdout/stderr hashes are NOT_OBSERVED; driver-captured fixture stdout and whole-control stream hashes are actual where exposed, successful execFileSync stderr unavailable. Missing streams are never represented by invented empty hashes.

Fixed launch samples: before Node203.0504–228.7376ms, Git190.5609–232.3969ms; after Node139.5821–174.3361ms, Git156.7934–220.1516ms,5samples each group. These minimal launches are not equivalent Git workloads. Ordered samples, cache/ambient conditions and observer bookkeeping prevent a statistical, cold-start, observer-overhead or speedup conclusion. Why baseline and observer differ is unproved. Costs are located in this reproduction only; the original12failure causes and host/candidate contributions remain unproved.

A separately bounded followup may investigate whether clean-state validations can use fewer native Git round trips while preserving every source/index/worktree checkpoint and fail-closed invariant. No source repair, validation removal or deadline authority is supplied by this task.

## Original failures and review/tool truth

Prior complete local full681272cd at899be81 remains nativeFAIL1/1599.0206486s:2416passed/12existing deadline failures/34skips/2462cases/245files. Failed files:T107,Jest,Vitest,Git tree digest,Git diff,drift. Current positive preparation is representative of shared work, not a reproduction or explanation of every failed case. No full-suite repeat occurred in this diagnosis. Historical local/Self failures and Task02463unresolved provenance lines remain. Task025 twelve hosted native suites/current Self0complete are prior exact-source evidence, not fresh Task026 CI; selector comparison remains unavailable. E00/release BLOCKED.

Concrete driver review at2e2d4f2 finalized CHANGES_REQUIRED_BEFORE_NATIVE_CONTROLS, originalSHA2561c58375098a0d48c9b68d47f093b6169c2cea024466fe1a8935c7a05fa296f55: release failure could skip full case elapsed fields. Original unexecuted driver4851413a369b36c458612f3b1139ae133835a4bbb88d1f7f6fa21c4a99311d4b retained. Nested finally repaired only this bookkeeping; delta review at0149520 originalSHA256740650636ad108eae6d2b9bdb6bdbe98eb40499ea788f4e427b12f34b6ce4771 clear before any native control. The bound actual driver67c73278bc649e1e2d4473084739c23707034b71942eb5824811d1155784522e is archived byte-identically at scripts/native_timing_probe.mjs inside this packet; source lock's archive path is packet-relative. Failed-release repair was reviewed statically; no live fault injection is claimed. All measured releases returned.

NTD-02: assertion-completion label is evaluated jointly with actual native exit, errors, source integrity and observer qualification. Here all four native0/error-free/integrity checks align; that does not turn the diagnostic label into a project-test PASS. NTD-03: source is now archived locally with actual member/packet hashes; remote publication/readback remains pending, so source lock alone proves no publication.

Actual local D1 preliminary triage ran after native controls, advisory only and not a security/merge/release gate. Alibaba actual local preview/rules exited0:1reviewable/11total, the JSON source lock only; other Markdown paths excluded, external driver not reviewed by that lookup. Rules check JSON-key spelling, no model/provider review. Fresh manual concrete review covers the actual driver. Unchanged product/browser/auxiliary infrastructure uses exact prior Graft/TesterArmy context; no fresh execution fabricated. No paid provider or new dependency/service.

Official Node24.19 module/child_process reference URLs, HTTP200 retrieval times and content hashes are retained in baseline with paraphrased API facts. Raw full documentation cache is excluded from publication. No third-party implementation was copied into Ascout. Public API observation remains inside the owned diagnostic process, consistent with independently executed tests and supported artifact inspection, never an unsupported REA capture workaround.

Packet44members/43manifest records: explicit text/JSON/actual diagnostic scripts with frozen-minimizer original/published hashes, raw modes/captures and the first adverse review/source retained. No opaque archives, installed dependencies/cache/browser profile/private REA/account quota/credentials. Homes/emails/personal profiles/raw signature payloads minimized recursively; reproducibility is not authentication or universal secret detection. Shared OpenAI reviewer lineage is role separation, not provider-independent certification. Fresh final interpretation/publication, actual applicable final-head CI/Self inner truth, live governance/eligibility, canonical and closing remote gates remain pending. No UA-P07, admission injection, new security/provider-policy waiver or release/deployment authority.
'''
write(prefix + '/REPORT.md', report)
write('docs/qualification/REA-E00-native-timing.md', '''# REA-E00 native timing diagnosis

Task026 preserves four fixed independent diagnostic captures at44d47ac with all434 source/test/benchmark entries and16controls unchanged. Baseline representative case15105.8276ms and observed10264.8785ms return original private-runtime assertions/release with native0; equal tracked fixture trees. The baseline crossed the15000ms comparison budget, without executing or relabeling the original Vitest case.

Observed29Git operations and2inclusive npm operations locate command-round-trip costs in this reproduction. Ordered cases prove no speedup, observer overhead, cold-start/statistical or historical cause. See [full observations and limits](../../qualification/native-timing-diagnosis/2026-10-26/REPORT.md). Prior actual complete localFAIL12/1599s remains; E00/release BLOCKED. No full-suite repeat, source/deadline repair or unsupported REA/OS capture.

Final interpretation/publication/CI/Self/governance/canonical/remote gates pending. Any repair is a separately bounded task.
''')
probe = repo / prefix / 'probe-source-lock.json'
value = json.loads(probe.read_text())
value.update(status='ARCHIVED_LOCALLY_FIXED_CONTROLS_EXECUTED_FINAL_REVIEWS_PENDING', execution_source_head=summary['source_head'], evidence_zip_sha256=lock['zip_sha256'], actual_archived_driver_sha256=summary['driver_sha256'], driver_faithfulness_review_sha256='740650636ad108eae6d2b9bdb6bdbe98eb40499ea788f4e427b12f34b6ce4771', publication_state='LOCAL_PACKET_ONLY_REMOTE_PUBLICATION_AND_READBACK_PENDING')
probe.write_bytes((json.dumps(value, indent=2) + '\n').encode())
replace('specs/026-native-timing-diagnosis/spec.md', 'Status: DIAGNOSTIC DRIVER STATICALLY REVIEWED; fixed native controls not yet executed.', 'Status: FIXED DIAGNOSTIC CONTROLS EXECUTED at44d47ac; final interpretation/publication/CI/canonical/remote gates pending. Source/tests/benchmarks frozen; E00/release BLOCKED.')
replace('specs/026-native-timing-diagnosis/tasks.md', 'No fixture/probe/project test or production edit executed yet. Steps4–7 pending.', 'Fixed four diagnostic controls executed once, native0 each; baseline case15105.8276ms and observer10264.8785ms, equal tracked fixture trees, no original Vitest case/full suite rerun. Source/test/benchmark freeze verified. Steps5–7 final interpretation/publication/CI/canonical/remote outcomes remain pending.')
replace('ROADMAP.md', 'prospective only; all source/tests/benchmarks frozen, audit/consistency/authority precede owned probes; no repair authority; E00/release BLOCKED', 'fixed four owned controls executed at44d47ac, source/tests/benchmarks frozen; baseline15105.8276ms, observer10264.8785ms, no speedup/historical-cause proof; final evidence/review/CI/canonical/remote gates pending; E00/release BLOCKED')
write('STATE.md', '''Last updated: 2026-10-26 Asia/Riyadh · Branch: ps/rea-native-timing-diagnosis

## Current state

Canonical23abb92 after focused CLOSED_CANONICAL Task025/PR647; final805d162 closing3core+7sidecar/127member bytes/ref actually verified before Task026. Existing source/tests/benchmarks434entries and16controls remain frozen. All prospective gates/authority and concrete driver fix/delta review preceded four fixed serial native controls at44d47ac; all actual exits0/integrity checks align.

## In flight

Task026 diagnosis only: baseline independent case15105.8276ms, observed10264.8785ms, equal fixture tree; both original positive API assertions/release return. Observed29Git operations plus2inclusive npm operations. Costs bounded to this reproduction; no original Vitest PASS, speedup, observer-overhead or historical cause established. Evidence44member packet assembled locally; final interpretation/publication reviews and GitHub durability pending.

## Next steps

Fresh interpretation and publication/privacy reviews, source purity and focused evidence PR; actual applicable exact-head CI/Self inner truth, live guarded governance/canonical and closing remote proof. Only afterward consider separately prospectively bounded repair. No source/test/benchmark/deadline edit or extra sampling/full-suite repeat.

## Blockers / open issues

Prior complete nativeFAIL1/1599.021s:2416passed/12deadline failures/34skips/2462cases/245files remains; causes/contribution UNPROVED. Historical failures/Task02463unresolved lines and selector unavailability remain. E00/release BLOCKED. Own API observer only, no OS/unsupported REA capture. D1 advisory/OCR local rules, shared reviewer lineage; no paid service, UA-P07, admission/security/policy/release authority or unrelated project mutation. Raw captures/owned fixtures retained.
''')
print('Actual diagnostic observations reconciled; source/test/deadline freeze and legacy full FAIL retained.')
