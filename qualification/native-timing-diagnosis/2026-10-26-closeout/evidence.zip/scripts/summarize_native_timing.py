"""Bind the four fixed observations; descriptive costs only, no historical causal claim."""
import datetime, hashlib, json, pathlib, subprocess

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
runs = root.parent / 'engineering/runs'
sha = lambda data: hashlib.sha256(data).hexdigest()
expected_head = '44d47acb48f75322e776f12202cbac4ae1af2097'
driver_sha = '67c73278bc649e1e2d4473084739c23707034b71942eb5824811d1155784522e'
observations = []
for mode in ['launch-before', 'baseline', 'observer', 'launch-after']:
    paths = list(runs.glob('native-timing-' + mode + '-*.json'))
    assert len(paths) == 1, (mode, paths)
    path = paths[0]
    capture = json.loads(path.read_text())
    assert capture['state'] == 'EXECUTED' and capture['exit'] == 0 and capture['source_unchanged']
    assert capture['source_start']['head'] == expected_head and capture['source_start']['status'] == ''
    for stream in ['stdout', 'stderr']:
        assert sha((runs / capture[stream]).read_bytes()) == capture[stream + '_sha256']
    pointer = json.loads((runs / capture['stdout']).read_text())
    record_path = pathlib.Path(pointer['record'])
    assert record_path.resolve().parent == (root / 'native-timing-output').resolve()
    value = json.loads(record_path.read_text())
    assert value['mode'] == mode and value['driver_sha256'] == driver_sha
    assert not value['errors'] and value['observer']['restored']
    assert all(value[key] for key in ['driver_source_unchanged', 'benchmark_source_unchanged', 'fixture_source_unchanged'])
    if mode.startswith('launch-'):
        assert value['diagnostic_result'] == 'FIXED_LAUNCH_SEQUENCE_RETURNED'
        assert len(value['launch_plan']) == len(value['launch_samples']) == 10
        assert all(row['state'] == 'RETURNED' for row in value['launch_plan'])
        assert all(row['native_status'] == 0 for row in value['launch_samples'])
    else:
        assert value['diagnostic_result'] == 'INDEPENDENT_POSITIVE_ASSERTIONS_RETURNED'
        assert len(value['stages']) == 5 and all(row['state'] == 'RETURNED' for row in value['stages'])
        assert len(value['fixture_commands']) == 10 and all(row['native_status'] == 0 for row in value['fixture_commands'])
    assert value['original_vitest_case_result'] == 'NOT_EXECUTED_BY_THIS_DIAGNOSTIC'
    observations.append({'mode': mode, 'capture': path.name, 'capture_sha256': sha(path.read_bytes()), 'record': record_path.name, 'record_sha256': sha(record_path.read_bytes()), 'native': {'exit': capture['exit'], 'wall_seconds': capture['wall_seconds'], 'started_at_utc': capture['started_at_utc'], 'finished_at_utc': capture['finished_at_utc']}, 'driver': value})
for previous, following in zip(observations, observations[1:]):
    assert previous['native']['finished_at_utc'] < following['native']['started_at_utc']
baseline = observations[1]['driver']
observer = observations[2]['driver']
assert baseline['fixture']['headTree'] == observer['fixture']['headTree']
assert observer['observer']['qualification'] == 'DIRECT_CHILD_EVENTS_OBSERVED'
children = observer['observer']['children']
assert len(children) == 21 and all(row['close_observed'] and row['native_code'] == 0 and row['native_signal'] is None and row['error'] is None for row in children)
assert all(row[stream]['state'] == 'NOT_OBSERVED' for row in children for stream in ['stdout_hash', 'stderr_hash'])
prepare = [row for row in children if row['phase'] == 'prepare_exact_runtime']
release = [row for row in children if row['phase'] == 'release_exact_runtime']
git_rows = [row for row in prepare if row['command'] == 'git']
npm_rows = [row for row in prepare if row['command'] != 'git']
assert len(git_rows) == 18 and len(npm_rows) == 2 and len(release) == 1
assert all(left['closed_ms'] <= right['started_ms'] for left, right in zip(children, children[1:]))
all_git = [row for row in children if row['command'] == 'git']
stats = {'observed_direct_children': 21, 'prepare_git_children': 18, 'prepare_npm_inclusive_children': 2,
    'release_git_children': 1, 'fixture_sync_git_commands': 10, 'total_observed_case_git_invocations': 29,
    'prepare_git_wall_ms_sum': sum(row['wall_ms'] for row in git_rows),
    'prepare_npm_inclusive_wall_ms_sum': sum(row['wall_ms'] for row in npm_rows),
    'release_git_wall_ms': release[0]['wall_ms'],
    'fixture_sync_git_wall_ms_sum': sum(row['wall_ms'] for row in observer['fixture_commands']),
    'observed_all_git_wall_ms_sum': sum(row['wall_ms'] for row in all_git) + sum(row['wall_ms'] for row in observer['fixture_commands']),
    'npm_children': [{'argv': row['argv'], 'wall_ms': row['wall_ms'], 'native_code': row['native_code']} for row in npm_rows],
    'baseline_case_wall_ms': baseline['case_wall_ms'], 'observed_case_wall_ms': observer['case_wall_ms'],
    'equal_fixture_tree': baseline['fixture']['headTree'], 'baseline_exceeds_15000ms': baseline['case_exceeds_original_budget'],
    'observer_exceeds_15000ms': observer['case_exceeds_original_budget']}
launch_summary = []
for observation in [observations[0], observations[3]]:
    samples = observation['driver']['launch_samples']
    for label, rows in [('node_noop', samples[:5]), ('git_version', samples[5:])]:
        launch_summary.append({'mode': observation['mode'], 'kind': label, 'count': len(rows), 'all_native_exit0': True,
            'wall_ms_each': [row['wall_ms'] for row in rows], 'min_ms': min(row['wall_ms'] for row in rows), 'max_ms': max(row['wall_ms'] for row in rows)})
base = json.loads((root / 'native-timing-baseline.json').read_text())
for name, digest in base['bindings'].items():
    assert sha((repo / name).read_bytes()) == digest, name
raw = subprocess.check_output(['rtk', 'proxy', 'git', 'ls-tree', '-r', '-z', 'HEAD', '--', 'src', 'tests', 'benchmarks'], cwd=repo)
current = {row.split(b'\t', 1)[1].decode(): row.split(b'\t', 1)[0].decode() for row in raw.split(b'\0') if row}
assert current == base['frozen_git_entries'] and sha((root / 'native_timing_probe.mjs').read_bytes()) == driver_sha
result = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'source_head': expected_head,
    'driver_sha256': driver_sha, 'sequence': observations, 'descriptive_costs': stats, 'launch_summary': launch_summary,
    'source_frozen_entries_verified': len(current), 'control_hashes_verified': len(base['bindings']),
    'interpretation': {
        'measured': 'In this bounded reproduction, fixture setup and repeated direct Git validation/registration/removal plus inclusive npm install/build consume the observed case. The independent baseline crossed15000ms; all functional assertions/release returned. The ordered observed case did not cross15000ms. Both actual native exits0 and all integrity/error/qualification fields jointly checked.',
        'not_proved': ['Cause of the original12 deadline failures', 'Why the two ordered cases differ', 'Observer overhead or speedup', 'Cold-start/statistical performance', 'OS/CPU/RSS or generic host cause/exoneration', 'That the original Vitest case passed or failed in these controls', 'Individual nested npm/build descendant cost or private async stream output hashes'],
        'followup_hypothesis_only': 'A separately bounded repair may investigate whether existing Git clean-state validations can use fewer native invocations while preserving every fail-closed source/index/worktree invariant. This task grants no source repair or deadline authority.',
        'legacy_full_suite': 'Prior actual681272cd native1/1599.021s with2416pass/12deadline failures/34skips/2462cases/245files remains FAIL; no full-suite rerun occurred.',
        'safety': 'Own public API observer only, no OS enumeration/attachment/unsupported REA capture; internal async streams NOT_OBSERVED, nested npm work inclusive. No reviewers/inference/installs/audits/samplers ran alongside native controls. No OS exclusivity claim.',
        'release': 'BLOCKED'}}
(root / 'native-timing-observations.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
print(json.dumps({'source_head': expected_head, 'costs': stats, 'launch_summary': launch_summary, 'frozen_entries': len(current)}, indent=2))
