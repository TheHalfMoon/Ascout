"""Actual local Alibaba preview/rules after native work; no provider/model review."""
import datetime, hashlib, json, os, pathlib, subprocess

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
head = subprocess.check_output(['rtk', 'proxy', 'git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip()
assert head == '44d47acb48f75322e776f12202cbac4ae1af2097'
ocr = pathlib.Path.home() / 'AppData/Roaming/npm/node_modules/@alibaba-group/open-code-review/bin/ocr.js'
commands = [('alibaba-preview', ['C:/Program Files/nodejs/node.exe', str(ocr), 'delegate', 'preview', '--from', '23abb92c3a37bd936c2d7386aa23ddc9d35a9579', '--to', head]), ('alibaba-rules', ['C:/Program Files/nodejs/node.exe', str(ocr), 'delegate', 'rule', 'qualification/native-timing-diagnosis/2026-10-26/probe-source-lock.json'])]
records = []
for label, argv in commands:
    result = subprocess.run(['rtk', 'proxy', *argv], cwd=repo, env={**os.environ, 'DO_NOT_TRACK': '1'}, capture_output=True, timeout=180)
    for stream in ['stdout', 'stderr']:
        (root / ('native-timing-tool-' + label + '.' + stream + '.txt')).write_bytes(getattr(result, stream))
    records.append({'label': label, 'argv': argv, 'exit': result.returncode, 'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(), 'stderr_sha256': hashlib.sha256(result.stderr).hexdigest()})
record = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head': head, 'commands': records, 'notice': 'Actual local preview/rule lookup after timed controls only. This documentation/JSON diff and external diagnostic artifact can be excluded by default; preview/rule output is not a review of the driver or model/provider approval. Fresh concrete manual review covers actual locked driver. D1 separately advisory. Product source/browser/auxiliary infrastructure unchanged: no fresh Graft or TesterArmy execution claimed, exact prior evidence retained. No paid service.'}
(root / 'native-timing-tool-execution.json').write_bytes((json.dumps(record, indent=2) + '\n').encode())
print(json.dumps(record))
