"""Actual submitted reviews, inline threads and public bot limitations for Task026."""
import pathlib

path = pathlib.Path(__file__).with_name('capture_packaging_pr_reviews.py')
source = path.read_text(encoding='utf-8').replace("'647'", "'648'").replace('number:647', 'number:648')
source = source.replace('31e9c88c55cd3d9043ff37096cfd9926d6691063', '71ceeb6fbd55c44165e1b3d574881ac885a17d17').replace('fe3064afabb18cffbc1d5a8e7f0b5396be7b28c2', '23abb92c3a37bd936c2d7386aa23ddc9d35a9579')
source = source.replace('packaging-final-pr-review-observation.json', 'native-timing-final-pr-review-observation.json')
exec(compile(source, str(path), 'exec'))
