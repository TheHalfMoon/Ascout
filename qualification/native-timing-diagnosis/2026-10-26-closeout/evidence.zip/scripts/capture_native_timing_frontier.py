"""Task026 distinct read-only frontier namespace; old observations untouched."""
import pathlib

path = pathlib.Path(__file__).with_name('capture_timing_frontier.py')
source = path.read_text(encoding='utf-8').replace('timing-frontier-', 'native-timing-frontier-').replace('Task021', 'Task026')
exec(compile(source, str(path), 'exec'))
