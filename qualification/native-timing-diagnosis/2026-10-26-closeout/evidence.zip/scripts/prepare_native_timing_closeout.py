"""Record actual canonical Task026 proof; never infer focused closure or release."""
import json, pathlib, subprocess

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
number = json.loads((root / 'native-timing-pr-number.json').read_text())['number']
proof = json.loads((root.parent / 'engineering/merges' / (str(number) + '.json')).read_text())
assert proof['tree_equal'] and proof['github_signature_verification']['verified']
assert subprocess.check_output(['rtk', 'proxy', 'git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == proof['merge']
assert not subprocess.check_output(['rtk', 'proxy', 'git', 'status', '--porcelain'], cwd=repo).strip()
final = json.loads((root / ('native-timing-ci-' + proof['head'][:7]) / 'summary.json').read_text())
post = json.loads((root / ('native-timing-ci-postmerge-' + proof['merge'][:7]) / 'summary.json').read_text())
assert all(s['all_actual_jobs_success'] and s['six_actual_native_full_suites_verified'] for s in [final, post])
assert len(final['jobs']) == 7 and len(post['jobs']) == 6
self_view = json.loads((root / 'native-timing-self-inspection.json').read_text())
assert self_view['head'] == proof['head']
prefix = 'qualification/native-timing-diagnosis/2026-10-26-closeout'
report = f'''# Task026 canonical timing diagnosis closeout

Status: MERGED_CANONICAL. Fresh closing correctness/privacy and actual closing core/member/sidecar remote readback remain pending. E00/release BLOCKED. No production repair or original Vitest PASS claim.

[PR{number}](https://github.com/TheHalfMoon/Ascout/pull/{number}) merged ordinarily to canonical {proof['merge']}; ordered parents {', '.join(proof['ordered_parents'])}, reviewed/merge tree {proof['merge_tree']} and valid GitHub verification were checked. Actual seven exact-head checks and live head/base/main/reviews/threads/eligibility were guarded without force/admin/admission/UA-P07. Concurrent work was not modified. Initial fixed packet and finalized review sidecars were downloaded and byte/member/ref verified before merge; actual receipts are preserved in this forward packet.

The fixed four native controls executed once at44d47ac remain unchanged. Independent baseline15105.8276ms and observed10264.8785ms; all original positive assertions/releases returned, native0/error-free/source-integrity true. These are independent reproductions, not original timed Vitest case results. Observed29Git+2inclusive npm invocations (21direct async children plus10fixture sync Git), Git intervals6225.7998ms and inclusive npm3987.5115ms locate measured work only. Ordered/cache/ambient/observer effects, nested descendants and asynchronous private streams remain limitations. No speedup, observer overhead, cold-start, CPU, OS-exclusive, historical root cause or host/candidate exoneration claim.

Original complete local681272cd remains FAIL1/1599.0206486s,2416passed/12deadline failures/34skips/2462cases/245files. T1073,Jest2,Vitest1,Git tree digest3,Git diff1,drift2 remain unexplained. Both300s and900s would truncate that observed attempt. No local full rerun in this diagnosis-only task; no product/test/benchmark/deadline/config/dependency/authority edit. Source434Git entries and16controls frozen.

Prospective plan audit, different consistency/purity, bounded user-derived authority, original adverse concrete driver review and its bookkeeping-only nested-finally fix/delta review preceded controls. Both actual and old unexecuted drivers are retained; fixed source SHA25667c73278bc649e1e2d4473084739c23707034b71942eb5824811d1155784522e is archived byte-identically. Assertion-completion labels require native/errors/integrity/observer interpretation; archive paths are packet-relative, not standalone publication proof. Final interpretation and separate publication reviews found no must-fix. They checked actual raw streams/sums/source and all44members43derivatives/CRC/20JSON10Python2JSsyntax. Same OpenAI lineage supplies role separation, not independent-provider certification. D1 advisory only; actual Alibaba local preview/rules1reviewable/11total, JSON only, no model review. Unchanged Graft/TesterArmy/browser context is prior exact-source evidence, no fabricated fresh run. Official Node24.19 versioned references/hashes/paraphrases retained; raw full documentation excluded.

Final-head {proof['head']} and canonical {proof['merge']} each have six actual native hosted suites, source guards, exact lock, pinned Chromium, strict typing/build,2462cases245files and16required regression files verified from raw logs. Actual platform counts and all existing skip counts are retained in the packet, not inferred from badges. Seven final jobs and six postmerge jobs succeeded. Self inner exit/completeness and source/receipt/artifact bindings are recorded separately below; workflow success alone supplies no PASS. Bounded Self artifact omits referenced raw testJSON/LCOV; payload hashes cannot be recomputed from that ZIP. Selector comparison remains unavailable when explicitly recorded, never relabeled MATCHED. Current docs-only zero changed source lines does not retrospectively resolve Task02463unresolved provenance lines or historical failures.

Actual Self inspection:

```json
{json.dumps(self_view, indent=2)}
```

Frozen minimizer with original/published hashes preserves final/postmerge raw logs, actual Self JSON, final reviews, ordinary merge and initial remote receipts. Opaque archives/install caches/browser profiles/private REA/account quota/credentials/full official-doc pages excluded. Homes/emails/personal authors/raw signatures minimized; neither authentication nor universal secret detection. Raw inputs/owned fixtures retained. No new paid service, mandatory cloud, dependency, security phase/provider waiver, UA-P07, changed-surface admission, release or deployment authority. Focused canonical closure requires final closing reviews and actual remote proof; any source repair needs its own prospective task after closure.
'''

def write(name, text):
    path = repo / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(text.encode())

write(prefix + '/REPORT.md', report)
write('STATE.md', f'''Last updated: 2026-10-26 Asia/Riyadh · Branch: evidence/native-timing-postmerge-20261026

Task026 PR{number} MERGED_CANONICAL at{proof['merge']}; reviewed tree/ordered parents/signature, actual final six suites/Self and canonical six suites verified. Fixed diagnosis only; source/tests/benchmarks434entries16controls unchanged. Closing correctness/privacy and actual remote readback pending before CLOSED_CANONICAL or next canonical task.

Independent baseline15105.8276ms/observed10264.8785ms and29Git2npm locate costs, not historical causes/speedup. Original complete local FAIL12/1599.021s remains; E00/release BLOCKED. No test/deadline/authority relaxation, UA-P07 or changed-surface admission. No raw evidence/fixture disposal. Full details: {prefix}/REPORT.md.
''')
for name in ['specs/026-native-timing-diagnosis/spec.md', 'specs/026-native-timing-diagnosis/tasks.md']:
    text = (repo / name).read_text()
    text = '\n'.join((f'Status: MERGED_CANONICAL PR{number}/{proof["merge"]}; final interpretation/publication reviews and applicable CI/Self complete; closing reviews/remote proof pending; E00/release BLOCKED.' if line.startswith('Status:') else line) for line in text.splitlines()) + '\n'
    text += f'\nCanonical update: PR{number} MERGED_CANONICAL at{proof["merge"]}; final-head/canonical actual CI and Self inspected. Fresh closing reviews and actual remote readback pending; E00/release BLOCKED. See {prefix}/REPORT.md.\n'
    write(name, text)
text = (repo / 'ROADMAP.md').read_text()
lines = text.splitlines()
for i, line in enumerate(lines):
    if '/ Task026-T01 ' in line:
        lines[i] = f'| REA-E00 / Task026-T01 native timing diagnosis | MERGED_CANONICAL PR{number}/{proof["merge"][:7]}; fixed controls/reviews and actual final/canonical suites verified; closing reviews/remote proof pending; historicalFAIL12 retained; E00/release BLOCKED | [report]({prefix}/REPORT.md) |'
write('ROADMAP.md', '\n'.join(lines) + '\n')
path = repo / 'docs/qualification/REA-E00-native-timing.md'
text = path.read_text().replace('Final interpretation/publication/CI/Self/governance/canonical/remote gates pending. Any repair is a separately bounded task.', f'Final interpretation/publication and actual final/canonical CI/Self/governance complete for PR{number}/{proof["merge"][:7]}; closing reviews/remote proof pending. Any repair remains a separately bounded task. See [canonical closeout](../../{prefix}/REPORT.md).')
write('docs/qualification/REA-E00-native-timing.md', text)
print(json.dumps({'merge': proof['merge'], 'head': proof['head'], 'status': 'MERGED_CANONICAL_CLOSING_GATES_PENDING'}))
