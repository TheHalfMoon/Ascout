"""Read-only Task026 source/tool/predecessor/full-failure bindings before planning."""
import datetime, hashlib, json, pathlib, subprocess

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
sha = lambda data: hashlib.sha256(data).hexdigest()
def git(*args):
    return subprocess.check_output(['rtk', 'proxy', 'git', *args], cwd=repo)
assert git('rev-parse', 'HEAD').decode().strip() == '23abb92c3a37bd936c2d7386aa23ddc9d35a9579'
assert git('status', '--porcelain') == b''
core = json.loads((root / 'packaging-publication-receipt-805d162.json').read_text())
sidecars = json.loads((root / 'packaging-closing-sidecars-readback-805d162.json').read_text())
assert core['head'] == sidecars['head'] == '805d1623cddf3e9d14d32422e14151be22ff59e0'
assert core['all_member_hashes_crc_json_python_verified'] and core['remote_bytes_equal_local'] and core['members'] == 127
assert sidecars['remote_ref_and_all_sidecar_bytes_verified'] and len(sidecars['records']) == 7
paths = ['benchmarks/self-verify.mjs', 'tests/t107-self-verification-harness.contract.test.ts', 'tests/drift.contract.test.ts', 'tests/git-tree-digest.test.ts', 'tests/git-diff.test.ts', 'tests/jest-check.integration.test.ts', 'tests/vitest-check.integration.test.ts', 'package.json', 'package-lock.json', 'tsconfig.json', 'vitest.config.ts', '.github/workflows/ci.yml', '.github/workflows/self-verify.yml', 'CONTRIBUTING.md', '.specify/memory/constitution.md', '.specify/PROVENANCE.md']
bindings = {name: sha((repo / name).read_bytes()) for name in paths}
entries = {}
for entry in git('ls-tree', '-r', '-z', 'HEAD', '--', 'src', 'tests', 'benchmarks').split(b'\0'):
    if entry:
        metadata, path = entry.split(b'\t', 1)
        entries[path.decode()] = metadata.decode()
full_path = root.parent / 'engineering/runs/packaging-repair-full-suite-681272cd-34ec-485e-ad9a-3193e8c86c48.json'
full = json.loads(full_path.read_text())
assert full['exit'] == 1 and full['state'] == 'EXECUTED' and full['source_unchanged']
for stream in ['stdout', 'stderr']:
    assert sha((full_path.parent / full[stream]).read_bytes()) == full[stream + '_sha256']
harness = root.parent / 'engineering/qualify_native.py'
assert sha(harness.read_bytes()) == '326d0fa4e1f850173cbb20bcfc92f621352f092166773533e7adac2108a2465a'
tools = []
for argv in [['C:/Program Files/nodejs/node.exe', '--version'], ['C:/Program Files/nodejs/node.exe', 'C:/Program Files/nodejs/node_modules/npm/bin/npm-cli.js', '--version'], ['git', '--version']]:
    result = subprocess.run(['rtk', 'proxy', *argv], cwd=repo, capture_output=True, timeout=30)
    tools.append({'argv': argv, 'exit': result.returncode, 'stdout': result.stdout.decode(), 'stderr': result.stderr.decode()})
docs = json.loads((root / 'native-timing-documentation.json').read_text())
assert all(value['state'] == 'RETRIEVED' and value['http_status'] == 200 for value in docs['records'])
references = [{'url': value['url'], 'requested_version': value['requested_node_version'], 'sha256': value['sha256'], 'bytes': value['bytes'], 'observed_at_utc': value['observed_at_utc'], 'http_status': 200} for value in docs['records']]
record = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head': git('rev-parse', 'HEAD').decode().strip(), 'tree': git('rev-parse', 'HEAD^{tree}').decode().strip(), 'bindings': bindings, 'frozen_git_entries': entries, 'source_tree': git('rev-parse', 'HEAD:src').decode().strip(), 'tests_tree': git('rev-parse', 'HEAD:tests').decode().strip(), 'benchmarks_tree': git('rev-parse', 'HEAD:benchmarks').decode().strip(), 'predecessor_core': core, 'predecessor_sidecars': sidecars, 'prior_full_capture': full, 'prior_full_capture_sha256': sha(full_path.read_bytes()), 'harness_sha256': sha(harness.read_bytes()), 'tool_observations': tools, 'official_references': references, 'documentation_facts': ['Node24.19 module.syncBuiltinESMExports updates existing built-in ESM live bindings to CommonJS export properties without adding/removing names.', 'Node child_process.spawn supports child event listeners; close follows process end and stdio closure, distinct from exit. The implementation retains original process behavior and listeners.', 'Any API observer is limited to its own explicitly spawned diagnostic process; no OS enumeration, process attachment or unsupported REA capture is allowed.'], 'notice': 'Read-only preparation only: no fixture benchmark, diagnostic driver or project test/source edit. All source/tests/benchmarks frozen. Actual predecessor closing3core+7sidecar/127member bytes/ref verified before this task. Historical full FAIL12 remains; neither cause nor candidate contribution established. Official reference facts paraphrased; raw documentation cache stays local, no copied implementation or paid service. Existing owned negative fixtures/raw captures retained; no disposal claimed.'}
destination = root / 'native-timing-baseline.json'
assert not destination.exists()
destination.write_bytes((json.dumps(record, indent=2) + '\n').encode())
print(json.dumps({'head': record['head'], 'frozen_entries': len(entries), 'controls': len(bindings), 'tools': tools, 'predecessor_readback': core['head']}))
