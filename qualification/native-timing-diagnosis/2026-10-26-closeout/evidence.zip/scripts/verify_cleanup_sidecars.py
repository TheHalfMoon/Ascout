"""Download actual Task024 sidecars at an immutable branch head."""
import ast, base64, datetime, hashlib, json, pathlib, subprocess, sys

root = pathlib.Path(__file__).resolve().parent
repo = root.parent / 'engineering/main-control'
head, branch = sys.argv[1:]
prefix = 'qualification/browser-cleanup/2026-10-26'
def get(path):
    return json.loads(subprocess.check_output(['rtk', 'proxy', 'gh', 'api', 'repos/TheHalfMoon/Ascout/' + path]))
assert get('commits/' + branch)['sha'] == head
manifest = json.loads((repo / prefix / 'review-manifest.json').read_text())
assert len(manifest['records']) == 4
records = []
for name in ['review-manifest.json'] + [item['path'] for item in manifest['records']]:
    assert pathlib.PurePosixPath(name).name == name and pathlib.Path(name).suffix in ['.json', '.mjs', '.py']
    item = get('contents/' + prefix + '/' + name + '?ref=' + head)
    remote = base64.b64decode(item['content'])
    assert remote == (repo / prefix / name).read_bytes()
    digest = hashlib.sha256(remote).hexdigest()
    if name.endswith('.json'):
        json.loads(remote)
    if name.endswith('.py'):
        ast.parse(remote.decode())
    if name != 'review-manifest.json':
        expected = next(value for value in manifest['records'] if value['path'] == name)
        assert digest == expected['published_sha256'] and len(remote) == expected['bytes']
    records.append({'path': name, 'git_blob': item['sha'], 'sha256': digest, 'bytes': len(remote)})
result = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head': head, 'branch': branch, 'prefix': prefix, 'remote_ref_and_all_sidecar_bytes_verified': True, 'records': records, 'notice': 'Durability only; no security/provider certification, merge approval or release readiness.'}
(root / ('cleanup-sidecars-readback-' + head[:7] + '.json')).write_bytes((json.dumps(result, indent=2) + '\n').encode())
print(json.dumps(result))
