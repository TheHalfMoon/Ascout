"""Record transient evidence download failure; retry reads, never rerun CI/tests."""
import datetime, hashlib, json, pathlib, subprocess, sys

root = pathlib.Path(__file__).resolve().parent
head, project, self_run, number = sys.argv[1:]
assert head == '71ceeb6fbd55c44165e1b3d574881ac885a17d17'
record = {'recorded_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head': head,
    'initial_attempt': {'native_exit': 1, 'action': 'read exact-head completed CI metadata/logs', 'failed_endpoint': 'repos/TheHalfMoon/Ascout/actions/jobs/121611611097/logs', 'observed_error': 'gh: HTTP 503', 'source': 'Actual unified exec session10662 final tool output. No initial failed-fetch stream file/hash claimed.', 'ci_or_tests_rerun': False},
    'retry': None, 'notice': 'Read-only GitHub evidence-download retry after transient HTTP503, not replacement of a failed test/workflow run. Same exact source and actual run IDs retained.'}
path = root / 'native-timing-ci-download-attempts.json'
assert not path.exists()
path.write_bytes((json.dumps(record, indent=2) + '\n').encode())
result = subprocess.run(['rtk', 'proxy', 'python', '-X', 'utf8', str(root / 'capture_native_timing_ci.py'), head, project, self_run, number], capture_output=True)
streams = {}
for name, data in [('stdout', result.stdout), ('stderr', result.stderr)]:
    target = root / ('native-timing-ci-download-retry.' + name + '.txt')
    target.write_bytes(data)
    streams[name] = {'path': target.name, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
record['retry'] = {'completed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'native_exit': result.returncode, 'streams': streams, 'ci_or_tests_rerun': False}
path.write_bytes((json.dumps(record, indent=2) + '\n').encode())
print(json.dumps(record))
raise SystemExit(result.returncode)
