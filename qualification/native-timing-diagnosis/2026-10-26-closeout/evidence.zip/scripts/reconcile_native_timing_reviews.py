"""Reconcile finalized reviews forward; fixed44member packet remains unchanged."""
import hashlib, pathlib

repo = pathlib.Path(__file__).resolve().parent.parent / 'engineering/main-control'
prefix = 'qualification/native-timing-diagnosis/2026-10-26'
archive = repo / prefix / 'evidence.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest() == '76799144cd8076bbcb38f4cdbb13f63ffc0cc859cb2ab8b8367923d9b23d1ffe'
path = repo / prefix / 'REPORT.md'
text = path.read_text()
text = text.replace('Status: fixed diagnostic sequence executed; interpretation/publication/final-head CI/Self/governance/canonical/remote gates pending.', 'Status: fixed diagnostic sequence and fresh final interpretation/publication reviews complete; final-head CI/Self/governance/canonical/remote gates pending.')
text = text.replace('Fresh final interpretation/publication, actual applicable final-head CI/Self inner truth, live governance/eligibility, canonical and closing remote gates remain pending.', 'Actual applicable final-head CI/Self inner truth, live governance/eligibility, canonical and closing remote gates remain pending.')
text += '\nFresh exact43e9ce3/treecade3 interpretation review originalSHA256a01f2f9a4c36713dd1f999f016020b46253430fc6820715a4badb70a392e9b44 and separate publication/privacy review originalSHA256e345fe5d3327607a9971fd41394914d40ad4c9a3e44412cfa679538a9e41b742 finalized with no must-fix. Interpretation independently checked raw captures/streams/sums/21events/29Git2npm and originalFAIL12. Publication reproduced all43original/derivative records,44members/CRC/paths and20JSON10Python2JSsyntax, excluding raw full documentation. Four separate review sidecars preserve finalized reports/producer/manifest, unchanged fixed ZIP. Shared lineage and all limits remain; these reviews provide no actual remote proof, final CI, merge or release approval.\n'
path.write_bytes(text.encode())
for name in ['STATE.md', 'specs/026-native-timing-diagnosis/spec.md', 'specs/026-native-timing-diagnosis/tasks.md']:
    path = repo / name
    text = path.read_text()
    text += '\nCurrent review update: fresh exact43e9ce3 result interpretation and separate publication/privacy finalized without must-fix; four finalized review sidecars, fixed44member packet unchanged. Applicable final-head CI/Self, governance, canonical and closing remote gates remain pending. No production repair or historicalFAIL12 erasure; E00/release BLOCKED.\n'
    path.write_bytes(text.encode())
