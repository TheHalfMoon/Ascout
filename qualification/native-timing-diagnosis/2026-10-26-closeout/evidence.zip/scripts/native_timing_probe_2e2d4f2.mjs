import assert from 'node:assert/strict';
import { createHash, randomUUID } from 'node:crypto';
import { existsSync, mkdirSync, mkdtempSync, readFileSync, realpathSync, writeFileSync } from 'node:fs';
import { createRequire, syncBuiltinESMExports } from 'node:module';
import { tmpdir } from 'node:os';
import { basename, dirname, isAbsolute, join, resolve } from 'node:path';
import { performance } from 'node:perf_hooks';
import { fileURLToPath, pathToFileURL } from 'node:url';

const [mode, repositoryArgument] = process.argv.slice(2);
assert(['launch-before', 'baseline', 'observer', 'launch-after'].includes(mode));
assert(repositoryArgument);
const repository = resolve(repositoryArgument);
const driver = fileURLToPath(import.meta.url);
const require = createRequire(import.meta.url);
const childProcess = require('node:child_process');
const originalSpawn = childProcess.spawn;
const esmChildProcess = await import('node:child_process');
const sha = value => createHash('sha256').update(value).digest('hex');
const benchmark = join(repository, 'benchmarks/self-verify.mjs');
const fixtureSource = join(repository, 'tests/t107-self-verification-harness.contract.test.ts');
const benchmarkHash = '6efbee04780061f1bb100837369d1e55e5756754007b2b7936f4cc6faa33ea82';
const fixtureHash = '47ed6ab753d32b21a6aee8859cbb627d57f7ce965775440dab3830bc42dc59e8';
assert.equal(sha(readFileSync(benchmark)), benchmarkHash);
assert.equal(sha(readFileSync(fixtureSource)), fixtureHash);
const record = {
  id: mode + '-' + randomUUID(), mode, started_at_utc: new Date().toISOString(),
  node: process.version, executable: process.execPath, platform: process.platform,
  driver_sha256: sha(readFileSync(driver)), benchmark_sha256: benchmarkHash,
  original_fixture_source_sha256: fixtureHash, diagnostic_result: 'NOT_EXECUTED',
  stages: mode.startsWith('launch-') ? [] : ['fixture_construction', 'subject_poison', 'prepare_exact_runtime', 'original_positive_assertions', 'release_exact_runtime'].map(stage => ({ stage, state: 'NOT_EXECUTED' })),
  fixture_commands: [], launch_samples: [], owned_fixtures: [],
  launch_plan: mode.startsWith('launch-') ? Array.from({ length: 10 }, (_, index) => ({ ordinal: index + 1, kind: index < 5 ? 'node_noop' : 'git_version', state: 'NOT_EXECUTED' })) : [],
  observer: { requested: mode === 'observer', children: [], faults: [], restored: null },
  errors: [], original_vitest_case_result: 'NOT_EXECUTED_BY_THIS_DIAGNOSTIC',
  notice: 'Owned independent reproduction only. Source/tests/deadlines unchanged. Direct own-child API lifecycle is not OS or REA process capture. Nested npm descendants and private async streams unobserved. No historical cause, host exoneration, cold-start, observer-overhead or release claim.'
};
let stage = 'outside_case';
const origin = performance.now();
const ownedRoots = new Set();
const errorValue = error => ({ name: error?.name ?? 'Error', message: String(error?.message ?? error), code: error?.code ?? null, status: error?.status ?? null, signal: error?.signal ?? null });
const safeObserver = action => {
  try { action(); } catch (error) { record.observer.faults.push(errorValue(error)); }
};

function observeSpawn(...args) {
  let observation;
  safeObserver(() => {
    observation = { ordinal: record.observer.children.length + 1, phase: stage,
      command: args[0], argv: Array.isArray(args[1]) ? [...args[1]] : null,
      started_ms: performance.now() - origin, close_observed: false, error: null,
      stdout_hash: { state: 'NOT_OBSERVED', reason: 'Private benchmark capture buffer is not exposed; no stream listener added.' },
      stderr_hash: { state: 'NOT_OBSERVED', reason: 'Private benchmark capture buffer is not exposed; no stream listener added.' } };
    record.observer.children.push(observation);
  });
  let child;
  try { child = Reflect.apply(originalSpawn, this, args); }
  catch (error) {
    safeObserver(() => { observation.synchronous_throw = errorValue(error); });
    throw error;
  }
  safeObserver(() => {
    child.once('error', error => safeObserver(() => { observation.error = errorValue(error); }));
    child.once('close', (code, signal) => safeObserver(() => {
      observation.close_observed = true;
      observation.closed_ms = performance.now() - origin;
      observation.wall_ms = observation.closed_ms - observation.started_ms;
      observation.native_code = code;
      observation.native_signal = signal;
    }));
  });
  return child;
}

function capturedSync(file, args, options, destination) {
  const entry = { ordinal: destination.length + 1, stage, file, argv: [...args], state: 'RUNNING' };
  destination.push(entry);
  const started = performance.now();
  try {
    const stdout = childProcess.execFileSync(file, args, options);
    entry.wall_ms = performance.now() - started;
    entry.state = 'RETURNED';
    entry.native_status = 0;
    entry.native_signal = null;
    entry.stdout_sha256 = sha(stdout);
    entry.stdout_encoding = 'utf8';
    entry.stderr = { state: 'NOT_OBSERVED', reason: 'Successful execFileSync exposes stdout only; no extra interception.' };
    return stdout;
  } catch (error) {
    entry.wall_ms = performance.now() - started;
    entry.state = 'THREW';
    entry.error = errorValue(error);
    for (const stream of ['stdout', 'stderr']) {
      entry[stream] = error?.[stream] === undefined || error?.[stream] === null
        ? { state: 'NOT_OBSERVED', reason: 'Native error did not expose this stream.' }
        : { state: 'OBSERVED', sha256: sha(error[stream]) };
    }
    throw error;
  }
}

function git(root, args) {
  assert(ownedRoots.has(root), 'Fixture Git mutation must stay in a freshly owned root');
  return capturedSync('git', ['-C', root, ...args], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }, record.fixture_commands).trim();
}
function commitAll(root, message) {
  git(root, ['add', '-A']);
  git(root, ['commit', '-q', '-m', message]);
  return git(root, ['rev-parse', 'HEAD']);
}
function writeRuntimeFile(root, relativePath, content) {
  const target = join(root, relativePath);
  mkdirSync(dirname(target), { recursive: true });
  writeFileSync(target, content, 'utf8');
}
function createBuildableFixture() {
  const root = mkdtempSync(join(tmpdir(), 'ascout-t107-repo-'));
  assert.notEqual(resolve(root), repository);
  ownedRoots.add(root);
  record.owned_fixtures.push({ root, owner_uuid: randomUUID(), ownership: 'Fresh mkdtemp return; memory journal only, no fixture marker file.' });
  git(root, ['init', '-q']);
  git(root, ['config', 'user.name', 'Ascout T107']);
  git(root, ['config', 'user.email', ['t107', 'example.invalid'].join('@')]);
  writeFileSync(join(root, '.gitignore'), 'dist/\nnode_modules/\ncoverage/\n.ascout/\n', 'utf8');
  writeFileSync(join(root, 'tracked.txt'), 'base\n', 'utf8');
  const base = commitAll(root, 'base');
  writeFileSync(join(root, 'tracked.txt'), 'head\n', 'utf8');
  writeFileSync(join(root, 'package.json'), JSON.stringify({ name: 'ascout-t107-runtime-fixture', version: '1.0.0', private: true, type: 'module', scripts: { build: 'node build.mjs' } }, null, 2) + '\n', 'utf8');
  writeFileSync(join(root, 'package-lock.json'), JSON.stringify({ name: 'ascout-t107-runtime-fixture', version: '1.0.0', lockfileVersion: 3, requires: true, packages: { '': { name: 'ascout-t107-runtime-fixture', version: '1.0.0' } } }, null, 2) + '\n', 'utf8');
  writeRuntimeFile(root, join('specs', '001-changed-code-verification-receipt', 'contracts', 'receipt-v1.schema.json'), '{"fixture":true}\n');
  writeFileSync(join(root, 'build.mjs'), [
    'import { mkdirSync, symlinkSync, writeFileSync } from "node:fs";',
    'import { dirname, join } from "node:path";',
    'const files = {',
    '  "cli.js": "export const fixtureCli = 1;\\n",',
    '  "check.js": "export const fixtureCheck = 1;\\n",',
    '  "receipt/json.js": "export const fixtureJson = 1;\\n",',
    '  "receipt/model.js": "export const fixtureModel = 1;\\n",',
    '  "nested/runtime.js": "export const fixtureNested = 1;\\n",',
    '};',
    'for (const [name, value] of Object.entries(files)) {',
    '  const target = join(process.cwd(), "dist", name);',
    '  mkdirSync(dirname(target), { recursive: true });',
    '  writeFileSync(target, value, "utf8");',
    '}',
  ].join('\n') + '\n', 'utf8');
  const head = commitAll(root, 'head with exact build contract');
  return { root, base, head, headTree: git(root, ['rev-parse', `${head}^{tree}`]) };
}
async function timed(label, action) {
  stage = label;
  const row = record.stages.find(row => row.stage === label);
  assert(row && row.state === 'NOT_EXECUTED');
  row.state = 'RUNNING';
  const started = performance.now();
  try { const value = await action(); row.state = 'RETURNED'; return value; }
  catch (error) { row.state = 'THREW'; row.error = errorValue(error); throw error; }
  finally { row.wall_ms = performance.now() - started; }
}

try {
  if (mode.startsWith('launch-')) {
    stage = mode;
    for (const [file, args] of [[process.execPath, ['-e', '']], ['git', ['--version']]]) {
      for (let sample = 0; sample < 5; sample++) {
        const planned = record.launch_plan[record.launch_samples.length];
        planned.state = 'RUNNING';
        try {
          capturedSync(file, args, { encoding: 'utf8', windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] }, record.launch_samples);
          planned.state = 'RETURNED';
        } catch (error) { planned.state = 'THREW'; planned.error = errorValue(error); throw error; }
      }
    }
    record.diagnostic_result = 'FIXED_LAUNCH_SEQUENCE_RETURNED';
  } else {
    if (mode === 'observer') {
      try {
        childProcess.spawn = observeSpawn;
        syncBuiltinESMExports();
        assert.equal(esmChildProcess.spawn, observeSpawn);
        record.observer.effective_mode = 'ACTIVE';
      } catch (error) {
        record.observer.faults.push(errorValue(error));
        childProcess.spawn = originalSpawn;
        syncBuiltinESMExports();
        assert.equal(esmChildProcess.spawn, originalSpawn);
        record.observer.effective_mode = 'UNSUPPORTED_DISABLED_OUTER_STAGES_ONLY';
      }
    }
    const api = await import(pathToFileURL(benchmark).href);
    const caseStarted = performance.now();
    let fixture;
    let prepared;
    try {
      fixture = await timed('fixture_construction', () => createBuildableFixture());
      record.fixture = fixture;
      await timed('subject_poison', () => {
        writeRuntimeFile(fixture.root, join('node_modules', 'typescript', 'bin', 'tsc'), "throw new Error('subject compiler must not run');\n");
        writeRuntimeFile(fixture.root, join('dist', 'check.js'), 'export const poisoned = true;\n');
      });
      prepared = await timed('prepare_exact_runtime', () => api.prepareExactHeadRuntime(fixture.root, fixture.head, { requireExistingHeadBuild: false }));
      record.api_runtime_root = prepared.repositoryRoot;
      await timed('original_positive_assertions', () => {
        assert.notEqual(prepared.repositoryRoot, fixture.root);
        assert.equal(prepared.headSha, fixture.head);
        assert.equal(prepared.headTreeSha, fixture.headTree);
        assert.equal(readFileSync(join(prepared.runtimeRoot, 'check.js'), 'utf8'), 'export const fixtureCheck = 1;\n');
        writeRuntimeFile(fixture.root, join('dist', 'check.js'), 'export const changedAgain = true;\n');
        assert.equal(readFileSync(join(prepared.runtimeRoot, 'check.js'), 'utf8'), 'export const fixtureCheck = 1;\n');
      });
    } finally {
      if (prepared) {
        await timed('release_exact_runtime', async () => {
          assert(isAbsolute(prepared.repositoryRoot));
          assert.equal(resolve(prepared.repositoryRoot), prepared.repositoryRoot);
          assert.equal(resolve(dirname(prepared.repositoryRoot)).toLowerCase(), resolve(tmpdir()).toLowerCase());
          assert(basename(prepared.repositoryRoot).startsWith('ascout-self-verify-head-'));
          assert.notEqual(resolve(prepared.repositoryRoot), repository);
          await api.releaseExactHeadRuntime(fixture.root, prepared);
        });
      } else record.stages.find(row => row.stage === 'release_exact_runtime').reason = 'No prepared runtime returned by original API.';
      record.case_wall_ms = performance.now() - caseStarted;
      record.original_budget_ms_for_observation_only = 15000;
      record.case_exceeds_original_budget = record.case_wall_ms > 15000;
    }
    record.diagnostic_result = 'INDEPENDENT_POSITIVE_ASSERTIONS_RETURNED';
  }
} catch (error) {
  record.diagnostic_result = 'FAILED';
  record.errors.push(errorValue(error));
  process.exitCode = 1;
} finally {
  try {
    childProcess.spawn = originalSpawn;
    syncBuiltinESMExports();
    record.observer.restored = childProcess.spawn === originalSpawn && esmChildProcess.spawn === originalSpawn;
  } catch (error) { record.observer.restored = false; record.observer.faults.push(errorValue(error)); }
  if (!record.observer.restored) { record.errors.push({ message: 'Original spawn bindings were not restored' }); process.exitCode = 1; }
}

stage = 'post_timing_journal';
for (const owner of record.owned_fixtures) {
  try {
    owner.post_timing_exists = existsSync(owner.root);
    owner.post_timing_realpath = owner.post_timing_exists ? realpathSync(owner.root) : null;
  } catch (error) { owner.post_timing_error = errorValue(error); record.errors.push(errorValue(error)); process.exitCode = 1; }
  owner.retained = true;
}
record.observer.qualification = mode !== 'observer' ? 'NOT_REQUESTED' : record.observer.faults.length || !record.observer.restored || !record.observer.children.length || record.observer.children.some(child => !child.close_observed) ? 'UNQUALIFIED' : 'DIRECT_CHILD_EVENTS_OBSERVED';
record.finished_at_utc = new Date().toISOString();
record.driver_source_unchanged = sha(readFileSync(driver)) === record.driver_sha256;
record.benchmark_source_unchanged = sha(readFileSync(benchmark)) === benchmarkHash;
record.fixture_source_unchanged = sha(readFileSync(fixtureSource)) === fixtureHash;
if (!record.driver_source_unchanged || !record.benchmark_source_unchanged || !record.fixture_source_unchanged) {
  record.errors.push({ message: 'A frozen diagnostic/source binding changed' });
  process.exitCode = 1;
}
const output = join(dirname(driver), 'native-timing-output');
mkdirSync(output, { recursive: true });
const destination = join(output, record.id + '.json');
writeFileSync(destination, JSON.stringify(record, null, 2) + '\n', { flag: 'wx' });
process.stdout.write(JSON.stringify({ record: destination, diagnostic_result: record.diagnostic_result, case_wall_ms: record.case_wall_ms ?? null, observer: record.observer.qualification, exit_code: process.exitCode ?? 0 }) + '\n');
