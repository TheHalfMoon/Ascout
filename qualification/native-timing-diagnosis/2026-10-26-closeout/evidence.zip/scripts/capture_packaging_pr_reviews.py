"""Capture actual submitted reviews, inline threads and public bot limitations."""
import datetime, json, pathlib, subprocess

root = pathlib.Path(__file__).resolve().parent
def gh(*args):
    return json.loads(subprocess.check_output(['rtk', 'proxy', 'gh', *args]))
pr = gh('pr', 'view', '647', '--repo', 'TheHalfMoon/Ascout', '--json', 'headRefOid,baseRefOid,state,isDraft,reviews,comments,mergeable,mergeStateStatus')
assert pr['headRefOid'] == '31e9c88c55cd3d9043ff37096cfd9926d6691063' and pr['baseRefOid'] == 'fe3064afabb18cffbc1d5a8e7f0b5396be7b28c2'
query = 'query { repository(owner:"TheHalfMoon",name:"Ascout") { pullRequest(number:647) { reviewThreads(first:100) { nodes { isResolved isOutdated path line comments(first:100) { nodes { body url } pageInfo { hasNextPage } } } pageInfo { hasNextPage } } } } }'
threads = gh('api', 'graphql', '-f', 'query=' + query)['data']['repository']['pullRequest']['reviewThreads']
assert not threads['pageInfo']['hasNextPage'] and all(not value['comments']['pageInfo']['hasNextPage'] for value in threads['nodes'])
result = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head': pr['headRefOid'], 'base': pr['baseRefOid'], 'state': pr['state'], 'is_draft': pr['isDraft'], 'mergeable': pr['mergeable'], 'merge_state': pr['mergeStateStatus'], 'reviews': [{key: value.get(key) for key in ['state', 'body', 'submittedAt']} for value in pr['reviews']], 'comments': [{key: value.get(key) for key in ['body', 'url', 'createdAt']} for value in pr['comments']], 'threads': threads, 'notice': 'Actual public point-in-time review state. Billing-blocked automated comments are unavailable reviews, not approval; no paid service enabled. Fresh local judgments share OpenAI lineage and are separately bound. No merge authority or release claim.'}
(root / 'packaging-final-pr-review-observation.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
print(json.dumps(result))
